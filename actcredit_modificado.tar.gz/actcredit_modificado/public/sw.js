// sw.js - Service Worker para ActCredit Premium PWA

const CACHE_NAME = 'actcredit-cache-v1'; // Mude a versão se atualizar os arquivos cacheados
const urlsToCache = [
  '/', // Ou './' ou '/index.html' dependendo da sua configuração de servidor
  '/index.html', // Garante que o index.html principal seja cacheado
  '/manifest.json',
  // Principais arquivos JS e CSS
  '/assets/index.js',
  '/assets/index.css',
  // Ícones do manifest
  '/assets/icons/192.png',
  '/assets/icons/512.png',
  '/assets/icons/180.png',
  '/assets/icons/225.png',
  // Página offline
  '/offline.html'
];

// Evento de Instalação: Cacheia os arquivos principais da aplicação
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache and caching initial assets');
        return cache.addAll(urlsToCache);
      })
      .catch(err => {
        console.error('Failed to cache initial assets:', err);
      })
  );
});

// Evento de Ativação: Limpa caches antigos
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) { // Deleta caches com nome diferente
            console.log('Service Worker: deleting old cache', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  return self.clients.claim(); // Torna este SW o controlador ativo imediatamente
});

// Evento de Fetch: Serve arquivos do cache ou busca na rede
self.addEventListener('fetch', (event) => {
  // Ignora requisições que não são GET (ex: POST para APIs)
  if (event.request.method !== 'GET') {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Cache hit - retorna a resposta do cache
        if (response) {
          return response;
        }

        // Não está no cache, busca na rede
        return fetch(event.request).then(
          (networkResponse) => {
            // Verifica se recebemos uma resposta válida
            if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
              return networkResponse;
            }

            // Importante: Clona a resposta. A resposta é um Stream e só pode ser consumida uma vez.
            // Precisamos de uma cópia para o navegador e outra para o cache.
            const responseToCache = networkResponse.clone();

            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, responseToCache);
              });

            return networkResponse;
          }
        ).catch(error => {
          console.error('Fetching failed:', error);
          // Retorna página offline para navegação de páginas HTML
          if (event.request.headers.get('accept').includes('text/html')) {
            return caches.match('/offline.html');
          }
          throw error;
        });
      })
  );
});

// Evento de mensagem para comunicação com a página
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
