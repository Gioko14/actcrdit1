/** @type {import('tailwindcss').Config} */
module.exports = {
	darkMode: ['class'],
	content: [
		'./pages/**/*.{js,jsx}',
		'./components/**/*.{js,jsx}',
		'./app/**/*.{js,jsx}',
		'./src/**/*.{js,jsx}',
	],
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'sm': '640px',
        'md': '768px',
        'lg': '1024px',
        'xl': '1280px',
				'2xl': '1536px',
			},
		},
		extend: {
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				primary: {
					DEFAULT: 'hsl(var(--primary))',
					foreground: 'hsl(var(--primary-foreground))',
				},
				secondary: {
					DEFAULT: 'hsl(var(--secondary))',
					foreground: 'hsl(var(--secondary-foreground))',
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))',
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))',
				},
				accent: {
					DEFAULT: 'hsl(var(--accent))',
					foreground: 'hsl(var(--accent-foreground))',
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))',
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))',
				},
        'dashboard-accent-pink': 'hsl(var(--dashboard-accent-pink))',
        'dashboard-accent-purple': 'hsl(var(--dashboard-accent-purple))',
        'dashboard-accent-blue': 'hsl(var(--dashboard-accent-blue))',
        
        'chart-blue': 'hsl(var(--chart-blue))',
        'chart-purple': 'hsl(var(--chart-purple))',
        'chart-pink': 'hsl(var(--chart-pink))',
        'chart-teal': 'hsl(var(--chart-teal))',
        'chart-orange': 'hsl(var(--chart-orange))',
        'chart-green': 'hsl(var(--chart-green))',
        'chart-gray': 'hsl(var(--chart-gray))',
			},
			borderRadius: {
				lg: 'var(--radius)', 
				xl: 'calc(var(--radius) + 6px)', 
        '2xl': 'calc(var(--radius) + 12px)', 
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)',
			},
			boxShadow: {
        'card-hover': '0 12px 35px -8px hsla(var(--primary), 0.35), 0 8px 18px -6px hsla(var(--primary), 0.25)',
        'card-subtle': '0 3px 10px 0 hsla(var(--foreground), 0.03)',
        'inner-glow': 'inset 0 0 15px 0 hsla(var(--primary), 0.2)',
        'input-focus': '0 0 0 2.5px hsl(var(--ring) / 0.5), 0 0 8px hsl(var(--ring) / 0.2)',
        'neon-glow-primary': '0 0 5px hsl(var(--primary)), 0 0 10px hsl(var(--primary)/0.8), 0 0 15px hsl(var(--primary)/0.6), 0 0 20px hsl(var(--primary)/0.4)',
        'neon-glow-accent': '0 0 5px hsl(var(--accent)), 0 0 10px hsl(var(--accent)/0.8), 0 0 15px hsl(var(--accent)/0.6), 0 0 20px hsl(var(--accent)/0.4)',
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'Roboto', '"Helvetica Neue"', 'Arial', '"Noto Sans"', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"', '"Noto Color Emoji"'],
      },
			keyframes: {
				'accordion-down': {
					from: { height: '0', opacity: '0' },
					to: { height: 'var(--radix-accordion-content-height)', opacity: '1' },
				},
				'accordion-up': {
					from: { height: 'var(--radix-accordion-content-height)', opacity: '1' },
					to: { height: '0', opacity: '0' },
				},
        'pulse-glow': {
          '0%, 100%': { boxShadow: '0 0 8px hsl(var(--primary)/0.4), 0 0 18px hsl(var(--primary)/0.3)' },
          '50%': { boxShadow: '0 0 20px hsl(var(--primary)/0.6), 0 0 35px hsl(var(--primary)/0.4)' },
        },
        'subtle-float': {
          '0%, 100%': { transform: 'translateY(0px) rotate(-0.5deg)' },
          '50%': { transform: 'translateY(-6px) rotate(0.5deg)' }, 
        },
        'aurora-bg': {
          '0%': { backgroundPosition: '0% 50%' },
          '50%': { backgroundPosition: '100% 50%' },
          '100%': { backgroundPosition: '0% 50%' },
        },
        'shimmer': {
          '0%': { backgroundPosition: '-1000px 0' },
          '100%': { backgroundPosition: '1000px 0' },
        }
			},
			animation: {
				'accordion-down': 'accordion-down 0.3s ease-out',
				'accordion-up': 'accordion-up 0.3s ease-out',
        'pulse-glow': 'pulse-glow 2.5s infinite ease-in-out', 
        'subtle-float': 'subtle-float 4s infinite ease-in-out', 
        'aurora-bg': 'aurora-bg 15s ease infinite',
        'shimmer': 'shimmer 2s infinite linear',
			},
		},
	},
	plugins: [require('tailwindcss-animate')],
};