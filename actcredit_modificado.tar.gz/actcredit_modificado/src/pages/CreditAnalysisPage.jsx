import React, { useState } from 'react';
import { Tabs, Card } from 'antd';
import ManualInputForm from '@/components/creditAnalysis/ManualInputForm';
import SimplifiedDocumentUploader from '@/components/upload/SimplifiedDocumentUploader';
import { supabase } from '@/lib/supabaseClient';

/**
 * Página principal de análise de crédito
 * Versão atualizada conforme novos requisitos
 */
const CreditAnalysisPage = () => {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('manual');

  // Manipular submissão de análise (tanto manual quanto PDF)
  const handleAnalysisSubmit = async (analise) => {
    setLoading(true);
    
    try {
      // Inserir análise no banco de dados
      const { data, error } = await supabase
        .from('analises')
        .insert([analise]);
        
      if (error) throw error;
      
      // Redirecionar para página de detalhes da análise
      // Em uma implementação real, redirecionaria para a página de detalhes
      message.success('Análise iniciada com sucesso!');
      
    } catch (error) {
      console.error('Erro ao salvar análise:', error);
      message.error('Erro ao iniciar análise. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">Análise de Crédito</h1>
      
      <Tabs
        activeKey={activeTab}
        onChange={setActiveTab}
        items={[
          {
            key: 'manual',
            label: 'Imputação Manual',
            children: (
              <ManualInputForm 
                onSubmit={handleAnalysisSubmit}
                loading={loading && activeTab === 'manual'}
              />
            ),
          },
          {
            key: 'pdf',
            label: 'Análise via PDF',
            children: (
              <SimplifiedDocumentUploader 
                onSubmit={handleAnalysisSubmit}
                loading={loading && activeTab === 'pdf'}
              />
            ),
          }
        ]}
      />
    </div>
  );
};

export default CreditAnalysisPage;
