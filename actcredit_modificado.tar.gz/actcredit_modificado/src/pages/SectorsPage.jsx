import React from 'react';
import { motion } from 'framer-motion';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Briefcase, PlusCircle, Search, Edit3, BarChart2, TrendingUp, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { useTheme } from '@/contexts/ThemeContext';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const SectorsPage = () => {
  const { theme } = useTheme();
  const primaryColor = theme === 'dark' ? 'hsl(var(--chart-blue))' : 'hsl(var(--primary))';
  const secondaryColor = theme === 'dark' ? 'hsl(var(--chart-purple))' : 'hsl(var(--secondary))';
  const textColor = theme === 'dark' ? 'hsl(var(--foreground))' : 'hsl(var(--muted-foreground))';
  const gridColor = theme === 'dark' ? 'hsla(var(--border), 0.5)' : 'hsla(var(--border), 0.7)';

  const scoreMedioPorSetorData = [
    { name: 'Varejo', scoreMedio: 780, volumeCredito: 1500000 },
    { name: 'Serviços', scoreMedio: 820, volumeCredito: 2200000 },
    { name: 'Indústria', scoreMedio: 710, volumeCredito: 3500000 },
    { name: 'Agronegócio', scoreMedio: 880, volumeCredito: 4100000 },
    { name: 'Tecnologia', scoreMedio: 900, volumeCredito: 1800000 },
    { name: 'Saúde', scoreMedio: 750, volumeCredito: 950000 },
  ];

  const mockSectors = [
    { id: 'SET001', nome: 'Tecnologia da Informação', numEmpresas: 125, riscoMedio: 'Baixo', tendencia: 'Crescimento' },
    { id: 'SET002', nome: 'Varejo Alimentício', numEmpresas: 340, riscoMedio: 'Médio', tendencia: 'Estável' },
    { id: 'SET003', nome: 'Construção Civil', numEmpresas: 88, riscoMedio: 'Alto', tendencia: 'Contração' },
    { id: 'SET004', nome: 'Serviços Financeiros', numEmpresas: 210, riscoMedio: 'Médio', tendencia: 'Crescimento' },
    { id: 'SET005', nome: 'Agronegócio Sustentável', numEmpresas: 150, riscoMedio: 'Baixo', tendencia: 'Expansão Forte' },
  ];

  const getRiskBadgeVariant = (risk) => {
    switch (risk?.toLowerCase()) {
      case 'baixo': return 'success';
      case 'médio': return 'warning';
      case 'alto': return 'destructive';
      default: return 'secondary';
    }
  };

  const getTrendIcon = (trend) => {
    if (trend?.toLowerCase().includes('crescimento') || trend?.toLowerCase().includes('expansão')) return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (trend?.toLowerCase().includes('contração')) return <TrendingUp className="h-4 w-4 text-red-500 transform rotate-180" />;
    return <BarChart2 className="h-4 w-4 text-muted-foreground" />;
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <motion.div variants={itemVariants} className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DashboardCard title="Score Médio por Setor" contentClassName="pt-6">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={scoreMedioPorSetorData} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false}/>
              <XAxis dataKey="name" stroke={textColor} tick={{ fontSize: 11 }} axisLine={{ stroke: gridColor }} tickLine={{ stroke: gridColor }} />
              <YAxis stroke={textColor} tick={{ fontSize: 11 }} axisLine={{ stroke: gridColor }} tickLine={{ stroke: gridColor }} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'hsl(var(--popover))', color: 'hsl(var(--popover-foreground))', borderRadius: 'var(--radius)', border: '1px solid hsl(var(--border))' }}
                cursor={{ fill: 'hsl(var(--primary)/0.05)' }}
                formatter={(value, name) => name === 'scoreMedio' ? value : `R$ ${value.toLocaleString('pt-BR')}`}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} iconSize={10}/>
              <Bar dataKey="scoreMedio" fill="url(#scoreSectorGradient)" radius={[4, 4, 0, 0]} name="Score Médio" barSize={20}/>
               <defs>
                <linearGradient id="scoreSectorGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--chart-blue))" stopOpacity={0.9}/>
                  <stop offset="100%" stopColor="hsl(var(--chart-blue))" stopOpacity={0.4}/>
                </linearGradient>
              </defs>
            </BarChart>
          </ResponsiveContainer>
        </DashboardCard>
        <DashboardCard title="Volume de Crédito por Setor" contentClassName="pt-6">
           <ResponsiveContainer width="100%" height={300}>
            <BarChart data={scoreMedioPorSetorData} margin={{ top: 5, right: 5, left: -5, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false}/>
              <XAxis dataKey="name" stroke={textColor} tick={{ fontSize: 11 }} axisLine={{ stroke: gridColor }} tickLine={{ stroke: gridColor }} />
              <YAxis 
                stroke={textColor} 
                tick={{ fontSize: 11 }} 
                axisLine={{ stroke: gridColor }} 
                tickLine={{ stroke: gridColor }}
                tickFormatter={(value) => `R$${(value/1000000).toFixed(1)}M`}
              />
              <Tooltip 
                contentStyle={{ backgroundColor: 'hsl(var(--popover))', color: 'hsl(var(--popover-foreground))', borderRadius: 'var(--radius)', border: '1px solid hsl(var(--border))' }}
                cursor={{ fill: 'hsl(var(--primary)/0.05)' }}
                formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} iconSize={10}/>
              <Bar dataKey="volumeCredito" fill="url(#volumeSectorGradient)" radius={[4, 4, 0, 0]} name="Volume de Crédito" barSize={20}/>
               <defs>
                <linearGradient id="volumeSectorGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--chart-purple))" stopOpacity={0.9}/>
                  <stop offset="100%" stopColor="hsl(var(--chart-purple))" stopOpacity={0.4}/>
                </linearGradient>
              </defs>
            </BarChart>
          </ResponsiveContainer>
        </DashboardCard>
      </motion.div>

      <motion.div variants={itemVariants}>
        <DashboardCard 
          title="Gerenciamento de Setores"
          description="Cadastre e analise o desempenho dos diferentes setores de mercado."
          contentClassName="pt-6"
        >
          <div className="flex flex-col sm:flex-row gap-3 justify-between items-center mb-6">
            <div className="relative w-full sm:w-auto sm:flex-grow max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                type="text" 
                placeholder="Buscar por nome do setor..." 
                className="pl-10 text-sm w-full"
              />
            </div>
             <Button className="w-full sm:w-auto text-sm">
                <PlusCircle className="mr-2 h-4 w-4" /> Novo Setor
              </Button>
          </div>

          <div className="overflow-x-auto rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/30">
                  <TableHead className="w-[100px] px-3 py-2.5 text-xs">ID</TableHead>
                  <TableHead className="px-3 py-2.5 text-xs">Nome do Setor</TableHead>
                  <TableHead className="text-center px-3 py-2.5 text-xs">Nº Empresas</TableHead>
                  <TableHead className="text-center px-3 py-2.5 text-xs">Risco Médio</TableHead>
                  <TableHead className="text-center px-3 py-2.5 text-xs">Tendência de Mercado</TableHead>
                  <TableHead className="text-right px-3 py-2.5 text-xs">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockSectors.map((sector) => (
                  <TableRow key={sector.id} className="hover:bg-muted/20">
                    <TableCell className="font-medium px-3 py-2 text-xs">{sector.id}</TableCell>
                    <TableCell className="px-3 py-2 text-xs">{sector.nome}</TableCell>
                    <TableCell className="text-center px-3 py-2 text-xs text-muted-foreground">{sector.numEmpresas}</TableCell>
                    <TableCell className="text-center px-3 py-2 text-xs">
                      <Badge variant={getRiskBadgeVariant(sector.riscoMedio)} className="text-xs">
                        {sector.riscoMedio}
                      </Badge>
                    </TableCell>
                    <TableCell className="flex items-center justify-center space-x-1 px-3 py-2 text-xs text-muted-foreground">
                      {getTrendIcon(sector.tendencia)} <span>{sector.tendencia}</span>
                    </TableCell>
                    <TableCell className="text-right px-3 py-2">
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <Edit3 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </DashboardCard>
      </motion.div>
    </motion.div>
  );
};

export default SectorsPage;