import React, { useState } from 'react';
import { motion } from 'framer-motion';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Users, Link as LinkIcon, FileCog, BellDot, SlidersHorizontal, Database, Shield, Palette, Server, FileText as FileTextIcon, Cloud } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';

const UserManagementTab = () => (
  <div className="space-y-4">
    <p className="text-muted-foreground">Gerencie usuários, perfis e permissões de acesso ao sistema.</p>
    <Button><Users className="mr-2 h-4 w-4"/>Adicionar Novo Usuário</Button>
    <div className="border border-dashed p-6 rounded-md text-center text-muted-foreground">
      Lista de usuários e gerenciamento de permissões aparecerão aqui.
    </div>
  </div>
);

const IntegrationSettingsTab = () => {
  const [serasaApiKey, setSerasaApiKey] = useState('');
  const [protheusUrl, setProtheusUrl] = useState('');
  const [zendeskSubdomain, setZendeskSubdomain] = useState('');
  const [awsAccessKey, setAwsAccessKey] = useState('');

  return (
    <div className="space-y-6">
      <p className="text-muted-foreground">Configure conexões com APIs de bureaus de crédito, ERPs, sistemas de suporte e serviços cloud.</p>
      
      <div className="space-y-4 p-4 border rounded-md">
        <h3 className="text-lg font-semibold text-foreground flex items-center"><img src="https://images.unsplash.com/photo-1669023414166-305c38995007?w=50&h=50" alt="Serasa Logo" className="h-6 w-auto mr-2 rounded-sm" /> Integração Serasa Experian</h3>
        <div>
          <Label htmlFor="serasaApiKey">Chave de API Serasa</Label>
          <Input id="serasaApiKey" type="password" value={serasaApiKey} onChange={(e) => setSerasaApiKey(e.target.value)} placeholder="Cole sua chave de API aqui"/>
        </div>
        <Button><LinkIcon className="mr-2 h-4 w-4"/>Salvar Configuração Serasa</Button>
      </div>

      <div className="space-y-4 p-4 border rounded-md">
        <h3 className="text-lg font-semibold text-foreground flex items-center"><img src="https://images.unsplash.com/photo-1678846200362-7b999549b411?w=50&h=50" alt="Protheus Logo" className="h-6 w-auto mr-2 rounded-sm" /> Integração Protheus (TOTVS)</h3>
        <div>
          <Label htmlFor="protheusUrl">URL do Endpoint Protheus</Label>
          <Input id="protheusUrl" value={protheusUrl} onChange={(e) => setProtheusUrl(e.target.value)} placeholder="https://seu-erp.com/api/v1"/>
        </div>
        <Button><LinkIcon className="mr-2 h-4 w-4"/>Salvar Configuração Protheus</Button>
      </div>

      <div className="space-y-4 p-4 border rounded-md">
        <h3 className="text-lg font-semibold text-foreground flex items-center"><img src="https://images.unsplash.com/photo-1624952085149-35897097f9d6?w=50&h=50" alt="Zendesk Logo" className="h-6 w-auto mr-2 rounded-sm" /> Integração Zendesk</h3>
        <div>
          <Label htmlFor="zendeskSubdomain">Subdomínio Zendesk</Label>
          <Input id="zendeskSubdomain" value={zendeskSubdomain} onChange={(e) => setZendeskSubdomain(e.target.value)} placeholder="suaempresa.zendesk.com"/>
        </div>
        <div>
          <Label htmlFor="zendeskApiToken">Token da API Zendesk</Label>
          <Input id="zendeskApiToken" type="password" placeholder="Cole seu token da API aqui"/>
        </div>
        <Button><LinkIcon className="mr-2 h-4 w-4"/>Salvar Configuração Zendesk</Button>
      </div>

      <div className="space-y-4 p-4 border rounded-md">
        <h3 className="text-lg font-semibold text-foreground flex items-center"><Cloud className="mr-2 h-5 w-5"/> Integração AWS (S3 para Documentos)</h3>
        <div>
          <Label htmlFor="awsAccessKey">Access Key ID AWS</Label>
          <Input id="awsAccessKey" value={awsAccessKey} onChange={(e) => setAwsAccessKey(e.target.value)} placeholder="AKIAIOSFODNN7EXAMPLE"/>
        </div>
         <div>
          <Label htmlFor="awsSecretKey">Secret Access Key AWS</Label>
          <Input id="awsSecretKey" type="password" placeholder="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"/>
        </div>
        <div>
          <Label htmlFor="awsS3Bucket">Nome do Bucket S3</Label>
          <Input id="awsS3Bucket" placeholder="meu-bucket-actcred-docs"/>
        </div>
        <Button><LinkIcon className="mr-2 h-4 w-4"/>Salvar Configuração AWS</Button>
      </div>
      
      <div className="border border-dashed p-6 rounded-md text-center text-muted-foreground">
        Mais opções de integração (SPC, Boa Vista, outros ERPs) aparecerão aqui.
      </div>
    </div>
  );
};

const ReportCustomizationTab = () => (
  <div className="space-y-4">
    <p className="text-muted-foreground">Ajuste o layout, seções e informações que aparecem nos relatórios de análise de crédito.</p>
    <div className="flex items-center space-x-2">
      <Switch id="incluir-logo" />
      <Label htmlFor="incluir-logo">Incluir logo da empresa nos relatórios</Label>
    </div>
    <div className="border border-dashed p-6 rounded-md text-center text-muted-foreground">
      Opções para selecionar campos, ordem das seções e branding do relatório.
    </div>
  </div>
);

const AlertSettingsTab = () => (
   <div className="space-y-4">
    <p className="text-muted-foreground">Defina gatilhos e notificações para alertas importantes sobre análises e riscos.</p>
    <div className="flex items-center space-x-2">
      <Switch id="alerta-score-baixo" defaultChecked/>
      <Label htmlFor="alerta-score-baixo">Notificar sobre análises com score abaixo de 500</Label>
    </div>
    <div className="flex items-center space-x-2">
      <Switch id="alerta-vencimento"/>
      <Label htmlFor="alerta-vencimento">Alertar sobre políticas de crédito próximas do vencimento</Label>
    </div>
    <div className="border border-dashed p-6 rounded-md text-center text-muted-foreground">
      Configurações de e-mail, notificações no sistema e webhooks.
    </div>
  </div>
);


const SettingsPage = () => {
  const settingsTabs = [
    { value: "users", name: "Usuários e Permissões", icon: Users, component: <UserManagementTab /> },
    { value: "integrations", name: "Integrações", icon: LinkIcon, component: <IntegrationSettingsTab /> },
    { value: "reports", name: "Personalização de Relatórios", icon: FileCog, component: <ReportCustomizationTab /> },
    { value: "alerts", name: "Configuração de Alertas", icon: BellDot, component: <AlertSettingsTab /> },
    { value: "policies", name: "Políticas de Crédito (Geral)", icon: SlidersHorizontal, component: <div className="text-muted-foreground">Configurações gerais de políticas. Para gerenciamento detalhado, acesse a seção "Políticas de Crédito".</div> },
    { value: "security", name: "Segurança", icon: Shield, component: <div className="text-muted-foreground">Opções de autenticação de dois fatores, políticas de senha, logs de auditoria.</div> },
    { value: "appearance", name: "Aparência", icon: Palette, component: <div className="text-muted-foreground">Personalização de tema, cores e logo (se aplicável globalmente).</div> },
    { value: "system", name: "Sistema", icon: Server, component: <div className="text-muted-foreground">Informações do sistema, backups, atualizações.</div> },
  ];
  const [activeTab, setActiveTab] = useState(settingsTabs[0].value);


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <DashboardCard>
        <div className="mb-6">
            <h2 className="text-2xl font-bold text-foreground">Configurações do Sistema</h2>
            <p className="text-muted-foreground">
            Personalize o ActCred de acordo com as necessidades da sua empresa.
            </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex flex-col md:flex-row gap-6">
          <TabsList className="flex md:flex-col md:w-1/4 h-auto items-start bg-transparent p-0">
            {settingsTabs.map((tab) => (
              <TabsTrigger 
                key={tab.value} 
                value={tab.value} 
                className="w-full justify-start data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-sm px-3 py-2.5 text-sm hover:bg-muted/50"
              >
                <tab.icon className="mr-2 h-5 w-5" /> {tab.name}
              </TabsTrigger>
            ))}
          </TabsList>
          <div className="md:w-3/4">
            {settingsTabs.map((tab) => (
              <TabsContent key={tab.value} value={tab.value} className="mt-0">
                <DashboardCard title={tab.name} className="shadow-none border-0 md:border md:shadow-sm">
                   {tab.component}
                </DashboardCard>
              </TabsContent>
            ))}
          </div>
        </Tabs>
      </DashboardCard>
    </motion.div>
  );
};

export default SettingsPage;