import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Lock, Mail, CreditCard } from 'lucide-react';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false); // Renomeado de isLoading para evitar conflito com o do AuthContext
  const { login, isLoading: isAuthLoading } = useAuth(); // Adicionado isAuthLoading do contexto
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const success = await login({ email, password }); // Adicionado await
      
      if (success) {
        navigate('/'); // Redireciona somente se o login for bem-sucedido
      } else {
        // A mensagem de erro já é tratada dentro da função login no AuthContext
        // mas podemos adicionar uma aqui se quisermos algo específico para a página
      }
    } catch (error) {
      // Este catch pode não ser necessário se o login já trata erros e retorna false
      toast({
        title: "Erro ao fazer login",
        description: error.message || "Ocorreu um erro inesperado. Verifique suas credenciais.",
        variant: "destructive",
        duration: 3000,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDemoLogin = () => {
    setEmail('admin@actcred.com');
    setPassword('admin123');
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <motion.div 
        className="hidden md:flex md:w-1/2 bg-primary p-8 text-white justify-center items-center"
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="max-w-md">
          <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="flex items-center mb-6"
          >
            <CreditCard className="h-10 w-10 mr-2" />
            <h1 className="text-4xl font-bold">ActCred</h1>
          </motion.div>
          
          <motion.h2 
            className="text-2xl font-semibold mb-4"
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            Motor de Análise de Crédito de Ponta
          </motion.h2>
          
          <motion.p
            className="text-lg opacity-90 mb-6"
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
          >
            Transforme sua análise de crédito com inteligência e precisão. 
            O ActCred oferece uma plataforma completa para avaliação de risco, 
            análise de perfil e tomada de decisões.
          </motion.p>
          
          <motion.div
            className="grid grid-cols-2 gap-4"
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-medium mb-1">Análise Avançada</h3>
              <p className="text-sm opacity-80">Algoritmos sofisticados para avaliação precisa</p>
            </div>
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-medium mb-1">Decisões Rápidas</h3>
              <p className="text-sm opacity-80">Resultados em tempo real para agilizar processos</p>
            </div>
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-medium mb-1">Relatórios Detalhados</h3>
              <p className="text-sm opacity-80">Visualização clara de todos os indicadores</p>
            </div>
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-medium mb-1">Segurança Total</h3>
              <p className="text-sm opacity-80">Proteção de dados e conformidade garantidas</p>
            </div>
          </motion.div>
        </div>
      </motion.div>
      
      <motion.div 
        className="flex-1 flex items-center justify-center p-8"
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-2 md:hidden">
              <CreditCard className="h-8 w-8 mr-2 text-primary" />
              <h1 className="text-3xl font-bold text-primary">ActCred</h1>
            </div>
            <h2 className="text-2xl font-bold">Bem-vindo de volta</h2>
            <p className="text-muted-foreground">Faça login para acessar sua conta</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  className="pl-10"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isSubmitting || isAuthLoading}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="password">Senha</Label>
                <a href="#" className="text-sm text-primary hover:underline">
                  Esqueceu a senha?
                </a>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  className="pl-10"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={isSubmitting || isAuthLoading}
                />
              </div>
            </div>
            
            <Button type="submit" className="w-full" disabled={isSubmitting || isAuthLoading}>
              {(isSubmitting || isAuthLoading) ? "Entrando..." : "Entrar"}
            </Button>
            
            <div className="text-center">
              <Button 
                type="button" 
                variant="link" 
                onClick={handleDemoLogin}
                className="text-sm"
                disabled={isSubmitting || isAuthLoading}
              >
                Usar credenciais de demonstração
              </Button>
            </div>
          </form>
          
          <div className="mt-8 text-center text-sm text-muted-foreground">
            <p>
              Credenciais de demonstração: <br />
              Email: admin@actcred.com <br />
              Senha: admin123
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginPage;