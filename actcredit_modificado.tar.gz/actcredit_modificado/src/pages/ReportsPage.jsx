import React from 'react';
import { motion } from 'framer-motion';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { FileCheck2, FileWarning, FileX2, FileText, Download, Filter, Search, BarChartHorizontalBig, TrendingUp, Users, ShieldCheck, ListChecks, ChevronDown, ChevronUp, Eye } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, PieChart, Pie, Cell, CartesianGrid } from 'recharts';
import { useTheme } from '@/contexts/ThemeContext';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const ReportsPage = () => {
  const { theme } = useTheme();
  const primaryColor = theme === 'dark' ? 'hsl(var(--chart-pink))' : 'hsl(var(--primary))';
  const secondaryColor = theme === 'dark' ? 'hsl(var(--chart-purple))' : 'hsl(var(--secondary))';
  const tertiaryColor = theme === 'dark' ? 'hsl(var(--chart-blue))' : 'hsl(var(--ring))';
  const textColor = theme === 'dark' ? 'hsl(var(--foreground))' : 'hsl(var(--muted-foreground))';
  const gridColor = theme === 'dark' ? 'hsla(var(--border), 0.5)' : 'hsla(var(--border), 0.7)';

  const reportStats = [
    { title: "Total de Relatórios Gerados", value: 185, icon: FileText, color: "text-chart-blue" },
    { title: "Relatórios de Aprovação", value: 128, icon: FileCheck2, color: "text-chart-green" },
    { title: "Relatórios com Restrições", value: 35, icon: FileWarning, color: "text-chart-orange" },
    { title: "Relatórios de Rejeição", value: 22, icon: FileX2, color: "text-chart-pink" },
  ];

  const relatoriosPorTipoData = [
    { name: 'Análise Completa PJ', value: 90 },
    { name: 'Análise Simplificada PF', value: 50 },
    { name: 'Relatório de Score', value: 25 },
    { name: 'Consulta de Restrições', value: 20 },
  ];
  const PIE_COLORS = [primaryColor, secondaryColor, tertiaryColor, 'hsl(var(--chart-orange))'];

  const conteudoRelatorio = [
    { id: 1, nome: "Resumo Executivo", icone: BarChartHorizontalBig, desc: "Principais informações e decisão." },
    { id: 2, nome: "Dados Cadastrais", icone: Users, desc: "Informações da empresa/cliente." },
    { id: 3, nome: "Análise Financeira", icone: TrendingUp, desc: "Indicadores de liquidez, endividamento, rentabilidade." },
    { id: 4, nome: "Score ActCred e Serasa", icone: ShieldCheck, desc: "Pontuações e comparativos." },
    { id: 5, nome: "Recomendação Comercial", icone: FileCheck2, desc: "Sugestões e condições." },
    { id: 6, nome: "Parecer Técnico", icone: FileText, desc: "Justificativa da análise." },
  ];

  const generatedReportsData = [
    { id: 'REL001', nome: 'Análise XPTO Ltda', data: '2025-05-20', tipo: 'Completa PJ', status: 'Aprovado', cliente: 'XPTO Ltda' },
    { id: 'REL002', nome: 'Consulta Maria Silva', data: '2025-05-19', tipo: 'Simplificada PF', status: 'Restrição', cliente: 'Maria Silva' },
    { id: 'REL003', nome: 'Score Empresa ABC', data: '2025-05-18', tipo: 'Relatório de Score', status: 'Concluído', cliente: 'Empresa ABC' },
    { id: 'REL004', nome: 'Análise Beta Soluções', data: '2025-05-17', tipo: 'Completa PJ', status: 'Rejeitado', cliente: 'Beta Soluções' },
    { id: 'REL005', nome: 'Consulta João Pereira', data: '2025-05-16', tipo: 'Consulta Restrições', status: 'Concluído', cliente: 'João Pereira' },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.07, delayChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: "spring", stiffness: 100, damping: 12 } }
  };

  const getStatusClass = (status) => {
    switch (status?.toLowerCase()) {
      case 'aprovado': return 'bg-green-500/10 text-green-400';
      case 'restrição': return 'bg-yellow-500/10 text-yellow-400';
      case 'rejeitado': return 'bg-red-500/10 text-red-400';
      default: return 'bg-sky-500/10 text-sky-400';
    }
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <motion.div variants={itemVariants}>
        <DashboardCard title="Visão Geral dos Relatórios" contentClassName="pt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {reportStats.map((stat, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="dashboard-panel p-5 !shadow-lg"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <h3 className="text-xs font-medium uppercase text-muted-foreground tracking-wider">{stat.title}</h3>
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
                <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
              </motion.div>
            ))}
          </div>
        </DashboardCard>
      </motion.div>

      <motion.div variants={itemVariants} className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DashboardCard title="Relatórios Gerados por Tipo" contentClassName="pt-6">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={relatoriosPorTipoData} layout="vertical" margin={{ top: 5, right: 20, left: 5, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} horizontal={false} />
              <XAxis type="number" stroke={textColor} tick={{ fontSize: 11 }} axisLine={{ stroke: gridColor }} tickLine={{ stroke: gridColor }} />
              <YAxis dataKey="name" type="category" stroke={textColor} tick={{ fontSize: 11 }} width={130} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--popover))', color: 'hsl(var(--popover-foreground))', borderRadius: 'var(--radius)', border: '1px solid hsl(var(--border))' }} cursor={{ fill: 'hsl(var(--primary)/0.05)' }}/>
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} iconSize={10}/>
              <Bar dataKey="value" fill="url(#reportsBarGradient)" radius={[0, 4, 4, 0]} name="Quantidade" barSize={20}/>
              <defs>
                <linearGradient id="reportsBarGradient" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="hsl(var(--chart-purple))" stopOpacity={0.5}/>
                  <stop offset="100%" stopColor="hsl(var(--chart-purple))" stopOpacity={0.9}/>
                </linearGradient>
              </defs>
            </BarChart>
          </ResponsiveContainer>
        </DashboardCard>
        
        <DashboardCard title="Distribuição de Decisões nos Relatórios" contentClassName="pt-6">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
              <Pie 
                data={[
                  { name: 'Aprovados', value: reportStats.find(s=>s.title.includes("Aprovação"))?.value || 0 }, 
                  { name: 'Com Restrições', value: reportStats.find(s=>s.title.includes("Restrições"))?.value || 0 },
                  { name: 'Rejeitados', value: reportStats.find(s=>s.title.includes("Rejeição"))?.value || 0 }
                ]} 
                cx="50%" 
                cy="50%" 
                labelLine={false} 
                outerRadius={90} 
                innerRadius={55} 
                fill="#8884d8" 
                dataKey="value" 
                label={({ name, percent, fill }) => <text x={0} y={0} fill={fill} dominantBaseline="central" textAnchor="middle" style={{ fontSize: '10px', fontWeight: 500 }}>{`${name} ${(percent * 100).toFixed(0)}%`}</text>}
              >
                {reportStats.map((stat, index) => (
                  <Cell key={`cell-${index}`} fill={stat.color.startsWith('text-') ? `hsl(var(--${stat.color.substring(5).replace('-','-chart-')}))` : PIE_COLORS[index % PIE_COLORS.length]} stroke="hsl(var(--card))" strokeWidth={3} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--popover))', color: 'hsl(var(--popover-foreground))', borderRadius: 'var(--radius)', border: '1px solid hsl(var(--border))' }}/>
              <Legend wrapperStyle={{fontSize: "11px", paddingTop: "15px"}} iconSize={10} layout="horizontal" verticalAlign="bottom" align="center" />
            </PieChart>
          </ResponsiveContainer>
        </DashboardCard>
      </motion.div>

      <motion.div variants={itemVariants}>
        <DashboardCard title="Conteúdo Detalhado dos Relatórios" contentClassName="pt-6">
          <p className="text-muted-foreground mb-4 text-sm">
            Cada relatório ActCred é abrangente, fornecendo todas as informações necessárias para uma tomada de decisão segura e informada.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {conteudoRelatorio.map(item => (
              <div key={item.id} className="bg-card p-3.5 rounded-md border border-border/60 flex items-start space-x-2.5 hover:shadow-md hover:border-primary/30 transition-all">
                <item.icone className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                <div>
                  <h4 className="font-semibold text-foreground text-sm">{item.nome}</h4>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </DashboardCard>
      </motion.div>
      
      <motion.div variants={itemVariants}>
        <DashboardCard title="Lista de Relatórios Gerados" contentClassName="pt-6">
          <div className="flex flex-col sm:flex-row gap-3 justify-between items-center mb-4">
            <div className="flex items-center space-x-2 flex-grow w-full sm:w-auto">
              <Search className="h-5 w-5 text-muted-foreground absolute ml-3 pointer-events-none" />
              <Input type="text" placeholder="Buscar por nome, ID, cliente..." className="pl-10 text-sm w-full sm:w-72" />
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button variant="outline" size="sm" className="w-full sm:w-auto">
                <Filter className="mr-1.5 h-3.5 w-3.5" /> Filtros Avançados
              </Button>
              <Button size="sm" className="w-full sm:w-auto">
                <Download className="mr-1.5 h-3.5 w-3.5" /> Exportar Lista
              </Button>
            </div>
          </div>
          
          <div className="overflow-x-auto rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/30">
                  <TableHead className="w-[100px] px-3 py-2.5 text-xs">ID</TableHead>
                  <TableHead className="px-3 py-2.5 text-xs">Nome do Relatório</TableHead>
                  <TableHead className="px-3 py-2.5 text-xs">Cliente</TableHead>
                  <TableHead className="px-3 py-2.5 text-xs">Data</TableHead>
                  <TableHead className="px-3 py-2.5 text-xs">Tipo</TableHead>
                  <TableHead className="text-center px-3 py-2.5 text-xs">Status</TableHead>
                  <TableHead className="text-right px-3 py-2.5 text-xs">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {generatedReportsData.map((report) => (
                  <TableRow key={report.id} className="hover:bg-muted/20">
                    <TableCell className="font-medium px-3 py-2 text-xs">{report.id}</TableCell>
                    <TableCell className="px-3 py-2 text-xs">{report.nome}</TableCell>
                    <TableCell className="px-3 py-2 text-xs text-muted-foreground">{report.cliente}</TableCell>
                    <TableCell className="px-3 py-2 text-xs text-muted-foreground">{report.data}</TableCell>
                    <TableCell className="px-3 py-2 text-xs text-muted-foreground">{report.tipo}</TableCell>
                    <TableCell className="text-center px-3 py-2 text-xs">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${getStatusClass(report.status)}`}>
                        {report.status}
                      </span>
                    </TableCell>
                    <TableCell className="text-right px-3 py-2">
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      </Button>
                       <Button variant="ghost" size="icon" className="h-7 w-7">
                        <Download className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
           <div className="flex justify-between items-center mt-4 text-xs text-muted-foreground">
            <p>Mostrando {generatedReportsData.length} de {generatedReportsData.length} relatórios</p>
            <div className="flex gap-1">
              <Button variant="outline" size="sm" className="h-7 text-xs">Anterior</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs">Próximo</Button>
            </div>
          </div>
        </DashboardCard>
      </motion.div>
    </motion.div>
  );
};

export default ReportsPage;