import React from 'react';
import { motion } from 'framer-motion';
import { Filter, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Import refactored sections
import KpiSection from '@/components/dashboard/sections/KpiSection';
import RegionalApprovalChart from '@/components/dashboard/sections/RegionalApprovalChart';
import ApprovalTrendsChart from '@/components/dashboard/sections/ApprovalTrendsChart';
import SectorDistributionChart from '@/components/dashboard/sections/SectorDistributionChart';
import AnalysisTypeDistributionChart from '@/components/dashboard/sections/AnalysisTypeDistributionChart';
import ScoreComparisonChart from '@/components/dashboard/sections/ScoreComparisonChart';
import TotalValueSection from '@/components/dashboard/sections/TotalValueSection';
import RegionalAnalysisTableSection from '@/components/dashboard/sections/RegionalAnalysisTableSection';


const Dashboard = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.15 }
    }
  };

  const itemVariants = {
    hidden: { y: 25, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100, damping: 15 } }
  };

  return (
    <motion.div 
      className="space-y-6 md:space-y-8"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" variants={itemVariants}>
        <div>
          <h1 className="text-3xl font-bold text-foreground tracking-tight">Dashboard Analítico</h1>
          <p className="text-sm text-muted-foreground mt-1">Principais indicadores e métricas do sistema ActCredit.</p>
        </div>
        <div className="flex items-center gap-2.5">
          <Button variant="outline" size="sm" className="bg-card hover:bg-muted/80 dark:hover:bg-muted/50 text-xs">
            <Filter className="h-3.5 w-3.5 mr-2" />
            Filtrar Período
            <ChevronDown className="h-3.5 w-3.5 ml-1.5 text-muted-foreground/70" />
          </Button>
           <Select defaultValue="mes_atual">
            <SelectTrigger className="w-[130px] h-9 text-xs bg-card">
              <SelectValue placeholder="Este Mês" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hoje">Hoje</SelectItem>
              <SelectItem value="ult_7_dias">Últimos 7 dias</SelectItem>
              <SelectItem value="mes_atual">Este Mês</SelectItem>
              <SelectItem value="ult_30_dias">Últimos 30 dias</SelectItem>
              <SelectItem value="trimestre_atual">Este Trimestre</SelectItem>
              <SelectItem value="ano_atual">Este Ano</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </motion.div>

      <KpiSection />

      <motion.div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8" variants={itemVariants}>
        <RegionalApprovalChart />
        <ApprovalTrendsChart />
      </motion.div>

      <motion.div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8" variants={itemVariants}>
        <SectorDistributionChart />
        <AnalysisTypeDistributionChart />
      </motion.div>

      <motion.div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8" variants={itemVariants}>
        <ScoreComparisonChart />
        <TotalValueSection />
      </motion.div>

      <motion.div variants={itemVariants}>
        <RegionalAnalysisTableSection />
      </motion.div>

    </motion.div>
  );
};

export default Dashboard;