import React, { useState } from 'react';
import { motion } from 'framer-motion';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Building, PlusCircle, Search, Filter, Edit3, Trash2, Eye, ChevronDown, ChevronUp } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const CompaniesPage = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const mockCompanies = [
    { id: 'EMP001', nome: 'Soluções Inovadoras Ltda.', cnpj: '12.345.678/0001-99', score: 850, status: 'Ativo', setor: 'Tecnologia', ultimaAnalise: '2025-05-15' },
    { id: 'EMP002', nome: 'Comércio Varejista Delta', cnpj: '98.765.432/0001-11', score: 720, status: 'Ativo', setor: 'Varejo', ultimaAnalise: '2025-04-20' },
    { id: 'EMP003', nome: 'Indústria Pesada Alfa SA', cnpj: '45.678.123/0001-50', score: 680, status: 'Bloqueado', setor: 'Indústria', ultimaAnalise: '2025-03-10' },
    { id: 'EMP004', nome: 'Serviços Rápidos Express', cnpj: '23.456.789/0001-00', score: 790, status: 'Pendente', setor: 'Serviços', ultimaAnalise: '2025-05-01' },
    { id: 'EMP005', nome: 'Agro Forte Brasil', cnpj: '10.203.040/0001-05', score: 910, status: 'Ativo', setor: 'Agronegócio', ultimaAnalise: '2025-05-18' },
  ];

  const filteredCompanies = mockCompanies.filter(company => 
    company.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    company.cnpj.includes(searchTerm)
  );

  const getStatusBadgeVariant = (status) => {
    switch (status?.toLowerCase()) {
      case 'ativo': return 'success';
      case 'bloqueado': return 'destructive';
      case 'pendente': return 'warning';
      default: return 'secondary';
    }
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <motion.div variants={itemVariants}>
        <DashboardCard 
          title="Gerenciamento de Empresas" 
          description="Visualize e gerencie o cadastro completo das empresas."
          contentClassName="pt-6"
        >
          <div className="flex flex-col sm:flex-row gap-3 justify-between items-center mb-6">
            <div className="relative w-full sm:w-auto sm:flex-grow max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                type="text" 
                placeholder="Buscar por nome ou CNPJ..." 
                className="pl-10 text-sm w-full"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button variant="outline" className="w-full sm:w-auto text-sm">
                <Filter className="mr-2 h-4 w-4" /> Filtros
              </Button>
              <Button className="w-full sm:w-auto text-sm">
                <PlusCircle className="mr-2 h-4 w-4" /> Nova Empresa
              </Button>
            </div>
          </div>

          <div className="overflow-x-auto rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/30">
                  <TableHead className="w-[100px] px-3 py-2.5 text-xs">ID</TableHead>
                  <TableHead className="px-3 py-2.5 text-xs">Nome da Empresa</TableHead>
                  <TableHead className="px-3 py-2.5 text-xs">CNPJ</TableHead>
                  <TableHead className="text-center px-3 py-2.5 text-xs">Score</TableHead>
                  <TableHead className="text-center px-3 py-2.5 text-xs">Status</TableHead>
                  <TableHead className="px-3 py-2.5 text-xs">Setor</TableHead>
                  <TableHead className="text-center px-3 py-2.5 text-xs">Últ. Análise</TableHead>
                  <TableHead className="text-right px-3 py-2.5 text-xs">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCompanies.length > 0 ? filteredCompanies.map((company) => (
                  <TableRow key={company.id} className="hover:bg-muted/20">
                    <TableCell className="font-medium px-3 py-2 text-xs">{company.id}</TableCell>
                    <TableCell className="px-3 py-2 text-xs">{company.nome}</TableCell>
                    <TableCell className="px-3 py-2 text-xs text-muted-foreground">{company.cnpj}</TableCell>
                    <TableCell className="text-center px-3 py-2 text-xs font-semibold text-primary">{company.score}</TableCell>
                    <TableCell className="text-center px-3 py-2 text-xs">
                      <Badge variant={getStatusBadgeVariant(company.status)} className="text-xs">
                        {company.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="px-3 py-2 text-xs text-muted-foreground">{company.setor}</TableCell>
                    <TableCell className="text-center px-3 py-2 text-xs text-muted-foreground">{company.ultimaAnalise}</TableCell>
                    <TableCell className="text-right px-3 py-2">
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <Edit3 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive/70 hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={8} className="h-24 text-center text-muted-foreground">
                      Nenhuma empresa encontrada.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
           <div className="flex justify-between items-center mt-4 text-xs text-muted-foreground">
            <p>Mostrando {filteredCompanies.length} de {mockCompanies.length} empresas</p>
            <div className="flex gap-1">
              <Button variant="outline" size="sm" className="h-7 text-xs">Anterior</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs">Próximo</Button>
            </div>
          </div>
        </DashboardCard>
      </motion.div>
    </motion.div>
  );
};

export default CompaniesPage;