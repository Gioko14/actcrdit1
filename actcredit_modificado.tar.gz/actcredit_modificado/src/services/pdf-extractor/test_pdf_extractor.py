# Testes automatizados para o extrator de PDF
# Valida o fluxo completo de extração e processamento

import os
import sys
import json
import time
import logging
import unittest
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('pdf_extractor_tests')

# Caminho para o PDF de teste
TEST_PDF_PATH = '/home/ubuntu/upload/Cadastro_Completo_Censi.pdf'

class PDFExtractorTests(unittest.TestCase):
    """Testes para o extrator de PDF"""
    
    def setUp(self):
        """Configuração inicial para os testes"""
        logger.info("Iniciando testes do extrator de PDF")
        
        # Verificar se o arquivo de teste existe
        self.assertTrue(os.path.exists(TEST_PDF_PATH), f"Arquivo de teste não encontrado: {TEST_PDF_PATH}")
        
        # Importar bibliotecas necessárias
        try:
            import pytesseract
            import pdf2image
            import numpy as np
            import cv2
            logger.info("Bibliotecas básicas importadas com sucesso")
        except ImportError as e:
            self.fail(f"Falha ao importar bibliotecas necessárias: {str(e)}")
    
    def test_pdf_to_images(self):
        """Testa a conversão de PDF para imagens"""
        logger.info("Testando conversão de PDF para imagens")
        
        try:
            from pdf2image import convert_from_path
            
            # Converter primeira página do PDF para imagem
            images = convert_from_path(TEST_PDF_PATH, first_page=1, last_page=1)
            
            # Verificar se a conversão foi bem-sucedida
            self.assertIsNotNone(images, "Falha ao converter PDF para imagens")
            self.assertTrue(len(images) > 0, "Nenhuma imagem extraída do PDF")
            
            # Verificar propriedades da imagem
            image = images[0]
            self.assertIsNotNone(image.width, "Largura da imagem não disponível")
            self.assertIsNotNone(image.height, "Altura da imagem não disponível")
            
            logger.info(f"PDF convertido para imagem com sucesso: {image.width}x{image.height}")
        except Exception as e:
            self.fail(f"Erro ao converter PDF para imagens: {str(e)}")
    
    def test_tesseract_ocr(self):
        """Testa a extração de texto com Tesseract OCR"""
        logger.info("Testando extração de texto com Tesseract OCR")
        
        try:
            import pytesseract
            from pdf2image import convert_from_path
            
            # Converter primeira página do PDF para imagem
            images = convert_from_path(TEST_PDF_PATH, first_page=1, last_page=1)
            image = images[0]
            
            # Extrair texto com Tesseract
            text = pytesseract.image_to_string(image, lang='por')
            
            # Verificar se o texto foi extraído
            self.assertIsNotNone(text, "Falha ao extrair texto com Tesseract")
            self.assertTrue(len(text) > 0, "Nenhum texto extraído com Tesseract")
            
            # Verificar se o texto contém palavras-chave esperadas
            keywords = ["CNPJ", "CPF", "CADASTRO", "EMPRESA", "ENDEREÇO"]
            found_keywords = [keyword for keyword in keywords if keyword in text.upper()]
            
            logger.info(f"Palavras-chave encontradas: {found_keywords}")
            logger.info(f"Texto extraído (primeiros 200 caracteres): {text[:200]}...")
            
            # Deve encontrar pelo menos algumas das palavras-chave
            self.assertTrue(len(found_keywords) > 0, "Nenhuma palavra-chave esperada encontrada no texto")
        except Exception as e:
            self.fail(f"Erro ao extrair texto com Tesseract: {str(e)}")
    
    def test_extract_structured_data(self):
        """Testa a extração de dados estruturados do PDF"""
        logger.info("Testando extração de dados estruturados")
        
        try:
            import pytesseract
            from pdf2image import convert_from_path
            import re
            
            # Converter primeira página do PDF para imagem
            images = convert_from_path(TEST_PDF_PATH, first_page=1, last_page=1)
            image = images[0]
            
            # Extrair texto com Tesseract
            text = pytesseract.image_to_string(image, lang='por')
            
            # Tentar extrair CNPJ
            cnpj_pattern = r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}'
            cnpj_matches = re.findall(cnpj_pattern, text)
            
            # Tentar extrair CPF
            cpf_pattern = r'\d{3}\.\d{3}\.\d{3}-\d{2}'
            cpf_matches = re.findall(cpf_pattern, text)
            
            # Tentar extrair valores monetários
            money_pattern = r'R\$\s*[\d\.,]+'
            money_matches = re.findall(money_pattern, text)
            
            # Tentar extrair datas
            date_pattern = r'\d{2}/\d{2}/\d{4}'
            date_matches = re.findall(date_pattern, text)
            
            # Registrar resultados
            logger.info(f"CNPJs encontrados: {cnpj_matches}")
            logger.info(f"CPFs encontrados: {cpf_matches}")
            logger.info(f"Valores monetários encontrados: {money_matches}")
            logger.info(f"Datas encontradas: {date_matches}")
            
            # Criar estrutura de dados com as informações extraídas
            extracted_data = {
                "cnpjs": cnpj_matches,
                "cpfs": cpf_matches,
                "valores": money_matches,
                "datas": date_matches,
                "texto_completo": text
            }
            
            # Salvar dados extraídos em arquivo JSON para análise
            output_path = '/home/ubuntu/extracted_data.json'
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(extracted_data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"Dados extraídos salvos em: {output_path}")
        except Exception as e:
            self.fail(f"Erro ao extrair dados estruturados: {str(e)}")
    
    def test_paddle_ocr(self):
        """Testa a extração de texto com PaddleOCR (se disponível)"""
        logger.info("Testando extração com PaddleOCR")
        
        try:
            # Tentar importar PaddleOCR
            try:
                from paddleocr import PaddleOCR
                paddle_available = True
            except ImportError:
                logger.warning("PaddleOCR não está disponível, pulando este teste")
                paddle_available = False
                return
            
            if paddle_available:
                # Inicializar PaddleOCR com parâmetro atualizado
                ocr = PaddleOCR(use_textline_orientation=True, lang='pt')
                
                # Executar OCR no arquivo PDF (sem o parâmetro cls)
                result = ocr.predict(TEST_PDF_PATH)
                
                # Verificar resultados
                self.assertIsNotNone(result, "Falha ao extrair texto com PaddleOCR")
                
                # Extrair texto dos resultados
                extracted_text = []
                for page in result:
                    if page:
                        for line in page:
                            extracted_text.append(line[1][0])  # Texto reconhecido
                
                # Verificar se o texto foi extraído
                self.assertTrue(len(extracted_text) > 0, "Nenhum texto extraído com PaddleOCR")
                
                # Registrar resultados
                logger.info(f"PaddleOCR extraiu {len(extracted_text)} linhas de texto")
                logger.info(f"Amostra de texto (primeiras 5 linhas): {extracted_text[:5]}")
                
                # Salvar resultados em arquivo JSON
                paddle_output = '/home/ubuntu/paddle_extracted_data.json'
                with open(paddle_output, 'w', encoding='utf-8') as f:
                    json.dump(extracted_text, f, ensure_ascii=False, indent=2)
                
                logger.info(f"Dados do PaddleOCR salvos em: {paddle_output}")
        except Exception as e:
            logger.warning(f"Erro ao testar PaddleOCR: {str(e)}")
            # Não falhar o teste, pois PaddleOCR pode não estar disponível
    
    def test_full_extraction_pipeline(self):
        """Testa o pipeline completo de extração"""
        logger.info("Testando pipeline completo de extração")
        
        try:
            # Simular pipeline completo
            from pdf2image import convert_from_path
            import pytesseract
            import re
            import cv2
            import numpy as np
            
            # 1. Converter PDF para imagens
            images = convert_from_path(TEST_PDF_PATH)
            logger.info(f"PDF convertido em {len(images)} páginas")
            
            all_text = []
            structured_data = {
                "cnpjs": [],
                "cpfs": [],
                "valores": [],
                "datas": [],
                "telefones": [],
                "emails": []
            }
            
            # 2. Processar cada página
            for i, image in enumerate(images):
                logger.info(f"Processando página {i+1}/{len(images)}")
                
                # Converter para formato numpy/OpenCV
                img_np = np.array(image)
                
                # Pré-processamento da imagem
                gray = cv2.cvtColor(img_np, cv2.COLOR_RGB2GRAY)
                _, binary = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY_INV)
                
                # Extrair texto
                text = pytesseract.image_to_string(gray, lang='por')
                all_text.append(text)
                
                # Extrair dados estruturados
                # CNPJ
                cnpj_pattern = r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}'
                cnpjs = re.findall(cnpj_pattern, text)
                structured_data["cnpjs"].extend(cnpjs)
                
                # CPF
                cpf_pattern = r'\d{3}\.\d{3}\.\d{3}-\d{2}'
                cpfs = re.findall(cpf_pattern, text)
                structured_data["cpfs"].extend(cpfs)
                
                # Valores monetários
                money_pattern = r'R\$\s*[\d\.,]+'
                valores = re.findall(money_pattern, text)
                structured_data["valores"].extend(valores)
                
                # Datas
                date_pattern = r'\d{2}/\d{2}/\d{4}'
                datas = re.findall(date_pattern, text)
                structured_data["datas"].extend(datas)
                
                # Telefones
                phone_pattern = r'\(\d{2}\)\s*\d{4,5}-\d{4}'
                telefones = re.findall(phone_pattern, text)
                structured_data["telefones"].extend(telefones)
                
                # Emails
                email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
                emails = re.findall(email_pattern, text)
                structured_data["emails"].extend(emails)
            
            # 3. Consolidar resultados
            full_text = "\n\n".join(all_text)
            
            # 4. Salvar resultados
            pipeline_output = '/home/ubuntu/full_extraction_results.json'
            with open(pipeline_output, 'w', encoding='utf-8') as f:
                json.dump({
                    "texto_completo": full_text,
                    "dados_estruturados": structured_data
                }, f, ensure_ascii=False, indent=2)
            
            logger.info(f"Resultados do pipeline completo salvos em: {pipeline_output}")
            
            # Verificar se dados importantes foram extraídos
            self.assertTrue(len(structured_data["cnpjs"]) > 0 or len(structured_data["cpfs"]) > 0, 
                           "Nenhum CNPJ ou CPF encontrado no documento")
        except Exception as e:
            self.fail(f"Erro no pipeline completo de extração: {str(e)}")

if __name__ == '__main__':
    unittest.main()
