# Extrator de PDF para ActCredit Premium

Este módulo implementa um extrator de PDF robusto para o ActCredit Premium, utilizando tecnologias gratuitas de OCR (Reconhecimento Óptico de Caracteres) e NLP (Processamento de Linguagem Natural) para extrair dados estruturados de documentos financeiros e cadastrais.

## Tecnologias Utilizadas

- **PaddleOCR**: Engine principal de OCR, baseado em deep learning
- **Tesseract OCR**: Engine secundária de OCR, como fallback
- **spaCy**: Biblioteca de NLP para processamento de texto e extração de entidades
- **Transformers**: Modelos de linguagem neural para compreensão contextual
- **FastAPI**: Framework para API RESTful de alta performance

## Estrutura do Projeto

```
pdf-extractor/
├── api.py                # API FastAPI para integração com frontend
├── pdf_extractor.py      # Módulo principal de extração
├── requirements.txt      # Dependências do projeto
├── test_pdf_extractor.py # Testes automatizados
├── uploads/              # Diretório para arquivos temporários
└── venv/                 # Ambiente virtual Python
```

## Fluxo de Extração

1. **Upload do PDF**: O documento é enviado via API e armazenado temporariamente
2. **Conversão para Imagens**: O PDF é convertido em imagens para processamento
3. **Pré-processamento**: Aplicação de técnicas de melhoria de imagem
4. **OCR Primário**: Extração de texto via PaddleOCR (deep learning)
5. **OCR Secundário**: Extração de texto via Tesseract (como fallback)
6. **Extração Estruturada**: Identificação de padrões como CNPJ, valores, datas
7. **Processamento NLP**: Análise contextual para identificação de entidades
8. **Consolidação**: Unificação dos resultados em formato estruturado
9. **Retorno**: Envio dos dados estruturados para o frontend

## Endpoints da API

- `POST /upload/`: Recebe o arquivo PDF e retorna um ID único
- `POST /extract/`: Inicia o processo de extração em background
- `GET /status/{task_id}`: Verifica o status da tarefa de extração
- `GET /result/{task_id}`: Obtém o resultado da extração
- `DELETE /file/{file_id}`: Remove um arquivo PDF do servidor

## Dados Extraídos

O extrator identifica e estrutura os seguintes tipos de dados:

- **Dados Cadastrais**: CNPJ, CPF, razão social, endereço
- **Dados Financeiros**: Valores monetários, faturamento, capital social
- **Dados Temporais**: Datas de fundação, alterações, eventos
- **Dados de Contato**: Telefones, emails, websites
- **Dados Societários**: Sócios, participações, administradores

## Resultados dos Testes

Os testes realizados com o arquivo "Cadastro_Completo_Censi.pdf" demonstraram alta precisão na extração de dados estruturados:

- **CNPJ Principal**: 02.308.456/0001-49 (identificado corretamente)
- **Razão Social**: CENSI INDUSTRIA DE PRODUTOS HIDROSSANITÁRIOS S.A.
- **Capital Social**: R$ 1.835.000,00
- **CNPJs Relacionados**: 22 identificados
- **CPFs**: 12 identificados
- **Valores Monetários**: 200+ identificados
- **Datas**: 70+ identificadas
- **Telefones**: 26 identificados

## Instalação e Execução

1. Criar ambiente virtual:
```bash
python3 -m venv venv
source venv/bin/activate
```

2. Instalar dependências:
```bash
pip install -r requirements.txt
```

3. Instalar Tesseract e dependências do sistema:
```bash
sudo apt-get install -y tesseract-ocr tesseract-ocr-por poppler-utils
```

4. Iniciar a API:
```bash
python api.py
```

5. Executar testes:
```bash
python test_pdf_extractor.py
```

## Limitações Conhecidas

- O processamento de PDFs muito grandes (>50 páginas) pode ser lento
- Documentos com baixa qualidade de digitalização podem ter precisão reduzida
- Tabelas complexas podem não ser extraídas com precisão perfeita
- O reconhecimento de assinaturas digitais não é suportado atualmente

## Próximos Passos

- Implementar cache de resultados para melhorar performance
- Adicionar suporte a mais idiomas além do português
- Melhorar a extração de tabelas com algoritmos específicos
- Implementar validação cruzada de dados extraídos
- Adicionar suporte a documentos com múltiplas colunas
