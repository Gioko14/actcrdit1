"""
Módulo principal do extrator de PDF com PaddleOCR e Tesseract
Implementa funções para extração de texto, dados estruturados e análise de documentos
"""

import os
import re
import cv2
import json
import time
import logging
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("pdf_extractor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("pdf_extractor")

# Importar bibliotecas de OCR e processamento de imagem
try:
    import pytesseract
    from pdf2image import convert_from_path
    import cv2
    import numpy as np
    logger.info("Bibliotecas básicas importadas com sucesso")
except ImportError as e:
    logger.error(f"Falha ao importar bibliotecas necessárias: {str(e)}")
    raise

# Verificar disponibilidade do PaddleOCR
try:
    from paddleocr import PaddleOCR
    paddle_available = True
    logger.info("PaddleOCR disponível e importado com sucesso")
except ImportError:
    paddle_available = False
    logger.warning("PaddleOCR não está disponível, usando apenas Tesseract")

# Diretório para arquivos temporários
TEMP_DIR = Path("./temp")
TEMP_DIR.mkdir(exist_ok=True)

def extract_text_from_pdf(pdf_path: str) -> str:
    """
    Extrai texto de um arquivo PDF usando Tesseract OCR
    
    Args:
        pdf_path: Caminho para o arquivo PDF
        
    Returns:
        Texto extraído do PDF
    """
    logger.info(f"Extraindo texto do PDF: {pdf_path}")
    
    try:
        # Converter PDF para imagens
        images = convert_from_path(pdf_path)
        logger.info(f"PDF convertido em {len(images)} páginas")
        
        all_text = []
        
        # Processar cada página
        for i, image in enumerate(images):
            logger.info(f"Processando página {i+1}/{len(images)}")
            
            # Converter para formato numpy/OpenCV
            img_np = np.array(image)
            
            # Pré-processamento da imagem
            gray = cv2.cvtColor(img_np, cv2.COLOR_RGB2GRAY)
            
            # Aplicar threshold adaptativo para melhorar contraste
            adaptive_threshold = cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
            )
            
            # Extrair texto com Tesseract
            text = pytesseract.image_to_string(adaptive_threshold, lang='por')
            all_text.append(text)
            
            logger.debug(f"Texto extraído da página {i+1} (primeiros 100 caracteres): {text[:100]}...")
        
        # Consolidar texto de todas as páginas
        full_text = "\n\n".join(all_text)
        logger.info(f"Extração de texto concluída, {len(full_text)} caracteres extraídos")
        
        return full_text
    
    except Exception as e:
        logger.error(f"Erro ao extrair texto do PDF: {str(e)}")
        raise

def process_pdf_with_tesseract(pdf_path: str) -> Dict[str, Any]:
    """
    Processa um PDF com Tesseract OCR, incluindo pré-processamento avançado
    
    Args:
        pdf_path: Caminho para o arquivo PDF
        
    Returns:
        Dicionário com resultados do processamento
    """
    logger.info(f"Processando PDF com Tesseract: {pdf_path}")
    
    try:
        # Converter PDF para imagens
        images = convert_from_path(pdf_path)
        
        results = {
            "pages": [],
            "text": "",
            "metadata": {
                "num_pages": len(images),
                "processing_time": 0
            }
        }
        
        start_time = time.time()
        all_text = []
        
        # Processar cada página
        for i, image in enumerate(images):
            logger.info(f"Processando página {i+1}/{len(images)} com Tesseract")
            
            # Converter para formato numpy/OpenCV
            img_np = np.array(image)
            
            # Aplicar diferentes técnicas de pré-processamento
            # 1. Escala de cinza
            gray = cv2.cvtColor(img_np, cv2.COLOR_RGB2GRAY)
            
            # 2. Redução de ruído
            denoised = cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)
            
            # 3. Threshold adaptativo
            adaptive_threshold = cv2.adaptiveThreshold(
                denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
            )
            
            # 4. Dilatação para melhorar a conectividade dos caracteres
            kernel = np.ones((1, 1), np.uint8)
            dilated = cv2.dilate(adaptive_threshold, kernel, iterations=1)
            
            # Extrair texto com Tesseract usando diferentes configurações
            # Configuração padrão
            text_default = pytesseract.image_to_string(gray, lang='por')
            
            # Configuração otimizada para precisão
            text_optimized = pytesseract.image_to_string(
                dilated, 
                lang='por',
                config='--psm 1 --oem 3'
            )
            
            # Escolher o melhor resultado (o mais longo geralmente tem mais conteúdo)
            text = text_default if len(text_default) > len(text_optimized) else text_optimized
            all_text.append(text)
            
            # Extrair dados estruturados da página
            page_data = extract_structured_data_from_text(text)
            
            # Adicionar resultados da página
            results["pages"].append({
                "page_num": i+1,
                "text": text,
                "structured_data": page_data
            })
        
        # Consolidar texto de todas as páginas
        full_text = "\n\n".join(all_text)
        results["text"] = full_text
        
        # Extrair dados estruturados do texto completo
        results["structured_data"] = extract_structured_data_from_text(full_text)
        
        # Calcular tempo de processamento
        processing_time = time.time() - start_time
        results["metadata"]["processing_time"] = processing_time
        
        logger.info(f"Processamento com Tesseract concluído em {processing_time:.2f} segundos")
        
        return results
    
    except Exception as e:
        logger.error(f"Erro ao processar PDF com Tesseract: {str(e)}")
        raise

def process_pdf_with_paddle(pdf_path: str) -> Dict[str, Any]:
    """
    Processa um PDF com PaddleOCR
    
    Args:
        pdf_path: Caminho para o arquivo PDF
        
    Returns:
        Dicionário com resultados do processamento
    """
    if not paddle_available:
        logger.warning("PaddleOCR não está disponível, retornando resultado vazio")
        return {"error": "PaddleOCR não disponível"}
    
    logger.info(f"Processando PDF com PaddleOCR: {pdf_path}")
    
    try:
        # Inicializar PaddleOCR com parâmetro atualizado
        ocr = PaddleOCR(use_textline_orientation=True, lang='pt')
        
        start_time = time.time()
        
        # Executar OCR no arquivo PDF (sem o parâmetro cls)
        result = ocr.predict(pdf_path)
        
        # Estruturar resultados
        structured_result = {
            "pages": [],
            "text": "",
            "metadata": {
                "num_pages": len(result),
                "processing_time": 0
            }
        }
        
        all_text = []
        
        # Processar resultados de cada página
        for i, page_result in enumerate(result):
            page_text = []
            page_data = []
            
            if page_result:
                for line in page_result:
                    text = line[1][0]  # Texto reconhecido
                    confidence = line[1][1]  # Confiança
                    box = line[0]  # Coordenadas da caixa
                    
                    page_text.append(text)
                    page_data.append({
                        "text": text,
                        "confidence": confidence,
                        "box": box
                    })
            
            # Juntar texto da página
            page_text_str = "\n".join(page_text)
            all_text.append(page_text_str)
            
            # Extrair dados estruturados da página
            structured_data = extract_structured_data_from_text(page_text_str)
            
            # Adicionar resultados da página
            structured_result["pages"].append({
                "page_num": i+1,
                "text": page_text_str,
                "data": page_data,
                "structured_data": structured_data
            })
        
        # Consolidar texto de todas as páginas
        full_text = "\n\n".join(all_text)
        structured_result["text"] = full_text
        
        # Extrair dados estruturados do texto completo
        structured_result["structured_data"] = extract_structured_data_from_text(full_text)
        
        # Calcular tempo de processamento
        processing_time = time.time() - start_time
        structured_result["metadata"]["processing_time"] = processing_time
        
        logger.info(f"Processamento com PaddleOCR concluído em {processing_time:.2f} segundos")
        
        return structured_result
    
    except Exception as e:
        logger.error(f"Erro ao processar PDF com PaddleOCR: {str(e)}")
        return {"error": str(e)}

def extract_structured_data_from_text(text: str) -> Dict[str, Any]:
    """
    Extrai dados estruturados de texto usando expressões regulares
    
    Args:
        text: Texto extraído do PDF
        
    Returns:
        Dicionário com dados estruturados extraídos
    """
    # Extrair CNPJ
    cnpj_pattern = r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}'
    cnpjs = re.findall(cnpj_pattern, text)
    
    # Extrair CPF
    cpf_pattern = r'\d{3}\.\d{3}\.\d{3}-\d{2}'
    cpfs = re.findall(cpf_pattern, text)
    
    # Extrair valores monetários
    money_pattern = r'R\$\s*[\d\.,]+'
    valores = re.findall(money_pattern, text)
    
    # Extrair datas
    date_pattern = r'\d{2}/\d{2}/\d{4}'
    datas = re.findall(date_pattern, text)
    
    # Extrair telefones
    phone_pattern = r'\(\d{2}\)\s*\d{4,5}-\d{4}'
    telefones = re.findall(phone_pattern, text)
    
    # Extrair emails
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    emails = re.findall(email_pattern, text)
    
    # Extrair possíveis razões sociais (palavras em maiúsculas seguidas de LTDA, SA, etc.)
    company_pattern = r'[A-Z][A-Z\s]+(?:LTDA|SA|S\.A\.|S/A|MEI|EIRELI|EPP|ME)'
    companies = re.findall(company_pattern, text)
    
    # Extrair endereços (linhas que contêm palavras como RUA, AVENIDA, etc.)
    address_pattern = r'(?:RUA|AVENIDA|AV|ALAMEDA|AL|PRAÇA|PÇA|RODOVIA|ROD)[\w\s,\.]+(?:,\s*\d+)?'
    addresses = re.findall(address_pattern, text.upper())
    
    return {
        "cnpjs": cnpjs,
        "cpfs": cpfs,
        "valores": valores,
        "datas": datas,
        "telefones": telefones,
        "emails": emails,
        "empresas": companies,
        "enderecos": addresses
    }

def extract_cnpj_from_text(text: str) -> Optional[str]:
    """
    Extrai CNPJ do texto
    
    Args:
        text: Texto extraído do PDF
        
    Returns:
        CNPJ extraído ou None se não encontrado
    """
    cnpj_pattern = r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}'
    cnpjs = re.findall(cnpj_pattern, text)
    
    if cnpjs:
        return cnpjs[0]
    
    # Tentar padrão sem formatação
    cnpj_pattern_raw = r'\d{14}'
    cnpjs_raw = re.findall(cnpj_pattern_raw, text)
    
    if cnpjs_raw:
        # Formatar CNPJ
        cnpj = cnpjs_raw[0]
        formatted_cnpj = f"{cnpj[:2]}.{cnpj[2:5]}.{cnpj[5:8]}/{cnpj[8:12]}-{cnpj[12:]}"
        return formatted_cnpj
    
    return None

def extract_financial_data(text: str) -> Dict[str, Any]:
    """
    Extrai dados financeiros do texto
    
    Args:
        text: Texto extraído do PDF
        
    Returns:
        Dicionário com dados financeiros extraídos
    """
    # Extrair valores monetários
    money_pattern = r'R\$\s*([\d\.,]+)'
    valores_match = re.findall(money_pattern, text)
    
    # Limpar e converter valores
    valores = []
    for valor in valores_match:
        # Remover pontos de milhar e substituir vírgula por ponto
        valor_limpo = valor.replace(".", "").replace(",", ".")
        try:
            valores.append(float(valor_limpo))
        except ValueError:
            pass
    
    # Tentar identificar faturamento
    faturamento = None
    faturamento_patterns = [
        r'faturamento\s*(?:anual|mensal)?\s*(?:de|:)?\s*R\$\s*([\d\.,]+)',
        r'receita\s*(?:anual|mensal)?\s*(?:de|:)?\s*R\$\s*([\d\.,]+)',
        r'fat(?:\.|uramento)?\s*(?:anual|mensal)?\s*(?:de|:)?\s*R\$\s*([\d\.,]+)'
    ]
    
    for pattern in faturamento_patterns:
        matches = re.findall(pattern, text.lower())
        if matches:
            # Limpar e converter valor
            valor = matches[0].replace(".", "").replace(",", ".")
            try:
                faturamento = float(valor)
                break
            except ValueError:
                pass
    
    # Tentar identificar capital social
    capital_social = None
    capital_patterns = [
        r'capital\s*social\s*(?:de|:)?\s*R\$\s*([\d\.,]+)',
        r'capital\s*(?:de|:)?\s*R\$\s*([\d\.,]+)'
    ]
    
    for pattern in capital_patterns:
        matches = re.findall(pattern, text.lower())
        if matches:
            # Limpar e converter valor
            valor = matches[0].replace(".", "").replace(",", ".")
            try:
                capital_social = float(valor)
                break
            except ValueError:
                pass
    
    return {
        "valores": valores,
        "faturamento": faturamento,
        "capital_social": capital_social
    }

def extract_structured_data(text: str) -> Dict[str, Any]:
    """
    Extrai dados estruturados do texto
    
    Args:
        text: Texto extraído do PDF
        
    Returns:
        Dicionário com dados estruturados extraídos
    """
    # Extrair dados básicos
    basic_data = extract_structured_data_from_text(text)
    
    # Extrair dados financeiros
    financial_data = extract_financial_data(text)
    
    # Extrair CNPJ
    cnpj = extract_cnpj_from_text(text)
    
    # Tentar identificar razão social
    razao_social = None
    if basic_data["empresas"]:
        razao_social = basic_data["empresas"][0]
    
    # Tentar identificar endereço
    endereco = None
    if basic_data["enderecos"]:
        endereco = basic_data["enderecos"][0]
    
    # Consolidar resultados
    result = {
        **basic_data,
        "dados_financeiros": financial_data,
        "cnpj_principal": cnpj,
        "razao_social": razao_social,
        "endereco_principal": endereco
    }
    
    return result

# Função principal para teste
def main():
    """Função principal para teste do extrator"""
    import sys
    
    if len(sys.argv) < 2:
        print("Uso: python pdf_extractor.py <caminho_do_pdf>")
        return
    
    pdf_path = sys.argv[1]
    
    if not os.path.exists(pdf_path):
        print(f"Arquivo não encontrado: {pdf_path}")
        return
    
    try:
        # Extrair texto
        text = extract_text_from_pdf(pdf_path)
        print(f"Texto extraído ({len(text)} caracteres)")
        
        # Extrair dados estruturados
        data = extract_structured_data(text)
        print("\nDados estruturados:")
        print(json.dumps(data, indent=2, ensure_ascii=False))
        
        # Salvar resultados
        with open("extracted_text.txt", "w", encoding="utf-8") as f:
            f.write(text)
        
        with open("extracted_data.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print("\nResultados salvos em extracted_text.txt e extracted_data.json")
        
        # Tentar processar com PaddleOCR se disponível
        if paddle_available:
            print("\nProcessando com PaddleOCR...")
            paddle_result = process_pdf_with_paddle(pdf_path)
            
            with open("paddle_result.json", "w", encoding="utf-8") as f:
                json.dump(paddle_result, f, indent=2, ensure_ascii=False)
            
            print("Resultados do PaddleOCR salvos em paddle_result.json")
    
    except Exception as e:
        print(f"Erro: {str(e)}")

if __name__ == "__main__":
    main()
