/**
 * Serviço de BI Self-Service e Analytics Avançado
 * Implementa funcionalidades para exploração de dados, criação de relatórios
 * e dashboards customizados pelos usuários finais.
 */

import { v4 as uuidv4 } from 'uuid';
import { cloneDeep, get, set, merge, groupBy, sumBy, meanBy, countBy } from 'lodash';
import { RbacDlpService } from '../rbac-dlp/RbacDlpService'; // Assumindo integração

// Simulação de um Data Warehouse ou Data Lake
const mockDataWarehouse = {
  credit_applications: [
    { id: 'app1', clientId: 'clientA', amount: 10000, status: 'approved', score: 750, region: 'Sudeste', sector: 'Varejo', analysisType: 'Majoração', date: '2024-01-15' },
    { id: 'app2', clientId: 'clientB', amount: 5000, status: 'rejected', score: 550, region: 'Nordeste', sector: 'Serviços', analysisType: 'Prospecção', date: '2024-01-20' },
    { id: 'app3', clientId: 'clientC', amount: 20000, status: 'approved', score: 800, region: 'Sul', sector: 'Indústria', analysisType: 'Reativação', date: '2024-02-10' },
    { id: 'app4', clientId: 'clientA', amount: 15000, status: 'approved', score: 760, region: 'Sudeste', sector: 'Varejo', analysisType: 'Revisão', date: '2024-03-05' },
    { id: 'app5', clientId: 'clientD', amount: 8000, status: 'rejected', score: 600, region: 'Centro-Oeste', sector: 'Agronegócio', analysisType: 'Prospecção', date: '2024-03-15' },
    { id: 'app6', clientId: 'clientB', amount: 12000, status: 'approved', score: 680, region: 'Nordeste', sector: 'Serviços', analysisType: 'Majoração', date: '2024-04-01' },
    { id: 'app7', clientId: 'clientE', amount: 30000, status: 'approved', score: 850, region: 'Sudeste', sector: 'Tecnologia', analysisType: 'Prospecção', date: '2024-04-10' },
    { id: 'app8', clientId: 'clientC', amount: 25000, status: 'approved', score: 810, region: 'Sul', sector: 'Indústria', analysisType: 'Majoração', date: '2024-05-02' },
  ],
  clients: [
    { id: 'clientA', name: 'Empresa Alpha', registrationDate: '2023-01-10', revenue: 1000000 },
    { id: 'clientB', name: 'Empresa Beta', registrationDate: '2023-05-20', revenue: 500000 },
    { id: 'clientC', name: 'Empresa Gamma', registrationDate: '2022-11-01', revenue: 2000000 },
    { id: 'clientD', name: 'Empresa Delta', registrationDate: '2024-02-15', revenue: 300000 },
    { id: 'clientE', name: 'Empresa Epsilon', registrationDate: '2024-03-20', revenue: 1500000 },
  ],
  // Outras tabelas/coleções simuladas
};

/**
 * Classe para Gerenciamento de BI e Analytics
 */
export class BiAnalyticsManager {
  constructor(config = {}) {
    this.config = {
      maxQueryResults: config.maxQueryResults || 1000,
      defaultVisualization: config.defaultVisualization || 'table',
      cacheEnabled: config.cacheEnabled !== undefined ? config.cacheEnabled : true,
      cacheTTL: config.cacheTTL || 600000, // 10 minutos em ms
      auditEnabled: config.auditEnabled !== undefined ? config.auditEnabled : true,
      ...config
    };

    // Serviço RBAC/DLP para controle de acesso e proteção de dados
    this.rbacDlpService = config.rbacDlpService || new RbacDlpService(); // Usar instância real se fornecida

    // Armazenamento de relatórios salvos
    this.reports = new Map();
    
    // Armazenamento de dashboards salvos
    this.dashboards = new Map();
    
    // Armazenamento de datasets (visões de dados pré-definidas)
    this.datasets = new Map();
    
    // Cache de resultados de query
    this.queryCache = new Map();
    
    // Armazenamento de logs de auditoria
    this.auditLogs = [];
    
    // Inicializar datasets padrão
    this._initializeDefaultDatasets();
  }

  /**
   * Inicializa datasets padrão
   * @private
   */
  _initializeDefaultDatasets() {
    this.createDataset({
      name: 'credit_applications_summary',
      description: 'Resumo das aplicações de crédito',
      source: 'credit_applications',
      fields: [
        { name: 'id', type: 'string', label: 'ID Aplicação', visible: true },
        { name: 'clientId', type: 'string', label: 'ID Cliente', visible: true },
        { name: 'amount', type: 'number', label: 'Valor Solicitado', format: 'currency', visible: true },
        { name: 'status', type: 'string', label: 'Status', visible: true },
        { name: 'score', type: 'number', label: 'Score', visible: true },
        { name: 'region', type: 'string', label: 'Região', visible: true },
        { name: 'sector', type: 'string', label: 'Setor', visible: true },
        { name: 'analysisType', type: 'string', label: 'Tipo Análise', visible: true },
        { name: 'date', type: 'date', label: 'Data', visible: true },
      ],
      permissions: ['reports:view:applications'],
      isSystem: true
    });
    
    this.createDataset({
      name: 'client_overview',
      description: 'Visão geral dos clientes',
      source: 'clients',
      fields: [
        { name: 'id', type: 'string', label: 'ID Cliente', visible: true },
        { name: 'name', type: 'string', label: 'Nome Cliente', visible: true, dlpPolicy: 'mask_name' }, // Exemplo de política DLP
        { name: 'registrationDate', type: 'date', label: 'Data Cadastro', visible: true },
        { name: 'revenue', type: 'number', label: 'Receita Anual', format: 'currency', visible: true },
      ],
      permissions: ['reports:view:clients'],
      isSystem: true
    });
  }

  /**
   * Cria um novo dataset
   * @param {Object} datasetData Dados do dataset
   * @returns {Object} Dataset criado
   */
  createDataset(datasetData) {
    const datasetName = datasetData.name.toLowerCase();
    
    if (this.datasets.has(datasetName)) {
      throw new Error(`Dataset já existe: ${datasetName}`);
    }
    
    const dataset = {
      name: datasetName,
      description: datasetData.description || ".",
      source: datasetData.source,
      fields: datasetData.fields || [],
      joins: datasetData.joins || [],
      filters: datasetData.filters || [],
      permissions: datasetData.permissions || [],
      isSystem: datasetData.isSystem || false,
      metadata: datasetData.metadata || {},
      createdAt: new Date().toISOString(),
      createdBy: datasetData.createdBy || 'system'
    };
    
    // Validar dataset
    this._validateDataset(dataset);
    
    // Armazenar dataset
    this.datasets.set(datasetName, dataset);
    
    return cloneDeep(dataset);
  }

  /**
   * Executa uma query em um dataset
   * @param {string} userId ID do usuário executando a query
   * @param {string} datasetName Nome do dataset
   * @param {Object} queryParams Parâmetros da query (filtros, agregações, ordenação, etc.)
   * @returns {Promise<Object>} Resultado da query
   */
  async executeQuery(userId, datasetName, queryParams = {}) {
    datasetName = datasetName.toLowerCase();
    
    if (!this.datasets.has(datasetName)) {
      throw new Error(`Dataset não encontrado: ${datasetName}`);
    }
    
    const dataset = this.datasets.get(datasetName);
    
    // 1. Verificar permissão de acesso ao dataset
    const hasDatasetPermission = await this._checkPermissions(userId, dataset.permissions);
    if (!hasDatasetPermission) {
      this._logAuditEvent(userId, 'query_denied', { datasetName, reason: 'Dataset permission denied' });
      throw new Error('Permissão negada para acessar este dataset');
    }
    
    // 2. Construir chave de cache
    const cacheKey = `${userId}:${datasetName}:${JSON.stringify(queryParams)}`;
    
    // 3. Verificar cache
    if (this.config.cacheEnabled) {
      const cachedResult = this.queryCache.get(cacheKey);
      if (cachedResult && cachedResult.expiresAt > Date.now()) {
        this._logAuditEvent(userId, 'query_executed_cache', { datasetName, queryParams });
        return cachedResult.result;
      }
    }
    
    // 4. Obter dados brutos da fonte (simulado)
    let rawData = this._getRawData(dataset.source);
    
    // 5. Aplicar filtros do dataset
    rawData = this._applyFilters(rawData, dataset.filters);
    
    // 6. Aplicar filtros da query
    rawData = this._applyFilters(rawData, queryParams.filters);
    
    // 7. Processar dados com DLP e RBAC a nível de linha/coluna
    const processedData = await this._processDataWithRbacDlp(userId, dataset, rawData, queryParams.fields);
    
    // 8. Aplicar agregações
    let finalData = this._applyAggregations(processedData, queryParams.aggregations);
    
    // 9. Aplicar ordenação
    finalData = this._applySorting(finalData, queryParams.sort);
    
    // 10. Limitar resultados
    finalData = finalData.slice(0, this.config.maxQueryResults);
    
    // 11. Preparar resultado final
    const result = {
      metadata: {
        dataset: datasetName,
        query: queryParams,
        timestamp: new Date().toISOString(),
        rowCount: finalData.length,
        executedBy: userId
      },
      data: finalData
    };
    
    // 12. Armazenar no cache
    if (this.config.cacheEnabled) {
      this.queryCache.set(cacheKey, {
        result,
        expiresAt: Date.now() + this.config.cacheTTL
      });
    }
    
    // 13. Registrar auditoria
    this._logAuditEvent(userId, 'query_executed', { datasetName, queryParams, rowCount: finalData.length });
    
    return result;
  }

  /**
   * Cria um novo relatório
   * @param {string} userId ID do usuário criando o relatório
   * @param {Object} reportData Dados do relatório
   * @returns {Object} Relatório criado
   */
  createReport(userId, reportData) {
    const reportId = reportData.id || uuidv4();
    
    if (this.reports.has(reportId)) {
      throw new Error(`Relatório já existe: ${reportId}`);
    }
    
    const report = {
      id: reportId,
      name: reportData.name,
      description: reportData.description || ".",
      dataset: reportData.dataset,
      query: reportData.query || {},
      visualization: reportData.visualization || { type: this.config.defaultVisualization },
      ownerId: userId,
      sharedWith: reportData.sharedWith || [], // { type: 'user'/'group', id: '...' }
      permissions: reportData.permissions || ['owner'], // 'owner', 'edit', 'view'
      metadata: reportData.metadata || {},
      createdAt: new Date().toISOString(),
      createdBy: userId
    };
    
    // Validar relatório
    this._validateReport(report);
    
    // Armazenar relatório
    this.reports.set(reportId, report);
    
    // Registrar auditoria
    this._logAuditEvent(userId, 'report_created', { reportId, reportName: report.name });
    
    return cloneDeep(report);
  }

  /**
   * Cria um novo dashboard
   * @param {string} userId ID do usuário criando o dashboard
   * @param {Object} dashboardData Dados do dashboard
   * @returns {Object} Dashboard criado
   */
  createDashboard(userId, dashboardData) {
    const dashboardId = dashboardData.id || uuidv4();
    
    if (this.dashboards.has(dashboardId)) {
      throw new Error(`Dashboard já existe: ${dashboardId}`);
    }
    
    const dashboard = {
      id: dashboardId,
      name: dashboardData.name,
      description: dashboardData.description || ".",
      layout: dashboardData.layout || [], // { reportId: '...', position: { x, y, w, h } }
      filters: dashboardData.filters || [],
      ownerId: userId,
      sharedWith: dashboardData.sharedWith || [],
      permissions: dashboardData.permissions || ['owner'],
      metadata: dashboardData.metadata || {},
      createdAt: new Date().toISOString(),
      createdBy: userId
    };
    
    // Validar dashboard
    this._validateDashboard(dashboard);
    
    // Armazenar dashboard
    this.dashboards.set(dashboardId, dashboard);
    
    // Registrar auditoria
    this._logAuditEvent(userId, 'dashboard_created', { dashboardId, dashboardName: dashboard.name });
    
    return cloneDeep(dashboard);
  }

  /**
   * Obtém dados de um relatório
   * @param {string} userId ID do usuário acessando o relatório
   * @param {string} reportId ID do relatório
   * @returns {Promise<Object>} Dados do relatório
   */
  async getReportData(userId, reportId) {
    if (!this.reports.has(reportId)) {
      throw new Error(`Relatório não encontrado: ${reportId}`);
    }
    
    const report = this.reports.get(reportId);
    
    // Verificar permissão de visualização do relatório
    const hasReportPermission = await this._checkReportPermission(userId, report, 'view');
    if (!hasReportPermission) {
      this._logAuditEvent(userId, 'report_access_denied', { reportId, reason: 'Report permission denied' });
      throw new Error('Permissão negada para visualizar este relatório');
    }
    
    // Executar a query associada ao relatório
    const queryResult = await this.executeQuery(userId, report.dataset, report.query);
    
    // Registrar auditoria
    this._logAuditEvent(userId, 'report_viewed', { reportId, reportName: report.name });
    
    return {
      reportInfo: cloneDeep(report),
      queryResult
    };
  }

  /**
   * Obtém dados de um dashboard
   * @param {string} userId ID do usuário acessando o dashboard
   * @param {string} dashboardId ID do dashboard
   * @returns {Promise<Object>} Dados do dashboard
   */
  async getDashboardData(userId, dashboardId) {
    if (!this.dashboards.has(dashboardId)) {
      throw new Error(`Dashboard não encontrado: ${dashboardId}`);
    }
    
    const dashboard = this.dashboards.get(dashboardId);
    
    // Verificar permissão de visualização do dashboard
    const hasDashboardPermission = await this._checkDashboardPermission(userId, dashboard, 'view');
    if (!hasDashboardPermission) {
      this._logAuditEvent(userId, 'dashboard_access_denied', { dashboardId, reason: 'Dashboard permission denied' });
      throw new Error('Permissão negada para visualizar este dashboard');
    }
    
    // Obter dados de cada relatório no layout
    const reportDataPromises = dashboard.layout.map(async (item) => {
      try {
        const reportResult = await this.getReportData(userId, item.reportId);
        return {
          reportId: item.reportId,
          position: item.position,
          data: reportResult.queryResult.data,
          visualization: reportResult.reportInfo.visualization,
          error: null
        };
      } catch (error) {
        return {
          reportId: item.reportId,
          position: item.position,
          data: null,
          visualization: null,
          error: error.message
        };
      }
    });
    
    const reportResults = await Promise.all(reportDataPromises);
    
    // Registrar auditoria
    this._logAuditEvent(userId, 'dashboard_viewed', { dashboardId, dashboardName: dashboard.name });
    
    return {
      dashboardInfo: cloneDeep(dashboard),
      reports: reportResults
    };
  }

  /**
   * Obtém logs de auditoria do BI/Analytics
   * @param {Object} filters Filtros para consulta
   * @returns {Array} Logs de auditoria
   */
  getAuditLogs(filters = {}) {
    let logs = this.auditLogs;
    
    // Aplicar filtros (exemplo)
    if (filters.userId) {
      logs = logs.filter(log => log.userId === filters.userId);
    }
    if (filters.action) {
      logs = logs.filter(log => log.action === filters.action);
    }
    
    // Ordenar por timestamp (mais recente primeiro)
    logs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    // Limitar resultados
    if (filters.limit) {
      logs = logs.slice(0, filters.limit);
    }
    
    return cloneDeep(logs);
  }

  // --- Métodos Privados --- 

  /**
   * Obtém dados brutos de uma fonte (simulado)
   * @param {string} source Nome da fonte
   * @returns {Array} Dados brutos
   * @private
   */
  _getRawData(source) {
    // Em um sistema real, isso se conectaria a um banco de dados, data lake, etc.
    return cloneDeep(mockDataWarehouse[source] || []);
  }

  /**
   * Aplica filtros aos dados
   * @param {Array} data Dados
   * @param {Array} filters Filtros
   * @returns {Array} Dados filtrados
   * @private
   */
  _applyFilters(data, filters) {
    if (!filters || filters.length === 0) {
      return data;
    }
    
    return data.filter(row => {
      return filters.every(filter => {
        const rowValue = get(row, filter.field);
        
        switch (filter.operator) {
          case 'equals': return rowValue === filter.value;
          case 'not_equals': return rowValue !== filter.value;
          case 'contains': return typeof rowValue === 'string' && rowValue.includes(filter.value);
          case 'greater_than': return rowValue > filter.value;
          case 'less_than': return rowValue < filter.value;
          case 'in': return Array.isArray(filter.value) && filter.value.includes(rowValue);
          case 'not_in': return !Array.isArray(filter.value) || !filter.value.includes(rowValue);
          // Adicionar mais operadores conforme necessário
          default: return true;
        }
      });
    });
  }

  /**
   * Aplica agregações aos dados
   * @param {Array} data Dados
   * @param {Object} aggregations Configurações de agregação
   * @returns {Array} Dados agregados
   * @private
   */
  _applyAggregations(data, aggregations) {
    if (!aggregations || !aggregations.groupBy || aggregations.groupBy.length === 0) {
      return data; // Retorna dados detalhados se não houver agrupamento
    }
    
    const groupedData = groupBy(data, row => {
      return aggregations.groupBy.map(field => get(row, field)).join('||');
    });
    
    const aggregatedResult = Object.entries(groupedData).map(([key, group]) => {
      const row = {};
      
      // Adicionar campos de agrupamento
      const groupKeys = key.split('||');
      aggregations.groupBy.forEach((field, index) => {
        set(row, field, groupKeys[index]);
      });
      
      // Calcular métricas
      if (aggregations.metrics) {
        aggregations.metrics.forEach(metric => {
          let value;
          switch (metric.func) {
            case 'count': value = group.length; break;
            case 'sum': value = sumBy(group, metric.field); break;
            case 'average': value = meanBy(group, metric.field); break;
            case 'distinct_count': value = new Set(group.map(item => get(item, metric.field))).size; break;
            // Adicionar mais funções de agregação
            default: value = null;
          }
          set(row, metric.alias || `${metric.func}_${metric.field}`, value);
        });
      }
      
      return row;
    });
    
    return aggregatedResult;
  }

  /**
   * Aplica ordenação aos dados
   * @param {Array} data Dados
   * @param {Array} sortFields Campos de ordenação
   * @returns {Array} Dados ordenados
   * @private
   */
  _applySorting(data, sortFields) {
    if (!sortFields || sortFields.length === 0) {
      return data;
    }
    
    return data.sort((a, b) => {
      for (const sortField of sortFields) {
        const field = sortField.field;
        const direction = sortField.direction === 'desc' ? -1 : 1;
        const valueA = get(a, field);
        const valueB = get(b, field);
        
        if (valueA < valueB) return -1 * direction;
        if (valueA > valueB) return 1 * direction;
      }
      return 0;
    });
  }

  /**
   * Processa dados com RBAC e DLP
   * @param {string} userId ID do usuário
   * @param {Object} dataset Definição do dataset
   * @param {Array} data Dados brutos
   * @param {Array} requestedFields Campos solicitados na query (opcional)
   * @returns {Promise<Array>} Dados processados
   * @private
   */
  async _processDataWithRbacDlp(userId, dataset, data, requestedFields = null) {
    const processedRows = [];
    
    // Determinar campos visíveis baseado no dataset e na query
    const visibleFields = dataset.fields
      .filter(f => f.visible && (!requestedFields || requestedFields.includes(f.name)))
      .map(f => f.name);
      
    for (const row of data) {
      // TODO: Implementar RBAC a nível de linha (ex: usuário só vê clientes da sua região)
      const rowAllowed = true; // Simulação
      
      if (rowAllowed) {
        const processedRow = {};
        let rowBlocked = false;
        
        for (const fieldDef of dataset.fields) {
          const fieldName = fieldDef.name;
          
          // Incluir apenas campos visíveis
          if (!visibleFields.includes(fieldName)) {
            continue;
          }
          
          const fieldValue = get(row, fieldName);
          
          // Verificar permissão a nível de coluna (se definida no dataset)
          if (fieldDef.permissions && fieldDef.permissions.length > 0) {
            const hasColumnPermission = await this._checkPermissions(userId, fieldDef.permissions);
            if (!hasColumnPermission) {
              // Se não tem permissão, não incluir o campo
              continue;
            }
          }
          
          // Aplicar DLP
          const dlpContext = { userId, dataset: dataset.name, field: fieldName, dlpPolicy: fieldDef.dlpPolicy };
          const dlpResult = await this.rbacDlpService.processData(fieldValue, dlpContext);
          
          if (dlpResult.blocked) {
            // Se um campo for bloqueado, a linha inteira pode ser bloqueada (depende da política)
            // Neste exemplo, vamos bloquear a linha inteira
            rowBlocked = true;
            break; // Sair do loop de campos
          }
          
          // Usar o valor processado (possivelmente redactado)
          set(processedRow, fieldName, dlpResult.data);
        }
        
        // Adicionar linha processada se não foi bloqueada
        if (!rowBlocked) {
          processedRows.push(processedRow);
        }
      }
    }
    
    return processedRows;
  }

  /**
   * Verifica um conjunto de permissões para um usuário
   * @param {string} userId ID do usuário
   * @param {Array} permissions Permissões necessárias
   * @returns {Promise<boolean>} Se o usuário tem todas as permissões
   * @private
   */
  async _checkPermissions(userId, permissions) {
    if (!permissions || permissions.length === 0) {
      return true; // Sem restrições de permissão
    }
    
    for (const permission of permissions) {
      const hasPermission = await this.rbacDlpService.checkPermission(userId, permission);
      if (!hasPermission) {
        return false;
      }
    }
    
    return true;
  }

  /**
   * Verifica permissão de acesso a um relatório
   * @param {string} userId ID do usuário
   * @param {Object} report Relatório
   * @param {string} requiredPermission Permissão necessária ('view', 'edit', 'owner')
   * @returns {Promise<boolean>} Se tem permissão
   * @private
   */
  async _checkReportPermission(userId, report, requiredPermission) {
    // Dono sempre tem permissão total
    if (report.ownerId === userId) {
      return true;
    }
    
    // Verificar compartilhamento direto com usuário
    const userShare = report.sharedWith.find(s => s.type === 'user' && s.id === userId);
    if (userShare) {
      const userPermissions = userShare.permissions || ['view'];
      if (requiredPermission === 'view' && userPermissions.includes('view')) return true;
      if (requiredPermission === 'edit' && userPermissions.includes('edit')) return true;
    }
    
    // Verificar compartilhamento com grupos do usuário
    const userGroups = await this.rbacDlpService.rbacManager._getAllUserGroups(userId);
    for (const groupShare of report.sharedWith.filter(s => s.type === 'group')) {
      if (userGroups.includes(groupShare.id)) {
        const groupPermissions = groupShare.permissions || ['view'];
        if (requiredPermission === 'view' && groupPermissions.includes('view')) return true;
        if (requiredPermission === 'edit' && groupPermissions.includes('edit')) return true;
      }
    }
    
    // Verificar permissões globais (ex: admin pode ver tudo)
    if (requiredPermission === 'view' && await this.rbacDlpService.checkPermission(userId, 'reports:view:all')) {
      return true;
    }
    if (requiredPermission === 'edit' && await this.rbacDlpService.checkPermission(userId, 'reports:edit:all')) {
      return true;
    }
    
    return false;
  }

  /**
   * Verifica permissão de acesso a um dashboard
   * @param {string} userId ID do usuário
   * @param {Object} dashboard Dashboard
   * @param {string} requiredPermission Permissão necessária ('view', 'edit', 'owner')
   * @returns {Promise<boolean>} Se tem permissão
   * @private
   */
  async _checkDashboardPermission(userId, dashboard, requiredPermission) {
    // Lógica similar à de relatórios
    if (dashboard.ownerId === userId) {
      return true;
    }
    
    const userShare = dashboard.sharedWith.find(s => s.type === 'user' && s.id === userId);
    if (userShare) {
      const userPermissions = userShare.permissions || ['view'];
      if (requiredPermission === 'view' && userPermissions.includes('view')) return true;
      if (requiredPermission === 'edit' && userPermissions.includes('edit')) return true;
    }
    
    const userGroups = await this.rbacDlpService.rbacManager._getAllUserGroups(userId);
    for (const groupShare of dashboard.sharedWith.filter(s => s.type === 'group')) {
      if (userGroups.includes(groupShare.id)) {
        const groupPermissions = groupShare.permissions || ['view'];
        if (requiredPermission === 'view' && groupPermissions.includes('view')) return true;
        if (requiredPermission === 'edit' && groupPermissions.includes('edit')) return true;
      }
    }
    
    if (requiredPermission === 'view' && await this.rbacDlpService.checkPermission(userId, 'dashboards:view:all')) {
      return true;
    }
    if (requiredPermission === 'edit' && await this.rbacDlpService.checkPermission(userId, 'dashboards:edit:all')) {
      return true;
    }
    
    return false;
  }

  /**
   * Registra um evento de auditoria
   * @param {string} userId ID do usuário
   * @param {string} action Ação realizada
   * @param {Object} details Detalhes do evento
   * @private
   */
  _logAuditEvent(userId, action, details) {
    if (!this.config.auditEnabled) {
      return;
    }
    
    const event = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      userId,
      action,
      details,
      // Adicionar IP, User Agent, etc. se disponível no contexto
    };
    
    this.auditLogs.push(event);
    
    // Limitar tamanho do log
    if (this.auditLogs.length > 10000) {
      this.auditLogs.shift();
    }
  }

  /**
   * Valida um dataset
   * @param {Object} dataset Dataset
   * @private
   */
  _validateDataset(dataset) {
    if (!dataset.name) throw new Error('Nome do dataset é obrigatório');
    if (!dataset.source) throw new Error('Fonte do dataset é obrigatória');
    if (!Array.isArray(dataset.fields)) throw new Error('Campos do dataset devem ser um array');
    
    // Validar se a fonte existe (simulado)
    if (!mockDataWarehouse[dataset.source]) {
      throw new Error(`Fonte de dados não encontrada: ${dataset.source}`);
    }
  }

  /**
   * Valida um relatório
   * @param {Object} report Relatório
   * @private
   */
  _validateReport(report) {
    if (!report.id) throw new Error('ID do relatório é obrigatório');
    if (!report.name) throw new Error('Nome do relatório é obrigatório');
    if (!report.dataset) throw new Error('Dataset do relatório é obrigatório');
    if (!this.datasets.has(report.dataset)) {
      throw new Error(`Dataset não encontrado: ${report.dataset}`);
    }
    if (!report.ownerId) throw new Error('Dono do relatório é obrigatório');
  }

  /**
   * Valida um dashboard
   * @param {Object} dashboard Dashboard
   * @private
   */
  _validateDashboard(dashboard) {
    if (!dashboard.id) throw new Error('ID do dashboard é obrigatório');
    if (!dashboard.name) throw new Error('Nome do dashboard é obrigatório');
    if (!Array.isArray(dashboard.layout)) throw new Error('Layout do dashboard deve ser um array');
    if (!dashboard.ownerId) throw new Error('Dono do dashboard é obrigatório');
    
    // Validar se os relatórios no layout existem
    for (const item of dashboard.layout) {
      if (!item.reportId || !this.reports.has(item.reportId)) {
        throw new Error(`Relatório não encontrado no layout: ${item.reportId}`);
      }
    }
  }
}

export default BiAnalyticsManager;
