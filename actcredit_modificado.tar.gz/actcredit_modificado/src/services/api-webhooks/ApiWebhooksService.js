/**
 * Serviço de APIs Bidirecionais e Webhooks
 * Implementa funcionalidades para integração externa, automação de eventos
 * e orquestração de fluxos de trabalho.
 */

import { v4 as uuidv4 } from 'uuid';
import { cloneDeep, get, set, merge } from 'lodash';
import crypto from 'crypto';

/**
 * Classe para Gerenciamento de APIs Bidirecionais
 */
export class ApiManager {
  constructor(config = {}) {
    this.config = {
      apiVersion: config.apiVersion || 'v1',
      baseUrl: config.baseUrl || '/api',
      rateLimitEnabled: config.rateLimitEnabled !== undefined ? config.rateLimitEnabled : true,
      rateLimitRequests: config.rateLimitRequests || 100, // Requisições por intervalo
      rateLimitInterval: config.rateLimitInterval || 60000, // Intervalo em ms (1 minuto)
      authRequired: config.authRequired !== undefined ? config.authRequired : true,
      corsEnabled: config.corsEnabled !== undefined ? config.corsEnabled : true,
      corsOrigins: config.corsOrigins || ['*'],
      loggingEnabled: config.loggingEnabled !== undefined ? config.loggingEnabled : true,
      ...config
    };

    // Armazenamento de endpoints registrados
    this.endpoints = new Map();
    
    // Armazenamento de chaves de API
    this.apiKeys = new Map();
    
    // Armazenamento de logs de requisições
    this.requestLogs = [];
    
    // Armazenamento de contadores de rate limit
    this.rateLimitCounters = new Map();
    
    // Inicializar endpoints padrão
    this._initializeDefaultEndpoints();
  }

  /**
   * Inicializa endpoints padrão
   * @private
   */
  _initializeDefaultEndpoints() {
    // Endpoint de status da API
    this.registerEndpoint({
      path: '/status',
      method: 'GET',
      description: 'Retorna o status da API',
      authRequired: false,
      handler: async (req) => {
        return {
          status: 'online',
          version: this.config.apiVersion,
          timestamp: new Date().toISOString(),
          uptime: process.uptime()
        };
      }
    });
    
    // Endpoint de documentação da API
    this.registerEndpoint({
      path: '/docs',
      method: 'GET',
      description: 'Retorna a documentação da API',
      authRequired: false,
      handler: async (req) => {
        return this.generateApiDocumentation();
      }
    });
  }

  /**
   * Registra um novo endpoint
   * @param {Object} endpointData Dados do endpoint
   * @returns {Object} Endpoint registrado
   */
  registerEndpoint(endpointData) {
    const path = endpointData.path;
    const method = endpointData.method.toUpperCase();
    const endpointKey = `${method}:${path}`;
    
    if (this.endpoints.has(endpointKey)) {
      throw new Error(`Endpoint já registrado: ${method} ${path}`);
    }
    
    const endpoint = {
      path,
      method,
      description: endpointData.description || '',
      version: endpointData.version || this.config.apiVersion,
      authRequired: endpointData.authRequired !== undefined ? endpointData.authRequired : this.config.authRequired,
      rateLimitEnabled: endpointData.rateLimitEnabled !== undefined ? endpointData.rateLimitEnabled : this.config.rateLimitEnabled,
      rateLimitRequests: endpointData.rateLimitRequests || this.config.rateLimitRequests,
      rateLimitInterval: endpointData.rateLimitInterval || this.config.rateLimitInterval,
      permissions: endpointData.permissions || [],
      parameters: endpointData.parameters || [],
      responses: endpointData.responses || {},
      handler: endpointData.handler,
      middleware: endpointData.middleware || [],
      deprecated: endpointData.deprecated || false,
      tags: endpointData.tags || [],
      createdAt: new Date().toISOString()
    };
    
    // Validar endpoint
    this._validateEndpoint(endpoint);
    
    // Armazenar endpoint
    this.endpoints.set(endpointKey, endpoint);
    
    return cloneDeep(endpoint);
  }

  /**
   * Atualiza um endpoint existente
   * @param {string} path Caminho do endpoint
   * @param {string} method Método HTTP
   * @param {Object} endpointData Novos dados do endpoint
   * @returns {Object} Endpoint atualizado
   */
  updateEndpoint(path, method, endpointData) {
    method = method.toUpperCase();
    const endpointKey = `${method}:${path}`;
    
    if (!this.endpoints.has(endpointKey)) {
      throw new Error(`Endpoint não encontrado: ${method} ${path}`);
    }
    
    const currentEndpoint = this.endpoints.get(endpointKey);
    
    // Campos que não podem ser atualizados diretamente
    const protectedFields = ['path', 'method', 'createdAt'];
    
    const updatedEndpoint = {
      ...currentEndpoint,
      ...Object.fromEntries(
        Object.entries(endpointData).filter(([key]) => !protectedFields.includes(key))
      ),
      updatedAt: new Date().toISOString()
    };
    
    // Validar endpoint
    this._validateEndpoint(updatedEndpoint);
    
    // Armazenar endpoint atualizado
    this.endpoints.set(endpointKey, updatedEndpoint);
    
    return cloneDeep(updatedEndpoint);
  }

  /**
   * Remove um endpoint
   * @param {string} path Caminho do endpoint
   * @param {string} method Método HTTP
   * @returns {boolean} Sucesso da remoção
   */
  removeEndpoint(path, method) {
    method = method.toUpperCase();
    const endpointKey = `${method}:${path}`;
    
    if (!this.endpoints.has(endpointKey)) {
      throw new Error(`Endpoint não encontrado: ${method} ${path}`);
    }
    
    return this.endpoints.delete(endpointKey);
  }

  /**
   * Processa uma requisição para um endpoint
   * @param {Object} req Objeto de requisição
   * @returns {Promise<Object>} Resposta do endpoint
   */
  async processRequest(req) {
    const { path, method, headers, query, body, auth } = req;
    const endpointKey = `${method.toUpperCase()}:${path}`;
    
    // Verificar se o endpoint existe
    if (!this.endpoints.has(endpointKey)) {
      return {
        status: 404,
        body: {
          error: 'Not Found',
          message: `Endpoint não encontrado: ${method} ${path}`
        }
      };
    }
    
    const endpoint = this.endpoints.get(endpointKey);
    
    try {
      // Verificar autenticação
      if (endpoint.authRequired) {
        if (!auth || !auth.apiKey) {
          return {
            status: 401,
            body: {
              error: 'Unauthorized',
              message: 'Autenticação necessária'
            }
          };
        }
        
        const apiKey = auth.apiKey;
        if (!this.apiKeys.has(apiKey)) {
          return {
            status: 401,
            body: {
              error: 'Unauthorized',
              message: 'Chave de API inválida'
            }
          };
        }
        
        const apiKeyData = this.apiKeys.get(apiKey);
        if (apiKeyData.revoked) {
          return {
            status: 401,
            body: {
              error: 'Unauthorized',
              message: 'Chave de API revogada'
            }
          };
        }
        
        if (apiKeyData.expiresAt && new Date(apiKeyData.expiresAt) < new Date()) {
          return {
            status: 401,
            body: {
              error: 'Unauthorized',
              message: 'Chave de API expirada'
            }
          };
        }
        
        // Verificar permissões
        if (endpoint.permissions.length > 0) {
          const hasPermission = endpoint.permissions.some(permission => 
            apiKeyData.permissions.includes(permission)
          );
          
          if (!hasPermission) {
            return {
              status: 403,
              body: {
                error: 'Forbidden',
                message: 'Permissão negada'
              }
            };
          }
        }
        
        // Adicionar dados do cliente à requisição
        req.client = apiKeyData.client;
      }
      
      // Verificar rate limit
      if (endpoint.rateLimitEnabled) {
        const clientId = auth?.apiKey || req.ip || 'anonymous';
        const rateLimitKey = `${clientId}:${endpointKey}`;
        
        if (!this.rateLimitCounters.has(rateLimitKey)) {
          this.rateLimitCounters.set(rateLimitKey, {
            count: 0,
            resetAt: new Date(Date.now() + endpoint.rateLimitInterval)
          });
        }
        
        const rateLimitData = this.rateLimitCounters.get(rateLimitKey);
        
        // Resetar contador se necessário
        if (new Date() > new Date(rateLimitData.resetAt)) {
          rateLimitData.count = 0;
          rateLimitData.resetAt = new Date(Date.now() + endpoint.rateLimitInterval);
        }
        
        // Verificar limite
        if (rateLimitData.count >= endpoint.rateLimitRequests) {
          return {
            status: 429,
            body: {
              error: 'Too Many Requests',
              message: 'Limite de requisições excedido',
              resetAt: rateLimitData.resetAt
            },
            headers: {
              'X-RateLimit-Limit': endpoint.rateLimitRequests,
              'X-RateLimit-Remaining': 0,
              'X-RateLimit-Reset': Math.floor(new Date(rateLimitData.resetAt).getTime() / 1000)
            }
          };
        }
        
        // Incrementar contador
        rateLimitData.count += 1;
        this.rateLimitCounters.set(rateLimitKey, rateLimitData);
        
        // Adicionar headers de rate limit
        req.rateLimitHeaders = {
          'X-RateLimit-Limit': endpoint.rateLimitRequests,
          'X-RateLimit-Remaining': endpoint.rateLimitRequests - rateLimitData.count,
          'X-RateLimit-Reset': Math.floor(new Date(rateLimitData.resetAt).getTime() / 1000)
        };
      }
      
      // Executar middlewares
      for (const middleware of endpoint.middleware) {
        const result = await middleware(req);
        if (result) {
          return result;
        }
      }
      
      // Registrar requisição
      if (this.config.loggingEnabled) {
        this._logRequest(req, endpoint);
      }
      
      // Executar handler
      const startTime = Date.now();
      const result = await endpoint.handler(req);
      const endTime = Date.now();
      
      // Registrar resposta
      if (this.config.loggingEnabled) {
        this._logResponse(req, result, endTime - startTime);
      }
      
      // Adicionar headers de rate limit à resposta
      if (endpoint.rateLimitEnabled && req.rateLimitHeaders) {
        if (!result.headers) {
          result.headers = {};
        }
        Object.assign(result.headers, req.rateLimitHeaders);
      }
      
      return result;
    } catch (error) {
      // Registrar erro
      if (this.config.loggingEnabled) {
        this._logError(req, error);
      }
      
      return {
        status: 500,
        body: {
          error: 'Internal Server Error',
          message: this.config.exposeErrors ? error.message : 'Erro interno do servidor'
        }
      };
    }
  }

  /**
   * Cria uma nova chave de API
   * @param {Object} apiKeyData Dados da chave de API
   * @returns {Object} Chave de API criada
   */
  createApiKey(apiKeyData) {
    const apiKey = this._generateApiKey();
    
    const apiKeyRecord = {
      key: apiKey,
      client: {
        id: apiKeyData.clientId || uuidv4(),
        name: apiKeyData.clientName,
        email: apiKeyData.clientEmail
      },
      permissions: apiKeyData.permissions || [],
      createdAt: new Date().toISOString(),
      createdBy: apiKeyData.createdBy,
      expiresAt: apiKeyData.expiresAt,
      revoked: false,
      metadata: apiKeyData.metadata || {}
    };
    
    // Validar chave de API
    this._validateApiKey(apiKeyRecord);
    
    // Armazenar chave de API
    this.apiKeys.set(apiKey, apiKeyRecord);
    
    return {
      ...cloneDeep(apiKeyRecord),
      key: apiKey // Incluir a chave apenas na criação
    };
  }

  /**
   * Revoga uma chave de API
   * @param {string} apiKey Chave de API
   * @param {Object} metadata Metadados adicionais
   * @returns {Object} Chave de API atualizada
   */
  revokeApiKey(apiKey, metadata = {}) {
    if (!this.apiKeys.has(apiKey)) {
      throw new Error(`Chave de API não encontrada: ${apiKey}`);
    }
    
    const apiKeyRecord = this.apiKeys.get(apiKey);
    
    // Atualizar chave
    apiKeyRecord.revoked = true;
    apiKeyRecord.revokedAt = new Date().toISOString();
    apiKeyRecord.revokedBy = metadata.revokedBy;
    apiKeyRecord.revocationReason = metadata.reason || 'Revogada manualmente';
    
    // Armazenar chave atualizada
    this.apiKeys.set(apiKey, apiKeyRecord);
    
    return cloneDeep(apiKeyRecord);
  }

  /**
   * Atualiza permissões de uma chave de API
   * @param {string} apiKey Chave de API
   * @param {Array} permissions Novas permissões
   * @param {Object} metadata Metadados adicionais
   * @returns {Object} Chave de API atualizada
   */
  updateApiKeyPermissions(apiKey, permissions, metadata = {}) {
    if (!this.apiKeys.has(apiKey)) {
      throw new Error(`Chave de API não encontrada: ${apiKey}`);
    }
    
    const apiKeyRecord = this.apiKeys.get(apiKey);
    
    // Verificar se a chave está revogada
    if (apiKeyRecord.revoked) {
      throw new Error('Não é possível atualizar uma chave de API revogada');
    }
    
    // Atualizar permissões
    apiKeyRecord.permissions = permissions;
    apiKeyRecord.updatedAt = new Date().toISOString();
    apiKeyRecord.updatedBy = metadata.updatedBy;
    
    // Armazenar chave atualizada
    this.apiKeys.set(apiKey, apiKeyRecord);
    
    return cloneDeep(apiKeyRecord);
  }

  /**
   * Lista todas as chaves de API
   * @param {Object} filters Filtros para consulta
   * @returns {Array} Lista de chaves de API
   */
  listApiKeys(filters = {}) {
    let apiKeys = Array.from(this.apiKeys.entries()).map(([key, record]) => ({
      ...record,
      key: key.substring(0, 8) + '...' // Mostrar apenas parte da chave por segurança
    }));
    
    // Aplicar filtros
    if (filters.clientId) {
      apiKeys = apiKeys.filter(record => record.client.id === filters.clientId);
    }
    
    if (filters.active !== undefined) {
      apiKeys = apiKeys.filter(record => {
        const isActive = !record.revoked && 
          (!record.expiresAt || new Date(record.expiresAt) > new Date());
        return filters.active ? isActive : !isActive;
      });
    }
    
    // Ordenar por data de criação (mais recente primeiro)
    apiKeys.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    return apiKeys;
  }

  /**
   * Gera documentação da API
   * @returns {Object} Documentação da API
   */
  generateApiDocumentation() {
    const endpoints = Array.from(this.endpoints.values())
      .filter(endpoint => !endpoint.deprecated)
      .map(endpoint => ({
        path: endpoint.path,
        method: endpoint.method,
        description: endpoint.description,
        version: endpoint.version,
        authRequired: endpoint.authRequired,
        permissions: endpoint.permissions,
        parameters: endpoint.parameters,
        responses: endpoint.responses,
        tags: endpoint.tags
      }));
    
    // Agrupar por tags
    const endpointsByTag = {};
    for (const endpoint of endpoints) {
      const tags = endpoint.tags.length > 0 ? endpoint.tags : ['default'];
      for (const tag of tags) {
        if (!endpointsByTag[tag]) {
          endpointsByTag[tag] = [];
        }
        endpointsByTag[tag].push(endpoint);
      }
    }
    
    return {
      info: {
        title: 'ActCredit Premium API',
        version: this.config.apiVersion,
        description: 'API para integração com o motor de crédito ActCredit Premium'
      },
      servers: [
        {
          url: this.config.baseUrl,
          description: 'Servidor principal'
        }
      ],
      security: this.config.authRequired ? [
        {
          apiKey: []
        }
      ] : [],
      tags: Object.keys(endpointsByTag).map(tag => ({
        name: tag,
        description: `Endpoints relacionados a ${tag}`
      })),
      paths: endpointsByTag,
      components: {
        securitySchemes: {
          apiKey: {
            type: 'apiKey',
            in: 'header',
            name: 'X-API-Key'
          }
        }
      }
    };
  }

  /**
   * Gera uma chave de API
   * @returns {string} Chave de API
   * @private
   */
  _generateApiKey() {
    return `act_${crypto.randomBytes(32).toString('hex')}`;
  }

  /**
   * Registra uma requisição
   * @param {Object} req Requisição
   * @param {Object} endpoint Endpoint
   * @private
   */
  _logRequest(req, endpoint) {
    const log = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      type: 'request',
      method: req.method,
      path: req.path,
      clientId: req.client?.id || 'anonymous',
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      query: req.query,
      body: this._sanitizeBody(req.body)
    };
    
    this.requestLogs.push(log);
    
    // Limitar tamanho do log
    if (this.requestLogs.length > 1000) {
      this.requestLogs.shift();
    }
  }

  /**
   * Registra uma resposta
   * @param {Object} req Requisição
   * @param {Object} result Resultado
   * @param {number} duration Duração em ms
   * @private
   */
  _logResponse(req, result, duration) {
    const log = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      type: 'response',
      method: req.method,
      path: req.path,
      clientId: req.client?.id || 'anonymous',
      status: result.status,
      duration,
      responseSize: JSON.stringify(result.body).length
    };
    
    this.requestLogs.push(log);
    
    // Limitar tamanho do log
    if (this.requestLogs.length > 1000) {
      this.requestLogs.shift();
    }
  }

  /**
   * Registra um erro
   * @param {Object} req Requisição
   * @param {Error} error Erro
   * @private
   */
  _logError(req, error) {
    const log = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      type: 'error',
      method: req.method,
      path: req.path,
      clientId: req.client?.id || 'anonymous',
      error: error.message,
      stack: this.config.logErrorStacks ? error.stack : undefined
    };
    
    this.requestLogs.push(log);
    
    // Limitar tamanho do log
    if (this.requestLogs.length > 1000) {
      this.requestLogs.shift();
    }
  }

  /**
   * Sanitiza o corpo da requisição para log
   * @param {Object} body Corpo da requisição
   * @returns {Object} Corpo sanitizado
   * @private
   */
  _sanitizeBody(body) {
    if (!body) return body;
    
    const sensitiveFields = ['password', 'senha', 'token', 'secret', 'apiKey', 'api_key', 'credit_card', 'cartao'];
    const sanitized = cloneDeep(body);
    
    for (const field of sensitiveFields) {
      if (sanitized[field]) {
        sanitized[field] = '******';
      }
    }
    
    return sanitized;
  }

  /**
   * Valida um endpoint
   * @param {Object} endpoint Endpoint
   * @private
   */
  _validateEndpoint(endpoint) {
    if (!endpoint.path) {
      throw new Error('Caminho do endpoint é obrigatório');
    }
    
    if (!endpoint.method) {
      throw new Error('Método HTTP do endpoint é obrigatório');
    }
    
    if (!endpoint.handler || typeof endpoint.handler !== 'function') {
      throw new Error('Handler do endpoint é obrigatório e deve ser uma função');
    }
    
    // Validar método HTTP
    const validMethods = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS', 'HEAD'];
    if (!validMethods.includes(endpoint.method)) {
      throw new Error(`Método HTTP inválido: ${endpoint.method}`);
    }
  }

  /**
   * Valida uma chave de API
   * @param {Object} apiKey Chave de API
   * @private
   */
  _validateApiKey(apiKey) {
    if (!apiKey.client || !apiKey.client.id) {
      throw new Error('ID do cliente é obrigatório');
    }
    
    if (!apiKey.client.name) {
      throw new Error('Nome do cliente é obrigatório');
    }
  }
}

/**
 * Classe para Gerenciamento de Webhooks
 */
export class WebhookManager {
  constructor(config = {}) {
    this.config = {
      signatureSecret: config.signatureSecret || crypto.randomBytes(32).toString('hex'),
      signatureHeader: config.signatureHeader || 'X-Webhook-Signature',
      signatureAlgorithm: config.signatureAlgorithm || 'sha256',
      retryEnabled: config.retryEnabled !== undefined ? config.retryEnabled : true,
      maxRetries: config.maxRetries || 5,
      retryDelay: config.retryDelay || 60000, // 1 minuto
      retryBackoffFactor: config.retryBackoffFactor || 2,
      loggingEnabled: config.loggingEnabled !== undefined ? config.loggingEnabled : true,
      ...config
    };

    // Armazenamento de webhooks registrados
    this.webhooks = new Map();
    
    // Armazenamento de eventos
    this.events = [];
    
    // Armazenamento de entregas
    this.deliveries = new Map();
  }

  /**
   * Registra um novo webhook
   * @param {Object} webhookData Dados do webhook
   * @returns {Object} Webhook registrado
   */
  registerWebhook(webhookData) {
    const webhookId = webhookData.id || uuidv4();
    
    const webhook = {
      id: webhookId,
      name: webhookData.name,
      url: webhookData.url,
      events: webhookData.events || [],
      active: webhookData.active !== undefined ? webhookData.active : true,
      secret: webhookData.secret || crypto.randomBytes(16).toString('hex'),
      headers: webhookData.headers || {},
      createdAt: new Date().toISOString(),
      createdBy: webhookData.createdBy,
      metadata: webhookData.metadata || {}
    };
    
    // Validar webhook
    this._validateWebhook(webhook);
    
    // Armazenar webhook
    this.webhooks.set(webhookId, webhook);
    
    return {
      ...cloneDeep(webhook),
      secret: webhook.secret // Incluir o segredo apenas na criação
    };
  }

  /**
   * Atualiza um webhook existente
   * @param {string} webhookId ID do webhook
   * @param {Object} webhookData Novos dados do webhook
   * @returns {Object} Webhook atualizado
   */
  updateWebhook(webhookId, webhookData) {
    if (!this.webhooks.has(webhookId)) {
      throw new Error(`Webhook não encontrado: ${webhookId}`);
    }
    
    const currentWebhook = this.webhooks.get(webhookId);
    
    // Campos que não podem ser atualizados diretamente
    const protectedFields = ['id', 'createdAt', 'createdBy'];
    
    const updatedWebhook = {
      ...currentWebhook,
      ...Object.fromEntries(
        Object.entries(webhookData).filter(([key]) => !protectedFields.includes(key))
      ),
      updatedAt: new Date().toISOString()
    };
    
    // Validar webhook
    this._validateWebhook(updatedWebhook);
    
    // Armazenar webhook atualizado
    this.webhooks.set(webhookId, updatedWebhook);
    
    // Não retornar o segredo na atualização
    const result = cloneDeep(updatedWebhook);
    delete result.secret;
    
    return result;
  }

  /**
   * Remove um webhook
   * @param {string} webhookId ID do webhook
   * @returns {boolean} Sucesso da remoção
   */
  removeWebhook(webhookId) {
    if (!this.webhooks.has(webhookId)) {
      throw new Error(`Webhook não encontrado: ${webhookId}`);
    }
    
    return this.webhooks.delete(webhookId);
  }

  /**
   * Dispara um evento
   * @param {string} eventType Tipo do evento
   * @param {Object} eventData Dados do evento
   * @returns {Promise<Array>} Resultados das entregas
   */
  async triggerEvent(eventType, eventData) {
    const eventId = uuidv4();
    const timestamp = new Date().toISOString();
    
    const event = {
      id: eventId,
      type: eventType,
      data: eventData,
      timestamp
    };
    
    // Armazenar evento
    this.events.push(event);
    
    // Limitar tamanho do histórico de eventos
    if (this.events.length > 1000) {
      this.events.shift();
    }
    
    // Encontrar webhooks que assinam este evento
    const subscribedWebhooks = Array.from(this.webhooks.values())
      .filter(webhook => webhook.active && (webhook.events.includes(eventType) || webhook.events.includes('*')));
    
    // Entregar evento para cada webhook
    const deliveryPromises = subscribedWebhooks.map(webhook => 
      this._deliverEvent(webhook, event)
    );
    
    return Promise.all(deliveryPromises);
  }

  /**
   * Entrega um evento para um webhook
   * @param {Object} webhook Webhook
   * @param {Object} event Evento
   * @returns {Promise<Object>} Resultado da entrega
   * @private
   */
  async _deliverEvent(webhook, event) {
    const deliveryId = uuidv4();
    
    const delivery = {
      id: deliveryId,
      webhookId: webhook.id,
      eventId: event.id,
      eventType: event.type,
      url: webhook.url,
      status: 'pending', // 'pending', 'success', 'failed', 'retrying'
      attempts: 0,
      maxAttempts: this.config.maxRetries,
      createdAt: new Date().toISOString(),
      completedAt: null,
      response: null,
      error: null
    };
    
    // Armazenar entrega
    this.deliveries.set(deliveryId, delivery);
    
    // Preparar payload
    const payload = {
      id: deliveryId,
      event: event.type,
      timestamp: event.timestamp,
      data: event.data
    };
    
    // Calcular assinatura
    const signature = this._calculateSignature(payload, webhook.secret);
    
    // Preparar headers
    const headers = {
      'Content-Type': 'application/json',
      [this.config.signatureHeader]: signature,
      'X-Webhook-ID': webhook.id,
      'X-Delivery-ID': deliveryId,
      'X-Event-Type': event.type,
      ...webhook.headers
    };
    
    try {
      // Simular entrega (em um sistema real, isso seria uma requisição HTTP)
      const result = await this._simulateHttpRequest(webhook.url, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload)
      });
      
      // Atualizar entrega
      delivery.status = result.success ? 'success' : 'failed';
      delivery.attempts += 1;
      delivery.completedAt = new Date().toISOString();
      delivery.response = result.response;
      delivery.error = result.error;
      
      // Armazenar entrega atualizada
      this.deliveries.set(deliveryId, delivery);
      
      // Verificar se deve tentar novamente
      if (!result.success && this.config.retryEnabled && delivery.attempts < delivery.maxAttempts) {
        this._scheduleRetry(deliveryId, delivery.attempts);
      }
      
      return {
        deliveryId,
        success: result.success,
        status: delivery.status,
        attempts: delivery.attempts
      };
    } catch (error) {
      // Atualizar entrega em caso de erro
      delivery.status = 'failed';
      delivery.attempts += 1;
      delivery.completedAt = new Date().toISOString();
      delivery.error = error.message;
      
      // Armazenar entrega atualizada
      this.deliveries.set(deliveryId, delivery);
      
      // Verificar se deve tentar novamente
      if (this.config.retryEnabled && delivery.attempts < delivery.maxAttempts) {
        this._scheduleRetry(deliveryId, delivery.attempts);
      }
      
      return {
        deliveryId,
        success: false,
        status: delivery.status,
        attempts: delivery.attempts,
        error: error.message
      };
    }
  }

  /**
   * Agenda uma nova tentativa de entrega
   * @param {string} deliveryId ID da entrega
   * @param {number} attempts Número de tentativas já realizadas
   * @private
   */
  _scheduleRetry(deliveryId, attempts) {
    const delivery = this.deliveries.get(deliveryId);
    
    if (!delivery) {
      return;
    }
    
    // Calcular atraso com backoff exponencial
    const delay = this.config.retryDelay * Math.pow(this.config.retryBackoffFactor, attempts - 1);
    
    // Atualizar status
    delivery.status = 'retrying';
    this.deliveries.set(deliveryId, delivery);
    
    // Agendar nova tentativa
    setTimeout(async () => {
      const webhook = this.webhooks.get(delivery.webhookId);
      const event = this.events.find(e => e.id === delivery.eventId);
      
      if (webhook && event) {
        await this._deliverEvent(webhook, event);
      }
    }, delay);
  }

  /**
   * Simula uma requisição HTTP
   * @param {string} url URL
   * @param {Object} options Opções
   * @returns {Promise<Object>} Resultado
   * @private
   */
  async _simulateHttpRequest(url, options) {
    // Simular atraso de rede
    await new Promise(resolve => setTimeout(resolve, 100 + Math.random() * 500));
    
    // Simular sucesso ou falha
    const success = Math.random() > 0.2; // 80% de chance de sucesso
    
    if (success) {
      return {
        success: true,
        response: {
          status: 200,
          body: { message: 'Webhook received successfully' }
        }
      };
    } else {
      return {
        success: false,
        response: {
          status: 500,
          body: { error: 'Internal server error' }
        },
        error: 'Failed to deliver webhook'
      };
    }
  }

  /**
   * Calcula a assinatura de um payload
   * @param {Object} payload Payload
   * @param {string} secret Segredo
   * @returns {string} Assinatura
   * @private
   */
  _calculateSignature(payload, secret) {
    const hmac = crypto.createHmac(this.config.signatureAlgorithm, secret);
    hmac.update(typeof payload === 'string' ? payload : JSON.stringify(payload));
    return `${this.config.signatureAlgorithm}=${hmac.digest('hex')}`;
  }

  /**
   * Verifica a assinatura de um payload
   * @param {Object|string} payload Payload
   * @param {string} signature Assinatura
   * @param {string} secret Segredo
   * @returns {boolean} Validade da assinatura
   */
  verifySignature(payload, signature, secret) {
    const expectedSignature = this._calculateSignature(payload, secret);
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    );
  }

  /**
   * Lista todos os webhooks
   * @param {Object} filters Filtros para consulta
   * @returns {Array} Lista de webhooks
   */
  listWebhooks(filters = {}) {
    let webhooks = Array.from(this.webhooks.values()).map(webhook => {
      const result = cloneDeep(webhook);
      delete result.secret; // Não retornar o segredo
      return result;
    });
    
    // Aplicar filtros
    if (filters.active !== undefined) {
      webhooks = webhooks.filter(webhook => webhook.active === filters.active);
    }
    
    if (filters.event) {
      webhooks = webhooks.filter(webhook => 
        webhook.events.includes(filters.event) || webhook.events.includes('*')
      );
    }
    
    // Ordenar por data de criação (mais recente primeiro)
    webhooks.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    return webhooks;
  }

  /**
   * Lista entregas de um webhook
   * @param {string} webhookId ID do webhook
   * @param {Object} filters Filtros para consulta
   * @returns {Array} Lista de entregas
   */
  listDeliveries(webhookId, filters = {}) {
    let deliveries = Array.from(this.deliveries.values())
      .filter(delivery => delivery.webhookId === webhookId);
    
    // Aplicar filtros
    if (filters.status) {
      deliveries = deliveries.filter(delivery => delivery.status === filters.status);
    }
    
    if (filters.eventType) {
      deliveries = deliveries.filter(delivery => delivery.eventType === filters.eventType);
    }
    
    // Ordenar por data de criação (mais recente primeiro)
    deliveries.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Limitar resultados
    if (filters.limit) {
      deliveries = deliveries.slice(0, filters.limit);
    }
    
    return cloneDeep(deliveries);
  }

  /**
   * Obtém detalhes de uma entrega
   * @param {string} deliveryId ID da entrega
   * @returns {Object} Detalhes da entrega
   */
  getDeliveryDetails(deliveryId) {
    if (!this.deliveries.has(deliveryId)) {
      throw new Error(`Entrega não encontrada: ${deliveryId}`);
    }
    
    return cloneDeep(this.deliveries.get(deliveryId));
  }

  /**
   * Valida um webhook
   * @param {Object} webhook Webhook
   * @private
   */
  _validateWebhook(webhook) {
    if (!webhook.name) {
      throw new Error('Nome do webhook é obrigatório');
    }
    
    if (!webhook.url) {
      throw new Error('URL do webhook é obrigatória');
    }
    
    // Validar URL
    try {
      new URL(webhook.url);
    } catch (error) {
      throw new Error(`URL inválida: ${webhook.url}`);
    }
    
    // Validar eventos
    if (!webhook.events || webhook.events.length === 0) {
      throw new Error('Pelo menos um evento deve ser especificado');
    }
  }
}

/**
 * Serviço Integrado de APIs e Webhooks
 */
export class ApiWebhooksService {
  constructor(config = {}) {
    this.apiManager = new ApiManager(config.api);
    this.webhookManager = new WebhookManager(config.webhook);
    
    // Inicializar endpoints para webhooks
    this._initializeWebhookEndpoints();
  }

  /**
   * Inicializa endpoints para gerenciamento de webhooks
   * @private
   */
  _initializeWebhookEndpoints() {
    // Listar webhooks
    this.apiManager.registerEndpoint({
      path: '/webhooks',
      method: 'GET',
      description: 'Lista todos os webhooks registrados',
      authRequired: true,
      permissions: ['webhooks:read'],
      handler: async (req) => {
        const webhooks = this.webhookManager.listWebhooks(req.query);
        return {
          status: 200,
          body: {
            webhooks,
            count: webhooks.length
          }
        };
      }
    });
    
    // Criar webhook
    this.apiManager.registerEndpoint({
      path: '/webhooks',
      method: 'POST',
      description: 'Cria um novo webhook',
      authRequired: true,
      permissions: ['webhooks:write'],
      handler: async (req) => {
        try {
          const webhook = this.webhookManager.registerWebhook({
            ...req.body,
            createdBy: req.client.id
          });
          
          return {
            status: 201,
            body: webhook
          };
        } catch (error) {
          return {
            status: 400,
            body: {
              error: 'Bad Request',
              message: error.message
            }
          };
        }
      }
    });
    
    // Obter webhook
    this.apiManager.registerEndpoint({
      path: '/webhooks/:id',
      method: 'GET',
      description: 'Obtém detalhes de um webhook',
      authRequired: true,
      permissions: ['webhooks:read'],
      handler: async (req) => {
        try {
          const webhookId = req.params.id;
          const webhooks = this.webhookManager.listWebhooks();
          const webhook = webhooks.find(w => w.id === webhookId);
          
          if (!webhook) {
            return {
              status: 404,
              body: {
                error: 'Not Found',
                message: `Webhook não encontrado: ${webhookId}`
              }
            };
          }
          
          return {
            status: 200,
            body: webhook
          };
        } catch (error) {
          return {
            status: 500,
            body: {
              error: 'Internal Server Error',
              message: error.message
            }
          };
        }
      }
    });
    
    // Atualizar webhook
    this.apiManager.registerEndpoint({
      path: '/webhooks/:id',
      method: 'PUT',
      description: 'Atualiza um webhook existente',
      authRequired: true,
      permissions: ['webhooks:write'],
      handler: async (req) => {
        try {
          const webhookId = req.params.id;
          const webhook = this.webhookManager.updateWebhook(webhookId, {
            ...req.body,
            updatedBy: req.client.id
          });
          
          return {
            status: 200,
            body: webhook
          };
        } catch (error) {
          if (error.message.includes('não encontrado')) {
            return {
              status: 404,
              body: {
                error: 'Not Found',
                message: error.message
              }
            };
          }
          
          return {
            status: 400,
            body: {
              error: 'Bad Request',
              message: error.message
            }
          };
        }
      }
    });
    
    // Remover webhook
    this.apiManager.registerEndpoint({
      path: '/webhooks/:id',
      method: 'DELETE',
      description: 'Remove um webhook',
      authRequired: true,
      permissions: ['webhooks:write'],
      handler: async (req) => {
        try {
          const webhookId = req.params.id;
          const success = this.webhookManager.removeWebhook(webhookId);
          
          return {
            status: success ? 204 : 404,
            body: success ? null : {
              error: 'Not Found',
              message: `Webhook não encontrado: ${webhookId}`
            }
          };
        } catch (error) {
          if (error.message.includes('não encontrado')) {
            return {
              status: 404,
              body: {
                error: 'Not Found',
                message: error.message
              }
            };
          }
          
          return {
            status: 500,
            body: {
              error: 'Internal Server Error',
              message: error.message
            }
          };
        }
      }
    });
    
    // Listar entregas de um webhook
    this.apiManager.registerEndpoint({
      path: '/webhooks/:id/deliveries',
      method: 'GET',
      description: 'Lista entregas de um webhook',
      authRequired: true,
      permissions: ['webhooks:read'],
      handler: async (req) => {
        try {
          const webhookId = req.params.id;
          const deliveries = this.webhookManager.listDeliveries(webhookId, req.query);
          
          return {
            status: 200,
            body: {
              deliveries,
              count: deliveries.length
            }
          };
        } catch (error) {
          return {
            status: 500,
            body: {
              error: 'Internal Server Error',
              message: error.message
            }
          };
        }
      }
    });
    
    // Obter detalhes de uma entrega
    this.apiManager.registerEndpoint({
      path: '/webhooks/deliveries/:id',
      method: 'GET',
      description: 'Obtém detalhes de uma entrega',
      authRequired: true,
      permissions: ['webhooks:read'],
      handler: async (req) => {
        try {
          const deliveryId = req.params.id;
          const delivery = this.webhookManager.getDeliveryDetails(deliveryId);
          
          return {
            status: 200,
            body: delivery
          };
        } catch (error) {
          if (error.message.includes('não encontrada')) {
            return {
              status: 404,
              body: {
                error: 'Not Found',
                message: error.message
              }
            };
          }
          
          return {
            status: 500,
            body: {
              error: 'Internal Server Error',
              message: error.message
            }
          };
        }
      }
    });
  }

  /**
   * Registra um endpoint de API
   * @param {Object} endpointData Dados do endpoint
   * @returns {Object} Endpoint registrado
   */
  registerApiEndpoint(endpointData) {
    return this.apiManager.registerEndpoint(endpointData);
  }

  /**
   * Processa uma requisição para um endpoint
   * @param {Object} req Objeto de requisição
   * @returns {Promise<Object>} Resposta do endpoint
   */
  async processApiRequest(req) {
    return this.apiManager.processRequest(req);
  }

  /**
   * Cria uma nova chave de API
   * @param {Object} apiKeyData Dados da chave de API
   * @returns {Object} Chave de API criada
   */
  createApiKey(apiKeyData) {
    return this.apiManager.createApiKey(apiKeyData);
  }

  /**
   * Registra um novo webhook
   * @param {Object} webhookData Dados do webhook
   * @returns {Object} Webhook registrado
   */
  registerWebhook(webhookData) {
    return this.webhookManager.registerWebhook(webhookData);
  }

  /**
   * Dispara um evento
   * @param {string} eventType Tipo do evento
   * @param {Object} eventData Dados do evento
   * @returns {Promise<Array>} Resultados das entregas
   */
  async triggerEvent(eventType, eventData) {
    return this.webhookManager.triggerEvent(eventType, eventData);
  }

  /**
   * Gera documentação da API
   * @returns {Object} Documentação da API
   */
  generateApiDocumentation() {
    return this.apiManager.generateApiDocumentation();
  }
}

export default ApiWebhooksService;
