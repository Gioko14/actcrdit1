import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, precision_recall_curve, confusion_matrix
from sklearn.metrics import classification_report, roc_curve, auc, accuracy_score
import xgboost as xgb
import lightgbm as lgb
import joblib
import os
import yaml
import json
import logging
import datetime
import mlflow
import mlflow.sklearn
import mlflow.xgboost
import mlflow.lightgbm
import shap
import lime
import lime.lime_tabular
from alibi.explainers import AnchorTabular
import optuna
from optuna.integration import XGBoostPruningCallback

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("ml_scoring.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Carregar configuração
def load_config(config_path="config/config.yaml"):
    """Carrega configurações do arquivo YAML"""
    try:
        with open(config_path, 'r') as file:
            config = yaml.safe_load(file)
        return config
    except Exception as e:
        logger.error(f"Erro ao carregar configuração: {e}")
        # Configuração padrão
        return {
            "ml": {
                "random_state": 42,
                "test_size": 0.2,
                "cv_folds": 5,
                "scoring": "roc_auc"
            },
            "paths": {
                "data": "data",
                "models": "models"
            }
        }

# Classe principal para scoring de crédito
class CreditScoring:
    """
    Classe para modelagem de scoring de crédito
    Implementa pipeline completo de ML para previsão de risco
    """
    def __init__(self, config_path="config/config.yaml"):
        """Inicializa o modelo de scoring de crédito"""
        self.config = load_config(config_path)
        self.random_state = self.config["ml"]["random_state"]
        self.test_size = self.config["ml"]["test_size"]
        self.cv_folds = self.config["ml"]["cv_folds"]
        self.scoring = self.config["ml"]["scoring"]
        self.data_path = self.config["paths"]["data"]
        self.models_path = self.config["paths"]["models"]
        
        # Criar diretórios se não existirem
        os.makedirs(os.path.join(self.models_path, "trained"), exist_ok=True)
        os.makedirs(os.path.join(self.models_path, "deployed"), exist_ok=True)
        
        # Inicializar MLflow
        mlflow.set_tracking_uri("sqlite:///mlflow/mlflow.db")
        mlflow.set_experiment("credit_scoring")
        
        self.model = None
        self.preprocessor = None
        self.feature_names = None
        self.target_name = None
        self.model_metadata = {}
        
        logger.info("CreditScoring inicializado com sucesso")
    
    def load_data(self, file_path, target_column):
        """
        Carrega dados de um arquivo CSV ou Excel
        
        Args:
            file_path: Caminho para o arquivo de dados
            target_column: Nome da coluna alvo (variável dependente)
            
        Returns:
            X: Features
            y: Target
        """
        try:
            # Determinar o tipo de arquivo pela extensão
            if file_path.endswith('.csv'):
                df = pd.read_csv(file_path)
            elif file_path.endswith(('.xls', '.xlsx')):
                df = pd.read_excel(file_path)
            else:
                raise ValueError("Formato de arquivo não suportado. Use CSV ou Excel.")
            
            logger.info(f"Dados carregados com sucesso: {df.shape[0]} linhas, {df.shape[1]} colunas")
            
            # Separar features e target
            if target_column not in df.columns:
                raise ValueError(f"Coluna alvo '{target_column}' não encontrada nos dados")
            
            X = df.drop(columns=[target_column])
            y = df[target_column]
            
            self.feature_names = X.columns.tolist()
            self.target_name = target_column
            
            return X, y
        
        except Exception as e:
            logger.error(f"Erro ao carregar dados: {e}")
            raise
    
    def preprocess_data(self, X, categorical_features=None, numerical_features=None):
        """
        Cria e aplica preprocessador para dados categóricos e numéricos
        
        Args:
            X: DataFrame com features
            categorical_features: Lista de colunas categóricas (se None, detecta automaticamente)
            numerical_features: Lista de colunas numéricas (se None, detecta automaticamente)
            
        Returns:
            preprocessor: ColumnTransformer configurado
        """
        try:
            # Detectar tipos de colunas automaticamente se não especificados
            if categorical_features is None and numerical_features is None:
                categorical_features = X.select_dtypes(include=['object', 'category']).columns.tolist()
                numerical_features = X.select_dtypes(include=['int64', 'float64']).columns.tolist()
            
            logger.info(f"Features categóricas: {len(categorical_features)}, Features numéricas: {len(numerical_features)}")
            
            # Criar transformadores para cada tipo de feature
            categorical_transformer = Pipeline(steps=[
                ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
                ('onehot', OneHotEncoder(handle_unknown='ignore'))
            ])
            
            numerical_transformer = Pipeline(steps=[
                ('imputer', SimpleImputer(strategy='median')),
                ('scaler', StandardScaler())
            ])
            
            # Combinar transformadores
            self.preprocessor = ColumnTransformer(
                transformers=[
                    ('num', numerical_transformer, numerical_features),
                    ('cat', categorical_transformer, categorical_features)
                ])
            
            return self.preprocessor
        
        except Exception as e:
            logger.error(f"Erro ao preprocessar dados: {e}")
            raise
    
    def train_test_split(self, X, y):
        """
        Divide os dados em conjuntos de treino e teste
        
        Args:
            X: Features
            y: Target
            
        Returns:
            X_train, X_test, y_train, y_test: Conjuntos de treino e teste
        """
        try:
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, 
                test_size=self.test_size, 
                random_state=self.random_state,
                stratify=y
            )
            
            logger.info(f"Dados divididos: {X_train.shape[0]} amostras de treino, {X_test.shape[0]} amostras de teste")
            
            return X_train, X_test, y_train, y_test
        
        except Exception as e:
            logger.error(f"Erro ao dividir dados: {e}")
            raise
    
    def train_model(self, X_train, y_train, X_test, y_test, model_type="xgboost", tune_hyperparams=True):
        """
        Treina um modelo de scoring de crédito
        
        Args:
            X_train: Features de treino
            y_train: Target de treino
            X_test: Features de teste
            y_test: Target de teste
            model_type: Tipo de modelo ('logistic', 'random_forest', 'xgboost', 'lightgbm')
            tune_hyperparams: Se True, realiza otimização de hiperparâmetros
            
        Returns:
            model: Modelo treinado
            metrics: Métricas de performance
        """
        try:
            # Iniciar tracking do MLflow
            with mlflow.start_run() as run:
                run_id = run.info.run_id
                logger.info(f"MLflow run iniciado: {run_id}")
                
                # Registrar parâmetros
                mlflow.log_param("model_type", model_type)
                mlflow.log_param("random_state", self.random_state)
                mlflow.log_param("test_size", self.test_size)
                
                # Selecionar e configurar modelo
                if model_type == "logistic":
                    model = LogisticRegression(random_state=self.random_state, max_iter=1000)
                    model_params = {
                        "C": 1.0,
                        "penalty": "l2",
                        "solver": "lbfgs"
                    }
                
                elif model_type == "random_forest":
                    model = RandomForestClassifier(random_state=self.random_state)
                    model_params = {
                        "n_estimators": 100,
                        "max_depth": 10,
                        "min_samples_split": 2,
                        "min_samples_leaf": 1
                    }
                
                elif model_type == "xgboost":
                    model = xgb.XGBClassifier(random_state=self.random_state)
                    model_params = {
                        "n_estimators": 100,
                        "max_depth": 6,
                        "learning_rate": 0.1,
                        "subsample": 0.8,
                        "colsample_bytree": 0.8
                    }
                
                elif model_type == "lightgbm":
                    model = lgb.LGBMClassifier(random_state=self.random_state)
                    model_params = {
                        "n_estimators": 100,
                        "max_depth": 6,
                        "learning_rate": 0.1,
                        "num_leaves": 31,
                        "subsample": 0.8,
                        "colsample_bytree": 0.8
                    }
                
                else:
                    raise ValueError(f"Tipo de modelo não suportado: {model_type}")
                
                # Otimização de hiperparâmetros
                if tune_hyperparams:
                    logger.info(f"Iniciando otimização de hiperparâmetros para {model_type}")
                    model_params = self._tune_hyperparameters(X_train, y_train, model_type)
                    
                    # Atualizar modelo com melhores parâmetros
                    if model_type == "logistic":
                        model = LogisticRegression(
                            random_state=self.random_state,
                            C=model_params["C"],
                            penalty=model_params["penalty"],
                            solver=model_params["solver"],
                            max_iter=1000
                        )
                    
                    elif model_type == "random_forest":
                        model = RandomForestClassifier(
                            random_state=self.random_state,
                            n_estimators=model_params["n_estimators"],
                            max_depth=model_params["max_depth"],
                            min_samples_split=model_params["min_samples_split"],
                            min_samples_leaf=model_params["min_samples_leaf"]
                        )
                    
                    elif model_type == "xgboost":
                        model = xgb.XGBClassifier(
                            random_state=self.random_state,
                            n_estimators=model_params["n_estimators"],
                            max_depth=model_params["max_depth"],
                            learning_rate=model_params["learning_rate"],
                            subsample=model_params["subsample"],
                            colsample_bytree=model_params["colsample_bytree"]
                        )
                    
                    elif model_type == "lightgbm":
                        model = lgb.LGBMClassifier(
                            random_state=self.random_state,
                            n_estimators=model_params["n_estimators"],
                            max_depth=model_params["max_depth"],
                            learning_rate=model_params["learning_rate"],
                            num_leaves=model_params["num_leaves"],
                            subsample=model_params["subsample"],
                            colsample_bytree=model_params["colsample_bytree"]
                        )
                
                # Registrar hiperparâmetros
                for param_name, param_value in model_params.items():
                    mlflow.log_param(param_name, param_value)
                
                # Criar pipeline com preprocessamento
                pipeline = Pipeline(steps=[
                    ('preprocessor', self.preprocessor),
                    ('classifier', model)
                ])
                
                # Treinar modelo
                logger.info(f"Treinando modelo {model_type}")
                pipeline.fit(X_train, y_train)
                
                # Avaliar modelo
                y_pred_proba = pipeline.predict_proba(X_test)[:, 1]
                y_pred = pipeline.predict(X_test)
                
                # Calcular métricas
                metrics = self._calculate_metrics(y_test, y_pred, y_pred_proba)
                
                # Registrar métricas
                for metric_name, metric_value in metrics.items():
                    mlflow.log_metric(metric_name, metric_value)
                
                # Gerar e salvar gráficos
                self._generate_evaluation_plots(y_test, y_pred, y_pred_proba, run_id)
                
                # Gerar explicabilidade
                self._generate_explanations(pipeline, X_test, run_id)
                
                # Salvar modelo
                model_path = os.path.join(self.models_path, "trained", f"{model_type}_{run_id}.pkl")
                joblib.dump(pipeline, model_path)
                mlflow.log_artifact(model_path)
                
                # Registrar modelo no MLflow
                mlflow.sklearn.log_model(pipeline, "model")
                
                # Armazenar metadados do modelo
                self.model_metadata = {
                    "model_type": model_type,
                    "run_id": run_id,
                    "feature_names": self.feature_names,
                    "target_name": self.target_name,
                    "metrics": metrics,
                    "hyperparameters": model_params,
                    "training_date": datetime.datetime.now().isoformat(),
                    "model_path": model_path
                }
                
                # Salvar metadados
                metadata_path = os.path.join(self.models_path, "trained", f"{model_type}_{run_id}_metadata.json")
                with open(metadata_path, 'w') as f:
                    json.dump(self.model_metadata, f, indent=4)
                
                logger.info(f"Modelo treinado e salvo: {model_path}")
                logger.info(f"Métricas: {metrics}")
                
                self.model = pipeline
                
                return pipeline, metrics
        
        except Exception as e:
            logger.error(f"Erro ao treinar modelo: {e}")
            raise
    
    def _tune_hyperparameters(self, X, y, model_type):
        """
        Otimiza hiperparâmetros usando Optuna
        
        Args:
            X: Features
            y: Target
            model_type: Tipo de modelo
            
        Returns:
            best_params: Melhores hiperparâmetros
        """
        try:
            logger.info(f"Iniciando otimização de hiperparâmetros para {model_type}")
            
            # Definir função objetivo para Optuna
            def objective(trial):
                # Espaço de hiperparâmetros específico para cada modelo
                if model_type == "logistic":
                    params = {
                        "C": trial.suggest_float("C", 0.01, 10.0, log=True),
                        "penalty": trial.suggest_categorical("penalty", ["l1", "l2", "elasticnet", "none"]),
                        "solver": trial.suggest_categorical("solver", ["newton-cg", "lbfgs", "liblinear", "sag", "saga"])
                    }
                    
                    # Verificar compatibilidade de penalty e solver
                    if params["penalty"] == "elasticnet" and params["solver"] != "saga":
                        params["solver"] = "saga"
                    elif params["penalty"] == "l1" and params["solver"] not in ["liblinear", "saga"]:
                        params["solver"] = "saga"
                    elif params["penalty"] == "none" and params["solver"] in ["liblinear"]:
                        params["solver"] = "lbfgs"
                    
                    model = LogisticRegression(
                        random_state=self.random_state,
                        C=params["C"],
                        penalty=params["penalty"],
                        solver=params["solver"],
                        max_iter=1000
                    )
                
                elif model_type == "random_forest":
                    params = {
                        "n_estimators": trial.suggest_int("n_estimators", 50, 500),
                        "max_depth": trial.suggest_int("max_depth", 3, 30),
                        "min_samples_split": trial.suggest_int("min_samples_split", 2, 20),
                        "min_samples_leaf": trial.suggest_int("min_samples_leaf", 1, 10)
                    }
                    
                    model = RandomForestClassifier(
                        random_state=self.random_state,
                        n_estimators=params["n_estimators"],
                        max_depth=params["max_depth"],
                        min_samples_split=params["min_samples_split"],
                        min_samples_leaf=params["min_samples_leaf"]
                    )
                
                elif model_type == "xgboost":
                    params = {
                        "n_estimators": trial.suggest_int("n_estimators", 50, 500),
                        "max_depth": trial.suggest_int("max_depth", 3, 15),
                        "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
                        "subsample": trial.suggest_float("subsample", 0.5, 1.0),
                        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 1.0)
                    }
                    
                    model = xgb.XGBClassifier(
                        random_state=self.random_state,
                        n_estimators=params["n_estimators"],
                        max_depth=params["max_depth"],
                        learning_rate=params["learning_rate"],
                        subsample=params["subsample"],
                        colsample_bytree=params["colsample_bytree"]
                    )
                
                elif model_type == "lightgbm":
                    params = {
                        "n_estimators": trial.suggest_int("n_estimators", 50, 500),
                        "max_depth": trial.suggest_int("max_depth", 3, 15),
                        "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
                        "num_leaves": trial.suggest_int("num_leaves", 10, 100),
                        "subsample": trial.suggest_float("subsample", 0.5, 1.0),
                        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 1.0)
                    }
                    
                    model = lgb.LGBMClassifier(
                        random_state=self.random_state,
                        n_estimators=params["n_estimators"],
                        max_depth=params["max_depth"],
                        learning_rate=params["learning_rate"],
                        num_leaves=params["num_leaves"],
                        subsample=params["subsample"],
                        colsample_bytree=params["colsample_bytree"]
                    )
                
                else:
                    raise ValueError(f"Tipo de modelo não suportado: {model_type}")
                
                # Criar pipeline com preprocessamento
                pipeline = Pipeline(steps=[
                    ('preprocessor', self.preprocessor),
                    ('classifier', model)
                ])
                
                # Validação cruzada
                cv = StratifiedKFold(n_splits=self.cv_folds, shuffle=True, random_state=self.random_state)
                scores = cross_val_score(pipeline, X, y, cv=cv, scoring=self.scoring)
                
                return scores.mean()
            
            # Criar estudo Optuna
            study = optuna.create_study(direction="maximize")
            study.optimize(objective, n_trials=100, timeout=3600)
            
            logger.info(f"Melhores hiperparâmetros: {study.best_params}")
            logger.info(f"Melhor score: {study.best_value}")
            
            return study.best_params
        
        except Exception as e:
            logger.error(f"Erro na otimização de hiperparâmetros: {e}")
            raise
    
    def _calculate_metrics(self, y_true, y_pred, y_pred_proba):
        """
        Calcula métricas de performance do modelo
        
        Args:
            y_true: Valores reais
            y_pred: Valores previstos (classes)
            y_pred_proba: Probabilidades previstas
            
        Returns:
            metrics: Dicionário com métricas
        """
        try:
            # Calcular métricas básicas
            accuracy = accuracy_score(y_true, y_pred)
            roc_auc = roc_auc_score(y_true, y_pred_proba)
            
            # Calcular precision e recall para diferentes thresholds
            precision, recall, thresholds = precision_recall_curve(y_true, y_pred_proba)
            
            # Calcular F1 para cada threshold
            f1_scores = 2 * (precision * recall) / (precision + recall + 1e-10)
            best_threshold_idx = np.argmax(f1_scores)
            best_threshold = thresholds[best_threshold_idx] if best_threshold_idx < len(thresholds) else 0.5
            best_f1 = f1_scores[best_threshold_idx]
            
            # Calcular matriz de confusão
            tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
            
            # Calcular métricas adicionais
            precision_score = tp / (tp + fp) if (tp + fp) > 0 else 0
            recall_score = tp / (tp + fn) if (tp + fn) > 0 else 0
            specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
            
            # Calcular Gini e KS
            fpr, tpr, _ = roc_curve(y_true, y_pred_proba)
            gini = 2 * roc_auc - 1
            ks = np.max(np.abs(tpr - fpr))
            
            # Compilar métricas
            metrics = {
                "accuracy": accuracy,
                "roc_auc": roc_auc,
                "gini": gini,
                "ks": ks,
                "precision": precision_score,
                "recall": recall_score,
                "specificity": specificity,
                "f1_score": best_f1,
                "best_threshold": best_threshold,
                "true_positives": tp,
                "false_positives": fp,
                "true_negatives": tn,
                "false_negatives": fn
            }
            
            return metrics
        
        except Exception as e:
            logger.error(f"Erro ao calcular métricas: {e}")
            raise
    
    def _generate_evaluation_plots(self, y_true, y_pred, y_pred_proba, run_id):
        """
        Gera gráficos de avaliação do modelo
        
        Args:
            y_true: Valores reais
            y_pred: Valores previstos (classes)
            y_pred_proba: Probabilidades previstas
            run_id: ID do run do MLflow
        """
        try:
            # Criar diretório para gráficos
            plots_dir = os.path.join(self.models_path, "plots", run_id)
            os.makedirs(plots_dir, exist_ok=True)
            
            # ROC Curve
            plt.figure(figsize=(10, 8))
            fpr, tpr, _ = roc_curve(y_true, y_pred_proba)
            roc_auc = auc(fpr, tpr)
            
            plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (area = {roc_auc:.2f})')
            plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
            plt.xlim([0.0, 1.0])
            plt.ylim([0.0, 1.05])
            plt.xlabel('False Positive Rate')
            plt.ylabel('True Positive Rate')
            plt.title('Receiver Operating Characteristic (ROC)')
            plt.legend(loc="lower right")
            
            roc_path = os.path.join(plots_dir, 'roc_curve.png')
            plt.savefig(roc_path)
            plt.close()
            
            # Precision-Recall Curve
            plt.figure(figsize=(10, 8))
            precision, recall, _ = precision_recall_curve(y_true, y_pred_proba)
            pr_auc = auc(recall, precision)
            
            plt.plot(recall, precision, color='blue', lw=2, label=f'PR curve (area = {pr_auc:.2f})')
            plt.xlabel('Recall')
            plt.ylabel('Precision')
            plt.title('Precision-Recall Curve')
            plt.legend(loc="lower left")
            
            pr_path = os.path.join(plots_dir, 'precision_recall_curve.png')
            plt.savefig(pr_path)
            plt.close()
            
            # Confusion Matrix
            plt.figure(figsize=(10, 8))
            cm = confusion_matrix(y_true, y_pred)
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
            plt.xlabel('Predicted')
            plt.ylabel('Actual')
            plt.title('Confusion Matrix')
            
            cm_path = os.path.join(plots_dir, 'confusion_matrix.png')
            plt.savefig(cm_path)
            plt.close()
            
            # Distribution of Probabilities
            plt.figure(figsize=(10, 8))
            sns.histplot(y_pred_proba, bins=50, kde=True)
            plt.xlabel('Predicted Probability')
            plt.ylabel('Count')
            plt.title('Distribution of Predicted Probabilities')
            
            dist_path = os.path.join(plots_dir, 'probability_distribution.png')
            plt.savefig(dist_path)
            plt.close()
            
            # Log plots to MLflow
            mlflow.log_artifact(roc_path)
            mlflow.log_artifact(pr_path)
            mlflow.log_artifact(cm_path)
            mlflow.log_artifact(dist_path)
            
            logger.info(f"Gráficos de avaliação gerados e salvos em {plots_dir}")
        
        except Exception as e:
            logger.error(f"Erro ao gerar gráficos de avaliação: {e}")
            raise
    
    def _generate_explanations(self, model, X_test, run_id):
        """
        Gera explicações para o modelo usando SHAP e LIME
        
        Args:
            model: Modelo treinado
            X_test: Dados de teste
            run_id: ID do run do MLflow
        """
        try:
            # Criar diretório para explicações
            explanations_dir = os.path.join(self.models_path, "explanations", run_id)
            os.makedirs(explanations_dir, exist_ok=True)
            
            # Obter preprocessador e classificador do pipeline
            preprocessor = model.named_steps['preprocessor']
            classifier = model.named_steps['classifier']
            
            # Transformar dados para explicabilidade
            X_test_transformed = preprocessor.transform(X_test)
            
            # SHAP Explanations
            if hasattr(classifier, 'feature_importances_'):
                # Para modelos baseados em árvore
                explainer = shap.TreeExplainer(classifier)
                shap_values = explainer.shap_values(X_test_transformed)
                
                # Gerar gráfico de resumo SHAP
                plt.figure(figsize=(12, 10))
                shap.summary_plot(shap_values, X_test_transformed, show=False)
                plt.title('SHAP Feature Importance')
                
                shap_path = os.path.join(explanations_dir, 'shap_summary.png')
                plt.savefig(shap_path)
                plt.close()
                
                # Log SHAP plot to MLflow
                mlflow.log_artifact(shap_path)
            
            # LIME Explanations
            # Criar explicador LIME
            feature_names = []
            for name, transformer, features in preprocessor.transformers_:
                if hasattr(transformer, 'get_feature_names_out'):
                    transformed_features = transformer.get_feature_names_out(features)
                    feature_names.extend(transformed_features)
                else:
                    feature_names.extend(features)
            
            lime_explainer = lime.lime_tabular.LimeTabularExplainer(
                X_test_transformed,
                feature_names=feature_names,
                class_names=['0', '1'],
                mode='classification'
            )
            
            # Explicar uma instância de exemplo
            idx = 0
            exp = lime_explainer.explain_instance(
                X_test_transformed[idx], 
                model.predict_proba,
                num_features=10
            )
            
            # Salvar explicação LIME
            plt.figure(figsize=(12, 8))
            exp.as_pyplot_figure()
            
            lime_path = os.path.join(explanations_dir, 'lime_explanation.png')
            plt.savefig(lime_path)
            plt.close()
            
            # Log LIME plot to MLflow
            mlflow.log_artifact(lime_path)
            
            logger.info(f"Explicações geradas e salvas em {explanations_dir}")
        
        except Exception as e:
            logger.error(f"Erro ao gerar explicações: {e}")
            # Não interromper o fluxo se as explicações falharem
            logger.warning("Continuando sem explicações")
    
    def deploy_model(self, run_id=None):
        """
        Implanta um modelo treinado para produção
        
        Args:
            run_id: ID do run do MLflow (se None, usa o modelo atual)
            
        Returns:
            model_path: Caminho para o modelo implantado
        """
        try:
            if run_id is None and self.model is None:
                raise ValueError("Nenhum modelo disponível para implantação")
            
            if run_id is not None:
                # Carregar modelo do MLflow
                model = mlflow.sklearn.load_model(f"runs:/{run_id}/model")
                
                # Buscar metadados
                client = mlflow.tracking.MlflowClient()
                run = client.get_run(run_id)
                model_type = run.data.params.get("model_type", "unknown")
            else:
                # Usar modelo atual
                model = self.model
                model_type = self.model_metadata.get("model_type", "unknown")
                run_id = self.model_metadata.get("run_id", "current")
            
            # Salvar modelo na pasta de produção
            deploy_path = os.path.join(self.models_path, "deployed", f"{model_type}_{run_id}.pkl")
            joblib.dump(model, deploy_path)
            
            # Salvar metadados
            metadata = {
                "model_type": model_type,
                "run_id": run_id,
                "deployment_date": datetime.datetime.now().isoformat(),
                "model_path": deploy_path
            }
            
            metadata_path = os.path.join(self.models_path, "deployed", f"{model_type}_{run_id}_metadata.json")
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=4)
            
            logger.info(f"Modelo implantado com sucesso: {deploy_path}")
            
            return deploy_path
        
        except Exception as e:
            logger.error(f"Erro ao implantar modelo: {e}")
            raise
    
    def load_deployed_model(self, model_path=None):
        """
        Carrega um modelo implantado
        
        Args:
            model_path: Caminho para o modelo (se None, carrega o modelo mais recente)
            
        Returns:
            model: Modelo carregado
        """
        try:
            if model_path is None:
                # Buscar modelo mais recente
                deployed_dir = os.path.join(self.models_path, "deployed")
                model_files = [f for f in os.listdir(deployed_dir) if f.endswith('.pkl')]
                
                if not model_files:
                    raise ValueError("Nenhum modelo implantado encontrado")
                
                # Ordenar por data de modificação (mais recente primeiro)
                model_files.sort(key=lambda x: os.path.getmtime(os.path.join(deployed_dir, x)), reverse=True)
                model_path = os.path.join(deployed_dir, model_files[0])
            
            # Carregar modelo
            model = joblib.load(model_path)
            self.model = model
            
            logger.info(f"Modelo carregado com sucesso: {model_path}")
            
            return model
        
        except Exception as e:
            logger.error(f"Erro ao carregar modelo: {e}")
            raise
    
    def predict(self, X, threshold=0.5):
        """
        Realiza previsões com o modelo carregado
        
        Args:
            X: Dados para previsão
            threshold: Limiar de classificação
            
        Returns:
            predictions: Previsões (classes)
            probabilities: Probabilidades
        """
        try:
            if self.model is None:
                raise ValueError("Nenhum modelo carregado")
            
            # Fazer previsões
            probabilities = self.model.predict_proba(X)[:, 1]
            predictions = (probabilities >= threshold).astype(int)
            
            logger.info(f"Previsões realizadas para {len(X)} amostras")
            
            return predictions, probabilities
        
        except Exception as e:
            logger.error(f"Erro ao realizar previsões: {e}")
            raise
    
    def explain_prediction(self, X, idx=0):
        """
        Explica uma previsão específica
        
        Args:
            X: Dados para explicação
            idx: Índice da amostra a ser explicada
            
        Returns:
            explanation: Explicação da previsão
        """
        try:
            if self.model is None:
                raise ValueError("Nenhum modelo carregado")
            
            # Obter preprocessador e classificador do pipeline
            preprocessor = self.model.named_steps['preprocessor']
            classifier = self.model.named_steps['classifier']
            
            # Transformar dados
            X_transformed = preprocessor.transform(X)
            
            # Fazer previsão
            prediction = self.model.predict(X.iloc[[idx]])
            probability = self.model.predict_proba(X.iloc[[idx]])[:, 1]
            
            # Criar explicador LIME
            feature_names = []
            for name, transformer, features in preprocessor.transformers_:
                if hasattr(transformer, 'get_feature_names_out'):
                    transformed_features = transformer.get_feature_names_out(features)
                    feature_names.extend(transformed_features)
                else:
                    feature_names.extend(features)
            
            lime_explainer = lime.lime_tabular.LimeTabularExplainer(
                X_transformed,
                feature_names=feature_names,
                class_names=['0', '1'],
                mode='classification'
            )
            
            # Explicar a instância
            exp = lime_explainer.explain_instance(
                X_transformed[idx], 
                self.model.predict_proba,
                num_features=10
            )
            
            # Criar dicionário de explicação
            explanation = {
                "prediction": int(prediction[0]),
                "probability": float(probability[0]),
                "features": exp.as_list(),
                "local_explanation": {
                    "feature_importance": exp.as_list(),
                    "intercept": exp.intercept[1]
                }
            }
            
            logger.info(f"Explicação gerada para a amostra {idx}")
            
            return explanation
        
        except Exception as e:
            logger.error(f"Erro ao explicar previsão: {e}")
            raise
    
    def monitor_model_performance(self, X, y):
        """
        Monitora a performance do modelo em novos dados
        
        Args:
            X: Features
            y: Target
            
        Returns:
            drift_metrics: Métricas de drift
        """
        try:
            if self.model is None:
                raise ValueError("Nenhum modelo carregado")
            
            # Fazer previsões
            y_pred = self.model.predict(X)
            y_pred_proba = self.model.predict_proba(X)[:, 1]
            
            # Calcular métricas
            metrics = self._calculate_metrics(y, y_pred, y_pred_proba)
            
            # Comparar com métricas originais (se disponíveis)
            drift_metrics = {}
            if self.model_metadata and "metrics" in self.model_metadata:
                original_metrics = self.model_metadata["metrics"]
                
                for metric_name, metric_value in metrics.items():
                    if metric_name in original_metrics:
                        original_value = original_metrics[metric_name]
                        drift = metric_value - original_value
                        drift_pct = (drift / original_value) * 100 if original_value != 0 else float('inf')
                        
                        drift_metrics[metric_name] = {
                            "current": metric_value,
                            "original": original_value,
                            "drift": drift,
                            "drift_pct": drift_pct
                        }
            
            # Registrar métricas de drift
            logger.info(f"Métricas de drift: {drift_metrics}")
            
            return drift_metrics
        
        except Exception as e:
            logger.error(f"Erro ao monitorar performance do modelo: {e}")
            raise

# Função principal para demonstração
def main():
    """Função principal para demonstração do scoring de crédito"""
    try:
        # Inicializar modelo de scoring
        credit_scoring = CreditScoring()
        
        # Gerar dados sintéticos para demonstração
        from sklearn.datasets import make_classification
        
        X, y = make_classification(
            n_samples=1000,
            n_features=20,
            n_informative=10,
            n_redundant=5,
            n_classes=2,
            random_state=42
        )
        
        # Converter para DataFrame
        X_df = pd.DataFrame(X, columns=[f'feature_{i}' for i in range(X.shape[1])])
        y_series = pd.Series(y, name='target')
        
        # Adicionar algumas features categóricas
        X_df['category_1'] = np.random.choice(['A', 'B', 'C'], size=X_df.shape[0])
        X_df['category_2'] = np.random.choice(['X', 'Y', 'Z'], size=X_df.shape[0])
        
        # Dividir dados
        X_train, X_test, y_train, y_test = credit_scoring.train_test_split(X_df, y_series)
        
        # Preprocessar dados
        categorical_features = ['category_1', 'category_2']
        numerical_features = [col for col in X_df.columns if col not in categorical_features]
        credit_scoring.preprocess_data(X_train, categorical_features, numerical_features)
        
        # Treinar modelo
        model, metrics = credit_scoring.train_model(
            X_train, y_train, X_test, y_test,
            model_type="xgboost",
            tune_hyperparams=True
        )
        
        # Implantar modelo
        deploy_path = credit_scoring.deploy_model()
        
        # Carregar modelo implantado
        loaded_model = credit_scoring.load_deployed_model(deploy_path)
        
        # Fazer previsões
        predictions, probabilities = credit_scoring.predict(X_test)
        
        # Explicar uma previsão
        explanation = credit_scoring.explain_prediction(X_test, idx=0)
        
        # Monitorar performance
        drift_metrics = credit_scoring.monitor_model_performance(X_test, y_test)
        
        logger.info("Demonstração concluída com sucesso!")
    
    except Exception as e:
        logger.error(f"Erro na demonstração: {e}")

if __name__ == "__main__":
    main()
