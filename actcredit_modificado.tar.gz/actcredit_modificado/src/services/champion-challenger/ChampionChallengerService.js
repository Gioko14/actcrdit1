/**
 * Serviço de Champion-Challenger e Simulação
 * Implementa funcionalidades para testes A/B de modelos e políticas,
 * simulação de cenários e otimização contínua de decisões de crédito.
 */

import { v4 as uuidv4 } from 'uuid';
import { cloneDeep, get, set, merge } from 'lodash';

/**
 * Classe para Gestão de Experimentos Champion-Challenger
 */
export class ChampionChallengerManager {
  constructor(config = {}) {
    this.config = {
      storageMethod: config.storageMethod || 'memory', // 'memory', 'database'
      defaultTrafficAllocation: config.defaultTrafficAllocation || 0.1, // 10% para challengers por padrão
      minExperimentDuration: config.minExperimentDuration || 7, // 7 dias mínimo
      maxExperimentDuration: config.maxExperimentDuration || 90, // 90 dias máximo
      autoPromoteThreshold: config.autoPromoteThreshold || 0.05, // 5% de melhoria para promoção automática
      ...config
    };

    // Armazenamento de experimentos
    this.experiments = new Map();
    
    // Armazenamento de variantes
    this.variants = new Map();
    
    // Armazenamento de resultados
    this.results = new Map();
    
    // Armazenamento de decisões
    this.decisions = new Map();
  }

  /**
   * Cria um novo experimento champion-challenger
   * @param {Object} experimentData Dados do experimento
   * @returns {Promise<Object>} Experimento criado
   */
  async createExperiment(experimentData) {
    const experimentId = experimentData.id || uuidv4();
    
    const experiment = {
      id: experimentId,
      name: experimentData.name,
      description: experimentData.description || '',
      type: experimentData.type, // 'model', 'policy', 'rule', 'parameter'
      entityId: experimentData.entityId, // ID do modelo, política ou regra
      entityType: experimentData.entityType, // Tipo específico da entidade
      owner: experimentData.owner,
      team: experimentData.team || [],
      status: 'draft', // 'draft', 'active', 'paused', 'completed', 'cancelled'
      startDate: experimentData.startDate,
      endDate: experimentData.endDate,
      metrics: experimentData.metrics || [], // Métricas para avaliação
      primaryMetric: experimentData.primaryMetric, // Métrica principal
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      metadata: experimentData.metadata || {}
    };
    
    // Validar experimento
    this._validateExperiment(experiment);
    
    // Armazenar experimento
    this.experiments.set(experimentId, experiment);
    
    // Criar variante champion
    if (experimentData.champion) {
      await this.addVariant(experimentId, {
        ...experimentData.champion,
        isChampion: true,
        trafficAllocation: 1 - this._calculateTotalChallengerAllocation(experimentData.challengers || [])
      });
    }
    
    // Criar variantes challenger
    if (experimentData.challengers && experimentData.challengers.length > 0) {
      for (const challenger of experimentData.challengers) {
        await this.addVariant(experimentId, {
          ...challenger,
          isChampion: false
        });
      }
    }
    
    return cloneDeep(experiment);
  }

  /**
   * Adiciona uma variante a um experimento
   * @param {string} experimentId ID do experimento
   * @param {Object} variantData Dados da variante
   * @returns {Promise<Object>} Variante adicionada
   */
  async addVariant(experimentId, variantData) {
    if (!this.experiments.has(experimentId)) {
      throw new Error(`Experimento não encontrado: ${experimentId}`);
    }
    
    const experiment = this.experiments.get(experimentId);
    
    // Verificar se o experimento já está ativo ou concluído
    if (['active', 'completed'].includes(experiment.status)) {
      throw new Error(`Não é possível adicionar variantes a um experimento ${experiment.status}`);
    }
    
    // Gerar ID da variante
    const variantId = variantData.id || uuidv4();
    
    // Criar variante
    const variant = {
      id: variantId,
      experimentId,
      name: variantData.name,
      description: variantData.description || '',
      isChampion: variantData.isChampion || false,
      entityVersionId: variantData.entityVersionId, // ID da versão do modelo, política ou regra
      trafficAllocation: variantData.trafficAllocation || this._getDefaultTrafficAllocation(experiment, variantData.isChampion),
      parameters: variantData.parameters || {},
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      metadata: variantData.metadata || {}
    };
    
    // Validar variante
    this._validateVariant(variant, experiment);
    
    // Armazenar variante
    if (!this.variants.has(experimentId)) {
      this.variants.set(experimentId, new Map());
    }
    
    this.variants.get(experimentId).set(variantId, variant);
    
    // Atualizar experimento
    experiment.updatedAt = new Date().toISOString();
    if (variant.isChampion) {
      experiment.championVariantId = variantId;
    }
    
    // Armazenar experimento atualizado
    this.experiments.set(experimentId, experiment);
    
    return cloneDeep(variant);
  }

  /**
   * Atualiza o status de um experimento
   * @param {string} experimentId ID do experimento
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @returns {Promise<Object>} Experimento atualizado
   */
  async updateExperimentStatus(experimentId, status, metadata = {}) {
    if (!this.experiments.has(experimentId)) {
      throw new Error(`Experimento não encontrado: ${experimentId}`);
    }
    
    const experiment = this.experiments.get(experimentId);
    
    // Validar transição de status
    this._validateStatusTransition(experiment.status, status);
    
    // Atualizar status
    experiment.status = status;
    experiment.updatedAt = new Date().toISOString();
    
    // Adicionar metadados específicos do status
    if (status === 'active') {
      experiment.activatedAt = new Date().toISOString();
      experiment.activatedBy = metadata.activatedBy;
      
      // Se a data de início não foi definida, usar a data atual
      if (!experiment.startDate) {
        experiment.startDate = experiment.activatedAt;
      }
    } else if (status === 'paused') {
      experiment.pausedAt = new Date().toISOString();
      experiment.pausedBy = metadata.pausedBy;
      experiment.pauseReason = metadata.pauseReason;
    } else if (status === 'completed') {
      experiment.completedAt = new Date().toISOString();
      experiment.completedBy = metadata.completedBy;
      experiment.completionNotes = metadata.completionNotes;
      
      // Determinar o vencedor
      if (metadata.winnerVariantId) {
        experiment.winnerVariantId = metadata.winnerVariantId;
      } else {
        // Tentar determinar o vencedor automaticamente
        const winner = await this._determineWinner(experimentId);
        if (winner) {
          experiment.winnerVariantId = winner.variantId;
          experiment.winnerMetrics = winner.metrics;
          experiment.winnerImprovement = winner.improvement;
        }
      }
    } else if (status === 'cancelled') {
      experiment.cancelledAt = new Date().toISOString();
      experiment.cancelledBy = metadata.cancelledBy;
      experiment.cancellationReason = metadata.cancellationReason;
    }
    
    // Atualizar metadados
    experiment.metadata = {
      ...experiment.metadata,
      ...metadata
    };
    
    // Armazenar experimento atualizado
    this.experiments.set(experimentId, experiment);
    
    return cloneDeep(experiment);
  }

  /**
   * Registra resultados para uma variante
   * @param {string} experimentId ID do experimento
   * @param {string} variantId ID da variante
   * @param {Object} resultsData Dados dos resultados
   * @returns {Promise<Object>} Resultados registrados
   */
  async recordVariantResults(experimentId, variantId, resultsData) {
    if (!this.experiments.has(experimentId)) {
      throw new Error(`Experimento não encontrado: ${experimentId}`);
    }
    
    if (!this.variants.has(experimentId) || !this.variants.get(experimentId).has(variantId)) {
      throw new Error(`Variante não encontrada: ${experimentId}/${variantId}`);
    }
    
    const experiment = this.experiments.get(experimentId);
    const variant = this.variants.get(experimentId).get(variantId);
    
    // Verificar se o experimento está ativo
    if (experiment.status !== 'active') {
      throw new Error(`Não é possível registrar resultados para um experimento ${experiment.status}`);
    }
    
    // Gerar ID dos resultados
    const resultId = uuidv4();
    
    // Criar resultados
    const result = {
      id: resultId,
      experimentId,
      variantId,
      timestamp: new Date().toISOString(),
      metrics: resultsData.metrics || {},
      sampleSize: resultsData.sampleSize || 0,
      period: {
        startDate: resultsData.startDate || experiment.startDate,
        endDate: resultsData.endDate || new Date().toISOString()
      },
      metadata: resultsData.metadata || {}
    };
    
    // Validar resultados
    this._validateResults(result, experiment);
    
    // Armazenar resultados
    if (!this.results.has(experimentId)) {
      this.results.set(experimentId, new Map());
    }
    
    if (!this.results.get(experimentId).has(variantId)) {
      this.results.get(experimentId).set(variantId, []);
    }
    
    this.results.get(experimentId).get(variantId).push(result);
    
    // Verificar se deve promover automaticamente
    if (this.config.autoPromoteEnabled && variant.isChampion === false) {
      await this._checkForAutoPromotion(experimentId, variantId, result);
    }
    
    return cloneDeep(result);
  }

  /**
   * Registra uma decisão tomada por uma variante
   * @param {string} experimentId ID do experimento
   * @param {string} variantId ID da variante
   * @param {Object} decisionData Dados da decisão
   * @returns {Promise<Object>} Decisão registrada
   */
  async recordDecision(experimentId, variantId, decisionData) {
    if (!this.experiments.has(experimentId)) {
      throw new Error(`Experimento não encontrado: ${experimentId}`);
    }
    
    if (!this.variants.has(experimentId) || !this.variants.get(experimentId).has(variantId)) {
      throw new Error(`Variante não encontrada: ${experimentId}/${variantId}`);
    }
    
    const experiment = this.experiments.get(experimentId);
    
    // Verificar se o experimento está ativo
    if (experiment.status !== 'active') {
      throw new Error(`Não é possível registrar decisões para um experimento ${experiment.status}`);
    }
    
    // Gerar ID da decisão
    const decisionId = uuidv4();
    
    // Criar decisão
    const decision = {
      id: decisionId,
      experimentId,
      variantId,
      entityId: decisionData.entityId, // ID da entidade avaliada (ex: cliente, proposta)
      timestamp: new Date().toISOString(),
      decision: decisionData.decision, // Resultado da decisão (ex: 'approved', 'rejected')
      score: decisionData.score, // Score calculado
      factors: decisionData.factors || [], // Fatores que influenciaram a decisão
      metadata: decisionData.metadata || {}
    };
    
    // Armazenar decisão
    if (!this.decisions.has(experimentId)) {
      this.decisions.set(experimentId, []);
    }
    
    this.decisions.get(experimentId).push(decision);
    
    return cloneDeep(decision);
  }

  /**
   * Seleciona uma variante para uma entidade específica
   * @param {string} experimentId ID do experimento
   * @param {string} entityId ID da entidade (ex: cliente, proposta)
   * @returns {Promise<Object>} Variante selecionada
   */
  async selectVariant(experimentId, entityId) {
    if (!this.experiments.has(experimentId)) {
      throw new Error(`Experimento não encontrado: ${experimentId}`);
    }
    
    const experiment = this.experiments.get(experimentId);
    
    // Verificar se o experimento está ativo
    if (experiment.status !== 'active') {
      // Se não estiver ativo, retornar o champion
      if (experiment.championVariantId && this.variants.has(experimentId) && 
          this.variants.get(experimentId).has(experiment.championVariantId)) {
        return cloneDeep(this.variants.get(experimentId).get(experiment.championVariantId));
      }
      throw new Error(`Experimento não está ativo: ${experimentId}`);
    }
    
    // Obter todas as variantes do experimento
    if (!this.variants.has(experimentId)) {
      throw new Error(`Nenhuma variante encontrada para o experimento: ${experimentId}`);
    }
    
    const variants = Array.from(this.variants.get(experimentId).values());
    
    // Verificar se há variantes
    if (variants.length === 0) {
      throw new Error(`Nenhuma variante encontrada para o experimento: ${experimentId}`);
    }
    
    // Se houver apenas uma variante, retorná-la
    if (variants.length === 1) {
      return cloneDeep(variants[0]);
    }
    
    // Verificar se a entidade já foi atribuída a uma variante
    if (this.decisions.has(experimentId)) {
      const existingDecision = this.decisions.get(experimentId)
        .find(decision => decision.entityId === entityId);
      
      if (existingDecision) {
        const existingVariant = this.variants.get(experimentId).get(existingDecision.variantId);
        if (existingVariant) {
          return cloneDeep(existingVariant);
        }
      }
    }
    
    // Selecionar variante com base na alocação de tráfego
    const selectedVariant = this._selectVariantByTrafficAllocation(variants, entityId);
    
    return cloneDeep(selectedVariant);
  }

  /**
   * Promove uma variante challenger para champion
   * @param {string} experimentId ID do experimento
   * @param {string} variantId ID da variante challenger
   * @param {Object} metadata Metadados adicionais
   * @returns {Promise<Object>} Resultado da promoção
   */
  async promoteChallenger(experimentId, variantId, metadata = {}) {
    if (!this.experiments.has(experimentId)) {
      throw new Error(`Experimento não encontrado: ${experimentId}`);
    }
    
    if (!this.variants.has(experimentId) || !this.variants.get(experimentId).has(variantId)) {
      throw new Error(`Variante não encontrada: ${experimentId}/${variantId}`);
    }
    
    const experiment = this.experiments.get(experimentId);
    const variant = this.variants.get(experimentId).get(variantId);
    
    // Verificar se a variante é um challenger
    if (variant.isChampion) {
      throw new Error(`A variante já é o champion: ${variantId}`);
    }
    
    // Verificar se há um champion atual
    if (!experiment.championVariantId || !this.variants.get(experimentId).has(experiment.championVariantId)) {
      throw new Error(`Não há um champion atual para o experimento: ${experimentId}`);
    }
    
    const currentChampion = this.variants.get(experimentId).get(experiment.championVariantId);
    
    // Atualizar o champion atual para não ser mais o champion
    currentChampion.isChampion = false;
    currentChampion.updatedAt = new Date().toISOString();
    currentChampion.metadata = {
      ...currentChampion.metadata,
      demotedAt: new Date().toISOString(),
      demotedBy: metadata.promotedBy || 'system',
      demotionReason: metadata.promotionReason || 'Challenger promoted'
    };
    
    // Atualizar o challenger para ser o novo champion
    variant.isChampion = true;
    variant.updatedAt = new Date().toISOString();
    variant.metadata = {
      ...variant.metadata,
      promotedAt: new Date().toISOString(),
      promotedBy: metadata.promotedBy || 'system',
      promotionReason: metadata.promotionReason || 'Better performance'
    };
    
    // Atualizar o experimento
    experiment.championVariantId = variantId;
    experiment.updatedAt = new Date().toISOString();
    experiment.metadata = {
      ...experiment.metadata,
      lastChampionChange: {
        timestamp: new Date().toISOString(),
        previousChampionId: currentChampion.id,
        newChampionId: variant.id,
        reason: metadata.promotionReason || 'Better performance'
      }
    };
    
    // Armazenar atualizações
    this.variants.get(experimentId).set(currentChampion.id, currentChampion);
    this.variants.get(experimentId).set(variant.id, variant);
    this.experiments.set(experimentId, experiment);
    
    return {
      success: true,
      timestamp: new Date().toISOString(),
      experimentId,
      previousChampionId: currentChampion.id,
      newChampionId: variant.id,
      reason: metadata.promotionReason || 'Better performance'
    };
  }

  /**
   * Obtém um experimento pelo ID
   * @param {string} experimentId ID do experimento
   * @returns {Promise<Object>} Experimento
   */
  async getExperiment(experimentId) {
    if (!this.experiments.has(experimentId)) {
      throw new Error(`Experimento não encontrado: ${experimentId}`);
    }
    
    return cloneDeep(this.experiments.get(experimentId));
  }

  /**
   * Lista todos os experimentos
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de experimentos
   */
  async listExperiments(filters = {}) {
    let experiments = Array.from(this.experiments.values());
    
    // Aplicar filtros
    if (filters.status) {
      experiments = experiments.filter(experiment => experiment.status === filters.status);
    }
    
    if (filters.type) {
      experiments = experiments.filter(experiment => experiment.type === filters.type);
    }
    
    if (filters.entityId) {
      experiments = experiments.filter(experiment => experiment.entityId === filters.entityId);
    }
    
    if (filters.owner) {
      experiments = experiments.filter(experiment => experiment.owner === filters.owner);
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      experiments = experiments.filter(experiment => !experiment.startDate || new Date(experiment.startDate) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      experiments = experiments.filter(experiment => !experiment.endDate || new Date(experiment.endDate) <= endDate);
    }
    
    // Ordenar por data de criação (mais recente primeiro)
    experiments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Limitar resultados
    if (filters.limit) {
      experiments = experiments.slice(0, filters.limit);
    }
    
    return cloneDeep(experiments);
  }

  /**
   * Obtém uma variante pelo ID
   * @param {string} experimentId ID do experimento
   * @param {string} variantId ID da variante
   * @returns {Promise<Object>} Variante
   */
  async getVariant(experimentId, variantId) {
    if (!this.variants.has(experimentId) || !this.variants.get(experimentId).has(variantId)) {
      throw new Error(`Variante não encontrada: ${experimentId}/${variantId}`);
    }
    
    return cloneDeep(this.variants.get(experimentId).get(variantId));
  }

  /**
   * Lista todas as variantes de um experimento
   * @param {string} experimentId ID do experimento
   * @returns {Promise<Array>} Lista de variantes
   */
  async listVariants(experimentId) {
    if (!this.variants.has(experimentId)) {
      return [];
    }
    
    const variants = Array.from(this.variants.get(experimentId).values());
    
    // Ordenar: champion primeiro, depois por nome
    variants.sort((a, b) => {
      if (a.isChampion && !b.isChampion) return -1;
      if (!a.isChampion && b.isChampion) return 1;
      return a.name.localeCompare(b.name);
    });
    
    return cloneDeep(variants);
  }

  /**
   * Obtém resultados de uma variante
   * @param {string} experimentId ID do experimento
   * @param {string} variantId ID da variante
   * @returns {Promise<Array>} Lista de resultados
   */
  async getVariantResults(experimentId, variantId) {
    if (!this.results.has(experimentId) || !this.results.get(experimentId).has(variantId)) {
      return [];
    }
    
    return cloneDeep(this.results.get(experimentId).get(variantId));
  }

  /**
   * Obtém decisões de um experimento
   * @param {string} experimentId ID do experimento
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de decisões
   */
  async getExperimentDecisions(experimentId, filters = {}) {
    if (!this.decisions.has(experimentId)) {
      return [];
    }
    
    let decisions = this.decisions.get(experimentId);
    
    // Aplicar filtros
    if (filters.variantId) {
      decisions = decisions.filter(decision => decision.variantId === filters.variantId);
    }
    
    if (filters.entityId) {
      decisions = decisions.filter(decision => decision.entityId === filters.entityId);
    }
    
    if (filters.decision) {
      decisions = decisions.filter(decision => decision.decision === filters.decision);
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      decisions = decisions.filter(decision => new Date(decision.timestamp) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      decisions = decisions.filter(decision => new Date(decision.timestamp) <= endDate);
    }
    
    // Ordenar por timestamp (mais recente primeiro)
    decisions.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    // Limitar resultados
    if (filters.limit) {
      decisions = decisions.slice(0, filters.limit);
    }
    
    return cloneDeep(decisions);
  }

  /**
   * Gera um relatório de comparação de variantes
   * @param {string} experimentId ID do experimento
   * @returns {Promise<Object>} Relatório de comparação
   */
  async generateComparisonReport(experimentId) {
    if (!this.experiments.has(experimentId)) {
      throw new Error(`Experimento não encontrado: ${experimentId}`);
    }
    
    const experiment = this.experiments.get(experimentId);
    
    // Verificar se há variantes
    if (!this.variants.has(experimentId)) {
      throw new Error(`Nenhuma variante encontrada para o experimento: ${experimentId}`);
    }
    
    const variants = Array.from(this.variants.get(experimentId).values());
    
    if (variants.length === 0) {
      throw new Error(`Nenhuma variante encontrada para o experimento: ${experimentId}`);
    }
    
    // Encontrar o champion
    const champion = variants.find(variant => variant.isChampion);
    
    if (!champion) {
      throw new Error(`Nenhum champion encontrado para o experimento: ${experimentId}`);
    }
    
    // Obter resultados de todas as variantes
    const variantResults = {};
    const variantMetrics = {};
    
    for (const variant of variants) {
      const results = await this.getVariantResults(experimentId, variant.id);
      variantResults[variant.id] = results;
      
      // Calcular métricas agregadas
      variantMetrics[variant.id] = this._calculateAggregateMetrics(results, experiment.metrics);
    }
    
    // Calcular comparações com o champion
    const comparisons = {};
    
    for (const variant of variants.filter(v => !v.isChampion)) {
      comparisons[variant.id] = this._compareWithChampion(
        variantMetrics[champion.id],
        variantMetrics[variant.id],
        experiment.metrics
      );
    }
    
    // Gerar relatório
    const report = {
      experimentId,
      experimentName: experiment.name,
      generatedAt: new Date().toISOString(),
      status: experiment.status,
      duration: {
        startDate: experiment.startDate,
        endDate: experiment.endDate || new Date().toISOString(),
        daysRunning: this._calculateDaysRunning(experiment.startDate)
      },
      champion: {
        id: champion.id,
        name: champion.name,
        metrics: variantMetrics[champion.id],
        sampleSize: this._calculateTotalSampleSize(variantResults[champion.id])
      },
      challengers: variants
        .filter(v => !v.isChampion)
        .map(challenger => ({
          id: challenger.id,
          name: challenger.name,
          metrics: variantMetrics[challenger.id],
          comparison: comparisons[challenger.id],
          sampleSize: this._calculateTotalSampleSize(variantResults[challenger.id])
        })),
      recommendations: this._generateRecommendations(
        experiment,
        champion,
        variants.filter(v => !v.isChampion),
        comparisons
      )
    };
    
    return report;
  }

  /**
   * Calcula a alocação total de tráfego para challengers
   * @param {Array} challengers Lista de challengers
   * @returns {number} Alocação total
   * @private
   */
  _calculateTotalChallengerAllocation(challengers) {
    if (!challengers || challengers.length === 0) {
      return 0;
    }
    
    return challengers.reduce((total, challenger) => {
      return total + (challenger.trafficAllocation || this.config.defaultTrafficAllocation / challengers.length);
    }, 0);
  }

  /**
   * Obtém a alocação de tráfego padrão para uma variante
   * @param {Object} experiment Experimento
   * @param {boolean} isChampion Se a variante é champion
   * @returns {number} Alocação de tráfego
   * @private
   */
  _getDefaultTrafficAllocation(experiment, isChampion) {
    if (isChampion) {
      // Champion recebe o restante do tráfego
      return 1 - this.config.defaultTrafficAllocation;
    }
    
    // Obter todas as variantes existentes
    const existingVariants = this.variants.has(experiment.id)
      ? Array.from(this.variants.get(experiment.id).values())
      : [];
    
    // Contar challengers existentes
    const existingChallengers = existingVariants.filter(v => !v.isChampion);
    
    // Calcular alocação para o novo challenger
    return this.config.defaultTrafficAllocation / (existingChallengers.length + 1);
  }

  /**
   * Seleciona uma variante com base na alocação de tráfego
   * @param {Array} variants Lista de variantes
   * @param {string} entityId ID da entidade
   * @returns {Object} Variante selecionada
   * @private
   */
  _selectVariantByTrafficAllocation(variants, entityId) {
    // Usar o entityId como semente para garantir consistência
    const seed = this._hashString(entityId);
    const random = this._seededRandom(seed);
    
    // Ordenar variantes para garantir determinismo
    const sortedVariants = [...variants].sort((a, b) => a.id.localeCompare(b.id));
    
    // Calcular pontos de corte cumulativos
    let cumulativeAllocation = 0;
    const allocationPoints = sortedVariants.map(variant => {
      cumulativeAllocation += variant.trafficAllocation;
      return {
        variant,
        point: cumulativeAllocation
      };
    });
    
    // Selecionar variante com base no valor aleatório
    for (const { variant, point } of allocationPoints) {
      if (random <= point) {
        return variant;
      }
    }
    
    // Fallback para o último (normalmente o champion)
    return sortedVariants[sortedVariants.length - 1];
  }

  /**
   * Gera um hash de string para uso como semente
   * @param {string} str String para hash
   * @returns {number} Valor hash
   * @private
   */
  _hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash);
  }

  /**
   * Gera um número aleatório determinístico baseado em semente
   * @param {number} seed Semente
   * @returns {number} Número aleatório entre 0 e 1
   * @private
   */
  _seededRandom(seed) {
    const x = Math.sin(seed) * 10000;
    return x - Math.floor(x);
  }

  /**
   * Determina o vencedor de um experimento
   * @param {string} experimentId ID do experimento
   * @returns {Promise<Object|null>} Informações do vencedor ou null
   * @private
   */
  async _determineWinner(experimentId) {
    const experiment = this.experiments.get(experimentId);
    
    // Verificar se há um champion
    if (!experiment.championVariantId) {
      return null;
    }
    
    // Obter todas as variantes
    const variants = await this.listVariants(experimentId);
    
    // Encontrar o champion
    const champion = variants.find(v => v.isChampion);
    
    if (!champion) {
      return null;
    }
    
    // Obter resultados de todas as variantes
    const variantMetrics = {};
    
    for (const variant of variants) {
      const results = await this.getVariantResults(experimentId, variant.id);
      variantMetrics[variant.id] = this._calculateAggregateMetrics(results, experiment.metrics);
    }
    
    // Comparar challengers com o champion
    let bestChallenger = null;
    let bestImprovement = 0;
    
    for (const variant of variants.filter(v => !v.isChampion)) {
      const comparison = this._compareWithChampion(
        variantMetrics[champion.id],
        variantMetrics[variant.id],
        experiment.metrics
      );
      
      // Verificar se há melhoria na métrica primária
      if (experiment.primaryMetric && comparison.metrics[experiment.primaryMetric]) {
        const improvement = comparison.metrics[experiment.primaryMetric].relativeImprovement;
        
        if (improvement > bestImprovement) {
          bestImprovement = improvement;
          bestChallenger = {
            variantId: variant.id,
            metrics: variantMetrics[variant.id],
            improvement
          };
        }
      }
    }
    
    // Verificar se o melhor challenger supera o threshold
    if (bestChallenger && bestImprovement > this.config.autoPromoteThreshold) {
      return bestChallenger;
    }
    
    // Se não houver challenger melhor, o champion é o vencedor
    return {
      variantId: champion.id,
      metrics: variantMetrics[champion.id],
      improvement: 0
    };
  }

  /**
   * Verifica se um challenger deve ser promovido automaticamente
   * @param {string} experimentId ID do experimento
   * @param {string} variantId ID da variante
   * @param {Object} result Resultado recente
   * @private
   */
  async _checkForAutoPromotion(experimentId, variantId, result) {
    const experiment = this.experiments.get(experimentId);
    
    // Verificar se há um champion
    if (!experiment.championVariantId) {
      return;
    }
    
    // Obter resultados do champion
    const championResults = await this.getVariantResults(experimentId, experiment.championVariantId);
    
    if (championResults.length === 0) {
      return;
    }
    
    // Calcular métricas agregadas
    const championMetrics = this._calculateAggregateMetrics(championResults, experiment.metrics);
    const challengerResults = await this.getVariantResults(experimentId, variantId);
    const challengerMetrics = this._calculateAggregateMetrics(challengerResults, experiment.metrics);
    
    // Comparar com o champion
    const comparison = this._compareWithChampion(championMetrics, challengerMetrics, experiment.metrics);
    
    // Verificar se há melhoria significativa na métrica primária
    if (experiment.primaryMetric && comparison.metrics[experiment.primaryMetric]) {
      const improvement = comparison.metrics[experiment.primaryMetric].relativeImprovement;
      
      // Verificar se a melhoria supera o threshold e há amostra suficiente
      if (improvement > this.config.autoPromoteThreshold && 
          this._calculateTotalSampleSize(challengerResults) >= this.config.minSampleSizeForPromotion) {
        
        // Promover automaticamente
        await this.promoteChallenger(experimentId, variantId, {
          promotedBy: 'auto_promotion',
          promotionReason: `Automatic promotion due to ${(improvement * 100).toFixed(2)}% improvement in ${experiment.primaryMetric}`
        });
      }
    }
  }

  /**
   * Calcula métricas agregadas a partir de resultados
   * @param {Array} results Lista de resultados
   * @param {Array} metricKeys Lista de chaves de métricas
   * @returns {Object} Métricas agregadas
   * @private
   */
  _calculateAggregateMetrics(results, metricKeys) {
    if (!results || results.length === 0) {
      return {};
    }
    
    const metrics = {};
    
    // Inicializar métricas
    for (const key of metricKeys) {
      metrics[key] = {
        sum: 0,
        count: 0,
        min: Infinity,
        max: -Infinity,
        values: []
      };
    }
    
    // Agregar valores
    for (const result of results) {
      for (const key of metricKeys) {
        if (result.metrics[key] !== undefined) {
          const value = result.metrics[key];
          metrics[key].sum += value;
          metrics[key].count += 1;
          metrics[key].min = Math.min(metrics[key].min, value);
          metrics[key].max = Math.max(metrics[key].max, value);
          metrics[key].values.push(value);
        }
      }
    }
    
    // Calcular estatísticas
    for (const key of metricKeys) {
      if (metrics[key].count > 0) {
        metrics[key].average = metrics[key].sum / metrics[key].count;
        
        // Calcular desvio padrão
        if (metrics[key].values.length > 1) {
          const mean = metrics[key].average;
          const squaredDiffs = metrics[key].values.map(value => Math.pow(value - mean, 2));
          const variance = squaredDiffs.reduce((sum, diff) => sum + diff, 0) / metrics[key].count;
          metrics[key].stdDev = Math.sqrt(variance);
        } else {
          metrics[key].stdDev = 0;
        }
        
        // Limpar valores brutos para economizar memória
        delete metrics[key].values;
      } else {
        // Se não houver valores, definir estatísticas como null
        metrics[key] = {
          average: null,
          min: null,
          max: null,
          stdDev: null,
          count: 0
        };
      }
    }
    
    return metrics;
  }

  /**
   * Compara métricas de um challenger com o champion
   * @param {Object} championMetrics Métricas do champion
   * @param {Object} challengerMetrics Métricas do challenger
   * @param {Array} metricKeys Lista de chaves de métricas
   * @returns {Object} Resultado da comparação
   * @private
   */
  _compareWithChampion(championMetrics, challengerMetrics, metricKeys) {
    const comparison = {
      metrics: {},
      overallImprovement: 0,
      significantImprovements: 0,
      significantRegressions: 0
    };
    
    for (const key of metricKeys) {
      if (championMetrics[key] && challengerMetrics[key] && 
          championMetrics[key].average !== null && challengerMetrics[key].average !== null) {
        
        const championValue = championMetrics[key].average;
        const challengerValue = challengerMetrics[key].average;
        
        // Calcular diferença absoluta
        const absoluteDiff = challengerValue - championValue;
        
        // Calcular diferença relativa (evitar divisão por zero)
        const relativeImprovement = championValue !== 0 
          ? absoluteDiff / Math.abs(championValue)
          : absoluteDiff;
        
        // Determinar se a diferença é estatisticamente significativa
        // Simplificação: usar um threshold fixo de 5% para significância
        const isSignificant = Math.abs(relativeImprovement) >= 0.05;
        
        // Determinar se é uma melhoria ou regressão
        // Assumindo que valores maiores são melhores para todas as métricas
        // Em um sistema real, isso dependeria da definição da métrica
        const isImprovement = relativeImprovement > 0;
        
        comparison.metrics[key] = {
          championValue,
          challengerValue,
          absoluteDiff,
          relativeImprovement,
          isSignificant,
          isImprovement
        };
        
        // Atualizar contadores
        if (isSignificant) {
          if (isImprovement) {
            comparison.significantImprovements += 1;
          } else {
            comparison.significantRegressions += 1;
          }
        }
      }
    }
    
    // Calcular melhoria geral (média das melhorias relativas)
    const metricCount = Object.keys(comparison.metrics).length;
    if (metricCount > 0) {
      comparison.overallImprovement = Object.values(comparison.metrics)
        .reduce((sum, metric) => sum + metric.relativeImprovement, 0) / metricCount;
    }
    
    return comparison;
  }

  /**
   * Calcula o tamanho total da amostra de resultados
   * @param {Array} results Lista de resultados
   * @returns {number} Tamanho total da amostra
   * @private
   */
  _calculateTotalSampleSize(results) {
    if (!results || results.length === 0) {
      return 0;
    }
    
    return results.reduce((total, result) => total + (result.sampleSize || 0), 0);
  }

  /**
   * Calcula o número de dias em execução
   * @param {string} startDate Data de início
   * @returns {number} Número de dias
   * @private
   */
  _calculateDaysRunning(startDate) {
    if (!startDate) {
      return 0;
    }
    
    const start = new Date(startDate);
    const now = new Date();
    const diffTime = Math.abs(now - start);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  /**
   * Gera recomendações para um experimento
   * @param {Object} experiment Experimento
   * @param {Object} champion Champion
   * @param {Array} challengers Lista de challengers
   * @param {Object} comparisons Comparações
   * @returns {Array} Lista de recomendações
   * @private
   */
  _generateRecommendations(experiment, champion, challengers, comparisons) {
    const recommendations = [];
    
    // Verificar duração mínima
    const daysRunning = this._calculateDaysRunning(experiment.startDate);
    
    if (daysRunning < this.config.minExperimentDuration) {
      recommendations.push({
        type: 'continue',
        priority: 'high',
        message: `Continue o experimento por pelo menos ${this.config.minExperimentDuration} dias (faltam ${this.config.minExperimentDuration - daysRunning} dias).`
      });
      return recommendations;
    }
    
    // Verificar se há challengers com melhorias significativas
    const improvingChallengers = challengers.filter(challenger => {
      const comparison = comparisons[challenger.id];
      return comparison && comparison.overallImprovement > 0 && comparison.significantImprovements > comparison.significantRegressions;
    });
    
    if (improvingChallengers.length > 0) {
      // Encontrar o melhor challenger
      let bestChallenger = improvingChallengers[0];
      let bestImprovement = comparisons[bestChallenger.id].overallImprovement;
      
      for (const challenger of improvingChallengers) {
        const improvement = comparisons[challenger.id].overallImprovement;
        if (improvement > bestImprovement) {
          bestImprovement = improvement;
          bestChallenger = challenger;
        }
      }
      
      // Verificar se a melhoria é significativa
      if (bestImprovement > this.config.autoPromoteThreshold) {
        recommendations.push({
          type: 'promote',
          priority: 'high',
          message: `Promova o challenger "${bestChallenger.name}" para champion. Melhoria geral de ${(bestImprovement * 100).toFixed(2)}%.`,
          variantId: bestChallenger.id
        });
      } else {
        recommendations.push({
          type: 'continue',
          priority: 'medium',
          message: `Continue o experimento para coletar mais dados. O challenger "${bestChallenger.name}" mostra melhorias promissoras (${(bestImprovement * 100).toFixed(2)}%), mas ainda não atingiu o threshold para promoção automática (${(this.config.autoPromoteThreshold * 100).toFixed(2)}%).`
        });
      }
    } else if (challengers.length > 0) {
      // Nenhum challenger está superando o champion
      recommendations.push({
        type: 'conclude',
        priority: 'medium',
        message: `Considere concluir o experimento. Nenhum challenger está superando o champion "${champion.name}".`
      });
      
      // Verificar se há challengers com regressões significativas
      const regressingChallengers = challengers.filter(challenger => {
        const comparison = comparisons[challenger.id];
        return comparison && comparison.overallImprovement < 0 && comparison.significantRegressions > 0;
      });
      
      if (regressingChallengers.length > 0) {
        recommendations.push({
          type: 'remove_challengers',
          priority: 'medium',
          message: `Considere remover os challengers com desempenho significativamente pior: ${regressingChallengers.map(c => `"${c.name}"`).join(', ')}.`,
          variantIds: regressingChallengers.map(c => c.id)
        });
      }
    }
    
    // Verificar duração máxima
    if (daysRunning > this.config.maxExperimentDuration) {
      recommendations.push({
        type: 'conclude',
        priority: 'high',
        message: `Conclua o experimento. Já está em execução há ${daysRunning} dias, excedendo a duração máxima recomendada de ${this.config.maxExperimentDuration} dias.`
      });
    }
    
    return recommendations;
  }

  /**
   * Valida um experimento
   * @param {Object} experiment Experimento a ser validado
   * @private
   */
  _validateExperiment(experiment) {
    if (!experiment.name) {
      throw new Error('Nome do experimento é obrigatório');
    }
    
    if (!experiment.type) {
      throw new Error('Tipo do experimento é obrigatório');
    }
    
    if (!experiment.entityId) {
      throw new Error('ID da entidade é obrigatório');
    }
    
    if (!experiment.owner) {
      throw new Error('Proprietário do experimento é obrigatório');
    }
    
    if (experiment.metrics.length === 0) {
      throw new Error('Pelo menos uma métrica deve ser definida');
    }
    
    if (experiment.primaryMetric && !experiment.metrics.includes(experiment.primaryMetric)) {
      throw new Error(`Métrica primária "${experiment.primaryMetric}" não está na lista de métricas`);
    }
  }

  /**
   * Valida uma variante
   * @param {Object} variant Variante a ser validada
   * @param {Object} experiment Experimento relacionado
   * @private
   */
  _validateVariant(variant, experiment) {
    if (!variant.name) {
      throw new Error('Nome da variante é obrigatório');
    }
    
    if (!variant.entityVersionId) {
      throw new Error('ID da versão da entidade é obrigatório');
    }
    
    // Verificar se já existe um champion
    if (variant.isChampion && experiment.championVariantId && 
        this.variants.has(experiment.id) && 
        this.variants.get(experiment.id).has(experiment.championVariantId)) {
      throw new Error('Já existe um champion para este experimento');
    }
    
    // Validar alocação de tráfego
    if (variant.trafficAllocation < 0 || variant.trafficAllocation > 1) {
      throw new Error('Alocação de tráfego deve estar entre 0 e 1');
    }
  }

  /**
   * Valida resultados
   * @param {Object} result Resultados a serem validados
   * @param {Object} experiment Experimento relacionado
   * @private
   */
  _validateResults(result, experiment) {
    // Verificar se há métricas definidas
    if (!result.metrics || Object.keys(result.metrics).length === 0) {
      throw new Error('Pelo menos uma métrica deve ser fornecida');
    }
    
    // Verificar se as métricas estão na lista de métricas do experimento
    for (const key of Object.keys(result.metrics)) {
      if (!experiment.metrics.includes(key)) {
        throw new Error(`Métrica "${key}" não está na lista de métricas do experimento`);
      }
    }
    
    // Verificar se o tamanho da amostra é válido
    if (result.sampleSize <= 0) {
      throw new Error('Tamanho da amostra deve ser maior que zero');
    }
  }

  /**
   * Valida uma transição de status
   * @param {string} currentStatus Status atual
   * @param {string} newStatus Novo status
   * @private
   */
  _validateStatusTransition(currentStatus, newStatus) {
    const validStatuses = ['draft', 'active', 'paused', 'completed', 'cancelled'];
    
    if (!validStatuses.includes(newStatus)) {
      throw new Error(`Status inválido: ${newStatus}`);
    }
    
    // Regras de transição de status
    if (currentStatus === 'completed' || currentStatus === 'cancelled') {
      throw new Error(`Não é possível alterar o status de um experimento ${currentStatus}`);
    }
    
    // Regras específicas de transição
    if (currentStatus === 'draft' && !['active', 'cancelled'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'active' && !['paused', 'completed', 'cancelled'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'paused' && !['active', 'completed', 'cancelled'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
  }
}

/**
 * Classe para Simulação de Cenários
 */
export class ScenarioSimulator {
  constructor(config = {}) {
    this.config = {
      storageMethod: config.storageMethod || 'memory', // 'memory', 'database'
      maxSimulationSize: config.maxSimulationSize || 10000, // Número máximo de entidades por simulação
      ...config
    };

    // Armazenamento de cenários
    this.scenarios = new Map();
    
    // Armazenamento de resultados de simulação
    this.simulationResults = new Map();
  }

  /**
   * Cria um novo cenário de simulação
   * @param {Object} scenarioData Dados do cenário
   * @returns {Promise<Object>} Cenário criado
   */
  async createScenario(scenarioData) {
    const scenarioId = scenarioData.id || uuidv4();
    
    const scenario = {
      id: scenarioId,
      name: scenarioData.name,
      description: scenarioData.description || '',
      type: scenarioData.type, // 'model', 'policy', 'rule', 'parameter'
      entityId: scenarioData.entityId, // ID do modelo, política ou regra
      entityType: scenarioData.entityType, // Tipo específico da entidade
      baselineVersionId: scenarioData.baselineVersionId, // Versão de referência
      testVersionIds: scenarioData.testVersionIds || [], // Versões a serem testadas
      parameters: scenarioData.parameters || {}, // Parâmetros da simulação
      datasetId: scenarioData.datasetId, // ID do conjunto de dados para simulação
      metrics: scenarioData.metrics || [], // Métricas para avaliação
      owner: scenarioData.owner,
      status: 'draft', // 'draft', 'running', 'completed', 'failed'
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      metadata: scenarioData.metadata || {}
    };
    
    // Validar cenário
    this._validateScenario(scenario);
    
    // Armazenar cenário
    this.scenarios.set(scenarioId, scenario);
    
    return cloneDeep(scenario);
  }

  /**
   * Atualiza um cenário existente
   * @param {string} scenarioId ID do cenário
   * @param {Object} scenarioData Novos dados do cenário
   * @returns {Promise<Object>} Cenário atualizado
   */
  async updateScenario(scenarioId, scenarioData) {
    if (!this.scenarios.has(scenarioId)) {
      throw new Error(`Cenário não encontrado: ${scenarioId}`);
    }
    
    const currentScenario = this.scenarios.get(scenarioId);
    
    // Verificar se o cenário pode ser atualizado
    if (['running', 'completed'].includes(currentScenario.status)) {
      throw new Error(`Não é possível atualizar um cenário ${currentScenario.status}`);
    }
    
    // Campos que não podem ser atualizados diretamente
    const protectedFields = ['id', 'createdAt', 'status'];
    
    const updatedScenario = {
      ...currentScenario,
      ...Object.fromEntries(
        Object.entries(scenarioData).filter(([key]) => !protectedFields.includes(key))
      ),
      updatedAt: new Date().toISOString()
    };
    
    // Validar cenário
    this._validateScenario(updatedScenario);
    
    // Armazenar cenário atualizado
    this.scenarios.set(scenarioId, updatedScenario);
    
    return cloneDeep(updatedScenario);
  }

  /**
   * Executa uma simulação para um cenário
   * @param {string} scenarioId ID do cenário
   * @param {Object} simulationData Dados adicionais para simulação
   * @returns {Promise<Object>} Resultado da simulação
   */
  async runSimulation(scenarioId, simulationData = {}) {
    if (!this.scenarios.has(scenarioId)) {
      throw new Error(`Cenário não encontrado: ${scenarioId}`);
    }
    
    const scenario = this.scenarios.get(scenarioId);
    
    // Verificar se o cenário já está em execução
    if (scenario.status === 'running') {
      throw new Error('Cenário já está em execução');
    }
    
    // Atualizar status do cenário
    scenario.status = 'running';
    scenario.updatedAt = new Date().toISOString();
    scenario.simulationStartedAt = new Date().toISOString();
    this.scenarios.set(scenarioId, scenario);
    
    try {
      // Simular execução da simulação
      const simulationResult = await this._simulateScenario(scenario, simulationData);
      
      // Armazenar resultado da simulação
      if (!this.simulationResults.has(scenarioId)) {
        this.simulationResults.set(scenarioId, []);
      }
      
      this.simulationResults.get(scenarioId).push(simulationResult);
      
      // Atualizar status do cenário
      scenario.status = 'completed';
      scenario.updatedAt = new Date().toISOString();
      scenario.simulationCompletedAt = new Date().toISOString();
      scenario.lastSimulationId = simulationResult.id;
      this.scenarios.set(scenarioId, scenario);
      
      return cloneDeep(simulationResult);
    } catch (error) {
      // Atualizar status do cenário em caso de erro
      scenario.status = 'failed';
      scenario.updatedAt = new Date().toISOString();
      scenario.simulationFailedAt = new Date().toISOString();
      scenario.simulationError = error.message;
      this.scenarios.set(scenarioId, scenario);
      
      throw error;
    }
  }

  /**
   * Obtém um cenário pelo ID
   * @param {string} scenarioId ID do cenário
   * @returns {Promise<Object>} Cenário
   */
  async getScenario(scenarioId) {
    if (!this.scenarios.has(scenarioId)) {
      throw new Error(`Cenário não encontrado: ${scenarioId}`);
    }
    
    return cloneDeep(this.scenarios.get(scenarioId));
  }

  /**
   * Lista todos os cenários
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de cenários
   */
  async listScenarios(filters = {}) {
    let scenarios = Array.from(this.scenarios.values());
    
    // Aplicar filtros
    if (filters.status) {
      scenarios = scenarios.filter(scenario => scenario.status === filters.status);
    }
    
    if (filters.type) {
      scenarios = scenarios.filter(scenario => scenario.type === filters.type);
    }
    
    if (filters.entityId) {
      scenarios = scenarios.filter(scenario => scenario.entityId === filters.entityId);
    }
    
    if (filters.owner) {
      scenarios = scenarios.filter(scenario => scenario.owner === filters.owner);
    }
    
    // Ordenar por data de criação (mais recente primeiro)
    scenarios.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Limitar resultados
    if (filters.limit) {
      scenarios = scenarios.slice(0, filters.limit);
    }
    
    return cloneDeep(scenarios);
  }

  /**
   * Obtém resultados de simulação para um cenário
   * @param {string} scenarioId ID do cenário
   * @returns {Promise<Array>} Lista de resultados de simulação
   */
  async getSimulationResults(scenarioId) {
    if (!this.simulationResults.has(scenarioId)) {
      return [];
    }
    
    return cloneDeep(this.simulationResults.get(scenarioId));
  }

  /**
   * Obtém um resultado de simulação específico
   * @param {string} scenarioId ID do cenário
   * @param {string} simulationId ID da simulação
   * @returns {Promise<Object>} Resultado da simulação
   */
  async getSimulationResult(scenarioId, simulationId) {
    if (!this.simulationResults.has(scenarioId)) {
      throw new Error(`Nenhum resultado de simulação encontrado para o cenário: ${scenarioId}`);
    }
    
    const result = this.simulationResults.get(scenarioId)
      .find(result => result.id === simulationId);
    
    if (!result) {
      throw new Error(`Resultado de simulação não encontrado: ${scenarioId}/${simulationId}`);
    }
    
    return cloneDeep(result);
  }

  /**
   * Gera um relatório de impacto para um resultado de simulação
   * @param {string} scenarioId ID do cenário
   * @param {string} simulationId ID da simulação
   * @returns {Promise<Object>} Relatório de impacto
   */
  async generateImpactReport(scenarioId, simulationId) {
    const simulationResult = await this.getSimulationResult(scenarioId, simulationId);
    const scenario = await this.getScenario(scenarioId);
    
    // Calcular métricas de impacto
    const impactMetrics = this._calculateImpactMetrics(simulationResult);
    
    // Gerar relatório
    const report = {
      scenarioId,
      scenarioName: scenario.name,
      simulationId,
      generatedAt: new Date().toISOString(),
      baseline: {
        versionId: scenario.baselineVersionId,
        metrics: simulationResult.baselineMetrics
      },
      testVersions: simulationResult.testVersionResults.map(testResult => ({
        versionId: testResult.versionId,
        metrics: testResult.metrics,
        impact: this._calculateVersionImpact(
          simulationResult.baselineMetrics,
          testResult.metrics,
          scenario.metrics
        )
      })),
      overallImpact: impactMetrics,
      recommendations: this._generateRecommendations(scenario, simulationResult, impactMetrics)
    };
    
    return report;
  }

  /**
   * Simula a execução de um cenário
   * @param {Object} scenario Cenário
   * @param {Object} simulationData Dados adicionais para simulação
   * @returns {Promise<Object>} Resultado da simulação
   * @private
   */
  async _simulateScenario(scenario, simulationData) {
    // Gerar ID da simulação
    const simulationId = uuidv4();
    
    // Criar resultado da simulação
    const simulationResult = {
      id: simulationId,
      scenarioId: scenario.id,
      startedAt: new Date().toISOString(),
      parameters: {
        ...scenario.parameters,
        ...simulationData.parameters
      },
      datasetInfo: {
        id: scenario.datasetId,
        size: simulationData.datasetSize || 1000, // Simulado
        period: simulationData.period || {
          startDate: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString(),
          endDate: new Date().toISOString()
        }
      },
      baselineMetrics: {},
      testVersionResults: [],
      status: 'running',
      metadata: {
        ...scenario.metadata,
        ...simulationData.metadata
      }
    };
    
    try {
      // Simular execução da baseline
      simulationResult.baselineMetrics = await this._simulateVersion(
        scenario.baselineVersionId,
        scenario.type,
        scenario.entityType,
        scenario.metrics,
        simulationResult.parameters,
        simulationResult.datasetInfo
      );
      
      // Simular execução das versões de teste
      for (const versionId of scenario.testVersionIds) {
        const versionMetrics = await this._simulateVersion(
          versionId,
          scenario.type,
          scenario.entityType,
          scenario.metrics,
          simulationResult.parameters,
          simulationResult.datasetInfo
        );
        
        simulationResult.testVersionResults.push({
          versionId,
          metrics: versionMetrics
        });
      }
      
      // Atualizar status da simulação
      simulationResult.status = 'completed';
      simulationResult.completedAt = new Date().toISOString();
      simulationResult.duration = new Date(simulationResult.completedAt) - new Date(simulationResult.startedAt);
      
      return simulationResult;
    } catch (error) {
      // Atualizar status da simulação em caso de erro
      simulationResult.status = 'failed';
      simulationResult.failedAt = new Date().toISOString();
      simulationResult.error = error.message;
      
      throw error;
    }
  }

  /**
   * Simula a execução de uma versão
   * @param {string} versionId ID da versão
   * @param {string} type Tipo da entidade
   * @param {string} entityType Tipo específico da entidade
   * @param {Array} metrics Métricas para avaliação
   * @param {Object} parameters Parâmetros da simulação
   * @param {Object} datasetInfo Informações do conjunto de dados
   * @returns {Promise<Object>} Métricas da versão
   * @private
   */
  async _simulateVersion(versionId, type, entityType, metrics, parameters, datasetInfo) {
    // Simulação de execução (em um sistema real, isso chamaria o modelo/política real)
    
    // Gerar métricas simuladas
    const simulatedMetrics = {};
    
    for (const metric of metrics) {
      // Gerar valor aleatório para a métrica
      // Em um sistema real, isso seria calculado com base nos resultados reais
      simulatedMetrics[metric] = {
        value: this._generateRandomMetricValue(metric, versionId),
        count: datasetInfo.size,
        distribution: this._generateDistribution(metric, datasetInfo.size)
      };
    }
    
    // Simular atraso para parecer realista
    await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));
    
    return simulatedMetrics;
  }

  /**
   * Gera um valor aleatório para uma métrica
   * @param {string} metric Nome da métrica
   * @param {string} seed Semente para geração
   * @returns {number} Valor da métrica
   * @private
   */
  _generateRandomMetricValue(metric, seed) {
    // Usar o seed para gerar um valor determinístico
    const seedValue = this._hashString(seed + metric) / 1000000;
    
    // Diferentes métricas têm diferentes faixas de valores
    switch (metric) {
      case 'approval_rate':
        return 0.6 + seedValue * 0.2; // 60-80%
      case 'rejection_rate':
        return 0.2 + seedValue * 0.2; // 20-40%
      case 'average_score':
        return 600 + seedValue * 200; // 600-800
      case 'default_rate':
        return 0.02 + seedValue * 0.03; // 2-5%
      case 'false_positive_rate':
        return 0.05 + seedValue * 0.05; // 5-10%
      case 'false_negative_rate':
        return 0.05 + seedValue * 0.05; // 5-10%
      case 'average_loan_amount':
        return 10000 + seedValue * 5000; // 10k-15k
      case 'processing_time':
        return 2 + seedValue * 3; // 2-5 seconds
      default:
        return seedValue;
    }
  }

  /**
   * Gera uma distribuição para uma métrica
   * @param {string} metric Nome da métrica
   * @param {number} size Tamanho da amostra
   * @returns {Object} Distribuição
   * @private
   */
  _generateDistribution(metric, size) {
    // Gerar distribuição simulada
    // Em um sistema real, isso seria calculado com base nos resultados reais
    
    // Diferentes métricas têm diferentes distribuições
    switch (metric) {
      case 'approval_rate':
      case 'rejection_rate':
      case 'default_rate':
      case 'false_positive_rate':
      case 'false_negative_rate':
        // Distribuição para taxas (0-1)
        return {
          type: 'histogram',
          bins: [
            { min: 0, max: 0.2, count: Math.floor(size * 0.1) },
            { min: 0.2, max: 0.4, count: Math.floor(size * 0.2) },
            { min: 0.4, max: 0.6, count: Math.floor(size * 0.4) },
            { min: 0.6, max: 0.8, count: Math.floor(size * 0.2) },
            { min: 0.8, max: 1, count: Math.floor(size * 0.1) }
          ]
        };
      case 'average_score':
        // Distribuição para scores (300-850)
        return {
          type: 'histogram',
          bins: [
            { min: 300, max: 400, count: Math.floor(size * 0.05) },
            { min: 400, max: 500, count: Math.floor(size * 0.1) },
            { min: 500, max: 600, count: Math.floor(size * 0.2) },
            { min: 600, max: 700, count: Math.floor(size * 0.3) },
            { min: 700, max: 800, count: Math.floor(size * 0.25) },
            { min: 800, max: 850, count: Math.floor(size * 0.1) }
          ]
        };
      case 'average_loan_amount':
        // Distribuição para valores de empréstimo
        return {
          type: 'histogram',
          bins: [
            { min: 0, max: 5000, count: Math.floor(size * 0.2) },
            { min: 5000, max: 10000, count: Math.floor(size * 0.3) },
            { min: 10000, max: 15000, count: Math.floor(size * 0.25) },
            { min: 15000, max: 20000, count: Math.floor(size * 0.15) },
            { min: 20000, max: 50000, count: Math.floor(size * 0.1) }
          ]
        };
      default:
        // Distribuição genérica
        return {
          type: 'normal',
          mean: 0.5,
          stdDev: 0.2
        };
    }
  }

  /**
   * Calcula métricas de impacto para um resultado de simulação
   * @param {Object} simulationResult Resultado da simulação
   * @returns {Object} Métricas de impacto
   * @private
   */
  _calculateImpactMetrics(simulationResult) {
    const impactMetrics = {
      bestVersion: null,
      worstVersion: null,
      averageImprovement: 0,
      significantImprovements: 0,
      significantRegressions: 0,
      metrics: {}
    };
    
    if (!simulationResult.testVersionResults || simulationResult.testVersionResults.length === 0) {
      return impactMetrics;
    }
    
    // Calcular impacto para cada versão
    const versionImpacts = simulationResult.testVersionResults.map(testResult => {
      const impact = this._calculateVersionImpact(
        simulationResult.baselineMetrics,
        testResult.metrics,
        Object.keys(simulationResult.baselineMetrics)
      );
      
      return {
        versionId: testResult.versionId,
        overallImprovement: impact.overallImprovement,
        significantImprovements: impact.significantImprovements,
        significantRegressions: impact.significantRegressions
      };
    });
    
    // Encontrar a melhor e pior versão
    if (versionImpacts.length > 0) {
      versionImpacts.sort((a, b) => b.overallImprovement - a.overallImprovement);
      
      impactMetrics.bestVersion = versionImpacts[0];
      impactMetrics.worstVersion = versionImpacts[versionImpacts.length - 1];
      
      // Calcular melhoria média
      impactMetrics.averageImprovement = versionImpacts.reduce(
        (sum, impact) => sum + impact.overallImprovement, 0
      ) / versionImpacts.length;
      
      // Contar melhorias e regressões significativas
      impactMetrics.significantImprovements = versionImpacts.reduce(
        (count, impact) => count + (impact.overallImprovement > 0.05 ? 1 : 0), 0
      );
      
      impactMetrics.significantRegressions = versionImpacts.reduce(
        (count, impact) => count + (impact.overallImprovement < -0.05 ? 1 : 0), 0
      );
    }
    
    // Calcular impacto por métrica
    for (const metric of Object.keys(simulationResult.baselineMetrics)) {
      const metricImpacts = simulationResult.testVersionResults.map(testResult => {
        const baselineValue = simulationResult.baselineMetrics[metric].value;
        const testValue = testResult.metrics[metric].value;
        
        return {
          versionId: testResult.versionId,
          absoluteDiff: testValue - baselineValue,
          relativeImprovement: baselineValue !== 0 
            ? (testValue - baselineValue) / Math.abs(baselineValue)
            : testValue
        };
      });
      
      impactMetrics.metrics[metric] = {
        bestVersion: metricImpacts.reduce(
          (best, current) => current.relativeImprovement > best.relativeImprovement ? current : best,
          { relativeImprovement: -Infinity }
        ),
        worstVersion: metricImpacts.reduce(
          (worst, current) => current.relativeImprovement < worst.relativeImprovement ? current : worst,
          { relativeImprovement: Infinity }
        ),
        averageImprovement: metricImpacts.reduce(
          (sum, impact) => sum + impact.relativeImprovement, 0
        ) / metricImpacts.length
      };
    }
    
    return impactMetrics;
  }

  /**
   * Calcula o impacto de uma versão em relação à baseline
   * @param {Object} baselineMetrics Métricas da baseline
   * @param {Object} versionMetrics Métricas da versão
   * @param {Array} metricKeys Lista de chaves de métricas
   * @returns {Object} Impacto da versão
   * @private
   */
  _calculateVersionImpact(baselineMetrics, versionMetrics, metricKeys) {
    const impact = {
      metrics: {},
      overallImprovement: 0,
      significantImprovements: 0,
      significantRegressions: 0
    };
    
    for (const key of metricKeys) {
      if (baselineMetrics[key] && versionMetrics[key]) {
        const baselineValue = baselineMetrics[key].value;
        const versionValue = versionMetrics[key].value;
        
        // Calcular diferença absoluta
        const absoluteDiff = versionValue - baselineValue;
        
        // Calcular diferença relativa (evitar divisão por zero)
        const relativeImprovement = baselineValue !== 0 
          ? absoluteDiff / Math.abs(baselineValue)
          : absoluteDiff;
        
        // Determinar se a diferença é estatisticamente significativa
        // Simplificação: usar um threshold fixo de 5% para significância
        const isSignificant = Math.abs(relativeImprovement) >= 0.05;
        
        // Determinar se é uma melhoria ou regressão
        // Assumindo que valores maiores são melhores para todas as métricas
        // Em um sistema real, isso dependeria da definição da métrica
        const isImprovement = relativeImprovement > 0;
        
        impact.metrics[key] = {
          baselineValue,
          versionValue,
          absoluteDiff,
          relativeImprovement,
          isSignificant,
          isImprovement
        };
        
        // Atualizar contadores
        if (isSignificant) {
          if (isImprovement) {
            impact.significantImprovements += 1;
          } else {
            impact.significantRegressions += 1;
          }
        }
      }
    }
    
    // Calcular melhoria geral (média das melhorias relativas)
    const metricCount = Object.keys(impact.metrics).length;
    if (metricCount > 0) {
      impact.overallImprovement = Object.values(impact.metrics)
        .reduce((sum, metric) => sum + metric.relativeImprovement, 0) / metricCount;
    }
    
    return impact;
  }

  /**
   * Gera recomendações para um resultado de simulação
   * @param {Object} scenario Cenário
   * @param {Object} simulationResult Resultado da simulação
   * @param {Object} impactMetrics Métricas de impacto
   * @returns {Array} Lista de recomendações
   * @private
   */
  _generateRecommendations(scenario, simulationResult, impactMetrics) {
    const recommendations = [];
    
    // Verificar se há versões de teste
    if (!simulationResult.testVersionResults || simulationResult.testVersionResults.length === 0) {
      recommendations.push({
        type: 'add_versions',
        priority: 'high',
        message: 'Adicione versões de teste ao cenário para comparação.'
      });
      return recommendations;
    }
    
    // Verificar se há uma versão claramente melhor
    if (impactMetrics.bestVersion && impactMetrics.bestVersion.overallImprovement > 0.05) {
      recommendations.push({
        type: 'promote',
        priority: 'high',
        message: `Considere promover a versão ${impactMetrics.bestVersion.versionId} para produção. Melhoria geral de ${(impactMetrics.bestVersion.overallImprovement * 100).toFixed(2)}%.`,
        versionId: impactMetrics.bestVersion.versionId
      });
    } else if (impactMetrics.averageImprovement <= 0) {
      // Nenhuma versão está superando a baseline
      recommendations.push({
        type: 'keep_baseline',
        priority: 'medium',
        message: 'Mantenha a versão baseline. Nenhuma versão de teste demonstrou melhoria significativa.'
      });
    }
    
    // Verificar se há versões com regressões significativas
    if (impactMetrics.significantRegressions > 0) {
      recommendations.push({
        type: 'remove_versions',
        priority: 'medium',
        message: 'Considere remover as versões com regressões significativas.',
        versionIds: simulationResult.testVersionResults
          .filter(testResult => {
            const impact = this._calculateVersionImpact(
              simulationResult.baselineMetrics,
              testResult.metrics,
              Object.keys(simulationResult.baselineMetrics)
            );
            return impact.overallImprovement < -0.05;
          })
          .map(testResult => testResult.versionId)
      });
    }
    
    // Recomendações específicas por métrica
    for (const [metric, impact] of Object.entries(impactMetrics.metrics)) {
      if (impact.bestVersion && impact.bestVersion.relativeImprovement > 0.1) {
        recommendations.push({
          type: 'metric_improvement',
          priority: 'medium',
          message: `A versão ${impact.bestVersion.versionId} demonstra melhoria significativa na métrica "${metric}" (${(impact.bestVersion.relativeImprovement * 100).toFixed(2)}%).`,
          metric,
          versionId: impact.bestVersion.versionId
        });
      }
      
      if (impact.worstVersion && impact.worstVersion.relativeImprovement < -0.1) {
        recommendations.push({
          type: 'metric_regression',
          priority: 'medium',
          message: `A versão ${impact.worstVersion.versionId} demonstra regressão significativa na métrica "${metric}" (${(impact.worstVersion.relativeImprovement * 100).toFixed(2)}%).`,
          metric,
          versionId: impact.worstVersion.versionId
        });
      }
    }
    
    // Recomendações para testes adicionais
    if (simulationResult.testVersionResults.length === 1) {
      recommendations.push({
        type: 'add_versions',
        priority: 'low',
        message: 'Considere adicionar mais versões de teste para uma comparação mais abrangente.'
      });
    }
    
    return recommendations;
  }

  /**
   * Gera um hash de string para uso como semente
   * @param {string} str String para hash
   * @returns {number} Valor hash
   * @private
   */
  _hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash);
  }

  /**
   * Valida um cenário
   * @param {Object} scenario Cenário a ser validado
   * @private
   */
  _validateScenario(scenario) {
    if (!scenario.name) {
      throw new Error('Nome do cenário é obrigatório');
    }
    
    if (!scenario.type) {
      throw new Error('Tipo do cenário é obrigatório');
    }
    
    if (!scenario.entityId) {
      throw new Error('ID da entidade é obrigatório');
    }
    
    if (!scenario.baselineVersionId) {
      throw new Error('ID da versão de referência é obrigatório');
    }
    
    if (!scenario.datasetId) {
      throw new Error('ID do conjunto de dados é obrigatório');
    }
    
    if (!scenario.owner) {
      throw new Error('Proprietário do cenário é obrigatório');
    }
    
    if (scenario.metrics.length === 0) {
      throw new Error('Pelo menos uma métrica deve ser definida');
    }
  }
}

/**
 * Serviço Integrado de Champion-Challenger e Simulação
 */
export class ChampionChallengerService {
  constructor(config = {}) {
    this.championChallengerManager = new ChampionChallengerManager(config.championChallenger);
    this.scenarioSimulator = new ScenarioSimulator(config.scenarioSimulator);
  }

  /**
   * Cria um experimento champion-challenger com auditoria
   * @param {Object} experimentData Dados do experimento
   * @param {Object} auditData Dados para auditoria
   * @returns {Promise<Object>} Experimento criado
   */
  async createExperimentWithAudit(experimentData, auditData = {}) {
    // Criar experimento
    const experiment = await this.championChallengerManager.createExperiment(experimentData);
    
    // Registrar evento de auditoria (simulado)
    console.log('[Audit] Experiment created:', {
      eventType: 'experiment_creation',
      actor: auditData.actor || experimentData.owner,
      action: 'create',
      entityType: 'experiment',
      entityId: experiment.id,
      details: {
        experimentName: experiment.name,
        experimentType: experiment.type,
        entityId: experiment.entityId
      }
    });
    
    return experiment;
  }

  /**
   * Atualiza o status de um experimento com auditoria
   * @param {string} experimentId ID do experimento
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @param {Object} auditData Dados para auditoria
   * @returns {Promise<Object>} Experimento atualizado
   */
  async updateExperimentStatusWithAudit(experimentId, status, metadata = {}, auditData = {}) {
    // Obter experimento atual para comparação
    const currentExperiment = await this.championChallengerManager.getExperiment(experimentId);
    
    // Atualizar status
    const updatedExperiment = await this.championChallengerManager.updateExperimentStatus(experimentId, status, metadata);
    
    // Registrar evento de auditoria (simulado)
    console.log('[Audit] Experiment status updated:', {
      eventType: 'experiment_status_change',
      actor: auditData.actor || metadata.updatedBy || 'system',
      action: 'update',
      entityType: 'experiment',
      entityId: experimentId,
      details: {
        experimentName: updatedExperiment.name,
        previousStatus: currentExperiment.status,
        newStatus: status,
        statusChangeReason: metadata.reason
      }
    });
    
    return updatedExperiment;
  }

  /**
   * Promove um challenger para champion com auditoria
   * @param {string} experimentId ID do experimento
   * @param {string} variantId ID da variante challenger
   * @param {Object} metadata Metadados adicionais
   * @param {Object} auditData Dados para auditoria
   * @returns {Promise<Object>} Resultado da promoção
   */
  async promoteChallenger(experimentId, variantId, metadata = {}, auditData = {}) {
    // Obter experimento e variantes para auditoria
    const experiment = await this.championChallengerManager.getExperiment(experimentId);
    const challenger = await this.championChallengerManager.getVariant(experimentId, variantId);
    const champion = await this.championChallengerManager.getVariant(experimentId, experiment.championVariantId);
    
    // Promover challenger
    const result = await this.championChallengerManager.promoteChallenger(experimentId, variantId, metadata);
    
    // Registrar evento de auditoria (simulado)
    console.log('[Audit] Challenger promoted:', {
      eventType: 'challenger_promotion',
      actor: auditData.actor || metadata.promotedBy || 'system',
      action: 'promote',
      entityType: 'variant',
      entityId: variantId,
      details: {
        experimentId,
        experimentName: experiment.name,
        previousChampionId: champion.id,
        previousChampionName: champion.name,
        newChampionId: challenger.id,
        newChampionName: challenger.name,
        promotionReason: metadata.promotionReason || 'Better performance'
      }
    });
    
    return result;
  }

  /**
   * Cria um cenário de simulação com auditoria
   * @param {Object} scenarioData Dados do cenário
   * @param {Object} auditData Dados para auditoria
   * @returns {Promise<Object>} Cenário criado
   */
  async createScenarioWithAudit(scenarioData, auditData = {}) {
    // Criar cenário
    const scenario = await this.scenarioSimulator.createScenario(scenarioData);
    
    // Registrar evento de auditoria (simulado)
    console.log('[Audit] Scenario created:', {
      eventType: 'scenario_creation',
      actor: auditData.actor || scenarioData.owner,
      action: 'create',
      entityType: 'scenario',
      entityId: scenario.id,
      details: {
        scenarioName: scenario.name,
        scenarioType: scenario.type,
        entityId: scenario.entityId,
        baselineVersionId: scenario.baselineVersionId
      }
    });
    
    return scenario;
  }

  /**
   * Executa uma simulação com auditoria
   * @param {string} scenarioId ID do cenário
   * @param {Object} simulationData Dados adicionais para simulação
   * @param {Object} auditData Dados para auditoria
   * @returns {Promise<Object>} Resultado da simulação
   */
  async runSimulationWithAudit(scenarioId, simulationData = {}, auditData = {}) {
    // Obter cenário para auditoria
    const scenario = await this.scenarioSimulator.getScenario(scenarioId);
    
    // Executar simulação
    const result = await this.scenarioSimulator.runSimulation(scenarioId, simulationData);
    
    // Registrar evento de auditoria (simulado)
    console.log('[Audit] Simulation executed:', {
      eventType: 'simulation_execution',
      actor: auditData.actor || scenario.owner,
      action: 'execute',
      entityType: 'simulation',
      entityId: result.id,
      details: {
        scenarioId,
        scenarioName: scenario.name,
        baselineVersionId: scenario.baselineVersionId,
        testVersionIds: scenario.testVersionIds,
        datasetId: scenario.datasetId,
        simulationStatus: result.status
      }
    });
    
    return result;
  }

  /**
   * Gera um relatório de comparação de experimento com auditoria
   * @param {string} experimentId ID do experimento
   * @param {Object} auditData Dados para auditoria
   * @returns {Promise<Object>} Relatório de comparação
   */
  async generateComparisonReportWithAudit(experimentId, auditData = {}) {
    // Obter experimento para auditoria
    const experiment = await this.championChallengerManager.getExperiment(experimentId);
    
    // Gerar relatório
    const report = await this.championChallengerManager.generateComparisonReport(experimentId);
    
    // Registrar evento de auditoria (simulado)
    console.log('[Audit] Comparison report generated:', {
      eventType: 'report_generation',
      actor: auditData.actor || experiment.owner,
      action: 'generate',
      entityType: 'report',
      entityId: `${experimentId}_comparison_${new Date().toISOString()}`,
      details: {
        experimentId,
        experimentName: experiment.name,
        reportType: 'comparison',
        generatedAt: report.generatedAt
      }
    });
    
    return report;
  }

  /**
   * Gera um relatório de impacto de simulação com auditoria
   * @param {string} scenarioId ID do cenário
   * @param {string} simulationId ID da simulação
   * @param {Object} auditData Dados para auditoria
   * @returns {Promise<Object>} Relatório de impacto
   */
  async generateImpactReportWithAudit(scenarioId, simulationId, auditData = {}) {
    // Obter cenário para auditoria
    const scenario = await this.scenarioSimulator.getScenario(scenarioId);
    
    // Gerar relatório
    const report = await this.scenarioSimulator.generateImpactReport(scenarioId, simulationId);
    
    // Registrar evento de auditoria (simulado)
    console.log('[Audit] Impact report generated:', {
      eventType: 'report_generation',
      actor: auditData.actor || scenario.owner,
      action: 'generate',
      entityType: 'report',
      entityId: `${scenarioId}_impact_${simulationId}`,
      details: {
        scenarioId,
        scenarioName: scenario.name,
        simulationId,
        reportType: 'impact',
        generatedAt: report.generatedAt
      }
    });
    
    return report;
  }
}

export default {
  ChampionChallengerManager,
  ScenarioSimulator,
  ChampionChallengerService
};
