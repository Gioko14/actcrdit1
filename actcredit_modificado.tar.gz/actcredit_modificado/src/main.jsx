import React, { useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import '@/index.css';
import { AuthProvider } from '@/contexts/AuthContext'; // Importando o AuthProvider
import { ThemeProvider } from '@/contexts/ThemeContext'; // Importando o ThemeProvider

// Componente para registrar o Service Worker
const ServiceWorkerRegistration = () => {
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
          .then((registration) => {
            console.log('ServiceWorker registration successful with scope: ', registration.scope);
          })
          .catch((error) => {
            console.log('ServiceWorker registration failed: ', error);
          });
      });
    }
  }, []);

  return null;
};

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ThemeProvider> {/* Envolvendo a aplicação com o ThemeProvider */}
      <AuthProvider> {/* Envolvendo a aplicação com o AuthProvider */}
        <ServiceWorkerRegistration />
        <App />
      </AuthProvider>
    </ThemeProvider>
  </React.StrictMode>
);
