import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Card, 
  Upload, 
  Button, 
  Table, 
  Tag, 
  Space, 
  Progress, 
  Select, 
  message, 
  Typography, 
  Divider,
  Alert
} from 'antd';
import { 
  UploadOutlined, 
  FileTextOutlined, 
  CheckCircleOutlined, 
  CloseCircleOutlined,
  LoadingOutlined
} from '@ant-design/icons';
import axios from 'axios';
import { InboxOutlined } from '@ant-design/icons';

const { Dragger } = Upload;
const { Option } = Select;
const { Title, Text } = Typography;

/**
 * Componente para processamento em lote de documentos PDF
 * Permite upload e análise de múltiplos arquivos simultaneamente
 */
const BatchProcessingUploader = () => {
  const [fileList, setFileList] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [results, setResults] = useState([]);
  const [analysisType, setAnalysisType] = useState(null);
  const [overallProgress, setOverallProgress] = useState(0);

  // URL da API de extração de PDF
  const API_URL = process.env.REACT_APP_PDF_EXTRACTOR_API || 'http://localhost:8000';

  // Colunas da tabela de resultados
  const columns = [
    {
      title: 'Arquivo',
      dataIndex: 'file_name',
      key: 'file_name',
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => (
        <>
          {status === 'success' && <Tag color="success">Sucesso</Tag>}
          {status === 'error' && <Tag color="error">Erro</Tag>}
          {status === 'processing' && <Tag color="processing">Processando</Tag>}
          {status === 'waiting' && <Tag color="default">Aguardando</Tag>}
        </>
      ),
    },
    {
      title: 'CNPJ',
      dataIndex: ['data', 'cnpj'],
      key: 'cnpj',
      render: (text, record) => record.data?.cnpj || '-',
    },
    {
      title: 'Razão Social',
      dataIndex: ['data', 'razao_social'],
      key: 'razao_social',
      render: (text, record) => record.data?.razao_social || '-',
    },
    {
      title: 'Tipo de Análise',
      dataIndex: 'analysis_type',
      key: 'analysis_type',
    },
    {
      title: 'Ações',
      key: 'action',
      render: (_, record) => (
        <Space size="middle">
          {record.status === 'success' && (
            <Button 
              type="link" 
              onClick={() => viewDetails(record)}
              icon={<FileTextOutlined />}
            >
              Detalhes
            </Button>
          )}
        </Space>
      ),
    },
  ];

  // Manipular mudança de arquivos
  const handleFileChange = ({ fileList }) => {
    // Filtrar apenas arquivos PDF
    const filteredFiles = fileList.filter(file => {
      if (file.type === 'application/pdf' || (file.name && file.name.toLowerCase().endsWith('.pdf'))) {
        return true;
      }
      message.error(`${file.name} não é um arquivo PDF válido`);
      return false;
    });
    
    setFileList(filteredFiles);
  };

  // Visualizar detalhes de um resultado
  const viewDetails = (record) => {
    message.info(`Visualizando detalhes de ${record.file_name}`);
    // Aqui você pode implementar a navegação para uma página de detalhes
    // ou abrir um modal com os detalhes completos
  };

  // Processar arquivos em lote
  const handleBatchUpload = async () => {
    if (fileList.length === 0) {
      message.warning('Por favor, selecione pelo menos um arquivo PDF para upload');
      return;
    }
    
    if (!analysisType) {
      message.warning('Por favor, selecione o tipo de análise');
      return;
    }
    
    setUploading(true);
    setProcessing(true);
    setOverallProgress(0);
    
    // Inicializar resultados com status "waiting"
    const initialResults = fileList.map(file => ({
      file_name: file.name,
      status: 'waiting',
      analysis_type: analysisType,
      task_id: null,
      data: null,
      error: null
    }));
    
    setResults(initialResults);
    
    // Processar cada arquivo sequencialmente
    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      const formData = new FormData();
      formData.append('file', file.originFileObj);
      formData.append('analysis_type', analysisType);
      
      try {
        // Atualizar status para "processing"
        setResults(prev => {
          const updated = [...prev];
          updated[i] = { ...updated[i], status: 'processing' };
          return updated;
        });
        
        // Enviar arquivo para processamento
        const response = await axios.post(`${API_URL}/upload`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          }
        });
        
        const taskId = response.data.task_id;
        
        // Atualizar com o ID da tarefa
        setResults(prev => {
          const updated = [...prev];
          updated[i] = { ...updated[i], task_id: taskId };
          return updated;
        });
        
        // Verificar status da tarefa até completar
        let completed = false;
        while (!completed) {
          await new Promise(resolve => setTimeout(resolve, 2000)); // Esperar 2 segundos
          
          const statusResponse = await axios.get(`${API_URL}/status/${taskId}`);
          const taskData = statusResponse.data;
          
          if (taskData.status === 'success') {
            setResults(prev => {
              const updated = [...prev];
              updated[i] = { 
                ...updated[i], 
                status: 'success',
                data: taskData.data
              };
              return updated;
            });
            completed = true;
          } else if (taskData.status === 'error') {
            setResults(prev => {
              const updated = [...prev];
              updated[i] = { 
                ...updated[i], 
                status: 'error',
                error: taskData.error
              };
              return updated;
            });
            completed = true;
          }
        }
        
        // Atualizar progresso geral
        setOverallProgress(Math.round(((i + 1) / fileList.length) * 100));
        
      } catch (error) {
        console.error(`Erro ao processar ${file.name}:`, error);
        
        // Atualizar status para "error"
        setResults(prev => {
          const updated = [...prev];
          updated[i] = { 
            ...updated[i], 
            status: 'error',
            error: error.response?.data?.detail || 'Erro ao processar arquivo'
          };
          return updated;
        });
        
        // Atualizar progresso geral
        setOverallProgress(Math.round(((i + 1) / fileList.length) * 100));
      }
    }
    
    setUploading(false);
    setProcessing(false);
    message.success(`Processamento em lote concluído. ${results.filter(r => r.status === 'success').length} de ${fileList.length} arquivos processados com sucesso.`);
  };

  // Calcular estatísticas dos resultados
  const getResultStats = () => {
    const total = results.length;
    const success = results.filter(r => r.status === 'success').length;
    const error = results.filter(r => r.status === 'error').length;
    const processing = results.filter(r => r.status === 'processing').length;
    const waiting = results.filter(r => r.status === 'waiting').length;
    
    return { total, success, error, processing, waiting };
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Card title="Processamento em Lote de Documentos" style={{ marginBottom: 16 }}>
        <Space direction="vertical" style={{ width: '100%' }}>
          <Dragger
            fileList={fileList}
            onChange={handleFileChange}
            beforeUpload={() => false}
            multiple={true}
            disabled={uploading || processing}
          >
            <p className="ant-upload-drag-icon">
              <InboxOutlined />
            </p>
            <p className="ant-upload-text">Clique ou arraste arquivos PDF para esta área</p>
            <p className="ant-upload-hint">
              Suporte para upload em lote. Apenas arquivos PDF são aceitos.
            </p>
          </Dragger>
          
          <Select
            placeholder="Selecione o tipo de análise"
            style={{ width: '100%', marginTop: 16 }}
            onChange={value => setAnalysisType(value)}
            disabled={uploading || processing}
          >
            <Option value="Majoração">Majoração</Option>
            <Option value="Reativação">Reativação</Option>
            <Option value="Prospecção">Prospecção</Option>
            <Option value="Revisão">Revisão</Option>
          </Select>
          
          <Button
            type="primary"
            onClick={handleBatchUpload}
            disabled={fileList.length === 0 || !analysisType || uploading || processing}
            loading={uploading || processing}
            style={{ marginTop: 16 }}
            block
          >
            {uploading || processing ? 'Processando...' : 'Iniciar Processamento em Lote'}
          </Button>
          
          {(uploading || processing) && (
            <div style={{ marginTop: 16 }}>
              <Progress percent={overallProgress} status="active" />
              <div style={{ textAlign: 'center', marginTop: 8 }}>
                <LoadingOutlined /> <Text>Processando documentos... {overallProgress}% concluído</Text>
              </div>
            </div>
          )}
        </Space>
      </Card>
      
      {results.length > 0 && (
        <Card title="Resultados do Processamento" style={{ marginTop: 16 }}>
          <div style={{ marginBottom: 16 }}>
            <Space>
              <Tag color="default">Total: {getResultStats().total}</Tag>
              <Tag color="success">Sucesso: {getResultStats().success}</Tag>
              <Tag color="error">Erro: {getResultStats().error}</Tag>
              <Tag color="processing">Processando: {getResultStats().processing}</Tag>
              <Tag color="default">Aguardando: {getResultStats().waiting}</Tag>
            </Space>
          </div>
          
          <Table 
            columns={columns} 
            dataSource={results} 
            rowKey="file_name"
            pagination={{ pageSize: 5 }}
          />
          
          {getResultStats().success > 0 && (
            <div style={{ marginTop: 16, textAlign: 'center' }}>
              <Button 
                type="primary" 
                icon={<CheckCircleOutlined />}
                onClick={() => {
                  // Aqui você pode implementar a integração com o fluxo de análise de crédito
                  message.success('Dados enviados para análise de crédito');
                }}
              >
                Continuar com Análises Bem-sucedidas
              </Button>
            </div>
          )}
        </Card>
      )}
    </motion.div>
  );
};

export default BatchProcessingUploader;
