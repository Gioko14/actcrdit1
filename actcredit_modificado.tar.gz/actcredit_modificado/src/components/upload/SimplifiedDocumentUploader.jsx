import React, { useState, useCallback } from 'react';
import { Upload, Button, Progress, message, Card, Alert } from 'antd';
import { UploadOutlined, FileTextOutlined, CheckCircleOutlined } from '@ant-design/icons';
import { motion } from 'framer-motion';
import { AnalysisTypeFormItem } from '../creditAnalysis/AnalysisTypeSelector';

const { Dragger } = Upload;

/**
 * Componente simplificado para upload de PDF e seleção de tipo de análise
 * Versão atualizada conforme novos requisitos
 */
const DocumentUploader = ({ onSubmit, loading = false }) => {
  const [fileList, setFileList] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState(null);
  const [form] = Form.useForm();

  // Manipular upload de arquivo
  const handleUpload = async () => {
    const formData = new FormData();
    
    if (fileList.length === 0) {
      message.error('Selecione um arquivo para upload');
      return;
    }
    
    // Validar tipo de análise
    const tipoAnalise = form.getFieldValue('tipoAnalise');
    if (!tipoAnalise) {
      message.error('Selecione o tipo de análise');
      return;
    }
    
    const file = fileList[0].originFileObj;
    formData.append('file', file);
    
    setUploading(true);
    setProgress(0);
    setError(null);
    
    try {
      // Simulação de upload (em produção, substituir por chamada real à API)
      await new Promise(resolve => {
        let progress = 0;
        const interval = setInterval(() => {
          progress += 10;
          setProgress(progress);
          
          if (progress >= 100) {
            clearInterval(interval);
            resolve();
          }
        }, 200);
      });
      
      // Criar objeto de análise
      const analise = {
        cnpj: '', // Será extraído do PDF posteriormente
        tipoAnalise,
        dataAnalise: new Date(),
        origem: 'pdf',
        pdfId: `pdf_${Date.now()}`, // Em produção, usar ID retornado pela API
        pdfUrl: URL.createObjectURL(file), // Em produção, usar URL retornada pela API
        resultado: {}
      };
      
      setUploading(false);
      message.success('Upload concluído');
      
      // Chamar callback de submissão
      if (onSubmit) {
        onSubmit(analise);
      }
      
    } catch (err) {
      console.error('Erro no upload', err);
      setError('Falha ao enviar arquivo');
      setUploading(false);
    }
  };
  
  // Configurações do componente de upload
  const uploadProps = {
    onRemove: () => {
      setFileList([]);
    },
    beforeUpload: (file) => {
      // Verificar tipo de arquivo
      const isPDF = file.type === 'application/pdf';
      if (!isPDF) {
        message.error('Você só pode fazer upload de arquivos PDF!');
        return Upload.LIST_IGNORE;
      }
      
      // Verificar tamanho do arquivo (máximo 10MB)
      const isLt10M = file.size / 1024 / 1024 < 10;
      if (!isLt10M) {
        message.error('O arquivo deve ter menos de 10MB!');
        return Upload.LIST_IGNORE;
      }
      
      setFileList([file]);
      return false;
    },
    fileList,
  };
  
  return (
    <Card className="shadow-md rounded-lg">
      <div className="mb-4">
        <h3 className="text-lg font-semibold mb-2">Análise via PDF</h3>
        <p className="text-sm text-gray-600">
          Faça upload de um PDF e selecione o tipo de análise.
        </p>
      </div>
      
      <Form
        form={form}
        layout="vertical"
        requiredMark={false}
      >
        {/* Seletor de tipo de análise */}
        <AnalysisTypeFormItem />
        
        {/* Área de upload */}
        <Dragger 
          {...uploadProps}
          disabled={uploading}
          className="mb-4"
        >
          <p className="ant-upload-drag-icon">
            <FileTextOutlined />
          </p>
          <p className="ant-upload-text">Clique ou arraste um arquivo PDF para esta área</p>
          <p className="ant-upload-hint">
            Suporte apenas para arquivos PDF. Tamanho máximo: 10MB.
          </p>
        </Dragger>
        
        {/* Botão de upload */}
        <Button
          type="primary"
          onClick={handleUpload}
          disabled={fileList.length === 0 || uploading || !form.getFieldValue('tipoAnalise')}
          loading={uploading}
          icon={<UploadOutlined />}
          block
        >
          {uploading ? 'Enviando...' : 'Enviar e Processar'}
        </Button>
      </Form>
      
      {/* Barra de progresso */}
      {uploading && (
        <div className="mt-4">
          <Progress percent={progress} status="active" />
          <p className="text-sm text-gray-600 mt-2">Enviando arquivo...</p>
        </div>
      )}
      
      {/* Mensagem de erro */}
      {error && (
        <Alert
          message="Erro"
          description={error}
          type="error"
          showIcon
          className="mt-4"
        />
      )}
    </Card>
  );
};

export default DocumentUploader;
