import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import ClientDataForm from '@/components/creditAnalysis/ClientDataForm';
import CreditDataForm from '@/components/creditAnalysis/CreditDataForm';
import AnalysisResultCard from '@/components/creditAnalysis/AnalysisResultCard';
import { useToast } from '@/components/ui/use-toast';
import { formatCurrency, formatCNPJ, formatCEP, formatPhone, validateAnalysisForm, parseCurrency } from '@/lib/creditAnalysisUtils';
import { supabase } from '@/lib/supabaseClient';

const initialFormData = {
  nome: '', cnpj: '', dataFundacao: '', setorAtividade: 'varejo', faturamentoAnual: '',
  cep: '', logradouro: '', numero: '', bairro: '', cidade: '',
  telefoneComercial: '', emailComercial: '',
  possuiRestricao: false, informacoesVerificadas: false, score: '',
  valorSolicitado: '', prazo: '12', finalidade: 'capital_giro', politicaId: '',
};

const ManualAnalysisTab = ({ policies, initialData }) => {
  const [formData, setFormData] = useState(() => ({
    ...initialFormData,
    politicaId: policies.find(p => p.isDefault && !p.isCustom)?.id.toString() || (policies.length > 0 ? policies[0].id.toString() : '')
  }));
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    const defaultPolicy = policies.find(p => p.isDefault && !p.isCustom) || (policies.length > 0 ? policies.find(p => !p.isCustom) || policies[0] : null);
    if (defaultPolicy && formData.politicaId === '' && policies.length > 0) {
      setFormData(prev => ({ ...prev, politicaId: defaultPolicy.id.toString() }));
    } else if (formData.politicaId === '' && policies.length > 0) {
      setFormData(prev => ({ ...prev, politicaId: policies[0].id.toString() }));
    }
  }, [policies, formData.politicaId]);

  useEffect(() => {
    if (initialData) {
      const defaultPolicyId = policies.find(p => p.isDefault && !p.isCustom)?.id.toString() || (policies.length > 0 ? policies[0].id.toString() : '');
      setFormData(prev => ({
        ...prev,
        ...initialData,
        faturamentoAnual: initialData.faturamentoAnual ? formatCurrency(initialData.faturamentoAnual.toString().replace(/\D/g, '')) : '',
        valorSolicitado: initialData.valorSolicitado ? formatCurrency(initialData.valorSolicitado.toString().replace(/\D/g, '')) : '',
        politicaId: initialData.politicaId || defaultPolicyId,
        cnpj: initialData.cnpj ? formatCNPJ(initialData.cnpj) : '',
        cep: initialData.cep ? formatCEP(initialData.cep) : '',
        telefoneComercial: initialData.telefoneComercial ? formatPhone(initialData.telefoneComercial) : '',
      }));
    }
  }, [initialData, policies]);


  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (name) => {
    setFormData(prev => ({ ...prev, [name]: !prev[name] }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAnalyze = async () => {
    if (!validateAnalysisForm(formData, toast)) return;
    setIsAnalyzing(true);
    setAnalysisResult(null);

    const selectedPolicy = policies.find(p => p.id.toString() === formData.politicaId) || policies.find(p => p.isDefault && !p.isCustom) || policies[0];
    if (!selectedPolicy) {
        toast({ title: "Erro", description: "Política de crédito não encontrada ou inválida.", variant: "destructive" });
        setIsAnalyzing(false);
        return;
    }

    const score = parseInt(formData.score, 10);
    const faturamentoAnual = parseCurrency(formData.faturamentoAnual);
    const valorSolicitado = parseCurrency(formData.valorSolicitado);
    const prazo = parseInt(formData.prazo, 10);
    
    const rendaMensalEstimada = faturamentoAnual / 12;
    
    const taxaJurosAnualEstimada = score < 600 ? 0.25 : (score < 700 ? 0.18 : 0.12);
    const taxaJurosMensal = Math.pow(1 + taxaJurosAnualEstimada, 1/12) - 1;
    let parcela = 0;
    if (taxaJurosMensal > 0 && !isNaN(taxaJurosMensal) && isFinite(taxaJurosMensal)) {
      parcela = valorSolicitado * (taxaJurosMensal * Math.pow(1 + taxaJurosMensal, prazo)) / (Math.pow(1 + taxaJurosMensal, prazo) - 1);
    } else {
      parcela = valorSolicitado / prazo;
    }
    parcela = isNaN(parcela) || !isFinite(parcela) ? 0 : parcela;


    const comprometimento = rendaMensalEstimada > 0 ? (parcela / rendaMensalEstimada) * 100 : 101;

    let decisao = 'aprovado';
    let motivo = 'Perfil de crédito adequado.';
    let risco = 'baixo';

    if (formData.possuiRestricao) {
      decisao = 'rejeitado'; motivo = 'Cliente possui restrições cadastrais (informado manualmente).'; risco = 'alto';
    } else if (score < selectedPolicy.scoreMinimo) {
      decisao = 'rejeitado'; motivo = `Score (${score}) abaixo do mínimo da política (${selectedPolicy.scoreMinimo}).`; risco = 'alto';
    } else if (comprometimento > selectedPolicy.endividamentoMax) {
      decisao = 'rejeitado'; motivo = `Comprometimento (${comprometimento.toFixed(1)}%) excede o máximo da política (${selectedPolicy.endividamentoMax}%).`; risco = 'médio';
    } else if (valorSolicitado > selectedPolicy.valorMax) {
       decisao = 'rejeitado'; motivo = `Valor (R$ ${valorSolicitado.toLocaleString('pt-BR')}) excede o máximo da política (R$ ${selectedPolicy.valorMax.toLocaleString('pt-BR')}).`; risco = 'médio';
    }
    if (decisao === 'aprovado' && score < (selectedPolicy.scoreMinimo + 100) ) risco = 'médio';

    const result = {
      decisao, motivo, risco, score,
      comprometimento: comprometimento.toFixed(2),
      valorAprovado: decisao === 'aprovado' ? valorSolicitado : 0,
      parcela: parcela.toFixed(2), prazo, taxaJuros: (taxaJurosMensal * 100).toFixed(2),
      data: new Date().toLocaleDateString('pt-BR'), politicaAplicada: selectedPolicy.name,
      formDataSnapshot: { ...formData }
    };
    
    setAnalysisResult(result);
    setIsAnalyzing(false);
    toast({
      title: `Análise Concluída: ${decisao === 'aprovado' ? "Crédito Aprovado" : "Crédito Rejeitado"}`,
      description: motivo, variant: decisao === 'aprovado' ? "default" : "destructive",
    });
    
    try {
      const { data: savedAnalysis, error } = await supabase
        .from('analises_credito')
        .insert([{ 
          nome_cliente: result.formDataSnapshot.nome,
          cnpj_cliente: result.formDataSnapshot.cnpj.replace(/\D/g, ''),
          valor_solicitado: parseCurrency(result.formDataSnapshot.valorSolicitado),
          valor_aprovado: result.valorAprovado,
          decisao: result.decisao,
          motivo: result.motivo,
          risco: result.risco,
          score: result.score,
          parcela: parseFloat(result.parcela),
          prazo: result.prazo,
          taxa_juros: parseFloat(result.taxaJuros),
          data_analise: new Date().toISOString(),
          politica_aplicada: result.politicaAplicada,
          dados_completos_analise: result 
        }])
        .select();
      if (error) throw error;
      toast({ title: "Sucesso", description: "Análise salva no histórico."});
    } catch (error) {
      console.error("Erro ao salvar análise:", error);
      toast({ title: "Erro ao Salvar", description: "Não foi possível salvar a análise no histórico. " + error.message, variant: "destructive"});
    }
  };

  const handleReset = () => {
    const defaultPolicyId = policies.find(p => p.isDefault && !p.isCustom)?.id.toString() || (policies.length > 0 ? policies[0].id.toString() : '');
    setFormData({...initialFormData, politicaId: defaultPolicyId});
    setAnalysisResult(null);
  };

  const containerVariants = { hidden: { opacity: 0 }, visible: { opacity: 1, transition: { staggerChildren: 0.1 } } };
  const itemVariants = { hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 } };

  return (
    <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-6">
      <motion.div variants={itemVariants}>
        <ClientDataForm
          formData={formData}
          setFormData={setFormData}
          handleInputChange={handleInputChange}
          handleCheckboxChange={handleCheckboxChange}
          handleSelectChange={handleSelectChange}
          formatCurrency={(e) => setFormData(prev => ({...prev, [e.target.name]: formatCurrency(e.target.value)}))}
          formatCNPJ={(e) => setFormData(prev => ({...prev, [e.target.name]: formatCNPJ(e.target.value)}))}
          formatCEP={(e) => setFormData(prev => ({...prev, [e.target.name]: formatCEP(e.target.value)}))}
          formatPhone={(e) => setFormData(prev => ({...prev, [e.target.name]: formatPhone(e.target.value)}))}
        />
      </motion.div>
      <motion.div variants={itemVariants}>
        <CreditDataForm
          formData={formData}
          handleInputChange={handleInputChange}
          handleSelectChange={handleSelectChange}
          formatCurrency={(e) => setFormData(prev => ({...prev, [e.target.name]: formatCurrency(e.target.value)}))}
          onAnalyze={handleAnalyze}
          onReset={handleReset}
          isAnalyzing={isAnalyzing}
          policies={policies}
        />
      </motion.div>
      {analysisResult && (
        <motion.div variants={itemVariants}>
          <AnalysisResultCard analysisResult={analysisResult} onReset={handleReset} />
        </motion.div>
      )}
    </motion.div>
  );
};

export default ManualAnalysisTab;