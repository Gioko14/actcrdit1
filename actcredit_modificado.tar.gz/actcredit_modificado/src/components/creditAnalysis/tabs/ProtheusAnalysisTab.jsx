import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Briefcase, Search, Building, MapPin, Phone, Calendar, DollarSign, Users, Info, Loader2, AlertCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { formatCNPJ, formatCEP } from '@/lib/creditAnalysisUtils'; // Import formatCEP
import ManualAnalysisTab from './ManualAnalysisTab'; // Import para usar como destino

const CNPJ_API_URL_TEMPLATE = "https://brasilapi.com.br/api/cnpj/v1/{cnpj}";
const TEST_CNPJ = "05383231000125"; // CNPJ público para teste (ex: Lojas Renner)

const ProtheusAnalysisTab = ({ policies, onDataFetched }) => {
  const [cnpj, setCnpj] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [fetchedData, setFetchedData] = useState(null);
  const [error, setError] = useState(null);
  const { toast } = useToast();

  const handleCnpjChange = (e) => {
    setCnpj(formatCNPJ(e.target.value));
  };

  const handleSearch = async () => {
    const cleanCnpj = cnpj.replace(/\D/g, '');
    if (cleanCnpj.length !== 14) {
      toast({ title: "CNPJ Inválido", description: "Por favor, insira um CNPJ com 14 dígitos.", variant: "destructive" });
      return;
    }

    setIsLoading(true);
    setFetchedData(null);
    setError(null);

    try {
      const apiUrl = CNPJ_API_URL_TEMPLATE.replace("{cnpj}", cleanCnpj);
      const response = await fetch(apiUrl);
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: "CNPJ não encontrado ou inválido."}));
        throw new Error(errorData.message || `Erro ${response.status}: ${response.statusText}`);
      }
      const data = await response.json();
      setFetchedData(data);
      toast({ title: "Dados Encontrados", description: `Informações para ${data.razao_social || 'empresa'} carregadas.` });
      if (onDataFetched) {
        // Mapear dados da BrasilAPI para o formato esperado pelo ManualAnalysisTab
        const mappedData = {
          nome: data.razao_social || '',
          cnpj: data.cnpj || '',
          dataFundacao: data.data_inicio_atividade || '',
          cep: data.cep ? formatCEP(data.cep) : '',
          logradouro: data.logradouro || '',
          numero: data.numero || '',
          bairro: data.bairro || '',
          cidade: data.municipio || '',
          telefoneComercial: data.ddd_telefone_1 || '',
          emailComercial: data.email || '',
          // Campos que a BrasilAPI não fornece diretamente, mas podem ser preenchidos ou inferidos
          setorAtividade: data.cnae_fiscal_descricao ? data.cnae_fiscal_descricao.substring(0,50) : 'outro', // Exemplo, pode precisar de mapeamento melhor
          faturamentoAnual: '', // Não disponível
          possuiRestricao: false, // Assumir como falso inicialmente
          informacoesVerificadas: true, // Dados da API
          score: '', // Não disponível
        };
        onDataFetched(mappedData); // Envia os dados mapeados para a aba de Análise Manual
      }

    } catch (err) {
      setError(err.message);
      toast({ title: "Erro ao Buscar CNPJ", description: err.message, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleTestSearch = () => {
    setCnpj(formatCNPJ(TEST_CNPJ));
     // Pequeno timeout para garantir que o estado do CNPJ seja atualizado antes de chamar handleSearch
    setTimeout(() => {
        handleSearch();
    }, 100);
  };

  const renderDataField = (IconComponent, label, value, className = "") => {
    if (!value && value !== 0) return null;
    return (
      <div className={`flex items-start space-x-2 py-2 border-b border-border/50 last:border-b-0 ${className}`}>
        <IconComponent className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
        <div>
          <p className="text-xs text-muted-foreground">{label}</p>
          <p className="text-sm font-medium text-foreground">{value}</p>
        </div>
      </div>
    );
  };
  
  const renderCnaeList = (cnaes, title) => {
    if (!cnaes || cnaes.length === 0) return null;
    return (
      <div className="mt-3">
        <p className="text-xs font-semibold text-muted-foreground mb-1">{title}:</p>
        <ul className="list-disc list-inside pl-2 space-y-1">
          {cnaes.map(cnae => (
            <li key={cnae.codigo} className="text-xs text-foreground">
              {cnae.codigo} - {cnae.descricao}
            </li>
          ))}
        </ul>
      </div>
    );
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Briefcase className="mr-2 h-5 w-5" />
            Consulta de CNPJ (BrasilAPI)
          </CardTitle>
          <CardDescription>
            Busque informações cadastrais de empresas diretamente da BrasilAPI.
            Após a busca, os dados podem ser enviados para a aba "Imputação Manual".
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row items-start sm:items-end gap-3 mb-6">
            <div className="flex-grow space-y-1.5">
              <label htmlFor="cnpj-protheus" className="text-sm font-medium text-muted-foreground">
                Número do CNPJ
              </label>
              <Input
                id="cnpj-protheus"
                type="text"
                placeholder="00.000.000/0000-00"
                value={cnpj}
                onChange={handleCnpjChange}
                className="text-base"
              />
            </div>
            <Button onClick={handleSearch} disabled={isLoading} className="w-full sm:w-auto">
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
              Buscar CNPJ
            </Button>
            <Button onClick={handleTestSearch} variant="outline" disabled={isLoading} className="w-full sm:w-auto" title={`Testar com CNPJ: ${TEST_CNPJ}`}>
              Testar
            </Button>
          </div>

          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Erro na Busca</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {fetchedData && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <Alert variant="default" className="mb-6 bg-green-50 dark:bg-green-900/30 border-green-200 dark:border-green-700">
                <Info className="h-4 w-4 text-green-600 dark:text-green-400" />
                <AlertTitle className="text-green-700 dark:text-green-300">Dados Carregados com Sucesso!</AlertTitle>
                <AlertDescription className="text-green-600 dark:text-green-500">
                  As informações de {fetchedData.razao_social || 'empresa'} foram obtidas. Você pode enviar estes dados para preencher o formulário na aba "Imputação Manual".
                </AlertDescription>
                 <Button 
                    onClick={() => {
                        if (onDataFetched) {
                            const mappedData = {
                                nome: fetchedData.razao_social || '',
                                cnpj: fetchedData.cnpj ? formatCNPJ(fetchedData.cnpj) : '', // Formata CNPJ
                                dataFundacao: fetchedData.data_inicio_atividade || '',
                                cep: fetchedData.cep ? formatCEP(fetchedData.cep) : '', // Formata CEP
                                logradouro: fetchedData.logradouro || '',
                                numero: fetchedData.numero || '',
                                bairro: fetchedData.bairro || '',
                                cidade: fetchedData.municipio || '',
                                telefoneComercial: fetchedData.ddd_telefone_1 || '',
                                emailComercial: fetchedData.email || '',
                                setorAtividade: fetchedData.cnae_fiscal_descricao ? fetchedData.cnae_fiscal_descricao.substring(0,50) : 'outro',
                                faturamentoAnual: '',
                                possuiRestricao: false,
                                informacoesVerificadas: true,
                                score: '',
                            };
                            onDataFetched(mappedData); // Chama a função passada por props
                            toast({ title: "Dados Enviados", description: "Os dados foram enviados para a aba de Imputação Manual." });
                        } else {
                            toast({ title: "Erro", description: "Função de callback não fornecida para enviar dados.", variant: "destructive" });
                        }
                    }} 
                    className="mt-3"
                    size="sm"
                >
                    Enviar para Análise Manual
                </Button>
              </Alert>

              <Card className="bg-card/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-xl flex items-center">
                    <Building className="mr-2 h-6 w-6 text-primary" />
                    {fetchedData.razao_social || "Nome da Empresa"}
                  </CardTitle>
                  <CardDescription>
                    CNPJ: {formatCNPJ(fetchedData.cnpj)} {fetchedData.descricao_situacao_cadastral && `(${fetchedData.descricao_situacao_cadastral})`}
                  </CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-0">
                  {renderDataField(Info, "Nome Fantasia", fetchedData.nome_fantasia)}
                  {renderDataField(Calendar, "Data de Início da Atividade", fetchedData.data_inicio_atividade ? new Date(fetchedData.data_inicio_atividade).toLocaleDateString('pt-BR') : 'N/A')}
                  {renderDataField(DollarSign, "Capital Social", fetchedData.capital_social ? parseFloat(fetchedData.capital_social).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : 'N/A')}
                  
                  <div className="md:col-span-2 pt-2"><hr className="border-border/30 my-2"/></div>

                  {renderDataField(MapPin, "Endereço", `${fetchedData.logradouro || ''}, ${fetchedData.numero || ''} - ${fetchedData.bairro || ''}`)}
                  {renderDataField(MapPin, "CEP", fetchedData.cep ? formatCEP(fetchedData.cep) : '')}
                  {renderDataField(MapPin, "Município/UF", `${fetchedData.municipio || ''}/${fetchedData.uf || ''}`)}
                  {renderDataField(Phone, "Telefone", fetchedData.ddd_telefone_1)}
                  {renderDataField(Info, "Porte", fetchedData.descricao_porte || fetchedData.porte)}
                  {renderDataField(Info, "Natureza Jurídica", fetchedData.natureza_juridica)}
                  
                  {renderCnaeList(fetchedData.cnaes_secundarios, "CNAEs Secundários")}
                  {fetchedData.qsa && fetchedData.qsa.length > 0 && (
                     <div className="md:col-span-2 pt-3">
                        <p className="text-sm font-semibold text-muted-foreground mb-2 flex items-center"><Users className="h-5 w-5 text-primary mr-2"/> Quadro de Sócios e Administradores (QSA):</p>
                        <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                        {fetchedData.qsa.map((socio, index) => (
                            <div key={index} className="p-2 border rounded-md bg-background/50 text-xs">
                                <p className="font-medium">{socio.nome_socio}</p>
                                <p className="text-muted-foreground">{socio.qualificacao_socio}</p>
                            </div>
                        ))}
                        </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* 
        Abaixo está um placeholder para onde a aba ManualAnalysisTab poderia ser renderizada
        se a navegação para ela com os dados fosse gerenciada internamente aqui.
        No entanto, a abordagem atual é usar a prop onDataFetched para passar dados para CreditAnalysisPage
        que então pode passá-los para ManualAnalysisTab.
      */}
      {/* {fetchedData && showManualAnalysis && (
        <div className="mt-6">
          <h2 className="text-xl font-semibold mb-3">Iniciar Análise Manual com Dados Buscados</h2>
          <ManualAnalysisTab policies={policies} initialData={fetchedDataForManualAnalysis} />
        </div>
      )} */}

    </motion.div>
  );
};

export default ProtheusAnalysisTab;