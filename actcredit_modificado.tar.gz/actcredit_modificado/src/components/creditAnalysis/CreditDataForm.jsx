import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CreditCard, RefreshCw, ArrowRight, CalendarDays, DollarSign, Sliders as FileSliders, ShieldCheck } from 'lucide-react';

const CreditDataForm = ({ formData, handleInputChange, handleSelectChange, formatCurrency, onAnalyze, onReset, isAnalyzing, policies }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <CreditCard className="mr-2 h-5 w-5" />
          Dados do Crédito Solicitado
        </CardTitle>
        <CardDescription>
          Informações sobre o crédito e política aplicada.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="valorSolicitado">Valor Solicitado</Label>
          <div className="relative">
            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              id="valorSolicitado"
              name="valorSolicitado"
              placeholder="0,00"
              value={formData.valorSolicitado}
              onChange={formatCurrency}
              className="pl-8"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="prazo">Prazo (meses)</Label>
            <div className="relative">
                <CalendarDays className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Select
                    value={formData.prazo}
                    onValueChange={(value) => handleSelectChange('prazo', value)}
                >
                <SelectTrigger className="pl-8">
                    <SelectValue placeholder="Selecione o prazo" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="6">6 meses</SelectItem>
                    <SelectItem value="12">12 meses</SelectItem>
                    <SelectItem value="18">18 meses</SelectItem>
                    <SelectItem value="24">24 meses</SelectItem>
                    <SelectItem value="36">36 meses</SelectItem>
                    <SelectItem value="48">48 meses</SelectItem>
                    <SelectItem value="60">60 meses</SelectItem>
                </SelectContent>
                </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="finalidade">Finalidade do Crédito</Label>
             <div className="relative">
                <FileSliders className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Select
                    value={formData.finalidade}
                    onValueChange={(value) => handleSelectChange('finalidade', value)}
                    >
                    <SelectTrigger className="pl-8"><SelectValue placeholder="Selecione a finalidade"/></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="capital_giro">Capital de Giro</SelectItem>
                        <SelectItem value="investimento">Investimento Fixo</SelectItem>
                        <SelectItem value="expansao">Expansão de Negócios</SelectItem>
                        <SelectItem value="refinanciamento">Refinanciamento de Dívidas</SelectItem>
                        <SelectItem value="outros">Outros</SelectItem>
                    </SelectContent>
                </Select>
            </div>
          </div>
        </div>
        
        <div className="space-y-2">
            <Label htmlFor="politicaId">Política de Crédito Aplicada</Label>
            <div className="relative">
                <ShieldCheck className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Select
                    value={formData.politicaId}
                    onValueChange={(value) => handleSelectChange('politicaId', value)}
                >
                    <SelectTrigger className="pl-8">
                        <SelectValue placeholder="Selecione a política de crédito" />
                    </SelectTrigger>
                    <SelectContent>
                        {policies.filter(p => !p.isCustom).map(policy => (
                            <SelectItem key={policy.id} value={policy.id.toString()}>
                                {policy.name}
                            </SelectItem>
                        ))}
                         <SelectItem value="custom">Usar Política Customizada (se houver)</SelectItem>
                    </SelectContent>
                </Select>
            </div>
        </div>

      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={onReset}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Limpar
        </Button>
        <Button onClick={onAnalyze} disabled={isAnalyzing}>
          {isAnalyzing ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Analisando...
            </>
          ) : (
            <>
              <ArrowRight className="mr-2 h-4 w-4" />
              Analisar Crédito
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default CreditDataForm;