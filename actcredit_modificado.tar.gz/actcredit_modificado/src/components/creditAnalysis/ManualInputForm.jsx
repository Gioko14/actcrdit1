import React, { useState } from 'react';
import { Form, Input, Button, Card, Alert, message } from 'antd';
import { CheckOutlined } from '@ant-design/icons';
import { AnalysisTypeFormItem } from './AnalysisTypeSelector';
import { cnpjMask, validateCNPJ } from '@/lib/utils';

/**
 * Componente para imputação manual de CNPJ e tipo de análise
 * Fluxo simplificado conforme solicitado pelo cliente
 */
const ManualInputForm = ({ onSubmit, loading = false }) => {
  const [form] = Form.useForm();
  const [cnpj, setCnpj] = useState('');
  const [cnpjError, setCnpjError] = useState('');

  // Aplicar máscara de CNPJ e validar
  const handleCnpjChange = (e) => {
    const value = e.target.value;
    const maskedValue = cnpjMask(value);
    setCnpj(maskedValue);
    
    // Validar CNPJ apenas se tiver o tamanho completo
    if (maskedValue.replace(/[^\d]/g, '').length === 14) {
      const isValid = validateCNPJ(maskedValue);
      setCnpjError(isValid ? '' : 'CNPJ inválido');
    } else {
      setCnpjError('');
    }
  };

  // Submeter formulário
  const handleSubmit = (values) => {
    // Verificar se CNPJ é válido
    if (!validateCNPJ(values.cnpj)) {
      setCnpjError('CNPJ inválido');
      return;
    }

    // Criar objeto de análise
    const analise = {
      cnpj: values.cnpj.replace(/[^\d]/g, ''), // Remover formatação
      tipoAnalise: values.tipoAnalise,
      dataAnalise: new Date(),
      origem: 'manual',
      pdfId: null,
      pdfUrl: null,
      resultado: {}
    };

    // Chamar callback de submissão
    if (onSubmit) {
      onSubmit(analise);
    } else {
      message.success('Análise iniciada com sucesso!');
    }
  };

  return (
    <Card className="shadow-md rounded-lg">
      <div className="mb-4">
        <h3 className="text-lg font-semibold mb-2">Imputação Manual</h3>
        <p className="text-sm text-gray-600">
          Insira o CNPJ e selecione o tipo de análise para iniciar.
        </p>
      </div>

      <Form
        form={form}
        layout="vertical"
        onFinish={handleSubmit}
        requiredMark={false}
      >
        {/* Campo de CNPJ */}
        <Form.Item
          name="cnpj"
          label="CNPJ"
          validateStatus={cnpjError ? 'error' : ''}
          help={cnpjError}
          rules={[
            { required: true, message: 'Por favor, insira o CNPJ' }
          ]}
        >
          <Input
            placeholder="00.000.000/0000-00"
            value={cnpj}
            onChange={handleCnpjChange}
            maxLength={18}
          />
        </Form.Item>

        {/* Seletor de tipo de análise */}
        <AnalysisTypeFormItem />

        {/* Botão de submissão */}
        <Form.Item>
          <Button
            type="primary"
            htmlType="submit"
            loading={loading}
            icon={<CheckOutlined />}
            block
          >
            Iniciar Análise
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default ManualInputForm;
