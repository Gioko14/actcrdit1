/**
 * Componente para resumo detalhado da análise de crédito
 * Implementa visualização rica e detalhada dos resultados
 */

import React from 'react';
import { 
  Card, 
  Descriptions, 
  Tag, 
  Divider, 
  Typography, 
  Row, 
  Col, 
  Statistic, 
  Progress,
  Space,
  Button,
  Table
} from 'antd';
import { 
  CheckCircleOutlined, 
  CloseCircleOutlined,
  WarningOutlined,
  FileTextOutlined,
  PrinterOutlined,
  DownloadOutlined
} from '@ant-design/icons';
import { motion } from 'framer-motion';
import logger, { logExport } from '@/lib/logger';

const { Title, Text, Paragraph } = Typography;

/**
 * Componente para exibição detalhada do resumo da análise de crédito
 * @param {Object} props - Propriedades do componente
 * @param {Object} props.analysisData - Dados da análise de crédito
 * @param {Function} props.onExport - Função chamada ao exportar o relatório
 * @param {Function} props.onPrint - Função chamada ao imprimir o relatório
 */
const ResumoAnaliseDetalhado = ({ analysisData, onExport, onPrint }) => {
  if (!analysisData) {
    return (
      <Card title="Resumo da Análise">
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <Text type="secondary">Nenhuma análise selecionada</Text>
        </div>
      </Card>
    );
  }

  // Determinar cor da tag de recomendação
  const getRecommendationColor = (recommendation) => {
    if (!recommendation) return 'default';
    if (recommendation.includes('Aprovado') && !recommendation.includes('não')) return 'success';
    if (recommendation.includes('Restrições')) return 'warning';
    if (recommendation.includes('Manual')) return 'processing';
    if (recommendation.includes('Reprovado') || recommendation.includes('não')) return 'error';
    return 'default';
  };

  // Determinar cor da tag de risco
  const getRiskColor = (risk) => {
    if (!risk) return 'default';
    if (risk === 'A') return 'success';
    if (risk === 'B') return 'success';
    if (risk === 'C') return 'warning';
    if (risk === 'D') return 'warning';
    if (risk === 'E') return 'error';
    return 'default';
  };

  // Determinar cor do score
  const getScoreColor = (score) => {
    if (!score) return '#000000';
    if (score >= 800) return '#52c41a';
    if (score >= 600) return '#1890ff';
    if (score >= 400) return '#faad14';
    if (score >= 200) return '#fa8c16';
    return '#f5222d';
  };

  // Formatar valor monetário
  const formatCurrency = (value) => {
    if (value === undefined || value === null) return 'N/A';
    return `R$ ${Number(value).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  // Formatar data
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('pt-BR');
    } catch (error) {
      return dateString;
    }
  };

  // Calcular percentual de utilização do limite
  const calculateUsagePercentage = () => {
    if (!analysisData.valorEmAberto || !analysisData.limiteCredito) return 0;
    return Math.min(Math.round((analysisData.valorEmAberto / analysisData.limiteCredito) * 100), 100);
  };

  // Determinar status do percentual de utilização
  const getUsageStatus = (percentage) => {
    if (percentage >= 90) return 'exception';
    if (percentage >= 70) return 'warning';
    return 'normal';
  };

  // Exportar relatório
  const handleExport = () => {
    logExport('pdf', { 
      analysisType: analysisData.tipoAnalise,
      cnpj: analysisData.cnpj,
      recommendation: analysisData.recomendacao
    });
    
    if (onExport) {
      onExport(analysisData);
    }
  };

  // Imprimir relatório
  const handlePrint = () => {
    logExport('print', { 
      analysisType: analysisData.tipoAnalise,
      cnpj: analysisData.cnpj,
      recommendation: analysisData.recomendacao
    });
    
    if (onPrint) {
      onPrint(analysisData);
    }
  };

  // Colunas para tabela de histórico de pagamentos
  const paymentColumns = [
    {
      title: 'Data',
      dataIndex: 'data',
      key: 'data',
      render: (text) => formatDate(text),
    },
    {
      title: 'Valor',
      dataIndex: 'valor',
      key: 'valor',
      render: (text) => formatCurrency(text),
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => {
        let color = 'default';
        if (status === 'Pago') color = 'success';
        if (status === 'Pendente') color = 'processing';
        if (status === 'Atrasado') color = 'error';
        return <Tag color={color}>{status}</Tag>;
      },
    },
    {
      title: 'Dias de Atraso',
      dataIndex: 'diasAtraso',
      key: 'diasAtraso',
      render: (text) => text || '0',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Card 
        title={
          <Space>
            <span>Resumo Detalhado da Análise</span>
            <Tag color="blue">{analysisData.tipoAnalise || 'Análise de Crédito'}</Tag>
          </Space>
        }
        extra={
          <Space>
            <Button 
              icon={<FileTextOutlined />} 
              onClick={handleExport}
            >
              Exportar
            </Button>
            <Button 
              icon={<PrinterOutlined />} 
              onClick={handlePrint}
            >
              Imprimir
            </Button>
          </Space>
        }
      >
        {/* Cabeçalho com informações principais */}
        <Row gutter={[16, 16]}>
          <Col xs={24} sm={8}>
            <Statistic 
              title="Score de Crédito" 
              value={analysisData.score || 0} 
              suffix="/1000"
              valueStyle={{ color: getScoreColor(analysisData.score) }}
            />
          </Col>
          <Col xs={24} sm={8}>
            <Statistic 
              title="Limite de Crédito" 
              value={analysisData.limiteCredito || 0} 
              precision={2}
              prefix="R$"
            />
          </Col>
          <Col xs={24} sm={8}>
            <div style={{ textAlign: 'center', marginTop: 4 }}>
              <div style={{ marginBottom: 8 }}>
                <Text strong>Recomendação</Text>
              </div>
              <Tag 
                color={getRecommendationColor(analysisData.recomendacao)} 
                style={{ fontSize: '14px', padding: '4px 8px' }}
              >
                {analysisData.recomendacao || 'Não disponível'}
              </Tag>
            </div>
          </Col>
        </Row>

        <Divider />

        {/* Informações da empresa */}
        <Title level={5}>Informações da Empresa</Title>
        <Descriptions bordered column={{ xs: 1, sm: 2, md: 3 }} size="small">
          <Descriptions.Item label="CNPJ">{analysisData.cnpj}</Descriptions.Item>
          <Descriptions.Item label="Razão Social">{analysisData.razaoSocial}</Descriptions.Item>
          <Descriptions.Item label="Nome Fantasia">{analysisData.nomeFantasia || 'Não informado'}</Descriptions.Item>
          <Descriptions.Item label="Data de Abertura">{formatDate(analysisData.dataAbertura)}</Descriptions.Item>
          <Descriptions.Item label="Porte">{analysisData.porte || 'Não informado'}</Descriptions.Item>
          <Descriptions.Item label="Situação Cadastral">
            <Tag color={analysisData.situacaoCadastral === 'ATIVA' ? 'success' : 'error'}>
              {analysisData.situacaoCadastral || 'Não informado'}
            </Tag>
          </Descriptions.Item>
          <Descriptions.Item label="Capital Social">{formatCurrency(analysisData.capitalSocial)}</Descriptions.Item>
          <Descriptions.Item label="Setor">{analysisData.setor || 'Não informado'}</Descriptions.Item>
          <Descriptions.Item label="Nível de Risco">
            <Tag color={getRiskColor(analysisData.nivelRisco)}>
              {analysisData.nivelRisco || 'Não informado'}
            </Tag>
          </Descriptions.Item>
        </Descriptions>

        <Divider />

        {/* Análise financeira */}
        <Title level={5}>Análise Financeira</Title>
        <Row gutter={[16, 16]}>
          <Col xs={24} md={12}>
            <Card size="small" title="Utilização do Limite de Crédito">
              <Progress 
                percent={calculateUsagePercentage()} 
                status={getUsageStatus(calculateUsagePercentage())}
                format={percent => `${percent}%`}
              />
              <div style={{ marginTop: 16 }}>
                <Row>
                  <Col span={12}>
                    <Text strong>Limite Total:</Text>
                  </Col>
                  <Col span={12} style={{ textAlign: 'right' }}>
                    <Text>{formatCurrency(analysisData.limiteCredito)}</Text>
                  </Col>
                </Row>
                <Row>
                  <Col span={12}>
                    <Text strong>Valor em Aberto:</Text>
                  </Col>
                  <Col span={12} style={{ textAlign: 'right' }}>
                    <Text>{formatCurrency(analysisData.valorEmAberto)}</Text>
                  </Col>
                </Row>
                <Row>
                  <Col span={12}>
                    <Text strong>Disponível:</Text>
                  </Col>
                  <Col span={12} style={{ textAlign: 'right' }}>
                    <Text>
                      {formatCurrency(
                        analysisData.limiteCredito && analysisData.valorEmAberto
                          ? analysisData.limiteCredito - analysisData.valorEmAberto
                          : null
                      )}
                    </Text>
                  </Col>
                </Row>
              </div>
            </Card>
          </Col>
          <Col xs={24} md={12}>
            <Card size="small" title="Indicadores de Risco">
              <Row gutter={[8, 8]}>
                <Col span={12}>
                  <Statistic 
                    title="Dias de Atraso Médio" 
                    value={analysisData.diasAtrasoMedio || 0}
                    valueStyle={{ 
                      color: analysisData.diasAtrasoMedio > 30 
                        ? '#f5222d' 
                        : analysisData.diasAtrasoMedio > 15 
                          ? '#faad14' 
                          : '#52c41a'
                    }}
                  />
                </Col>
                <Col span={12}>
                  <Statistic 
                    title="Protestos" 
                    value={analysisData.protestos || 0}
                    valueStyle={{ 
                      color: analysisData.protestos > 0 ? '#f5222d' : '#52c41a'
                    }}
                  />
                </Col>
                <Col span={12}>
                  <Statistic 
                    title="Restrições" 
                    value={analysisData.restricoes || 0}
                    valueStyle={{ 
                      color: analysisData.restricoes > 0 ? '#f5222d' : '#52c41a'
                    }}
                  />
                </Col>
                <Col span={12}>
                  <Statistic 
                    title="Última Compra" 
                    value={formatDate(analysisData.ultimaCompra) || 'N/A'}
                    valueStyle={{ fontSize: '14px' }}
                  />
                </Col>
              </Row>
            </Card>
          </Col>
        </Row>

        <Divider />

        {/* Histórico de pagamentos */}
        <Title level={5}>Histórico de Pagamentos</Title>
        <Table 
          dataSource={analysisData.historicoPagamentos || []} 
          columns={paymentColumns}
          rowKey={(record, index) => `payment-${index}`}
          pagination={{ pageSize: 5 }}
          size="small"
        />

        <Divider />

        {/* Observações e recomendações */}
        <Title level={5}>Observações e Recomendações</Title>
        <Card size="small">
          <Paragraph>
            {analysisData.observacoes || 'Nenhuma observação disponível.'}
          </Paragraph>
          
          {analysisData.recomendacaoDetalhada && (
            <>
              <Divider />
              <Title level={5}>Recomendação Detalhada</Title>
              <Paragraph>
                {analysisData.recomendacaoDetalhada}
              </Paragraph>
            </>
          )}
          
          {analysisData.alertas && analysisData.alertas.length > 0 && (
            <>
              <Divider />
              <Title level={5}>Alertas</Title>
              {analysisData.alertas.map((alerta, index) => (
                <div key={`alert-${index}`} style={{ marginBottom: 8 }}>
                  <Tag color="warning" icon={<WarningOutlined />}>
                    {alerta}
                  </Tag>
                </div>
              ))}
            </>
          )}
        </Card>

        <Divider />

        {/* Metadados da análise */}
        <Row>
          <Col span={24}>
            <div style={{ textAlign: 'right' }}>
              <Text type="secondary">
                Análise realizada em {formatDate(analysisData.dataAnalise)} via {analysisData.fonteDados || 'API'}
              </Text>
            </div>
          </Col>
        </Row>
      </Card>
    </motion.div>
  );
};

export default ResumoAnaliseDetalhado;
