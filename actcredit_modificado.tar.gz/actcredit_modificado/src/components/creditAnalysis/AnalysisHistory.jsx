import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { FileText, Search, CheckCircle, XCircle, AlertTriangle, Loader2, ServerCrash } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { formatCNPJ } from '@/lib/creditAnalysisUtils';

const ITEMS_PER_PAGE = 5;

const AnalysisHistory = () => {
  const [history, setHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const { toast } = useToast();

  useEffect(() => {
    const fetchHistory = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const { data, error: dbError } = await supabase
          .from('analises_credito')
          .select(`
            id, 
            nome_cliente, 
            cnpj_cliente, 
            valor_aprovado, 
            data_analise, 
            decisao, 
            score, 
            politica_aplicada,
            dados_completos_analise 
          `)
          .order('data_analise', { ascending: false });

        if (dbError) {
          throw dbError;
        }
        
        const formattedData = data.map(item => ({
          id: item.id,
          nome: item.nome_cliente || item.dados_completos_analise?.formDataSnapshot?.nome || 'N/A',
          cnpj: item.cnpj_cliente ? formatCNPJ(item.cnpj_cliente) : (item.dados_completos_analise?.formDataSnapshot?.cnpj ? formatCNPJ(item.dados_completos_analise.formDataSnapshot.cnpj) : 'N/A'),
          valor: item.valor_aprovado !== null && item.valor_aprovado !== undefined ? item.valor_aprovado : 0,
          data: item.data_analise ? new Date(item.data_analise).toLocaleDateString('pt-BR') : 'N/A',
          status: item.decisao || 'desconhecido',
          score: item.score !== null && item.score !== undefined ? item.score : 'N/A',
          tipo: item.politica_aplicada || 'N/A'
        }));
        setHistory(formattedData);

      } catch (err) {
        console.error("Erro ao buscar histórico:", err);
        setError("Não foi possível carregar o histórico de análises. Verifique a console para mais detalhes ou se a tabela 'analises_credito' existe e está acessível.");
        toast({
          title: "Erro ao Carregar Histórico",
          description: err.message || "Falha na comunicação com o banco de dados.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchHistory();
  }, [toast]);

  const filteredHistory = history.filter(analise => 
    (analise.nome && analise.nome.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (analise.cnpj && analise.cnpj.includes(searchTerm)) ||
    (analise.id && analise.id.toString().includes(searchTerm))
  );

  const totalPages = Math.ceil(filteredHistory.length / ITEMS_PER_PAGE);
  const paginatedHistory = filteredHistory.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Análises</CardTitle>
          <CardDescription>Carregando histórico...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center items-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border-destructive">
        <CardHeader>
          <CardTitle className="text-destructive">Erro no Histórico</CardTitle>
          <CardDescription className="text-destructive">
            {error}
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center py-10">
          <ServerCrash className="h-12 w-12 text-destructive mb-4" />
          <p>Tente recarregar a página ou contate o suporte.</p>
          <Button onClick={() => window.location.reload()} className="mt-4">Recarregar</Button>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Histórico de Análises</CardTitle>
        <CardDescription>
          Visualize e gerencie análises de crédito anteriores. Os dados são carregados do Supabase.
        </CardDescription>
        <div className="flex w-full max-w-md items-center space-x-2 mt-4">
          <Input 
            placeholder="Buscar por nome, CNPJ ou ID" 
            value={searchTerm}
            onChange={handleSearchChange}
          />
          <Button type="button" size="icon" onClick={() => setCurrentPage(1)}>
            <Search className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {paginatedHistory.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground">
            <FileText size={48} className="mx-auto mb-4" />
            <p className="text-lg font-semibold">Nenhuma análise encontrada.</p>
            <p>Se você acabou de configurar, pode levar um momento para os dados aparecerem ou a tabela 'analises_credito' pode estar vazia.</p>
            <p>Realize uma nova análise na aba "Imputação Manual" e ela deverá aparecer aqui se o salvamento no Supabase estiver ativo.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {paginatedHistory.map((analise) => (
              <div
                key={analise.id}
                className="flex flex-col md:flex-row items-start md:items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors gap-4 md:gap-2"
              >
                <div className="flex items-center space-x-3 flex-1">
                  <div className={`w-3 h-3 rounded-full mt-1 md:mt-0 flex-shrink-0 ${
                    analise.status === "aprovado" ? "bg-green-500" :
                    analise.status === "rejeitado" ? "bg-red-500" : "bg-yellow-500"
                  }`}></div>
                  <div>
                    <p className="font-medium text-foreground">{analise.nome}</p>
                    <p className="text-sm text-muted-foreground">{analise.cnpj} • Score: {analise.score} • Política: {analise.tipo}</p>
                  </div>
                </div>
                
                <div className="text-sm text-muted-foreground md:text-right">
                  <p className="font-medium text-foreground">
                    {analise.valor.toLocaleString('pt-BR', {
                      style: 'currency',
                      currency: 'BRL'
                    })}
                  </p>
                  <p>{analise.data}</p>
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                    analise.status === "aprovado"
                      ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300" :
                    analise.status === "rejeitado"
                      ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300" :
                      "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300"
                  }`}>
                    {analise.status === "aprovado" ? (
                      <CheckCircle className="mr-1 h-3 w-3" />
                    ) : analise.status === "rejeitado" ? (
                      <XCircle className="mr-1 h-3 w-3" />
                    ) : (
                      <AlertTriangle className="mr-1 h-3 w-3" />
                    )}
                    {analise.status.charAt(0).toUpperCase() + analise.status.slice(1)}
                  </span>
                  <Button variant="ghost" size="icon" title="Ver Detalhes/Relatório (Em breve)">
                    <FileText className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      {paginatedHistory.length > 0 && (
        <CardFooter className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="text-sm text-muted-foreground">
            Mostrando {((currentPage - 1) * ITEMS_PER_PAGE) + 1} - {Math.min(currentPage * ITEMS_PER_PAGE, filteredHistory.length)} de {filteredHistory.length} resultados.
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            >
              Anterior
            </Button>
            <span className="text-sm text-muted-foreground">Página {currentPage} de {totalPages}</span>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
            >
              Próximo
            </Button>
          </div>
        </CardFooter>
      )}
    </Card>
  );
};

export default AnalysisHistory;