import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Card, 
  Form, 
  Input, 
  Button, 
  Select, 
  Table, 
  Tag, 
  Space, 
  Progress, 
  message, 
  Typography, 
  Divider,
  Alert,
  Spin,
  Modal
} from 'antd';
import { 
  SearchOutlined, 
  CheckCircleOutlined, 
  CloseCircleOutlined,
  LoadingOutlined,
  FileTextOutlined,
  UploadOutlined
} from '@ant-design/icons';
import ProtheusService from '@/services/protheus-integration/ProtheusService';

const { Option } = Select;
const { Title, Text, Paragraph } = Typography;
const { TextArea } = Input;

/**
 * Componente para análise em lote via Protheus
 * Permite análise de múltiplos CNPJs simultaneamente
 */
const ProtheusBatchAnalysis = () => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);
  const [analysisType, setAnalysisType] = useState(null);
  const [overallProgress, setOverallProgress] = useState(0);
  const [detailsVisible, setDetailsVisible] = useState(false);
  const [selectedResult, setSelectedResult] = useState(null);

  // Colunas da tabela de resultados
  const columns = [
    {
      title: 'CNPJ',
      dataIndex: 'cnpj',
      key: 'cnpj',
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => (
        <>
          {status === 'success' && <Tag color="success">Sucesso</Tag>}
          {status === 'error' && <Tag color="error">Erro</Tag>}
          {status === 'processing' && <Tag color="processing">Processando</Tag>}
          {status === 'waiting' && <Tag color="default">Aguardando</Tag>}
        </>
      ),
    },
    {
      title: 'Razão Social',
      dataIndex: ['resultado', 'cliente', 'razao_social'],
      key: 'razao_social',
      render: (text, record) => record.resultado?.cliente?.razao_social || '-',
    },
    {
      title: 'Score',
      dataIndex: ['resultado', 'score_credito'],
      key: 'score',
      render: (text, record) => record.resultado?.score_credito || '-',
    },
    {
      title: 'Limite Recomendado',
      dataIndex: ['resultado', 'limite_recomendado'],
      key: 'limite',
      render: (text, record) => {
        if (!record.resultado?.limite_recomendado) return '-';
        return `R$ ${record.resultado.limite_recomendado.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
      },
    },
    {
      title: 'Recomendação',
      dataIndex: ['resultado', 'recomendacao'],
      key: 'recomendacao',
      render: (text, record) => {
        if (!record.resultado?.recomendacao) return '-';
        return (
          <Tag color={record.resultado.recomendacao === 'Aprovado' ? 'success' : 'error'}>
            {record.resultado.recomendacao}
          </Tag>
        );
      },
    },
    {
      title: 'Ações',
      key: 'action',
      render: (_, record) => (
        <Space size="middle">
          {record.status === 'success' && (
            <Button 
              type="link" 
              onClick={() => viewDetails(record)}
              icon={<FileTextOutlined />}
            >
              Detalhes
            </Button>
          )}
        </Space>
      ),
    },
  ];

  // Visualizar detalhes de um resultado
  const viewDetails = (record) => {
    setSelectedResult(record);
    setDetailsVisible(true);
  };

  // Processar CNPJs em lote
  const handleBatchAnalysis = async (values) => {
    const { cnpjs } = values;
    
    if (!cnpjs) {
      message.warning('Por favor, informe pelo menos um CNPJ para análise');
      return;
    }
    
    if (!analysisType) {
      message.warning('Por favor, selecione o tipo de análise');
      return;
    }
    
    // Separar CNPJs por linha ou vírgula
    const cnpjList = cnpjs
      .split(/[\n,;]/)
      .map(cnpj => cnpj.trim())
      .filter(cnpj => cnpj.length > 0);
    
    if (cnpjList.length === 0) {
      message.warning('Por favor, informe pelo menos um CNPJ válido para análise');
      return;
    }
    
    setLoading(true);
    setOverallProgress(0);
    
    // Inicializar resultados com status "waiting"
    const initialResults = cnpjList.map(cnpj => ({
      cnpj: cnpj,
      status: 'waiting',
      analysis_type: analysisType,
      resultado: null,
      erro: null
    }));
    
    setResults(initialResults);
    
    // Processar cada CNPJ sequencialmente
    for (let i = 0; i < cnpjList.length; i++) {
      const cnpj = cnpjList[i];
      
      try {
        // Atualizar status para "processing"
        setResults(prev => {
          const updated = [...prev];
          updated[i] = { ...updated[i], status: 'processing' };
          return updated;
        });
        
        // Realizar análise de crédito via Protheus
        const resultado = await ProtheusService.realizarAnaliseCredito(cnpj, analysisType);
        
        // Atualizar com o resultado
        setResults(prev => {
          const updated = [...prev];
          updated[i] = { 
            ...updated[i], 
            status: 'success',
            resultado: resultado
          };
          return updated;
        });
        
        // Atualizar progresso geral
        setOverallProgress(Math.round(((i + 1) / cnpjList.length) * 100));
        
      } catch (error) {
        console.error(`Erro ao analisar CNPJ ${cnpj}:`, error);
        
        // Atualizar status para "error"
        setResults(prev => {
          const updated = [...prev];
          updated[i] = { 
            ...updated[i], 
            status: 'error',
            erro: error.message || 'Erro ao analisar CNPJ'
          };
          return updated;
        });
        
        // Atualizar progresso geral
        setOverallProgress(Math.round(((i + 1) / cnpjList.length) * 100));
      }
    }
    
    setLoading(false);
    message.success(`Análise em lote concluída. ${results.filter(r => r.status === 'success').length} de ${cnpjList.length} CNPJs analisados com sucesso.`);
  };

  // Calcular estatísticas dos resultados
  const getResultStats = () => {
    const total = results.length;
    const success = results.filter(r => r.status === 'success').length;
    const error = results.filter(r => r.status === 'error').length;
    const processing = results.filter(r => r.status === 'processing').length;
    const waiting = results.filter(r => r.status === 'waiting').length;
    
    return { total, success, error, processing, waiting };
  };

  // Renderizar modal de detalhes
  const renderDetailsModal = () => {
    if (!selectedResult) return null;
    
    const result = selectedResult.resultado;
    
    return (
      <Modal
        title={`Detalhes da Análise - ${result.cliente.razao_social}`}
        open={detailsVisible}
        onCancel={() => setDetailsVisible(false)}
        width={800}
        footer={[
          <Button key="close" onClick={() => setDetailsVisible(false)}>
            Fechar
          </Button>,
          <Button 
            key="export" 
            type="primary" 
            icon={<FileTextOutlined />}
            onClick={() => {
              message.success('Relatório exportado com sucesso');
              setDetailsVisible(false);
            }}
          >
            Exportar Relatório
          </Button>
        ]}
      >
        <Space direction="vertical" style={{ width: '100%' }}>
          <Card title="Informações Gerais" style={{ marginBottom: 16 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <Text strong>CNPJ:</Text> <Text>{result.cnpj}</Text>
              </div>
              <div>
                <Text strong>Tipo de Análise:</Text> <Text>{result.tipo_analise}</Text>
              </div>
              <div>
                <Text strong>Data da Análise:</Text> <Text>{new Date(result.data_analise).toLocaleString('pt-BR')}</Text>
              </div>
              <div>
                <Text strong>Fonte de Dados:</Text> <Text>{result.fonte_dados}</Text>
              </div>
            </div>
          </Card>
          
          <Card title="Resultado da Análise" style={{ marginBottom: 16 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <Text strong>Score de Crédito:</Text> <Text>{result.score_credito}</Text>
              </div>
              <div>
                <Text strong>Classificação de Risco:</Text> <Text>{result.classificacao_risco}</Text>
              </div>
              <div>
                <Text strong>Limite Atual:</Text> <Text>R$ {result.limite_atual.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</Text>
              </div>
              <div>
                <Text strong>Limite Recomendado:</Text> <Text>R$ {result.limite_recomendado.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</Text>
              </div>
              <div>
                <Text strong>Recomendação:</Text> 
                <Tag color={result.recomendacao === 'Aprovado' ? 'success' : 'error'}>
                  {result.recomendacao}
                </Tag>
              </div>
            </div>
          </Card>
          
          <Card title="Dados do Cliente" style={{ marginBottom: 16 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <Text strong>Razão Social:</Text> <Text>{result.cliente.razao_social}</Text>
              </div>
              <div>
                <Text strong>Nome Fantasia:</Text> <Text>{result.cliente.nome_fantasia || 'Não informado'}</Text>
              </div>
              <div>
                <Text strong>Código Cliente:</Text> <Text>{result.cliente.codigo_cliente}</Text>
              </div>
              <div>
                <Text strong>Situação Cadastral:</Text> <Text>{result.cliente.situacao_cadastral}</Text>
              </div>
              <div>
                <Text strong>Data de Abertura:</Text> <Text>{result.cliente.data_inicio_atividade}</Text>
              </div>
              <div>
                <Text strong>Porte:</Text> <Text>{result.cliente.porte}</Text>
              </div>
            </div>
          </Card>
          
          <Card title="Histórico de Pedidos" style={{ marginBottom: 16 }}>
            <div style={{ marginBottom: 16 }}>
              <Text strong>Total de Pedidos:</Text> <Text>{result.historico_pedidos.total_pedidos}</Text>
              <br />
              <Text strong>Valor Total:</Text> <Text>R$ {result.historico_pedidos.valor_total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</Text>
            </div>
            
            <Table 
              dataSource={result.historico_pedidos.pedidos} 
              rowKey="numero_pedido"
              pagination={{ pageSize: 5 }}
              size="small"
              columns={[
                {
                  title: 'Número',
                  dataIndex: 'numero_pedido',
                  key: 'numero_pedido',
                },
                {
                  title: 'Data',
                  dataIndex: 'data_pedido',
                  key: 'data_pedido',
                },
                {
                  title: 'Valor',
                  dataIndex: 'valor_total',
                  key: 'valor_total',
                  render: (value) => `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
                },
                {
                  title: 'Status',
                  dataIndex: 'status',
                  key: 'status',
                  render: (status) => {
                    let color = 'default';
                    if (status === 'Faturado') color = 'processing';
                    if (status === 'Entregue') color = 'success';
                    if (status === 'Cancelado') color = 'error';
                    return <Tag color={color}>{status}</Tag>;
                  },
                },
              ]}
            />
          </Card>
          
          <Card title="Títulos em Aberto" style={{ marginBottom: 16 }}>
            <div style={{ marginBottom: 16 }}>
              <Text strong>Total de Títulos:</Text> <Text>{result.titulos_aberto.total_titulos}</Text>
              <br />
              <Text strong>Valor Total:</Text> <Text>R$ {result.titulos_aberto.valor_total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</Text>
              <br />
              <Text strong>Saldo Total:</Text> <Text>R$ {result.titulos_aberto.saldo_total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</Text>
            </div>
            
            <Table 
              dataSource={result.titulos_aberto.titulos} 
              rowKey="numero_titulo"
              pagination={{ pageSize: 5 }}
              size="small"
              columns={[
                {
                  title: 'Número',
                  dataIndex: 'numero_titulo',
                  key: 'numero_titulo',
                },
                {
                  title: 'Emissão',
                  dataIndex: 'data_emissao',
                  key: 'data_emissao',
                },
                {
                  title: 'Vencimento',
                  dataIndex: 'data_vencimento',
                  key: 'data_vencimento',
                },
                {
                  title: 'Valor',
                  dataIndex: 'valor',
                  key: 'valor',
                  render: (value) => `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
                },
                {
                  title: 'Saldo',
                  dataIndex: 'saldo',
                  key: 'saldo',
                  render: (value) => `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
                },
                {
                  title: 'Status',
                  dataIndex: 'status',
                  key: 'status',
                  render: (status) => {
                    let color = 'default';
                    if (status === 'Em aberto') color = 'processing';
                    if (status === 'Parcialmente pago') color = 'warning';
                    if (status === 'Vencido') color = 'error';
                    return <Tag color={color}>{status}</Tag>;
                  },
                },
              ]}
            />
          </Card>
          
          <Card title="Observações">
            <Paragraph>{result.observacoes}</Paragraph>
          </Card>
        </Space>
      </Modal>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Card title="Análise em Lote via Protheus" style={{ marginBottom: 16 }}>
        <Form
          form={form}
          layout="vertical"
          onFinish={handleBatchAnalysis}
        >
          <Form.Item
            name="cnpjs"
            label="Lista de CNPJs"
            rules={[{ required: true, message: 'Por favor, informe pelo menos um CNPJ' }]}
          >
            <TextArea 
              placeholder="Informe um CNPJ por linha ou separados por vírgula/ponto-e-vírgula"
              disabled={loading}
              rows={5}
            />
          </Form.Item>
          
          <Form.Item
            name="analysisType"
            label="Tipo de Análise"
            rules={[{ required: true, message: 'Por favor, selecione o tipo de análise' }]}
          >
            <Select
              placeholder="Selecione o tipo de análise"
              onChange={value => setAnalysisType(value)}
              disabled={loading}
            >
              <Option value="Majoração">Majoração</Option>
              <Option value="Reativação">Reativação</Option>
              <Option value="Prospecção">Prospecção</Option>
              <Option value="Revisão">Revisão</Option>
            </Select>
          </Form.Item>
          
          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              icon={<SearchOutlined />}
              loading={loading}
              block
            >
              {loading ? 'Processando...' : 'Iniciar Análise em Lote'}
            </Button>
          </Form.Item>
        </Form>
        
        {loading && (
          <div style={{ marginTop: 16 }}>
            <Progress percent={overallProgress} status="active" />
            <div style={{ textAlign: 'center', marginTop: 8 }}>
              <LoadingOutlined /> <Text>Analisando CNPJs... {overallProgress}% concluído</Text>
            </div>
          </div>
        )}
      </Card>
      
      {results.length > 0 && (
        <Card title="Resultados da Análise" style={{ marginTop: 16 }}>
          <div style={{ marginBottom: 16 }}>
            <Space>
              <Tag color="default">Total: {getResultStats().total}</Tag>
              <Tag color="success">Sucesso: {getResultStats().success}</Tag>
              <Tag color="error">Erro: {getResultStats().error}</Tag>
              <Tag color="processing">Processando: {getResultStats().processing}</Tag>
              <Tag color="default">Aguardando: {getResultStats().waiting}</Tag>
            </Space>
          </div>
          
          <Table 
            columns={columns} 
            dataSource={results} 
            rowKey="cnpj"
            pagination={{ pageSize: 5 }}
          />
          
          {getResultStats().success > 0 && (
            <div style={{ marginTop: 16, textAlign: 'center' }}>
              <Button 
                type="primary" 
                icon={<CheckCircleOutlined />}
                onClick={() => {
                  // Aqui você pode implementar a integração com o fluxo de análise de crédito
                  message.success('Dados enviados para análise de crédito');
                }}
              >
                Continuar com Análises Bem-sucedidas
              </Button>
            </div>
          )}
        </Card>
      )}
      
      {renderDetailsModal()}
    </motion.div>
  );
};

export default ProtheusBatchAnalysis;
