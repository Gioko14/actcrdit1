/**
 * Componente para validação do PWA instalável
 * Testa funcionalidades de instalação, cache e offline
 */

import React, { useState, useEffect } from 'react';
import { Card, Button, Steps, Result, Typography, Space, Divider, Alert } from 'antd';
import { CheckCircleOutlined, CloseCircleOutlined, LoadingOutlined } from '@ant-design/icons';

const { Title, Text, Paragraph } = Typography;
const { Step } = Steps;

const PWAValidator = () => {
  const [serviceWorkerStatus, setServiceWorkerStatus] = useState('checking');
  const [manifestStatus, setManifestStatus] = useState('checking');
  const [installabilityStatus, setInstallabilityStatus] = useState('checking');
  const [offlineStatus, setOfflineStatus] = useState('checking');
  const [cacheStatus, setCacheStatus] = useState('checking');
  const [overallStatus, setOverallStatus] = useState('checking');

  useEffect(() => {
    // Verificar Service Worker
    checkServiceWorker();
    
    // Verificar Manifest
    checkManifest();
    
    // Verificar Installability
    checkInstallability();
    
    // Verificar Offline Support
    checkOfflineSupport();
    
    // Verificar Cache
    checkCache();
  }, []);

  // Atualizar status geral quando todos os testes forem concluídos
  useEffect(() => {
    const allStatuses = [
      serviceWorkerStatus,
      manifestStatus,
      installabilityStatus,
      offlineStatus,
      cacheStatus
    ];
    
    if (allStatuses.includes('checking')) {
      setOverallStatus('checking');
    } else if (allStatuses.includes('failed')) {
      setOverallStatus('failed');
    } else {
      setOverallStatus('success');
    }
  }, [serviceWorkerStatus, manifestStatus, installabilityStatus, offlineStatus, cacheStatus]);

  // Verificar Service Worker
  const checkServiceWorker = async () => {
    try {
      if (!('serviceWorker' in navigator)) {
        setServiceWorkerStatus('failed');
        return;
      }
      
      const registration = await navigator.serviceWorker.getRegistration();
      if (registration) {
        setServiceWorkerStatus('success');
      } else {
        setServiceWorkerStatus('failed');
      }
    } catch (error) {
      console.error('Erro ao verificar Service Worker:', error);
      setServiceWorkerStatus('failed');
    }
  };

  // Verificar Manifest
  const checkManifest = async () => {
    try {
      const links = document.querySelectorAll('link[rel="manifest"]');
      if (links.length === 0) {
        setManifestStatus('failed');
        return;
      }
      
      const manifestUrl = links[0].href;
      const response = await fetch(manifestUrl);
      
      if (response.ok) {
        const manifest = await response.json();
        if (manifest.name && manifest.icons && manifest.start_url) {
          setManifestStatus('success');
        } else {
          setManifestStatus('failed');
        }
      } else {
        setManifestStatus('failed');
      }
    } catch (error) {
      console.error('Erro ao verificar Manifest:', error);
      setManifestStatus('failed');
    }
  };

  // Verificar Installability
  const checkInstallability = () => {
    try {
      let installable = false;
      
      window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        installable = true;
        setInstallabilityStatus('success');
      });
      
      // Se já estiver instalado, também é um sucesso
      if (window.matchMedia('(display-mode: standalone)').matches) {
        installable = true;
        setInstallabilityStatus('success');
      }
      
      // Timeout para verificar se o evento foi disparado
      setTimeout(() => {
        if (!installable) {
          // Não podemos ter certeza se é falha, pois o evento pode não ser disparado
          // por várias razões válidas (já instalado, critérios não atendidos, etc.)
          setInstallabilityStatus('warning');
        }
      }, 2000);
    } catch (error) {
      console.error('Erro ao verificar Installability:', error);
      setInstallabilityStatus('failed');
    }
  };

  // Verificar Offline Support
  const checkOfflineSupport = async () => {
    try {
      if (!('caches' in window)) {
        setOfflineStatus('failed');
        return;
      }
      
      // Verificar se o Service Worker está ativo
      const registration = await navigator.serviceWorker.getRegistration();
      if (!registration || registration.active.state !== 'activated') {
        setOfflineStatus('warning');
        return;
      }
      
      setOfflineStatus('success');
    } catch (error) {
      console.error('Erro ao verificar Offline Support:', error);
      setOfflineStatus('failed');
    }
  };

  // Verificar Cache
  const checkCache = async () => {
    try {
      if (!('caches' in window)) {
        setCacheStatus('failed');
        return;
      }
      
      const cacheNames = await window.caches.keys();
      if (cacheNames.length > 0) {
        // Verificar se pelo menos um cache contém arquivos
        let hasFiles = false;
        
        for (const cacheName of cacheNames) {
          const cache = await window.caches.open(cacheName);
          const keys = await cache.keys();
          
          if (keys.length > 0) {
            hasFiles = true;
            break;
          }
        }
        
        if (hasFiles) {
          setCacheStatus('success');
        } else {
          setCacheStatus('warning');
        }
      } else {
        setCacheStatus('warning');
      }
    } catch (error) {
      console.error('Erro ao verificar Cache:', error);
      setCacheStatus('failed');
    }
  };

  // Renderizar ícone de status
  const renderStatusIcon = (status) => {
    switch (status) {
      case 'success':
        return <CheckCircleOutlined style={{ color: '#52c41a' }} />;
      case 'failed':
        return <CloseCircleOutlined style={{ color: '#f5222d' }} />;
      case 'warning':
        return <CheckCircleOutlined style={{ color: '#faad14' }} />;
      default:
        return <LoadingOutlined />;
    }
  };

  // Renderizar mensagem de status
  const renderStatusMessage = (status) => {
    switch (status) {
      case 'success':
        return 'Sucesso';
      case 'failed':
        return 'Falha';
      case 'warning':
        return 'Atenção';
      default:
        return 'Verificando...';
    }
  };

  return (
    <Card title="Validação do PWA Instalável" style={{ maxWidth: 800, margin: '0 auto' }}>
      <Steps direction="vertical" current={overallStatus === 'success' ? 5 : -1}>
        <Step 
          title="Service Worker" 
          description="Verificando registro e ativação do Service Worker" 
          status={serviceWorkerStatus === 'checking' ? 'process' : serviceWorkerStatus === 'success' ? 'finish' : 'error'}
          icon={serviceWorkerStatus === 'checking' ? <LoadingOutlined /> : null}
        />
        <Step 
          title="Manifest" 
          description="Verificando arquivo de manifesto e suas propriedades" 
          status={manifestStatus === 'checking' ? 'process' : manifestStatus === 'success' ? 'finish' : 'error'}
          icon={manifestStatus === 'checking' ? <LoadingOutlined /> : null}
        />
        <Step 
          title="Instalabilidade" 
          description="Verificando se o aplicativo pode ser instalado" 
          status={installabilityStatus === 'checking' ? 'process' : installabilityStatus === 'success' ? 'finish' : installabilityStatus === 'warning' ? 'wait' : 'error'}
          icon={installabilityStatus === 'checking' ? <LoadingOutlined /> : null}
        />
        <Step 
          title="Suporte Offline" 
          description="Verificando funcionalidade offline" 
          status={offlineStatus === 'checking' ? 'process' : offlineStatus === 'success' ? 'finish' : offlineStatus === 'warning' ? 'wait' : 'error'}
          icon={offlineStatus === 'checking' ? <LoadingOutlined /> : null}
        />
        <Step 
          title="Cache" 
          description="Verificando armazenamento em cache" 
          status={cacheStatus === 'checking' ? 'process' : cacheStatus === 'success' ? 'finish' : cacheStatus === 'warning' ? 'wait' : 'error'}
          icon={cacheStatus === 'checking' ? <LoadingOutlined /> : null}
        />
      </Steps>
      
      <Divider />
      
      {overallStatus === 'checking' ? (
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <LoadingOutlined style={{ fontSize: 32, marginBottom: 16 }} />
          <Title level={4}>Verificando configuração do PWA...</Title>
          <Text>Por favor, aguarde enquanto validamos a configuração do PWA instalável.</Text>
        </div>
      ) : overallStatus === 'success' ? (
        <Result
          status="success"
          title="PWA Instalável Configurado com Sucesso!"
          subTitle="O ActCredit Premium está configurado corretamente como um PWA instalável e pronto para uso offline."
          extra={[
            <Button type="primary" key="console">
              Continuar
            </Button>,
          ]}
        />
      ) : (
        <Result
          status="warning"
          title="Configuração do PWA Incompleta"
          subTitle="Alguns aspectos da configuração do PWA precisam ser revisados."
          extra={[
            <Button type="primary" key="console">
              Corrigir Problemas
            </Button>,
          ]}
        >
          <div className="desc">
            <Paragraph>
              <Text strong>Os seguintes problemas foram encontrados:</Text>
            </Paragraph>
            
            {serviceWorkerStatus === 'failed' && (
              <Paragraph>
                <CloseCircleOutlined style={{ color: '#f5222d' }} /> Service Worker não está registrado ou ativo.
              </Paragraph>
            )}
            
            {manifestStatus === 'failed' && (
              <Paragraph>
                <CloseCircleOutlined style={{ color: '#f5222d' }} /> Manifest não encontrado ou incompleto.
              </Paragraph>
            )}
            
            {installabilityStatus === 'failed' && (
              <Paragraph>
                <CloseCircleOutlined style={{ color: '#f5222d' }} /> Aplicativo não pode ser instalado.
              </Paragraph>
            )}
            
            {offlineStatus === 'failed' && (
              <Paragraph>
                <CloseCircleOutlined style={{ color: '#f5222d' }} /> Suporte offline não está funcionando.
              </Paragraph>
            )}
            
            {cacheStatus === 'failed' && (
              <Paragraph>
                <CloseCircleOutlined style={{ color: '#f5222d' }} /> Cache não está configurado corretamente.
              </Paragraph>
            )}
            
            {installabilityStatus === 'warning' && (
              <Paragraph>
                <Alert
                  message="Instalabilidade não confirmada"
                  description="Não foi possível confirmar se o aplicativo pode ser instalado. Isso pode ocorrer se o aplicativo já estiver instalado ou se os critérios de instalação não forem atendidos."
                  type="warning"
                  showIcon
                />
              </Paragraph>
            )}
            
            {offlineStatus === 'warning' && (
              <Paragraph>
                <Alert
                  message="Suporte offline parcial"
                  description="O suporte offline está configurado, mas pode não estar totalmente funcional."
                  type="warning"
                  showIcon
                />
              </Paragraph>
            )}
            
            {cacheStatus === 'warning' && (
              <Paragraph>
                <Alert
                  message="Cache parcial"
                  description="O cache está configurado, mas pode não conter todos os arquivos necessários."
                  type="warning"
                  showIcon
                />
              </Paragraph>
            )}
          </div>
        </Result>
      )}
    </Card>
  );
};

export default PWAValidator;
