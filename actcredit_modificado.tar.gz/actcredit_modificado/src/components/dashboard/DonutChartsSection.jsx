import React from 'react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { useTheme } from '@/contexts/ThemeContext';

const DonutChart = ({ percentage, color, label }) => {
  const { theme } = useTheme();
  const data = [
    { name: 'Filled', value: percentage },
    { name: 'Remaining', value: 100 - percentage },
  ];
  const COLORS = [color, theme === 'dark' ? 'hsl(var(--muted))' : '#e0e0e0'];

  return (
    <div className="flex flex-col items-center">
      <ResponsiveContainer width="100%" height={120}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={35}
            outerRadius={50}
            fill="#8884d8"
            paddingAngle={2}
            dataKey="value"
            startAngle={90}
            endAngle={450}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <text
            x="50%"
            y="50%"
            textAnchor="middle"
            dominantBaseline="middle"
            className="text-xl font-bold"
            fill={theme === 'dark' ? 'hsl(var(--dashboard-text-primary))' : 'hsl(var(--foreground))'}
          >
            {`${percentage}%`}
          </text>
        </PieChart>
      </ResponsiveContainer>
      <p className="text-xs text-dashboard-text-secondary mt-1">{label}</p>
    </div>
  );
};

const DonutChartsSection = () => {
  const { theme } = useTheme();
  const purpleColor = theme === 'dark' ? 'hsl(var(--dashboard-accent-purple))' : 'purple';
  const blueColor = theme === 'dark' ? 'hsl(var(--dashboard-accent-blue))' : 'blue';

  return (
    <DashboardCard className="h-full">
      <div className="grid grid-cols-2 gap-4 h-full items-center">
        <DonutChart percentage={59} color={purpleColor} label="LOREM IPSUM" />
        <DonutChart percentage={77} color={blueColor} label="LOREM IPSUM" />
      </div>
    </DashboardCard>
  );
};

export default DonutChartsSection;