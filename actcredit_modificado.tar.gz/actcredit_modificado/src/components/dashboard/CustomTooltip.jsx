import React from 'react';

const formatCurrency = (value) => {
  if (typeof value !== 'number') return 'R$ 0,00';
  return `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

export const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-recharts-tooltip">
        <p className="recharts-tooltip-label">{label}</p>
        {payload.map((pld, index) => (
          <p key={index} style={{ color: pld.stroke || pld.fill }} className="text-xs">
            {`${pld.name}: ${pld.dataKey?.toLowerCase().includes('valor') || pld.name.toLowerCase().includes('valor') ? formatCurrency(pld.value) : pld.value.toLocaleString('pt-BR')}${pld.name.toLowerCase().includes('taxa') || pld.name.toLowerCase().includes('score') ? '' : (pld.name.toLowerCase().includes('percentual') || pld.name.toLowerCase().includes('%') ? '%' : '')}`}
          </p>
        ))}
      </div>
    );
  }
  return null;
};