import React from 'react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';
import { useTheme } from '@/contexts/ThemeContext';

const data = [
  { name: 'A', value: 400 },
  { name: 'B', value: 300 },
  { name: 'C', value: 600 },
  { name: 'D', value: 800 },
  { name: 'E', value: 500 },
  { name: 'F', value: 700 },
  { name: 'G', value: 450 },
];

const colors = ['hsl(var(--dashboard-accent-purple))', 'hsl(var(--dashboard-accent-pink))'];

const BarChartSection = () => {
  const { theme } = useTheme();
  const textColor = theme === 'dark' ? 'hsl(var(--dashboard-text-secondary))' : 'hsl(var(--muted-foreground))';
  
  return (
    <DashboardCard className="h-full">
      <div className="flex justify-between items-start mb-2">
        <div>
          <p className="text-2xl font-bold text-dashboard-text-primary">6,679</p>
          <p className="text-xs text-dashboard-text-secondary">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam</p>
        </div>
        <span className="text-sm text-dashboard-text-secondary">Lorem ipsum</span>
      </div>
      <ResponsiveContainer width="100%" height={150}>
        <BarChart data={data} barGap={5} margin={{ top: 5, right: 0, left: -30, bottom: -10 }}>
          <XAxis dataKey="name" stroke={textColor} tickLine={false} axisLine={false} tick={{ fontSize: 10 }} />
          <YAxis stroke={textColor} tickLine={false} axisLine={false} tick={{ fontSize: 10 }} />
          <Tooltip
            cursor={{ fill: 'transparent' }}
            contentStyle={{
              backgroundColor: theme === 'dark' ? 'hsl(var(--card))' : '#fff',
              borderColor: theme === 'dark' ? 'hsl(var(--border))' : '#ccc',
              borderRadius: '0.5rem',
            }}
            labelStyle={{ color: textColor }}
          />
          <Bar dataKey="value" radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </DashboardCard>
  );
};

export default BarChartSection;