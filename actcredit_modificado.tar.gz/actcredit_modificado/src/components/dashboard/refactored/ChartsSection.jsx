import React from 'react';
import { motion } from 'framer-motion';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend, BarChart, Bar, PieChart, Pie, Cell, ReferenceDot, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { useTheme } from '@/contexts/ThemeContext';

const ChartsSection = ({ tendenciaAprovacoesData, distribuicaoSetorData, aprovacoesRegiaoData, metricasRiscoData }) => {
  const { theme } = useTheme();
  const primaryColor = theme === 'dark' ? 'hsl(var(--dashboard-accent-pink))' : 'hsl(var(--primary))';
  const secondaryColor = theme === 'dark' ? 'hsl(var(--dashboard-accent-purple))' : 'hsl(var(--secondary))';
  const tertiaryColor = theme === 'dark' ? 'hsl(var(--dashboard-accent-blue))' : 'hsl(var(--ring))';
  const textColor = theme === 'dark' ? 'hsl(var(--dashboard-text-secondary))' : 'hsl(var(--muted-foreground))';
  const gridColor = theme === 'dark' ? 'hsla(var(--dashboard-text-secondary), 0.1)' : 'hsla(var(--muted-foreground), 0.1)';
  const PIE_COLORS = [primaryColor, secondaryColor, tertiaryColor, '#FFBB28', '#FF8042', '#00C49F'];

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.4, ease: "easeOut" } }
  };

  return (
    <>
      <motion.div variants={itemVariants} className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
        <div className="lg:col-span-2">
          {/* ID adicionado para o teste E2E: aprovacoesTempoChart (Tendência de Decisões) */}
          <DashboardCard title="Tendência de Decisões (Últimos Meses)" className="h-full" id="aprovacoesTempoChartContainer">
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={tendenciaAprovacoesData} margin={{ top: 5, right: 20, left: -15, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="name" stroke={textColor} tick={{ fontSize: 12 }} />
                <YAxis stroke={textColor} tick={{ fontSize: 12 }} />
                <Tooltip contentStyle={{ backgroundColor: theme === 'dark' ? 'hsl(var(--card))' : '#fff', borderColor: theme === 'dark' ? 'hsl(var(--border))' : '#ccc', borderRadius: '0.5rem' }} labelStyle={{ color: textColor }} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Line type="monotone" dataKey="aprovacoes" stroke={primaryColor} strokeWidth={2.5} dot={{ r: 4, fill: primaryColor }} activeDot={{ r: 6 }} name="Aprovações" />
                <Line type="monotone" dataKey="rejeicoes" stroke={tertiaryColor} strokeWidth={2.5} dot={{ r: 4, fill: tertiaryColor }} activeDot={{ r: 6 }} name="Rejeições" />
                <ReferenceDot x="Set" y={520} r={6} fill={primaryColor} stroke={theme === 'dark' ? 'hsl(var(--card))' : '#fff'} strokeWidth={2} isFront={true} />
              </LineChart>
            </ResponsiveContainer>
          </DashboardCard>
        </div>
        
        <div>
          {/* ID adicionado para o teste E2E: distribuicaoSetorChart */}
          <DashboardCard title="Distribuição por Setor" className="h-full" id="distribuicaoSetorChartContainer">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={distribuicaoSetorData} cx="50%" cy="50%" labelLine={false} outerRadius={90} innerRadius={50} fill="#8884d8" dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} legendType="circle">
                  {distribuicaoSetorData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: theme === 'dark' ? 'hsl(var(--card))' : '#fff', borderRadius: '0.5rem' }}/>
                <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }}/>
              </PieChart>
            </ResponsiveContainer>
          </DashboardCard>
        </div>
      </motion.div>

      <motion.div variants={itemVariants} className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6 mt-6">
        <div className="lg:col-span-2">
            {/* ID adicionado para o teste E2E: decisoesRegiaoChart (o script usa scoreSetorChart, que parece ser um engano, pois este é de decisões por região) */}
            {/* O script E2E procura por "scoreSetorChart". Vou adicionar este ID aqui, mas o gráfico é de "Decisões por Região". */}
            {/* Se houver um gráfico específico de "Score por Setor", ele precisará ser identificado e ter seu ID. */}
            <DashboardCard title="Decisões por Região" className="h-full" id="scoreSetorChartContainer"> {/* ID do script E2E */}
                <ResponsiveContainer width="100%" height={300}>
                <BarChart data={aprovacoesRegiaoData} margin={{ top: 5, right: 20, left: -15, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                    <XAxis dataKey="name" stroke={textColor} tick={{ fontSize: 12 }} angle={-15} textAnchor="end" />
                    <YAxis stroke={textColor} tick={{ fontSize: 12 }} />
                    <Tooltip contentStyle={{ backgroundColor: theme === 'dark' ? 'hsl(var(--card))' : '#fff', borderRadius: '0.5rem' }}/>
                    <Legend wrapperStyle={{ fontSize: '12px' }}/>
                    <Bar dataKey="aprovacoes" stackId="a" fill={primaryColor} radius={[4, 4, 0, 0]} name="Aprovações" />
                    <Bar dataKey="rejeicoes" stackId="a" fill={tertiaryColor} radius={[4, 4, 0, 0]} name="Rejeições" />
                </BarChart>
                </ResponsiveContainer>
            </DashboardCard>
        </div>
        <div>
            <DashboardCard title="Métricas de Risco (Perfil Médio)" className="h-full" id="metricasRiscoChartContainer">
                <ResponsiveContainer width="100%" height={300}>
                    <RadarChart cx="50%" cy="50%" outerRadius="80%" data={metricasRiscoData}>
                        <PolarGrid stroke={gridColor} />
                        <PolarAngleAxis dataKey="subject" stroke={textColor} tick={{ fontSize: 10 }}/>
                        <PolarRadiusAxis angle={30} domain={[0, 100]} stroke={textColor} tick={{ fontSize: 10 }}/>
                        <Radar name="Perfil Médio" dataKey="A" stroke={secondaryColor} fill={secondaryColor} fillOpacity={0.6} />
                        <Tooltip contentStyle={{ backgroundColor: theme === 'dark' ? 'hsl(var(--card))' : '#fff', borderRadius: '0.5rem' }}/>
                        <Legend wrapperStyle={{ fontSize: '12px' }}/>
                    </RadarChart>
                </ResponsiveContainer>
            </DashboardCard>
        </div>
      </motion.div>
    </>
  );
};

export default ChartsSection;