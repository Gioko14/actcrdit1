import React from 'react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Button } from '@/components/ui/button';
import { Users, Activity, BarChart } from 'lucide-react';

const InfoCardSection = () => {
  return (
    <DashboardCard className="h-full flex flex-col justify-between">
      <div>
        <div className="flex space-x-3 mb-4">
          <Button variant="outline" size="icon" className="bg-dashboard-accent-blue/20 border-dashboard-accent-blue text-dashboard-accent-blue hover:bg-dashboard-accent-blue/30">
            <Users className="h-5 w-5" />
          </Button>
          <Button variant="outline" size="icon" className="bg-dashboard-accent-pink/20 border-dashboard-accent-pink text-dashboard-accent-pink hover:bg-dashboard-accent-pink/30">
            <Activity className="h-5 w-5" />
          </Button>
          <Button variant="outline" size="icon" className="bg-dashboard-accent-purple/20 border-dashboard-accent-purple text-dashboard-accent-purple hover:bg-dashboard-accent-purple/30">
            <BarChart className="h-5 w-5" />
          </Button>
        </div>
        <p className="text-sm text-dashboard-text-secondary">
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed
        </p>
      </div>
      <div className="mt-4">
        <div className="h-1 w-1/3 bg-pink-500 rounded-full"></div>
        <p className="text-xs text-dashboard-text-secondary mt-2">
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed
        </p>
      </div>
    </DashboardCard>
  );
};

export default InfoCardSection;