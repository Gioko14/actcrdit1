import React from 'react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { ResponsiveContainer, LineChart, Line, Tooltip } from 'recharts';
import { useTheme } from '@/contexts/ThemeContext';

const data1 = [
  { value: 10 }, { value: 50 }, { value: 30 }, { value: 60 }, { value: 40 }, { value: 80 }, { value: 67 },
];
const data2 = [
  { value: 40 }, { value: 20 }, { value: 70 }, { value: 30 }, { value: 90 }, { value: 50 }, { value: 43 },
];

const TinyLineChart = ({ data, color }) => {
  const { theme } = useTheme();
  return (
    <ResponsiveContainer width="100%" height={60}>
      <LineChart data={data}>
        <Tooltip
          contentStyle={{
            backgroundColor: theme === 'dark' ? 'hsl(var(--card))' : '#fff',
            borderColor: theme === 'dark' ? 'hsl(var(--border))' : '#ccc',
            borderRadius: '0.5rem',
            padding: '4px 8px',
            fontSize: '12px'
          }}
          itemStyle={{ color: color }}
          labelStyle={{ display: 'none' }}
        />
        <Line type="monotone" dataKey="value" stroke={color} strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
};

const SmallLineChartsSection = () => {
  const { theme } = useTheme();
  const pinkColor = theme === 'dark' ? 'hsl(var(--dashboard-accent-pink))' : 'hsl(var(--primary))';
  const purpleColor = theme === 'dark' ? 'hsl(var(--dashboard-accent-purple))' : 'hsl(var(--secondary))';

  return (
    <div className="grid grid-cols-2 gap-6 h-full">
      <DashboardCard className="h-full">
        <div className="flex justify-between items-start mb-1">
          <span className="text-xs text-dashboard-text-secondary">Ipsum</span>
          <span className="text-sm font-semibold text-dashboard-text-primary">67,897</span>
        </div>
        <TinyLineChart data={data1} color={pinkColor} />
      </DashboardCard>
      <DashboardCard className="h-full">
        <div className="flex justify-between items-start mb-1">
          <span className="text-xs text-dashboard-text-secondary">Dolor</span>
          <span className="text-sm font-semibold text-dashboard-text-primary">43,223</span>
        </div>
        <TinyLineChart data={data2} color={purpleColor} />
      </DashboardCard>
    </div>
  );
};

export default SmallLineChartsSection;