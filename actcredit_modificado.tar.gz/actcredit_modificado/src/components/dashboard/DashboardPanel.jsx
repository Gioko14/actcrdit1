import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';
import { cn } from '@/lib/utils';

export const DashboardPanel = ({ title, children, className, exportable = true, headerClassName, contentClassName, titleClassName }) => (
  <Card className={cn("dashboard-panel", className)}>
    <CardHeader className={cn("dashboard-panel-header", headerClassName)}>
      <CardTitle className={cn("dashboard-panel-title", titleClassName)}>{title}</CardTitle>
      {exportable && (
        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary -mr-2.5 -my-1">
          <Download className="h-4 w-4" />
        </Button>
      )}
    </CardHeader>
    <CardContent className={cn("dashboard-panel-content", contentClassName)}>
      {children}
    </CardContent>
  </Card>
);