import React from 'react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Activity, TrendingUp, BarChartBig, UserCheck } from 'lucide-react';
import { cn } from '@/lib/utils';

const recentActivities = [
  { label: "Nova Análise (Empresa Alfa)", value: "Score 780", icon: UserCheck, color: "text-blue-500" },
  { label: "Consulta Serasa (Empresa Beta)", value: "Concluída", icon: Activity, color: "text-green-500" },
  { label: "Política 'PJ Risco Moderado' Aplicada", value: "Análise #12346", icon: BarChartBig, color: "text-purple-500" },
  { label: "Alerta: Score Baixo (Empresa Gama)", value: "Score 450", icon: TrendingUp, color: "text-red-500" },
];

const featuredMetrics = [
  {
    title: "Taxa de Conversão de Análises",
    description: "Análises aprovadas / Total realizadas",
    value: "85%",
    icon: UserCheck,
    iconColor: "text-green-500"
  },
  {
    title: "Tempo Médio de Consulta Externa",
    description: "Média de tempo para retorno dos bureaus",
    value: "45s",
    icon: Activity,
    iconColor: "text-blue-500"
  },
];

const ActivityFeedCard = () => {
  return (
    <DashboardCard title="Feed de Atividades Recentes" titleClassName="text-sm uppercase tracking-wider text-dashboard-text-secondary" className="h-full">
      <ul className="space-y-3">
        {recentActivities.map((item, index) => (
          <li key={index} className="flex justify-between items-center text-sm py-1.5 border-b border-border/30 last:border-b-0">
            <div className="flex items-center">
              <item.icon className={cn("h-4 w-4 mr-2", item.color)} />
              <span className="text-dashboard-text-primary">{item.label}</span>
            </div>
            <span className={cn("font-semibold text-xs", item.color)}>{item.value}</span>
          </li>
        ))}
      </ul>
      <div className="mt-4 space-y-3 pt-3 border-t border-border/50">
        <h4 className="text-xs uppercase tracking-wider text-dashboard-text-secondary mb-2">Métricas Destacadas</h4>
        {featuredMetrics.map((metric, index) => (
          <div key={index} className="flex items-center justify-between p-3 bg-muted/30 dark:bg-muted/10 rounded-lg">
            <div className="flex items-center">
              <metric.icon className={cn("h-6 w-6 mr-3", metric.iconColor)} />
              <div>
                <p className="text-sm font-medium text-dashboard-text-primary">{metric.title}</p>
                <p className="text-xs text-dashboard-text-secondary">{metric.description}</p>
              </div>
            </div>
            <span className="text-sm font-semibold text-dashboard-text-primary">{metric.value}</span>
          </div>
        ))}
      </div>
    </DashboardCard>
  );
};

export default ActivityFeedCard;