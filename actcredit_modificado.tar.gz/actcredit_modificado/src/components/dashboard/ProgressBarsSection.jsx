import React from 'react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Progress } from '@/components/ui/progress';

const ProgressBarsSection = () => {
  return (
    <DashboardCard className="h-full">
      <div className="space-y-6">
        <div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm text-dashboard-text-primary">Ipsum dolor</span>
            <span className="text-sm font-semibold text-dashboard-accent-blue">42%</span>
          </div>
          <Progress value={42} className="h-2 [&>div]:bg-dashboard-accent-blue" />
        </div>
        <div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm text-dashboard-text-primary">Ipsum dolor</span>
            <span className="text-sm font-semibold text-pink-400">71%</span>
          </div>
          <Progress value={71} className="h-2 [&>div]:bg-pink-400" />
        </div>
      </div>
    </DashboardCard>
  );
};

export default ProgressBarsSection;