import React, { useState, useEffect } from 'react';
import { Card, Select, Spin } from 'antd';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { supabase } from '@/lib/supabaseClient';

/**
 * Componente de gráfico para mostrar a distribuição dos tipos de análise
 * Conforme solicitado pelo cliente
 */
const AnalysisTypeDistributionChart = ({ period = 'month' }) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  // Cores para cada tipo de análise
  const COLORS = {
    'Majoração': '#8884d8',
    'Reativação': '#82ca9d',
    'Prospecção': '#ffc658',
    'Revisão': '#ff8042'
  };

  // Buscar dados do Supabase
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      
      try {
        // Definir período de filtro
        let startDate = new Date();
        if (period === 'month') {
          startDate.setMonth(startDate.getMonth() - 1);
        } else if (period === 'quarter') {
          startDate.setMonth(startDate.getMonth() - 3);
        } else if (period === 'year') {
          startDate.setFullYear(startDate.getFullYear() - 1);
        }
        
        // Buscar análises no período
        const { data: analyses, error } = await supabase
          .from('analises')
          .select('tipoAnalise')
          .gte('dataAnalise', startDate.toISOString());
        
        if (error) {
          throw error;
        }
        
        // Contar ocorrências de cada tipo
        const counts = {
          'Majoração': 0,
          'Reativação': 0,
          'Prospecção': 0,
          'Revisão': 0
        };
        
        analyses.forEach(analysis => {
          if (counts.hasOwnProperty(analysis.tipoAnalise)) {
            counts[analysis.tipoAnalise]++;
          }
        });
        
        // Formatar dados para o gráfico
        const chartData = Object.keys(counts).map(key => ({
          name: key,
          value: counts[key]
        }));
        
        setData(chartData);
      } catch (error) {
        console.error('Erro ao buscar dados:', error);
        
        // Em caso de erro ou sem dados, mostrar valores zerados
        setData([
          { name: 'Majoração', value: 0 },
          { name: 'Reativação', value: 0 },
          { name: 'Prospecção', value: 0 },
          { name: 'Revisão', value: 0 }
        ]);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [period]);
  
  // Manipular mudança de período
  const handlePeriodChange = (value) => {
    setPeriod(value);
  };
  
  // Renderizar componente
  return (
    <Card 
      title="Distribuição por Tipo de Análise" 
      className="shadow-md rounded-lg"
      extra={
        <Select 
          defaultValue={period} 
          onChange={handlePeriodChange}
          style={{ width: 120 }}
        >
          <Select.Option value="month">Este Mês</Select.Option>
          <Select.Option value="quarter">Trimestre</Select.Option>
          <Select.Option value="year">Ano</Select.Option>
        </Select>
      }
    >
      <div style={{ width: '100%', height: 300 }}>
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <Spin tip="Carregando dados..." />
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={true}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={COLORS[entry.name] || '#000000'} 
                  />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`${value} análises`, 'Quantidade']} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        )}
      </div>
    </Card>
  );
};

export default AnalysisTypeDistributionChart;
