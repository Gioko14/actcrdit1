import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowUpRight, ArrowDownRight, Users, BarChart, TrendingUp, TrendingDown } from 'lucide-react';

const kpiData = [
  { title: 'Clientes Registrados', value: '1.2K', change: '+12.5%', icon: Users, trend: 'up', color: 'text-chart-blue' },
  { title: 'Taxa de Aprovação', value: '68.7%', change: '+3.2%', icon: BarChart, trend: 'up', color: 'text-chart-green' },
  { title: 'Score Médio ActCredit', value: '720', change: '+25 pts', icon: TrendingUp, trend: 'up', color: 'text-chart-purple' },
  { title: 'Alerta de Risco', value: '37%', change: '-5.3%', icon: TrendingDown, trend: 'down', color: 'text-chart-pink' },
];

const KpiSection = () => {
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 120, damping: 12 } }
  };

  return (
    <motion.div 
      className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6"
      variants={{
        visible: { transition: { staggerChildren: 0.1 } }
      }}
    >
      {kpiData.map((kpi, index) => (
        <motion.div key={index} variants={itemVariants}>
          <Card className="dashboard-panel overflow-hidden relative">
             <div className={`absolute top-0 left-0 h-1 w-full bg-gradient-to-r from-transparent via-${kpi.color.replace('text-','')} to-transparent animate-shimmer`}></div>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 pt-5 px-5">
              <CardTitle className="text-xs font-medium uppercase text-muted-foreground tracking-wider">{kpi.title}</CardTitle>
              <kpi.icon className={`h-5 w-5 ${kpi.color}`} />
            </CardHeader>
            <CardContent className="px-5 pb-5">
              <div className={`text-3xl font-bold ${kpi.color}`}>{kpi.value}</div>
              <p className={`text-xs ${kpi.trend === 'up' ? 'text-emerald-400' : 'text-red-400'} flex items-center mt-1`}>
                {kpi.trend === 'up' ? <ArrowUpRight className="h-3.5 w-3.5 mr-1" /> : <ArrowDownRight className="h-3.5 w-3.5 mr-1" />}
                {kpi.change} <span className="text-muted-foreground/70 ml-1">vs mês anterior</span>
              </p>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </motion.div>
  );
};

export default KpiSection;