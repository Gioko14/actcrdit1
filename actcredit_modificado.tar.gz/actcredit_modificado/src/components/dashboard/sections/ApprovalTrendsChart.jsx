import React from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { DashboardPanel } from '@/components/dashboard/DashboardPanel';
import { CustomTooltip } from '@/components/dashboard/CustomTooltip';

const tendenciasAprovacoesData = [
  { name: 'Jan', Aprovadas: 650, Rejeitadas: 280 }, { name: 'Fev', Aprovadas: 590, Rejeitadas: 320 },
  { name: 'Mar', Aprovadas: 800, Rejeitadas: 200 }, { name: 'Abr', Aprovadas: 700, Rejeitadas: 250 },
  { name: 'Mai', Aprovadas: 750, Rejeitadas: 300 }, { name: 'Jun', Aprovadas: 820, Rejeitadas: 180 },
];

const ApprovalTrendsChart = () => {
  return (
    <DashboardPanel title="Tendências de Aprovações">
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={tendenciasAprovacoesData} margin={{ top: 10, right: 15, left: -15, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border)/0.2)" vertical={false} />
          <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={{ stroke: 'hsl(var(--border)/0.5)' }} />
          <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={{ stroke: 'hsl(var(--border)/0.5)' }} />
          <Tooltip content={<CustomTooltip />} cursor={{ stroke: 'hsl(var(--primary)/0.2)', strokeWidth: 1.5 }}/>
          <Legend wrapperStyle={{fontSize: "11px", paddingTop: "15px"}} iconSize={10} />
          <Line type="monotone" dataKey="Aprovadas" stroke="hsl(var(--chart-blue))" strokeWidth={2.5} dot={{ r: 4, fill: 'hsl(var(--chart-blue))', strokeWidth: 2, stroke: 'hsl(var(--card))' }} activeDot={{ r: 6, strokeWidth: 2, stroke: 'hsl(var(--card))' }} />
          <Line type="monotone" dataKey="Rejeitadas" stroke="hsl(var(--chart-pink))" strokeWidth={2.5} dot={{ r: 4, fill: 'hsl(var(--chart-pink))', strokeWidth: 2, stroke: 'hsl(var(--card))' }} activeDot={{ r: 6, strokeWidth: 2, stroke: 'hsl(var(--card))' }} />
        </LineChart>
      </ResponsiveContainer>
    </DashboardPanel>
  );
};

export default ApprovalTrendsChart;