import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Eye, Edit, Copy, Trash2, ShieldCheck, Star } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const PolicyListItem = ({ policy, index, onViewDetails, onEdit, onDuplicate, onDelete, onSetDefault }) => {
  const cardVariants = {
    hidden: { opacity: 0, scale: 0.95 },
    visible: { opacity: 1, scale: 1, transition: { duration: 0.3, delay: index * 0.05 } }
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      className="flex flex-col"
    >
      <Card className={cn("flex flex-col flex-grow hover:shadow-xl transition-shadow duration-300", policy.isDefault ? "border-primary border-2" : "border-border")}>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <CardTitle className="text-lg font-semibold text-primary flex items-center gap-2">
              <ShieldCheck size={22}/> {policy.name}
            </CardTitle>
            {policy.isDefault && (
              <Badge variant="default" className="bg-green-500 hover:bg-green-600 text-white text-xs">
                <Star size={12} className="mr-1 fill-current"/> Padrão
              </Badge>
            )}
          </div>
          <CardDescription className="text-xs">
            Tipo: {policy.type} {policy.isCustom && <Badge variant="outline" className="ml-1 text-xs">Custom</Badge>}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2 text-sm flex-grow">
          <p><span className="font-medium">Score Mín.:</span> {policy.scoreMinimo}</p>
          <p><span className="font-medium">Endivid. Máx.:</span> {policy.endividamentoMax}%</p>
          <p><span className="font-medium">Liquidez Mín.:</span> {policy.liquidezMin.toFixed(1)}</p>
          <p><span className="font-medium">Prazo Máx.:</span> {policy.prazoMax} meses</p>
          <p><span className="font-medium">Valor Máx.:</span> {Number(policy.valorMax).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
          <p className="truncate" title={policy.garantiasExigidas.join(', ') || 'Nenhuma'}>
            <span className="font-medium">Garantias:</span> {policy.garantiasExigidas.join(', ').substring(0,30) || 'Nenhuma'}{policy.garantiasExigidas.join(', ').length > 30 ? '...' : ''}
          </p>
        </CardContent>
        <CardFooter className="flex flex-col gap-2 pt-4 border-t">
          <div className="grid grid-cols-2 gap-2 w-full">
            <Button variant="outline" size="sm" onClick={() => onViewDetails(policy)} className="text-xs"><Eye size={14} className="mr-1.5"/> Ver Detalhes</Button>
            <Button variant="outline" size="sm" onClick={() => onEdit(policy)} className="text-xs"><Edit size={14} className="mr-1.5"/> Editar</Button>
            <Button variant="outline" size="sm" onClick={() => onDuplicate(policy)} className="text-xs"><Copy size={14} className="mr-1.5"/> Duplicar</Button>
            {!policy.isDefault && (
              <Button variant="destructive-outline" size="sm" onClick={() => onDelete(policy)} className="text-xs"><Trash2 size={14} className="mr-1.5"/> Excluir</Button>
            )}
          </div>
          {!policy.isDefault && (
            <Button variant="secondary" size="sm" onClick={() => onSetDefault(policy)} className="w-full text-xs mt-2">
              <Star size={14} className="mr-1.5"/> Definir como Padrão
            </Button>
          )}
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default PolicyListItem;