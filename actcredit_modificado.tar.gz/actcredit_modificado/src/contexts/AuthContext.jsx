import React, { createContext, useContext } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  // Com a remoção do login, este provedor se torna um placeholder
  // ou pode ser totalmente removido e suas referências atualizadas.
  // Por enquanto, vamos mantê-lo mínimo para evitar quebrar importações
  // em muitos arquivos, mas sua funcionalidade está desativada.

  const mockUser = {
    name: 'Usuário ActCred',
    email: 'usuario@actcred.com',
    role: 'Analista',
    avatar: null 
  };

  return (
    <AuthContext.Provider value={{
      user: mockUser, // Usuário mockado
      isAuthenticated: true, // Sempre autenticado
      isLoading: false, // Nunca carregando (relacionado à auth)
      login: async () => { console.warn("Login function called but auth is disabled."); return true; },
      logout: async () => { console.warn("Logout function called but auth is disabled."); },
      getCurrentUser: () => mockUser, // Retorna usuário mockado
      supabase: null // Supabase client não é mais gerenciado aqui diretamente para auth
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    // Isso não deve acontecer se o AuthProvider ainda estiver no topo da árvore de componentes.
    // Se o AuthProvider for removido, este hook precisará ser removido/substituído.
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}