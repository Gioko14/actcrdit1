# ActCredit - Sistema de Análise de Crédito

## Guia de Instalação e Uso

Este documento contém instruções detalhadas para instalação e uso do ActCredit em sistemas Windows 32 e 64 bits.

### Requisitos Mínimos

- Windows 7, 8, 10 ou 11 (32 ou 64 bits)
- 4GB de RAM (recomendado 8GB)
- 500MB de espaço em disco
- Conexão com a internet (apenas para instalação)

### Instalação Rápida

1. Extraia todos os arquivos deste pacote para uma pasta de sua escolha
2. Execute o arquivo `instalar_facil.bat` como administrador
3. Aguarde a conclusão da instalação
4. Execute o arquivo `iniciar_actcredit.bat` para iniciar o sistema

### O que o instalador faz automaticamente

O instalador inteligente do ActCredit foi projetado para funcionar sem intervenção manual:

- Detecta automaticamente se seu sistema é 32 ou 64 bits
- Verifica e instala o Node.js se necessário
- Verifica e instala o Python se necessário
- Instala todas as dependências necessárias
- Cria diretórios e arquivos de configuração
- Corrige automaticamente problemas de caminho e importação

### Solução de Problemas

Se encontrar algum problema durante a instalação ou execução:

1. **Erro de "Módulo não encontrado"**
   - O sistema tentará corrigir automaticamente
   - Se persistir, execute novamente o `instalar_facil.bat`

2. **Erro de "Porta em uso"**
   - O sistema tentará automaticamente usar outra porta
   - Verifique se não há outro serviço usando as portas 3000-3003

3. **Tela em branco no navegador**
   - Aguarde alguns segundos para o servidor inicializar completamente
   - Verifique se o prompt de comando mostra "Servidor ActCredit rodando"
   - Tente acessar manualmente http://localhost:3000 (ou a porta indicada)

4. **Falha na instalação de dependências**
   - O sistema tentará instalar com configurações alternativas
   - Verifique sua conexão com a internet
   - Execute o instalador novamente como administrador

### Logs e Diagnóstico

O sistema cria arquivos de log que podem ajudar a diagnosticar problemas:

- `instalacao_log.txt` - Log do processo de instalação
- `logs/inicializacao_log.txt` - Log do processo de inicialização

### Contato e Suporte

Para suporte adicional, entre em contato através dos canais:

- Email: suporte@actcredit.com.br
- Site: www.actcredit.com.br/suporte

---

© 2025 ActCredit - Todos os direitos reservados
