import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Edit3, Database, UploadCloud, SearchCheck } from 'lucide-react';
import AnalysisHistory from '@/components/creditAnalysis/AnalysisHistory';
import ManualAnalysisTab from '@/components/creditAnalysis/tabs/ManualAnalysisTab';
import ProtheusAnalysisTab from '@/components/creditAnalysis/tabs/ProtheusAnalysisTab';
import UploadAnalysisTab from '@/components/creditAnalysis/tabs/UploadAnalysisTab';
import { useToast } from "@/components/ui/use-toast";


const CreditAnalysis = () => {
  const [activeTab, setActiveTab] = useState('nova-analise-manual');
  const [policies, setPolicies] = useState([]);
  const [initialDataForManual, setInitialDataForManual] = useState(null);
  const { toast } = useToast();
  
  useEffect(() => {
    const storedPolicies = localStorage.getItem('actcred-policies');
    if (storedPolicies) {
      setPolicies(JSON.parse(storedPolicies));
    } else {
      const defaultPolicies = [
        { id: Date.now(), name: "Política Padrão PJ (Exemplo)", type: "PJ", scoreMinimo: 600, endividamentoMax: 40, liquidezMin: 1.2, prazoMax: 36, valorMax: 500000, garantiasExigidas: ['Aval'], isDefault: true, isCustom: false },
      ];
      setPolicies(defaultPolicies);
      localStorage.setItem('actcred-policies', JSON.stringify(defaultPolicies));
    }
  }, []);

  const handleDataFetchedFromApi = (data) => {
    setInitialDataForManual(data);
    setActiveTab('nova-analise-manual'); // Mudar para a aba manual
    toast({
      title: "Dados Prontos para Análise",
      description: "Os dados importados da API de CNPJ estão prontos na aba 'Imputação Manual'. Complete as informações de crédito.",
      duration: 6000,
    });
  };

  const handleDataExtractedFromUpload = (data) => {
    setInitialDataForManual(data);
    setActiveTab('nova-analise-manual'); // Mudar para a aba manual
     toast({
      title: "Dados (Simulados) Prontos",
      description: "Os dados 'extraídos' do PDF estão prontos na aba 'Imputação Manual'. Complete as informações de crédito.",
      duration: 6000,
    });
  };


  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center">
        <div>
            <h1 className="text-3xl font-bold tracking-tight">Análise de Crédito</h1>
            <p className="text-muted-foreground">
            Realize e gerencie análises de crédito utilizando dados manuais, importados ou de documentos.
            </p>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={(newTab) => {
        if (newTab !== 'nova-analise-manual') {
            setInitialDataForManual(null); // Limpa dados iniciais se sair da aba manual
        }
        setActiveTab(newTab);
      }} className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
          <TabsTrigger value="nova-analise-manual" className="flex items-center gap-2"><Edit3 size={16}/> Imputação Manual</TabsTrigger>
          <TabsTrigger value="importar-cnpj" className="flex items-center gap-2"><SearchCheck size={16}/> Importar CNPJ</TabsTrigger>
          <TabsTrigger value="upload-documentos" className="flex items-center gap-2"><UploadCloud size={16}/> Upload de Documentos</TabsTrigger>
          <TabsTrigger value="historico" className="flex items-center gap-2"><FileText size={16}/> Histórico</TabsTrigger>
        </TabsList>
        
        <TabsContent value="nova-analise-manual" className="mt-6">
          <ManualAnalysisTab policies={policies} initialData={initialDataForManual} />
        </TabsContent>
        <TabsContent value="importar-cnpj" className="mt-6">
            <ProtheusAnalysisTab policies={policies} onDataFetched={handleDataFetchedFromApi} />
        </TabsContent>
        <TabsContent value="upload-documentos" className="mt-6">
            <UploadAnalysisTab policies={policies} onDataExtracted={handleDataExtractedFromUpload} />
        </TabsContent>
        <TabsContent value="historico" className="mt-6">
          <AnalysisHistory />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CreditAnalysis;