import React, { useState } from 'react';
import { motion } from 'framer-motion';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Users, PlusCircle, Search, Filter, Edit3, Trash2, Eye, ChevronDown, ChevronUp } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const ClientsPage = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const mockClients = [
    { id: 'CLI001', nome: 'João da Silva Sauro', tipo: 'PF', documento: '123.456.789-00', email: 'joao.sauro@email.com', status: 'Ativo', ultimaAnalise: '2025-05-10' },
    { id: 'CLI002', nome: 'Maria Oliveira Costa', tipo: 'PF', documento: '987.654.321-99', email: 'maria.costa@email.com', status: 'Ativo', ultimaAnalise: '2025-04-22' },
    { id: 'CLI003', nome: 'Empresa Exemplo Ltda', tipo: 'PJ', documento: '11.222.333/0001-44', email: 'contato@exemplo.com', status: 'Inativo', ultimaAnalise: '2024-12-01' },
    { id: 'CLI004', nome: 'Pedro Martins Albuquerque', tipo: 'PF', documento: '456.789.123-55', email: 'pedro.martins@email.com', status: 'Pendente', ultimaAnalise: '2025-05-01' },
    { id: 'CLI005', nome: 'Consultoria Alpha S/A', tipo: 'PJ', documento: '55.666.777/0001-88', email: 'alpha@consultoria.com', status: 'Ativo', ultimaAnalise: '2025-05-18' },
  ];

  const filteredClients = mockClients.filter(client => 
    client.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.documento.includes(searchTerm) ||
    client.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadgeVariant = (status) => {
    switch (status?.toLowerCase()) {
      case 'ativo': return 'success';
      case 'inativo': return 'secondary';
      case 'pendente': return 'warning';
      default: return 'default';
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <motion.div variants={itemVariants}>
        <DashboardCard 
          title="Gerenciamento de Clientes"
          description="Acesse e gerencie informações detalhadas dos clientes."
          contentClassName="pt-6"
        >
          <div className="flex flex-col sm:flex-row gap-3 justify-between items-center mb-6">
            <div className="relative w-full sm:w-auto sm:flex-grow max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                type="text" 
                placeholder="Buscar por nome, documento ou email..." 
                className="pl-10 text-sm w-full"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button variant="outline" className="w-full sm:w-auto text-sm">
                <Filter className="mr-2 h-4 w-4" /> Filtros
              </Button>
              <Button className="w-full sm:w-auto text-sm">
                <PlusCircle className="mr-2 h-4 w-4" /> Novo Cliente
              </Button>
            </div>
          </div>

          <div className="overflow-x-auto rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/30">
                  <TableHead className="w-[100px] px-3 py-2.5 text-xs">ID</TableHead>
                  <TableHead className="px-3 py-2.5 text-xs">Nome / Razão Social</TableHead>
                  <TableHead className="text-center px-3 py-2.5 text-xs">Tipo</TableHead>
                  <TableHead className="px-3 py-2.5 text-xs">Documento (CPF/CNPJ)</TableHead>
                  <TableHead className="px-3 py-2.5 text-xs">Email</TableHead>
                  <TableHead className="text-center px-3 py-2.5 text-xs">Status</TableHead>
                  <TableHead className="text-center px-3 py-2.5 text-xs">Últ. Análise</TableHead>
                  <TableHead className="text-right px-3 py-2.5 text-xs">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredClients.length > 0 ? filteredClients.map((client) => (
                  <TableRow key={client.id} className="hover:bg-muted/20">
                    <TableCell className="font-medium px-3 py-2 text-xs">{client.id}</TableCell>
                    <TableCell className="px-3 py-2 text-xs">{client.nome}</TableCell>
                    <TableCell className="text-center px-3 py-2 text-xs">
                      <Badge variant={client.tipo === 'PF' ? 'outline' : 'info'} className="text-xs">{client.tipo}</Badge>
                    </TableCell>
                    <TableCell className="px-3 py-2 text-xs text-muted-foreground">{client.documento}</TableCell>
                    <TableCell className="px-3 py-2 text-xs text-muted-foreground">{client.email}</TableCell>
                    <TableCell className="text-center px-3 py-2 text-xs">
                      <Badge variant={getStatusBadgeVariant(client.status)} className="text-xs">
                        {client.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center px-3 py-2 text-xs text-muted-foreground">{client.ultimaAnalise}</TableCell>
                    <TableCell className="text-right px-3 py-2">
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <Edit3 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive/70 hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={8} className="h-24 text-center text-muted-foreground">
                      Nenhum cliente encontrado.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
           <div className="flex justify-between items-center mt-4 text-xs text-muted-foreground">
            <p>Mostrando {filteredClients.length} de {mockClients.length} clientes</p>
            <div className="flex gap-1">
              <Button variant="outline" size="sm" className="h-7 text-xs">Anterior</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs">Próximo</Button>
            </div>
          </div>
        </DashboardCard>
      </motion.div>
    </motion.div>
  );
};

export default ClientsPage;