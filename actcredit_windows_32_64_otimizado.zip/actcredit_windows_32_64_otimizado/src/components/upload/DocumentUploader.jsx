import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Upload, Button, Progress, message, Select, Card, Alert, Spin } from 'antd';
import { UploadOutlined, FileTextOutlined, CheckCircleOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import axios from 'axios';
import { useLogger } from '@/lib/logger';
import AnalysisTypeSelector from '../creditAnalysis/AnalysisTypeSelector';

const { Option } = Select;
const { Dragger } = Upload;

/**
 * Componente para upload e processamento de documentos PDF
 * Integrado com o extrator de PDF para análise de crédito
 */
const DocumentUploader = ({ onExtractComplete, onError }) => {
  const [fileList, setFileList] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [fileId, setFileId] = useState(null);
  const [taskId, setTaskId] = useState(null);
  const [extractionType, setExtractionType] = useState('full');
  const [analysisType, setAnalysisType] = useState('');
  const [statusMessage, setStatusMessage] = useState('');
  const [extractedData, setExtractedData] = useState(null);
  const [error, setError] = useState(null);
  
  const logger = useLogger();
  
  // URL base da API de extração
  const API_BASE_URL = process.env.NODE_ENV === 'production' 
    ? 'https://api.actcredit.com.br/pdf-extractor'
    : 'http://localhost:8000';
  
  // Limpar estado quando componente for desmontado
  useEffect(() => {
    return () => {
      if (fileId) {
        // Tentar remover arquivo do servidor quando componente for desmontado
        axios.delete(`${API_BASE_URL}/file/${fileId}`)
          .catch(err => logger.warn('Falha ao remover arquivo temporário', err));
      }
    };
  }, [fileId, logger]);
  
  // Verificar status da tarefa de extração
  const checkTaskStatus = useCallback(async (taskId) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/status/${taskId}`);
      
      if (response.data.status === 'completed') {
        // Buscar resultado da extração
        const resultResponse = await axios.get(`${API_BASE_URL}/result/${taskId}`);
        setExtractedData(resultResponse.data.data);
        setProcessing(false);
        setProgress(100);
        setStatusMessage('Extração concluída com sucesso!');
        
        // Notificar componente pai
        if (onExtractComplete) {
          onExtractComplete({
            data: resultResponse.data.data,
            analysisType,
            fileId
          });
        }
        
        return true;
      } else if (response.data.status === 'error') {
        throw new Error('Erro durante o processamento do PDF');
      } else {
        // Ainda processando
        return false;
      }
    } catch (err) {
      logger.error('Erro ao verificar status da tarefa', err);
      setError('Falha ao verificar status do processamento');
      setProcessing(false);
      
      if (onError) {
        onError(err);
      }
      
      return true; // Parar polling
    }
  }, [API_BASE_URL, fileId, analysisType, onExtractComplete, onError, logger]);
  
  // Iniciar polling para verificar status da tarefa
  const startPolling = useCallback((taskId) => {
    let pollCount = 0;
    const maxPolls = 60; // 5 minutos (5s * 60)
    
    const poll = async () => {
      pollCount++;
      
      // Atualizar progresso baseado no número de polls (simulação)
      const newProgress = Math.min(95, Math.floor(pollCount / maxPolls * 100));
      setProgress(newProgress);
      
      const isDone = await checkTaskStatus(taskId);
      
      if (!isDone && pollCount < maxPolls) {
        setTimeout(poll, 5000); // Verificar a cada 5 segundos
      } else if (!isDone) {
        // Timeout após 5 minutos
        setError('Tempo limite excedido para processamento do PDF');
        setProcessing(false);
        
        if (onError) {
          onError(new Error('Tempo limite excedido'));
        }
      }
    };
    
    poll();
  }, [checkTaskStatus, onError]);
  
  // Iniciar extração de dados do PDF
  const startExtraction = useCallback(async () => {
    if (!fileId) {
      message.error('Nenhum arquivo foi enviado');
      return;
    }
    
    if (!analysisType) {
      message.error('Selecione o tipo de análise');
      return;
    }
    
    try {
      setProcessing(true);
      setProgress(10);
      setStatusMessage('Iniciando extração de dados...');
      setError(null);
      
      const response = await axios.post(`${API_BASE_URL}/extract/`, {
        file_id: fileId,
        extraction_type: extractionType
      });
      
      setTaskId(response.data.task_id);
      setStatusMessage('Processando documento...');
      setProgress(20);
      
      // Iniciar polling para verificar status
      startPolling(response.data.task_id);
      
    } catch (err) {
      logger.error('Erro ao iniciar extração', err);
      setError('Falha ao iniciar processamento do documento');
      setProcessing(false);
      
      if (onError) {
        onError(err);
      }
    }
  }, [fileId, extractionType, analysisType, API_BASE_URL, startPolling, onError, logger]);
  
  // Manipular upload de arquivo
  const handleUpload = async () => {
    const formData = new FormData();
    
    if (fileList.length === 0) {
      message.error('Selecione um arquivo para upload');
      return;
    }
    
    const file = fileList[0].originFileObj;
    formData.append('file', file);
    
    setUploading(true);
    setProgress(0);
    setStatusMessage('Enviando arquivo...');
    setError(null);
    
    try {
      const response = await axios.post(`${API_BASE_URL}/upload/`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
          setProgress(percentCompleted);
        },
      });
      
      setFileId(response.data.file_id);
      setUploading(false);
      setStatusMessage('Arquivo enviado com sucesso');
      message.success('Upload concluído');
      
      // Iniciar extração automaticamente após upload
      setTimeout(() => {
        startExtraction();
      }, 500);
      
    } catch (err) {
      logger.error('Erro no upload', err);
      setError('Falha ao enviar arquivo');
      setUploading(false);
      
      if (onError) {
        onError(err);
      }
    }
  };
  
  // Configurações do componente de upload
  const uploadProps = {
    onRemove: () => {
      setFileList([]);
      setFileId(null);
    },
    beforeUpload: (file) => {
      // Verificar tipo de arquivo
      const isPDF = file.type === 'application/pdf';
      if (!isPDF) {
        message.error('Você só pode fazer upload de arquivos PDF!');
        return Upload.LIST_IGNORE;
      }
      
      // Verificar tamanho do arquivo (máximo 10MB)
      const isLt10M = file.size / 1024 / 1024 < 10;
      if (!isLt10M) {
        message.error('O arquivo deve ter menos de 10MB!');
        return Upload.LIST_IGNORE;
      }
      
      setFileList([file]);
      return false;
    },
    fileList,
  };
  
  // Renderizar componente
  return (
    <Card className="shadow-md rounded-lg">
      <div className="mb-4">
        <h3 className="text-lg font-semibold mb-2">Upload de Documento para Análise</h3>
        
        {/* Seletor de tipo de análise */}
        <div className="mb-4">
          <AnalysisTypeSelector 
            value={analysisType} 
            onChange={setAnalysisType} 
            disabled={uploading || processing}
          />
        </div>
        
        {/* Seletor de tipo de extração */}
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Tipo de Extração:</label>
          <Select
            value={extractionType}
            onChange={setExtractionType}
            style={{ width: '100%' }}
            disabled={uploading || processing}
          >
            <Option value="full">Extração Completa</Option>
            <Option value="cnpj_only">Apenas CNPJ</Option>
            <Option value="financial_only">Apenas Dados Financeiros</Option>
          </Select>
        </div>
      </div>
      
      {/* Área de upload */}
      <Dragger 
        {...uploadProps}
        disabled={uploading || processing}
        className="mb-4"
      >
        <p className="ant-upload-drag-icon">
          <FileTextOutlined />
        </p>
        <p className="ant-upload-text">Clique ou arraste um arquivo PDF para esta área</p>
        <p className="ant-upload-hint">
          Suporte apenas para arquivos PDF. Tamanho máximo: 10MB.
        </p>
      </Dragger>
      
      {/* Botão de upload */}
      <div className="flex justify-between mb-4">
        <Button
          type="primary"
          onClick={handleUpload}
          disabled={fileList.length === 0 || uploading || processing || !analysisType}
          loading={uploading}
          icon={<UploadOutlined />}
        >
          {uploading ? 'Enviando...' : 'Enviar e Processar'}
        </Button>
        
        {fileId && !uploading && !processing && (
          <Button
            type="default"
            onClick={startExtraction}
            disabled={!fileId || !analysisType}
            icon={<CheckCircleOutlined />}
          >
            Processar Novamente
          </Button>
        )}
      </div>
      
      {/* Barra de progresso */}
      {(uploading || processing) && (
        <div className="mb-4">
          <Progress percent={progress} status="active" />
          <p className="text-sm text-gray-600 mt-2">{statusMessage}</p>
        </div>
      )}
      
      {/* Mensagem de erro */}
      {error && (
        <Alert
          message="Erro"
          description={error}
          type="error"
          showIcon
          className="mb-4"
        />
      )}
      
      {/* Resultado da extração */}
      {extractedData && !error && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Alert
            message="Extração Concluída"
            description={
              <div>
                <p>Os dados foram extraídos com sucesso!</p>
                {extractedData.cnpj_principal && (
                  <p><strong>CNPJ:</strong> {extractedData.cnpj_principal}</p>
                )}
                {extractedData.razao_social && (
                  <p><strong>Razão Social:</strong> {extractedData.razao_social}</p>
                )}
              </div>
            }
            type="success"
            showIcon
            icon={<CheckCircleOutlined />}
          />
        </motion.div>
      )}
    </Card>
  );
};

export default DocumentUploader;
