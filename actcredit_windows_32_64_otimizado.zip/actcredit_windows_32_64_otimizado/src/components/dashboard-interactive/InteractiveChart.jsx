import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { Download, Filter, Share2, BarChart2, PieChart as PieChartIcon, LineChart as LineChartIcon, Maximize2, Minimize2 } from 'lucide-react';

/**
 * Componente de gráfico interativo avançado para dashboard
 * Permite visualização dinâmica, filtros, exportação e personalização
 */
const InteractiveChart = ({
  title = 'Gráfico Interativo',
  description = 'Visualização de dados com opções avançadas',
  initialData = [],
  initialType = 'bar',
  initialPeriod = 'month',
  height = 400,
  allowedTypes = ['bar', 'line', 'pie'],
  allowExport = true,
  allowFullscreen = true,
  colorPalette = ['#4f46e5', '#ec4899', '#10b981', '#f59e0b', '#6366f1', '#8b5cf6']
}) => {
  const [data, setData] = useState(initialData);
  const [chartType, setChartType] = useState(initialType);
  const [period, setPeriod] = useState(initialPeriod);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  
  // Dados de exemplo para diferentes períodos
  const sampleData = {
    day: [
      { name: '00:00', value: 240 },
      { name: '04:00', value: 139 },
      { name: '08:00', value: 980 },
      { name: '12:00', value: 1290 },
      { name: '16:00', value: 1190 },
      { name: '20:00', value: 490 },
    ],
    week: [
      { name: 'Dom', value: 2400 },
      { name: 'Seg', value: 1398 },
      { name: 'Ter', value: 9800 },
      { name: 'Qua', value: 3908 },
      { name: 'Qui', value: 4800 },
      { name: 'Sex', value: 3800 },
      { name: 'Sáb', value: 4300 },
    ],
    month: [
      { name: '01/05', value: 4000 },
      { name: '05/05', value: 3000 },
      { name: '10/05', value: 2000 },
      { name: '15/05', value: 2780 },
      { name: '20/05', value: 1890 },
      { name: '25/05', value: 2390 },
      { name: '30/05', value: 3490 },
    ],
    quarter: [
      { name: 'Jan', value: 4000 },
      { name: 'Fev', value: 3000 },
      { name: 'Mar', value: 2000 },
      { name: 'Abr', value: 2780 },
      { name: 'Mai', value: 1890 },
      { name: 'Jun', value: 2390 },
    ],
    year: [
      { name: 'Jan', value: 4000 },
      { name: 'Fev', value: 3000 },
      { name: 'Mar', value: 2000 },
      { name: 'Abr', value: 2780 },
      { name: 'Mai', value: 1890 },
      { name: 'Jun', value: 2390 },
      { name: 'Jul', value: 3490 },
      { name: 'Ago', value: 4000 },
      { name: 'Set', value: 2500 },
      { name: 'Out', value: 1500 },
      { name: 'Nov', value: 2800 },
      { name: 'Dez', value: 5000 },
    ],
  };

  // Atualizar dados quando o período mudar
  useEffect(() => {
    setData(sampleData[period] || initialData);
  }, [period, initialData]);

  // Alternar modo tela cheia
  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  // Exportar dados
  const exportData = (format) => {
    setIsExporting(true);
    
    // Simulação de exportação
    setTimeout(() => {
      let content = '';
      let filename = `${title.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}`;
      
      if (format === 'csv') {
        content = 'name,value\n' + data.map(item => `${item.name},${item.value}`).join('\n');
        filename += '.csv';
      } else if (format === 'json') {
        content = JSON.stringify(data, null, 2);
        filename += '.json';
      } else if (format === 'image') {
        // Em uma implementação real, aqui seria usado html2canvas ou similar
        // para capturar o gráfico como imagem
        alert('Exportação de imagem seria implementada com html2canvas ou similar');
        setIsExporting(false);
        return;
      }
      
      // Criar blob e link para download
      const blob = new Blob([content], { type: format === 'csv' ? 'text/csv' : 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      setIsExporting(false);
    }, 500);
  };

  // Renderizar o tipo de gráfico selecionado
  const renderChart = () => {
    switch (chartType) {
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={height}>
            <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'var(--background)', 
                  borderColor: 'var(--border)',
                  borderRadius: '0.5rem'
                }} 
              />
              <Legend />
              <Bar dataKey="value" fill={colorPalette[0]} name="Valor" />
            </BarChart>
          </ResponsiveContainer>
        );
      
      case 'line':
        return (
          <ResponsiveContainer width="100%" height={height}>
            <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'var(--background)', 
                  borderColor: 'var(--border)',
                  borderRadius: '0.5rem'
                }} 
              />
              <Legend />
              <Line type="monotone" dataKey="value" stroke={colorPalette[0]} name="Valor" activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        );
      
      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={height}>
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={height / 3}
                fill="#8884d8"
                dataKey="value"
                nameKey="name"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={colorPalette[index % colorPalette.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'var(--background)', 
                  borderColor: 'var(--border)',
                  borderRadius: '0.5rem'
                }} 
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        );
      
      default:
        return <div>Tipo de gráfico não suportado</div>;
    }
  };

  // Ícone para o tipo de gráfico
  const getChartTypeIcon = (type) => {
    switch (type) {
      case 'bar': return <BarChart2 className="h-4 w-4" />;
      case 'line': return <LineChartIcon className="h-4 w-4" />;
      case 'pie': return <PieChartIcon className="h-4 w-4" />;
      default: return <BarChart2 className="h-4 w-4" />;
    }
  };

  return (
    <Card className={`dashboard-panel ${isFullscreen ? 'fixed inset-4 z-50' : ''}`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle className="text-base font-semibold">{title}</CardTitle>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
        <div className="flex items-center space-x-2">
          {/* Seletor de tipo de gráfico */}
          {allowedTypes.length > 1 && (
            <Select value={chartType} onValueChange={setChartType}>
              <SelectTrigger className="w-[110px] h-8 text-xs">
                <div className="flex items-center">
                  {getChartTypeIcon(chartType)}
                  <span className="ml-2">{chartType.charAt(0).toUpperCase() + chartType.slice(1)}</span>
                </div>
              </SelectTrigger>
              <SelectContent>
                {allowedTypes.map(type => (
                  <SelectItem key={type} value={type} className="text-xs">
                    <div className="flex items-center">
                      {getChartTypeIcon(type)}
                      <span className="ml-2">{type.charAt(0).toUpperCase() + type.slice(1)}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          
          {/* Seletor de período */}
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[110px] h-8 text-xs">
              <div className="flex items-center">
                <Filter className="h-4 w-4" />
                <span className="ml-2">
                  {period === 'day' && 'Dia'}
                  {period === 'week' && 'Semana'}
                  {period === 'month' && 'Mês'}
                  {period === 'quarter' && 'Trimestre'}
                  {period === 'year' && 'Ano'}
                </span>
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="day" className="text-xs">Dia</SelectItem>
              <SelectItem value="week" className="text-xs">Semana</SelectItem>
              <SelectItem value="month" className="text-xs">Mês</SelectItem>
              <SelectItem value="quarter" className="text-xs">Trimestre</SelectItem>
              <SelectItem value="year" className="text-xs">Ano</SelectItem>
            </SelectContent>
          </Select>
          
          {/* Botão de exportação */}
          {allowExport && (
            <Select onValueChange={exportData} value="">
              <SelectTrigger className="w-[110px] h-8 text-xs">
                <div className="flex items-center">
                  <Download className="h-4 w-4" />
                  <span className="ml-2">Exportar</span>
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="csv" className="text-xs" disabled={isExporting}>CSV</SelectItem>
                <SelectItem value="json" className="text-xs" disabled={isExporting}>JSON</SelectItem>
                <SelectItem value="image" className="text-xs" disabled={isExporting}>Imagem</SelectItem>
              </SelectContent>
            </Select>
          )}
          
          {/* Botão de compartilhamento */}
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Share2 className="h-4 w-4" />
          </Button>
          
          {/* Botão de tela cheia */}
          {allowFullscreen && (
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={toggleFullscreen}>
              {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {renderChart()}
      </CardContent>
    </Card>
  );
};

export default InteractiveChart;
