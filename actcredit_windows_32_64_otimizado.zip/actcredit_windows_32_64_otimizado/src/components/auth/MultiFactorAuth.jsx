import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Shield, Key, Smartphone, AlertCircle, CheckCircle } from 'lucide-react';

/**
 * Componente de autenticação multifator (MFA)
 * Implementa TOTP (Time-based One-Time Password) usando bibliotecas gratuitas
 */
const MultiFactorAuth = () => {
  const [isEnabled, setIsEnabled] = useState(false);
  const [isSetupMode, setIsSetupMode] = useState(false);
  const [secretKey, setSecretKey] = useState('');
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [remainingTime, setRemainingTime] = useState(30);

  // Gerar chave secreta para TOTP
  const generateSecretKey = () => {
    // Em uma implementação real, usaríamos uma biblioteca como 'otplib'
    // Aqui simulamos a geração de uma chave base32
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let key = '';
    for (let i = 0; i < 16; i++) {
      key += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return key;
  };

  // Iniciar configuração de MFA
  const startSetup = () => {
    setIsSetupMode(true);
    setError(null);
    setSuccess(null);
    
    // Gerar nova chave secreta
    const newSecretKey = generateSecretKey();
    setSecretKey(newSecretKey);
    
    // Em uma implementação real, usaríamos uma biblioteca para gerar o QR code
    // Aqui apenas simulamos a URL que seria usada
    const appName = 'ActCredit';
    const username = 'usuario@actcred.com';
    const qrUrl = `otpauth://totp/${appName}:${username}?secret=${newSecretKey}&issuer=${appName}`;
    setQrCodeUrl(qrUrl);
  };

  // Verificar código TOTP
  const verifyCode = () => {
    if (!verificationCode || verificationCode.length !== 6) {
      setError('O código deve ter 6 dígitos');
      return;
    }
    
    // Em uma implementação real, verificaríamos o código usando uma biblioteca TOTP
    // Aqui apenas simulamos a verificação
    const isValid = Math.random() > 0.2; // 80% de chance de sucesso para simulação
    
    if (isValid) {
      setIsEnabled(true);
      setIsSetupMode(false);
      setSuccess('Autenticação multifator ativada com sucesso!');
      setError(null);
    } else {
      setError('Código inválido. Tente novamente.');
    }
  };

  // Desativar MFA
  const disableMFA = () => {
    setIsEnabled(false);
    setSecretKey('');
    setQrCodeUrl('');
    setVerificationCode('');
    setSuccess('Autenticação multifator desativada.');
    setError(null);
  };

  // Cancelar configuração
  const cancelSetup = () => {
    setIsSetupMode(false);
    setSecretKey('');
    setQrCodeUrl('');
    setVerificationCode('');
    setError(null);
  };

  // Atualizar contador regressivo para novo código TOTP
  useEffect(() => {
    if (isEnabled || isSetupMode) {
      const interval = setInterval(() => {
        // TOTP muda a cada 30 segundos
        const secondsRemaining = 30 - (Math.floor(Date.now() / 1000) % 30);
        setRemainingTime(secondsRemaining);
      }, 1000);
      
      return () => clearInterval(interval);
    }
  }, [isEnabled, isSetupMode]);

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Shield className="h-5 w-5 mr-2 text-primary" />
          Autenticação Multifator
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Mensagens de erro/sucesso */}
        {error && (
          <div className="p-3 bg-red-50 dark:bg-red-900/10 border border-red-200 dark:border-red-800 rounded-md flex items-start">
            <AlertCircle className="h-5 w-5 text-red-500 mt-0.5 mr-2 flex-shrink-0" />
            <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
          </div>
        )}
        
        {success && (
          <div className="p-3 bg-green-50 dark:bg-green-900/10 border border-green-200 dark:border-green-800 rounded-md flex items-start">
            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
            <p className="text-sm text-green-600 dark:text-green-400">{success}</p>
          </div>
        )}
        
        {/* Status atual */}
        <div className="flex items-center justify-between p-3 bg-muted rounded-md">
          <div className="flex items-center">
            <Key className="h-5 w-5 mr-2 text-muted-foreground" />
            <span>Status da autenticação multifator</span>
          </div>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${isEnabled ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'}`}>
            {isEnabled ? 'Ativado' : 'Desativado'}
          </span>
        </div>
        
        {/* Modo de configuração */}
        {isSetupMode && (
          <div className="space-y-4">
            <div className="p-4 border border-border rounded-md space-y-3">
              <h3 className="text-sm font-medium">1. Escaneie o QR code com seu aplicativo autenticador</h3>
              
              <div className="bg-white p-4 rounded-md flex items-center justify-center">
                {/* Em uma implementação real, aqui seria renderizado um QR code */}
                <div className="w-48 h-48 border-2 border-dashed border-gray-300 flex items-center justify-center text-center p-4">
                  <p className="text-xs text-gray-500">
                    QR Code para: {qrCodeUrl}
                  </p>
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Ou insira esta chave manualmente:</h3>
                <div className="flex items-center space-x-2">
                  <Input value={secretKey} readOnly className="font-mono text-sm" />
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      navigator.clipboard.writeText(secretKey);
                      setSuccess('Chave copiada para a área de transferência');
                    }}
                  >
                    Copiar
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="verification-code">
                2. Digite o código de 6 dígitos do seu aplicativo
              </Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="verification-code"
                  value={verificationCode}
                  onChange={(e) => {
                    // Permitir apenas números e limitar a 6 dígitos
                    const value = e.target.value.replace(/\D/g, '').slice(0, 6);
                    setVerificationCode(value);
                  }}
                  placeholder="000000"
                  className="text-center font-mono text-lg tracking-widest"
                  maxLength={6}
                />
                <div className="text-sm text-muted-foreground whitespace-nowrap">
                  {remainingTime}s
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                O código muda a cada 30 segundos
              </p>
            </div>
            
            <div className="flex space-x-2">
              <Button onClick={verifyCode} disabled={verificationCode.length !== 6} className="flex-1">
                Verificar e Ativar
              </Button>
              <Button variant="outline" onClick={cancelSetup}>
                Cancelar
              </Button>
            </div>
          </div>
        )}
        
        {/* Botões de ação principal */}
        {!isSetupMode && (
          <div>
            {isEnabled ? (
              <Button variant="destructive" onClick={disableMFA} className="w-full">
                Desativar Autenticação Multifator
              </Button>
            ) : (
              <Button onClick={startSetup} className="w-full">
                <Smartphone className="h-4 w-4 mr-2" />
                Configurar Autenticação Multifator
              </Button>
            )}
            
            <p className="mt-2 text-xs text-muted-foreground">
              {isEnabled 
                ? 'A autenticação multifator adiciona uma camada extra de segurança à sua conta.' 
                : 'Recomendamos ativar a autenticação multifator para aumentar a segurança da sua conta.'}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default MultiFactorAuth;
