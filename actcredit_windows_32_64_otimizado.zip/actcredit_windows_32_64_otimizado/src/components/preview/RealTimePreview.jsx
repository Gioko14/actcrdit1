import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Eye, Download, FileText, Image, FileSpreadsheet } from 'lucide-react';

/**
 * Componente de pré-visualização em tempo real
 * Permite visualizar documentos e dados antes do processamento final
 */
const RealTimePreview = ({
  file = null,
  data = null,
  previewType = 'auto',
  onDownload = null,
  title = 'Pré-visualização em Tempo Real'
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);
  
  // Determinar tipo de visualização automaticamente
  const getPreviewType = () => {
    if (previewType !== 'auto') return previewType;
    
    if (file) {
      const fileType = file.type.toLowerCase();
      if (fileType.includes('pdf')) return 'pdf';
      if (fileType.includes('image')) return 'image';
      if (fileType.includes('excel') || fileType.includes('spreadsheet') || fileType.includes('csv')) return 'spreadsheet';
      if (fileType.includes('json') || fileType.includes('xml')) return 'data';
      return 'text';
    }
    
    if (data) {
      if (typeof data === 'object') return 'data';
      return 'text';
    }
    
    return 'empty';
  };
  
  // Renderizar ícone com base no tipo
  const renderTypeIcon = () => {
    const type = getPreviewType();
    
    switch (type) {
      case 'pdf':
        return <FileText className="h-5 w-5 text-red-500" />;
      case 'image':
        return <Image className="h-5 w-5 text-blue-500" />;
      case 'spreadsheet':
        return <FileSpreadsheet className="h-5 w-5 text-green-500" />;
      case 'data':
        return <FileText className="h-5 w-5 text-purple-500" />;
      case 'text':
        return <FileText className="h-5 w-5 text-gray-500" />;
      default:
        return <Eye className="h-5 w-5 text-primary" />;
    }
  };
  
  // Renderizar conteúdo da pré-visualização
  const renderPreviewContent = () => {
    const type = getPreviewType();
    
    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      );
    }
    
    if (error) {
      return (
        <div className="flex flex-col items-center justify-center h-64 text-center p-4">
          <div className="text-red-500 mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="8" x2="12" y2="12"></line>
              <line x1="12" y1="16" x2="12.01" y2="16"></line>
            </svg>
          </div>
          <p className="text-red-600 dark:text-red-400">{error}</p>
        </div>
      );
    }
    
    if (type === 'empty') {
      return (
        <div className="flex flex-col items-center justify-center h-64 text-center p-4">
          <Eye className="h-12 w-12 text-muted-foreground mb-4" />
          <p className="text-muted-foreground">Nenhum arquivo ou dado para pré-visualizar</p>
        </div>
      );
    }
    
    if (type === 'pdf') {
      return (
        <div className="flex flex-col items-center">
          <div className="w-full bg-muted rounded-md p-4 min-h-[300px] flex items-center justify-center">
            <div className="text-center">
              <FileText className="h-16 w-16 text-red-500 mx-auto mb-4" />
              <p className="text-sm text-muted-foreground mb-2">Pré-visualização de PDF</p>
              <p className="text-xs text-muted-foreground/70">{file?.name}</p>
              <p className="text-xs text-muted-foreground/70">{file?.size ? `${(file.size / 1024).toFixed(1)} KB` : ''}</p>
            </div>
          </div>
          <div className="flex justify-center mt-4">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center"
              onClick={() => onDownload && onDownload(file)}
            >
              <Eye className="h-4 w-4 mr-2" />
              Visualizar PDF Completo
            </Button>
          </div>
        </div>
      );
    }
    
    if (type === 'image' && file) {
      return (
        <div className="flex flex-col items-center">
          <div className="w-full bg-muted rounded-md p-4 min-h-[300px] flex items-center justify-center">
            {file && (
              <img 
                src={URL.createObjectURL(file)} 
                alt="Pré-visualização" 
                className="max-w-full max-h-[300px] object-contain"
                onLoad={() => URL.revokeObjectURL(file)}
              />
            )}
          </div>
          <div className="flex justify-center mt-4">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center"
              onClick={() => onDownload && onDownload(file)}
            >
              <Download className="h-4 w-4 mr-2" />
              Baixar Imagem
            </Button>
          </div>
        </div>
      );
    }
    
    if (type === 'data' && data) {
      return (
        <div className="w-full">
          <pre className="bg-muted p-4 rounded-md overflow-auto max-h-[400px] text-xs">
            {JSON.stringify(data, null, 2)}
          </pre>
          <div className="flex justify-center mt-4">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center"
              onClick={() => {
                if (onDownload) {
                  onDownload(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
                }
              }}
            >
              <Download className="h-4 w-4 mr-2" />
              Baixar JSON
            </Button>
          </div>
        </div>
      );
    }
    
    if (type === 'text') {
      const content = typeof data === 'string' ? data : file ? 'Conteúdo do arquivo de texto' : '';
      return (
        <div className="w-full">
          <div className="bg-muted p-4 rounded-md overflow-auto max-h-[400px]">
            <p className="whitespace-pre-wrap text-sm">{content}</p>
          </div>
        </div>
      );
    }
    
    if (type === 'spreadsheet') {
      return (
        <div className="flex flex-col items-center">
          <div className="w-full bg-muted rounded-md p-4 min-h-[300px] flex items-center justify-center">
            <div className="text-center">
              <FileSpreadsheet className="h-16 w-16 text-green-500 mx-auto mb-4" />
              <p className="text-sm text-muted-foreground mb-2">Pré-visualização de Planilha</p>
              <p className="text-xs text-muted-foreground/70">{file?.name}</p>
              <p className="text-xs text-muted-foreground/70">{file?.size ? `${(file.size / 1024).toFixed(1)} KB` : ''}</p>
            </div>
          </div>
          <div className="flex justify-center mt-4">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center"
              onClick={() => onDownload && onDownload(file)}
            >
              <Eye className="h-4 w-4 mr-2" />
              Visualizar Planilha
            </Button>
          </div>
        </div>
      );
    }
    
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center p-4">
        <Eye className="h-12 w-12 text-muted-foreground mb-4" />
        <p className="text-muted-foreground">Tipo de arquivo não suportado para pré-visualização</p>
      </div>
    );
  };
  
  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-semibold flex items-center">
          {renderTypeIcon()}
          <span className="ml-2">{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {renderPreviewContent()}
      </CardContent>
    </Card>
  );
};

export default RealTimePreview;
