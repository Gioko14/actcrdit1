import React, { useEffect } from 'react';
import { Layout, notification } from 'antd';
import { initPWA, checkForUpdates, notifyUserAboutUpdate, applyUpdate } from '@/lib/pwaUtils';
import PWAInstallButton from '@/components/ui/PWAInstallButton';

/**
 * Componente para gerenciamento do PWA
 * Inicializa recursos e gerencia atualizações
 */
const PWAManager = ({ children }) => {
  useEffect(() => {
    // Inicializa recursos PWA
    initPWA();
    
    // Configura verificação periódica de atualizações
    const checkInterval = setInterval(() => {
      checkForUpdates();
    }, 60 * 60 * 1000); // A cada hora
    
    // Configura listener para atualizações do service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        // Notifica o usuário sobre a atualização aplicada
        notification.success({
          message: 'Atualização aplicada',
          description: 'O ActCredit Premium foi atualizado para a versão mais recente.',
          placement: 'bottomRight',
        });
      });
      
      // Configura listener para novas atualizações disponíveis
      navigator.serviceWorker.ready.then(registration => {
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              // Nova versão disponível, notifica o usuário
              notifyUserAboutUpdate(() => {
                applyUpdate();
              });
            }
          });
        });
      });
    }
    
    return () => clearInterval(checkInterval);
  }, []);
  
  return (
    <>
      {children}
      <div style={{ position: 'fixed', bottom: 20, right: 20, zIndex: 1000 }}>
        <PWAInstallButton />
      </div>
    </>
  );
};

export default PWAManager;
