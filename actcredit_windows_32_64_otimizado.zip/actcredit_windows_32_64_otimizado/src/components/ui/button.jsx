import { cn } from '@/lib/utils';
import { Slot } from '@radix-ui/react-slot';
import { cva } from 'class-variance-authority';
import React from 'react';
import { motion } from 'framer-motion';

const buttonVariants = cva(
	'inline-flex items-center justify-center rounded-lg text-sm font-semibold ring-offset-background transition-all duration-200 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-60 shadow-md hover:shadow-lg active:shadow-sm active:scale-[0.98]',
	{
		variants: {
			variant: {
				default: 'bg-primary text-primary-foreground hover:bg-primary/90 active:bg-primary/80 shadow-neon-glow-primary/30 hover:shadow-neon-glow-primary/50',
				destructive:
          'bg-destructive text-destructive-foreground hover:bg-destructive/90 active:bg-destructive/80 shadow-red-500/30 hover:shadow-red-500/50',
				outline:
          'border border-input bg-transparent hover:bg-accent hover:text-accent-foreground active:bg-accent/80 dark:border-border/70 dark:hover:border-primary dark:hover:text-primary',
				secondary:
          'bg-secondary text-secondary-foreground hover:bg-secondary/90 active:bg-secondary/80 dark:bg-secondary/70 dark:hover:bg-secondary/60',
				ghost: 'hover:bg-accent hover:text-accent-foreground active:bg-accent/80 shadow-none hover:shadow-none dark:hover:bg-primary/10 dark:hover:text-primary',
				link: 'text-primary underline-offset-4 hover:underline active:opacity-80 shadow-none hover:shadow-none',
        premium: 'bg-gradient-to-r from-chart-pink via-chart-purple to-chart-blue text-white border-0 hover:shadow-xl hover:opacity-95 active:opacity-85 animate-aurora-bg bg-[length:200%_200%]'
			},
			size: {
				default: 'h-10 px-5 py-2', // Increased padding
				sm: 'h-9 rounded-md px-3.5 text-xs', // Increased padding
				lg: 'h-12 rounded-lg px-7 text-base', // Increased padding & height
				icon: 'h-10 w-10',
			},
		},
		defaultVariants: {
			variant: 'default',
			size: 'default',
		},
	},
);

const Button = React.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	const Comp = asChild ? Slot : motion.button;
	return (
		<Comp
			className={cn(buttonVariants({ variant, size, className }))}
			ref={ref}
      whileTap={{ scale: 0.97 }} 
      transition={{ type: "spring", stiffness: 350, damping: 20 }}
			{...props}
		/>
	);
});
Button.displayName = 'Button';

export { Button, buttonVariants };