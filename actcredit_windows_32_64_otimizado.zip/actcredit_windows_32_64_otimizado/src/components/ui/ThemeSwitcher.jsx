import React from 'react';
import '../../css/theme-transitions.css';
import { useTheme } from '@/contexts/ThemeContext';
import { Button } from '@/components/ui/button';
import { Sun, Moon, Monitor } from 'lucide-react';

/**
 * Componente avançado para controle de tema
 * Permite alternar entre tema claro, escuro e preferência do sistema
 */
const ThemeSwitcher = () => {
  const { theme, toggleTheme, resetToSystemPreference, isTransitioning } = useTheme();
  
  return (
    <div className={`flex items-center gap-2 ${isTransitioning ? 'theme-transition-active' : ''}`}>
      <Button 
        variant={theme === 'light' ? "default" : "ghost"} 
        size="icon" 
        onClick={() => theme !== 'light' && toggleTheme()}
        className="text-yellow-500 hover:text-yellow-600 transition-all"
        title="Tema Claro"
      >
        <Sun className="h-5 w-5 transition-all duration-500 transform hover:rotate-90" />
      </Button>
      
      <Button 
        variant={theme === 'dark' ? "default" : "ghost"} 
        size="icon" 
        onClick={() => theme !== 'dark' && toggleTheme()}
        className="text-indigo-400 hover:text-indigo-500 transition-all"
        title="Tema Escuro"
      >
        <Moon className="h-5 w-5 transition-all duration-500 transform hover:rotate-[30deg]" />
      </Button>
      
      <Button 
        variant="ghost" 
        size="icon" 
        onClick={resetToSystemPreference}
        className="text-muted-foreground hover:text-primary transition-all"
        title="Usar Preferência do Sistema"
      >
        <Monitor className="h-5 w-5" />
      </Button>
    </div>
  );
};

export default ThemeSwitcher;
