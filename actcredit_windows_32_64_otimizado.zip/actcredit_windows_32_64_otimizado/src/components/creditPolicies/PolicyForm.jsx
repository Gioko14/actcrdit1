import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Save, X, ShieldCheck, Info } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { formatCurrency, parseCurrency } from '@/lib/creditAnalysisUtils';

const PolicyForm = ({ policy, onSave, onCancel, isEditing, allPolicies }) => {
  const [formData, setFormData] = useState(policy || { 
    name: '', type: 'PJ', scoreMinimo: 500, endividamentoMax: 30, liquidezMin: 1.0, prazoMax: 12, valorMax: 10000, garantiasExigidas: [], isCustom: false, isDefault: false
  });
  const { toast } = useToast();

  useEffect(() => {
    if (policy) {
      setFormData({
        ...policy,
        valorMax: policy.valorMax || 0 // Garante que valorMax seja um número
      });
    } else {
      // Se for nova política, verifica se já existe uma padrão. Se não, marca esta como padrão.
      const hasDefaultPolicy = allPolicies.some(p => p.isDefault);
      setFormData(prev => ({ ...prev, isDefault: !hasDefaultPolicy }));
    }
  }, [policy, allPolicies]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSliderChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value[0] }));
  };
  
  const handleCheckboxChange = (garantia) => {
    setFormData(prev => {
      const newGarantias = prev.garantiasExigidas.includes(garantia)
        ? prev.garantiasExigidas.filter(g => g !== garantia)
        : [...prev.garantiasExigidas, garantia];
      return { ...prev, garantiasExigidas: newGarantias };
    });
  };

  const handleValorMaxChange = (e) => {
    const rawValue = e.target.value;
    setFormData(prev => ({ ...prev, valorMax: formatCurrency(rawValue) }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast({ title: "Erro de Validação", description: "O nome da política é obrigatório.", variant: "destructive"});
      return;
    }
    const parsedValorMax = parseCurrency(formData.valorMax);
    if (isNaN(parsedValorMax) || parsedValorMax <= 0) {
        toast({ title: "Erro de Validação", description: "O Valor Máximo deve ser um número positivo.", variant: "destructive"});
        return;
    }

    const dataToSave = {
      ...formData,
      id: policy?.id || Date.now(),
      valorMax: parsedValorMax,
    };
    onSave(dataToSave);
  };

  const garantiaOptions = ['Aval', 'Alienação Fiduciária', 'Hipoteca Rural', 'Penhor Agrícola', 'Propriedade Intelectual', 'Recebíveis de Cartão', 'Fiança Bancária', 'Seguro Garantia'];

  return (
    <motion.form 
      onSubmit={handleSubmit} 
      className="space-y-6 bg-card p-4 sm:p-6 rounded-lg border shadow-md"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-primary flex items-center">
          <ShieldCheck className="mr-2 h-6 w-6" />
          {isEditing ? "Editar Política de Crédito" : "Nova Política de Crédito"}
        </h2>
        <Button type="button" variant="ghost" size="icon" onClick={onCancel} aria-label="Fechar formulário">
          <X className="h-5 w-5" />
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
        <div>
          <Label htmlFor="name" className="text-sm">Nome da Política</Label>
          <Input id="name" value={formData.name} onChange={(e) => handleChange('name', e.target.value)} placeholder="Ex: Política Conservadora PJ" className="mt-1"/>
        </div>
        <div>
          <Label htmlFor="type" className="text-sm">Tipo de Política</Label>
          <Select value={formData.type} onValueChange={(val) => handleChange('type', val)}>
            <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="PJ">Pessoa Jurídica (PJ)</SelectItem>
              <SelectItem value="PF">Pessoa Física (PF)</SelectItem>
              <SelectItem value="Agro">Agronegócio</SelectItem>
              <SelectItem value="Tech">Tecnologia</SelectItem>
              <SelectItem value="Varejo">Varejo</SelectItem>
              <SelectItem value="Outro">Outro</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
        <div>
          <Label htmlFor="scoreMinimo" className="text-sm">Score Mínimo ({formData.scoreMinimo})</Label>
          <Slider id="scoreMinimo" min={300} max={1000} step={10} value={[formData.scoreMinimo]} onValueChange={(val) => handleSliderChange('scoreMinimo', val)} className="mt-2"/>
        </div>
        <div>
          <Label htmlFor="endividamentoMax" className="text-sm">Endividamento Máx. ({formData.endividamentoMax}%)</Label>
          <Slider id="endividamentoMax" min={10} max={100} step={1} value={[formData.endividamentoMax]} onValueChange={(val) => handleSliderChange('endividamentoMax', val)} className="mt-2"/>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
        <div>
          <Label htmlFor="liquidezMin" className="text-sm">Liquidez Mínima ({formData.liquidezMin.toFixed(1)})</Label>
          <Slider id="liquidezMin" min={0.5} max={3} step={0.1} value={[formData.liquidezMin]} onValueChange={(val) => handleSliderChange('liquidezMin', val)} className="mt-2"/>
        </div>
        <div>
          <Label htmlFor="prazoMax" className="text-sm">Prazo Máximo ({formData.prazoMax} meses)</Label>
          <Slider id="prazoMax" min={6} max={120} step={6} value={[formData.prazoMax]} onValueChange={(val) => handleSliderChange('prazoMax', val)} className="mt-2"/>
        </div>
      </div>
      
      <div>
        <Label htmlFor="valorMax" className="text-sm">Valor Máximo</Label>
        <Input id="valorMax" value={typeof formData.valorMax === 'number' ? formatCurrency(formData.valorMax.toString()) : formData.valorMax} onChange={handleValorMaxChange} placeholder="R$ 0,00" className="mt-1"/>
      </div>

      <div>
        <Label className="text-sm">Garantias Exigidas</Label>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 mt-2">
          {garantiaOptions.map(g => (
            <div key={g} className="flex items-center space-x-2 p-2 bg-muted/30 rounded-md">
              <Checkbox id={`garantia-${g}-${formData.id || 'new'}`} checked={formData.garantiasExigidas.includes(g)} onCheckedChange={() => handleCheckboxChange(g)} />
              <Label htmlFor={`garantia-${g}-${formData.id || 'new'}`} className="text-xs font-normal cursor-pointer">{g}</Label>
            </div>
          ))}
        </div>
      </div>
      
      <div className="space-y-3 pt-3 border-t">
        <div className="flex items-center space-x-2">
          <Checkbox id={`isCustom-${formData.id || 'new'}`} checked={formData.isCustom} onCheckedChange={(checked) => handleChange('isCustom', Boolean(checked))} />
          <Label htmlFor={`isCustom-${formData.id || 'new'}`} className="text-sm font-normal">Política customizada (não listada para seleção padrão)</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Checkbox id={`isDefault-${formData.id || 'new'}`} checked={formData.isDefault} onCheckedChange={(checked) => handleChange('isDefault', Boolean(checked))} />
          <Label htmlFor={`isDefault-${formData.id || 'new'}`} className="text-sm font-normal">Definir como política padrão para novas análises</Label>
        </div>
        {formData.isDefault && (
          <div className="flex items-center text-xs text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/30 p-2 rounded-md">
            <Info size={14} className="mr-2 shrink-0" />
            <span>Ao marcar esta como padrão, qualquer outra política anteriormente padrão será desmarcada.</span>
          </div>
        )}
      </div>

      <div className="flex justify-end space-x-3 pt-4 border-t">
        <Button type="button" variant="outline" onClick={onCancel}>
          <X className="mr-2 h-4 w-4" /> Cancelar
        </Button>
        <Button type="submit">
          <Save className="mr-2 h-4 w-4" /> Salvar Política
        </Button>
      </div>
    </motion.form>
  );
};

export default PolicyForm;