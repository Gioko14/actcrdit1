import React, { useState } from 'react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { GripVertical, Plus, X, Move } from 'lucide-react';

// Tipos de itens para drag and drop
const ItemTypes = {
  WIDGET: 'widget',
  CARD: 'card'
};

/**
 * Componente de item arrastável
 */
const DraggableItem = ({ id, index, moveItem, children, onRemove }) => {
  const [{ isDragging }, drag] = useDrag({
    type: ItemTypes.WIDGET,
    item: { id, index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const [, drop] = useDrop({
    accept: ItemTypes.WIDGET,
    hover: (draggedItem) => {
      if (draggedItem.index !== index) {
        moveItem(draggedItem.index, index);
        draggedItem.index = index;
      }
    },
  });

  return (
    <div
      ref={(node) => drag(drop(node))}
      className={`mb-4 relative ${isDragging ? 'opacity-50' : 'opacity-100'}`}
      style={{ cursor: 'move' }}
    >
      <Card className="border border-border">
        <CardHeader className="p-3 flex flex-row items-center justify-between space-y-0">
          <div className="flex items-center">
            <GripVertical className="h-5 w-5 text-muted-foreground mr-2" />
            <CardTitle className="text-sm font-medium">Item {id}</CardTitle>
          </div>
          {onRemove && (
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-7 w-7 rounded-full hover:bg-destructive/10 hover:text-destructive"
              onClick={() => onRemove(id)}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </CardHeader>
        <CardContent className="p-3 pt-0">
          {children}
        </CardContent>
      </Card>
    </div>
  );
};

/**
 * Componente de contêiner para arrastar e soltar
 */
const DragDropContainer = ({ 
  items: initialItems = [], 
  onOrderChange,
  onItemRemove,
  onItemAdd,
  renderItem,
  allowAdd = true,
  allowRemove = true,
  title = "Arrastar e Soltar"
}) => {
  const [items, setItems] = useState(initialItems);

  // Mover item de uma posição para outra
  const moveItem = (fromIndex, toIndex) => {
    const updatedItems = [...items];
    const [movedItem] = updatedItems.splice(fromIndex, 1);
    updatedItems.splice(toIndex, 0, movedItem);
    
    setItems(updatedItems);
    
    if (onOrderChange) {
      onOrderChange(updatedItems);
    }
  };

  // Remover item
  const removeItem = (id) => {
    const updatedItems = items.filter(item => item.id !== id);
    setItems(updatedItems);
    
    if (onItemRemove) {
      onItemRemove(id, updatedItems);
    }
  };

  // Adicionar novo item
  const addItem = () => {
    const newId = Math.max(0, ...items.map(item => item.id)) + 1;
    const newItem = {
      id: newId,
      content: `Novo item ${newId}`
    };
    
    const updatedItems = [...items, newItem];
    setItems(updatedItems);
    
    if (onItemAdd) {
      onItemAdd(newItem, updatedItems);
    }
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="w-full p-4 border border-border rounded-lg bg-card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold flex items-center">
            <Move className="h-5 w-5 mr-2 text-primary" />
            {title}
          </h3>
          {allowAdd && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={addItem}
              className="flex items-center"
            >
              <Plus className="h-4 w-4 mr-1" />
              Adicionar Item
            </Button>
          )}
        </div>
        
        <div className="space-y-2">
          {items.map((item, index) => (
            <DraggableItem 
              key={item.id} 
              id={item.id} 
              index={index} 
              moveItem={moveItem}
              onRemove={allowRemove ? removeItem : null}
            >
              {renderItem ? renderItem(item) : (
                <div className="p-2 bg-muted rounded-md">
                  {item.content || `Conteúdo do item ${item.id}`}
                </div>
              )}
            </DraggableItem>
          ))}
          
          {items.length === 0 && (
            <div className="p-8 text-center border-2 border-dashed border-border rounded-lg">
              <p className="text-muted-foreground">
                Nenhum item para exibir. Clique em "Adicionar Item" para começar.
              </p>
            </div>
          )}
        </div>
      </div>
    </DndProvider>
  );
};

export default DragDropContainer;
