/**
 * Componente para seleção de tipo de análise de crédito
 * Implementa os tipos: Majoração, Reativação, Prospecção e Revisão
 */

import React from 'react';
import { Select, Form, Tooltip } from 'antd';
import { InfoCircleOutlined } from '@ant-design/icons';
import logger, { logCreditAnalysis, EventType } from '@/lib/logger';

const { Option } = Select;

const AnalysisTypeSelector = ({ value, onChange, disabled = false }) => {
  // Definição dos tipos de análise
  const analysisTypes = [
    {
      value: 'Majoração',
      label: 'Majoração',
      description: 'Aumento do limite de crédito para clientes existentes'
    },
    {
      value: 'Reativação',
      label: 'Reativação',
      description: 'Reativação de clientes inativos ou bloqueados'
    },
    {
      value: 'Prospecção',
      label: 'Prospecção',
      description: 'Análise de novos clientes potenciais'
    },
    {
      value: 'Revisão',
      label: 'Revisão',
      description: 'Revisão periódica de clientes existentes'
    }
  ];

  // Handler para mudança de valor
  const handleChange = (newValue) => {
    // Registrar evento de seleção de tipo de análise
    logCreditAnalysis('seleção de tipo', newValue, { previousValue: value });
    
    // Chamar callback de mudança
    if (onChange) {
      onChange(newValue);
    }
  };

  return (
    <Select
      placeholder="Selecione o tipo de análise"
      value={value}
      onChange={handleChange}
      style={{ width: '100%' }}
      disabled={disabled}
    >
      {analysisTypes.map(type => (
        <Option key={type.value} value={type.value}>
          <Tooltip title={type.description}>
            <span>{type.label} <InfoCircleOutlined style={{ fontSize: '12px', opacity: 0.6 }} /></span>
          </Tooltip>
        </Option>
      ))}
    </Select>
  );
};

// Componente Form.Item encapsulado para facilitar uso em formulários
export const AnalysisTypeFormItem = ({ name = 'analysisType', label = 'Tipo de Análise', required = true, ...props }) => {
  return (
    <Form.Item
      name={name}
      label={label}
      rules={[
        { 
          required: required, 
          message: 'Por favor, selecione o tipo de análise' 
        }
      ]}
      {...props}
    >
      <AnalysisTypeSelector />
    </Form.Item>
  );
};

export default AnalysisTypeSelector;
