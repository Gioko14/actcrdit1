import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Card, 
  Form, 
  Input, 
  Button, 
  Alert, 
  Space, 
  Spin, 
  Typography, 
  Divider,
  message,
  Descriptions,
  Tag,
  Statistic,
  Row,
  Col
} from 'antd';
import { 
  SearchOutlined, 
  CheckCircleOutlined, 
  CloseCircleOutlined,
  LoadingOutlined,
  FileTextOutlined
} from '@ant-design/icons';
import { AnalysisTypeFormItem } from './AnalysisTypeSelector';
import { validarCNPJ } from '@/lib/validacaoCNPJ';
import logger, { logCreditAnalysis } from '@/lib/logger';
import axios from 'axios';

const { Title, Text, Paragraph } = Typography;

/**
 * Componente para imputação manual de CNPJ e análise via API externa
 * Implementa a simplificação solicitada: apenas CNPJ + API externa
 */
const CNPJInputManual = () => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  // Realizar análise de crédito
  const handleAnalysis = async (values) => {
    const { cnpj, analysisType } = values;
    
    // Validar CNPJ
    if (!validarCNPJ(cnpj)) {
      message.error('CNPJ inválido. Por favor, verifique e tente novamente.');
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      // Registrar início da análise
      logCreditAnalysis('início', analysisType, { cnpj });
      
      // Remover caracteres especiais do CNPJ
      const cleanCNPJ = cnpj.replace(/[^\d]/g, '');
      
      // Consultar dados da empresa via API externa (Brasil API)
      const response = await axios.get(`https://brasilapi.com.br/api/cnpj/v1/${cleanCNPJ}`);
      
      // Simular análise de crédito com base nos dados obtidos
      const analysisResult = simulateAnalysis(response.data, analysisType);
      
      // Registrar sucesso da análise
      logCreditAnalysis('sucesso', analysisType, { 
        cnpj, 
        score: analysisResult.score,
        recommendation: analysisResult.recommendation
      });
      
      setResult(analysisResult);
      message.success('Análise de crédito realizada com sucesso!');
    } catch (error) {
      console.error('Erro ao realizar análise de crédito:', error);
      
      // Registrar erro na análise
      logCreditAnalysis('erro', analysisType, { 
        cnpj, 
        error: error.message || 'Erro desconhecido'
      });
      
      setError(error.response?.data?.message || 'Erro ao realizar análise de crédito. Verifique o CNPJ e tente novamente.');
      message.error('Falha ao realizar análise de crédito');
    } finally {
      setLoading(false);
    }
  };

  // Simular análise de crédito com base nos dados da empresa
  const simulateAnalysis = (companyData, analysisType) => {
    // Calcular idade da empresa em anos
    const foundationDate = new Date(companyData.data_inicio_atividade);
    const today = new Date();
    const ageInYears = Math.floor((today - foundationDate) / (365.25 * 24 * 60 * 60 * 1000));
    
    // Calcular score base com base na idade da empresa
    let baseScore = Math.min(ageInYears * 10, 300);
    
    // Ajustar score com base no capital social
    const capitalSocial = companyData.capital_social || 0;
    let capitalScore = 0;
    
    if (capitalSocial >= 1000000) {
      capitalScore = 300;
    } else if (capitalSocial >= 500000) {
      capitalScore = 200;
    } else if (capitalSocial >= 100000) {
      capitalScore = 100;
    } else if (capitalSocial >= 10000) {
      capitalScore = 50;
    }
    
    // Ajustar score com base no porte da empresa
    let porteScore = 0;
    
    switch (companyData.porte?.toUpperCase()) {
      case 'GRANDE PORTE':
        porteScore = 200;
        break;
      case 'MEDIO PORTE':
        porteScore = 150;
        break;
      case 'MICRO EMPRESA':
        porteScore = 50;
        break;
      case 'PEQUENO PORTE':
        porteScore = 100;
        break;
      default:
        porteScore = 0;
    }
    
    // Ajustar score com base na situação cadastral
    let situacaoScore = 0;
    
    if (companyData.situacao_cadastral === 'ATIVA') {
      situacaoScore = 200;
    }
    
    // Calcular score final
    const finalScore = Math.min(baseScore + capitalScore + porteScore + situacaoScore, 1000);
    
    // Determinar limite de crédito com base no score
    let creditLimit = 0;
    
    if (finalScore >= 800) {
      creditLimit = capitalSocial * 0.5;
    } else if (finalScore >= 600) {
      creditLimit = capitalSocial * 0.3;
    } else if (finalScore >= 400) {
      creditLimit = capitalSocial * 0.2;
    } else if (finalScore >= 200) {
      creditLimit = capitalSocial * 0.1;
    } else {
      creditLimit = capitalSocial * 0.05;
    }
    
    // Ajustar limite mínimo
    creditLimit = Math.max(creditLimit, 5000);
    
    // Determinar recomendação com base no score
    let recommendation = '';
    let riskLevel = '';
    
    if (finalScore >= 800) {
      recommendation = 'Aprovado';
      riskLevel = 'A';
    } else if (finalScore >= 600) {
      recommendation = 'Aprovado';
      riskLevel = 'B';
    } else if (finalScore >= 400) {
      recommendation = 'Aprovado com Restrições';
      riskLevel = 'C';
    } else if (finalScore >= 200) {
      recommendation = 'Análise Manual Requerida';
      riskLevel = 'D';
    } else {
      recommendation = 'Reprovado';
      riskLevel = 'E';
    }
    
    // Ajustar com base no tipo de análise
    if (analysisType === 'Majoração') {
      creditLimit *= 1.2;
    } else if (analysisType === 'Reativação') {
      creditLimit *= 0.8;
      if (finalScore < 400) {
        recommendation = 'Reprovado';
      }
    } else if (analysisType === 'Prospecção') {
      // Sem ajustes específicos
    } else if (analysisType === 'Revisão') {
      // Sem ajustes específicos
    }
    
    // Gerar resultado da análise
    return {
      company: companyData,
      analysisType,
      score: finalScore,
      creditLimit,
      recommendation,
      riskLevel,
      analysisDate: new Date().toISOString(),
      factors: {
        ageInYears,
        baseScore,
        capitalScore,
        porteScore,
        situacaoScore
      }
    };
  };

  // Renderizar resultado da análise
  const renderResult = () => {
    if (!result) return null;
    
    const { company, score, creditLimit, recommendation, riskLevel, analysisType, factors } = result;
    
    // Determinar cor da tag de recomendação
    let recommendationColor = 'default';
    if (recommendation === 'Aprovado') recommendationColor = 'success';
    if (recommendation === 'Aprovado com Restrições') recommendationColor = 'warning';
    if (recommendation === 'Análise Manual Requerida') recommendationColor = 'processing';
    if (recommendation === 'Reprovado') recommendationColor = 'error';
    
    // Determinar cor da tag de risco
    let riskColor = 'default';
    if (riskLevel === 'A') riskColor = 'success';
    if (riskLevel === 'B') riskColor = 'success';
    if (riskLevel === 'C') riskColor = 'warning';
    if (riskLevel === 'D') riskColor = 'warning';
    if (riskLevel === 'E') riskColor = 'error';
    
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card title="Resultado da Análise de Crédito" style={{ marginTop: 24 }}>
          <Row gutter={[16, 16]}>
            <Col span={8}>
              <Statistic 
                title="Score de Crédito" 
                value={score} 
                suffix="/1000"
                valueStyle={{ color: score >= 600 ? '#3f8600' : score >= 400 ? '#faad14' : '#cf1322' }}
              />
            </Col>
            <Col span={8}>
              <Statistic 
                title="Limite de Crédito" 
                value={creditLimit} 
                precision={2}
                prefix="R$"
              />
            </Col>
            <Col span={8}>
              <div style={{ textAlign: 'center', marginTop: 4 }}>
                <div style={{ marginBottom: 8 }}>
                  <Text strong>Recomendação</Text>
                </div>
                <Tag color={recommendationColor} style={{ fontSize: '14px', padding: '4px 8px' }}>
                  {recommendation}
                </Tag>
              </div>
            </Col>
          </Row>
          
          <Divider />
          
          <Descriptions title="Informações da Empresa" bordered column={2}>
            <Descriptions.Item label="CNPJ">{company.cnpj}</Descriptions.Item>
            <Descriptions.Item label="Tipo de Análise">
              <Tag>{analysisType}</Tag>
            </Descriptions.Item>
            <Descriptions.Item label="Razão Social">{company.razao_social}</Descriptions.Item>
            <Descriptions.Item label="Nome Fantasia">{company.nome_fantasia || 'Não informado'}</Descriptions.Item>
            <Descriptions.Item label="Data de Abertura">{company.data_inicio_atividade}</Descriptions.Item>
            <Descriptions.Item label="Idade da Empresa">{factors.ageInYears} anos</Descriptions.Item>
            <Descriptions.Item label="Capital Social">R$ {company.capital_social?.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || 'Não informado'}</Descriptions.Item>
            <Descriptions.Item label="Porte">{company.porte || 'Não informado'}</Descriptions.Item>
            <Descriptions.Item label="Situação Cadastral">{company.situacao_cadastral || 'Não informado'}</Descriptions.Item>
            <Descriptions.Item label="Nível de Risco">
              <Tag color={riskColor}>{riskLevel}</Tag>
            </Descriptions.Item>
          </Descriptions>
          
          <Divider />
          
          <Title level={5}>Fatores de Análise</Title>
          <Row gutter={[16, 16]}>
            <Col span={6}>
              <Card size="small">
                <Statistic 
                  title="Tempo de Atividade" 
                  value={factors.baseScore} 
                  suffix="/300"
                />
              </Card>
            </Col>
            <Col span={6}>
              <Card size="small">
                <Statistic 
                  title="Capital Social" 
                  value={factors.capitalScore} 
                  suffix="/300"
                />
              </Card>
            </Col>
            <Col span={6}>
              <Card size="small">
                <Statistic 
                  title="Porte da Empresa" 
                  value={factors.porteScore} 
                  suffix="/200"
                />
              </Card>
            </Col>
            <Col span={6}>
              <Card size="small">
                <Statistic 
                  title="Situação Cadastral" 
                  value={factors.situacaoScore} 
                  suffix="/200"
                />
              </Card>
            </Col>
          </Row>
          
          <div style={{ marginTop: 24, textAlign: 'center' }}>
            <Space>
              <Button 
                type="primary" 
                icon={<FileTextOutlined />}
                onClick={() => {
                  message.success('Relatório exportado com sucesso');
                  logCreditAnalysis('exportação', analysisType, { cnpj: company.cnpj });
                }}
              >
                Exportar Relatório
              </Button>
              <Button 
                onClick={() => {
                  setResult(null);
                  form.resetFields();
                  logCreditAnalysis('nova análise', '', { previous: analysisType });
                }}
              >
                Nova Análise
              </Button>
            </Space>
          </div>
        </Card>
      </motion.div>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Card title="Análise de Crédito por CNPJ">
        {!result && (
          <Form
            form={form}
            layout="vertical"
            onFinish={handleAnalysis}
          >
            <Form.Item
              name="cnpj"
              label="CNPJ"
              rules={[
                { required: true, message: 'Por favor, informe o CNPJ' },
                { 
                  validator: (_, value) => {
                    if (!value || validarCNPJ(value)) {
                      return Promise.resolve();
                    }
                    return Promise.reject(new Error('CNPJ inválido'));
                  }
                }
              ]}
            >
              <Input 
                placeholder="00.000.000/0000-00" 
                disabled={loading}
                maxLength={18}
              />
            </Form.Item>
            
            <AnalysisTypeFormItem disabled={loading} />
            
            <Form.Item>
              <Button
                type="primary"
                htmlType="submit"
                icon={<SearchOutlined />}
                loading={loading}
                block
              >
                {loading ? 'Analisando...' : 'Realizar Análise de Crédito'}
              </Button>
            </Form.Item>
          </Form>
        )}
        
        {loading && (
          <div style={{ textAlign: 'center', margin: '20px 0' }}>
            <Spin indicator={<LoadingOutlined style={{ fontSize: 24 }} spin />} />
            <div style={{ marginTop: 8 }}>
              <Text>Consultando dados e realizando análise de crédito...</Text>
            </div>
          </div>
        )}
        
        {error && (
          <Alert
            message="Erro na Análise"
            description={error}
            type="error"
            showIcon
            style={{ marginTop: 16 }}
          />
        )}
        
        {renderResult()}
      </Card>
    </motion.div>
  );
};

export default CNPJInputManual;
