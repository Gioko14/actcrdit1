import React, { useState } from 'react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';
import { useTheme } from '@/contexts/ThemeContext';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const RegionalAnalysisSection = ({ aprovacoesRegiaoData }) => {
  const { theme } = useTheme();
  const [selectedRegion, setSelectedRegion] = useState(aprovacoesRegiaoData[0].name);

  const primaryColor = theme === 'dark' ? 'hsl(var(--dashboard-accent-pink))' : 'hsl(var(--primary))';
  const textColor = theme === 'dark' ? 'hsl(var(--dashboard-text-secondary))' : 'hsl(var(--muted-foreground))';
  const gridColor = theme === 'dark' ? 'hsla(var(--dashboard-text-secondary), 0.1)' : 'hsla(var(--muted-foreground), 0.1)';
  
  const selectedRegionData = aprovacoesRegiaoData.find(r => r.name === selectedRegion);
  const stateData = selectedRegionData ? Object.entries(selectedRegionData.estados).map(([key, value]) => ({ name: key, aprovacoes: value })) : [];

  return (
    <DashboardCard title="Análise Detalhada por Estado (Região Selecionada)">
      <div className="mb-4">
        <Select value={selectedRegion} onValueChange={setSelectedRegion}>
          <SelectTrigger className="w-full md:w-[280px]">
            <SelectValue placeholder="Selecione uma região" />
          </SelectTrigger>
          <SelectContent>
            {aprovacoesRegiaoData.map(region => (
              <SelectItem key={region.name} value={region.name}>{region.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      {selectedRegionData && (
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={stateData} margin={{ top: 5, right: 20, left: -15, bottom: 20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
            <XAxis dataKey="name" stroke={textColor} tick={{ fontSize: 12 }} />
            <YAxis stroke={textColor} tick={{ fontSize: 12 }} />
            <Tooltip contentStyle={{ backgroundColor: theme === 'dark' ? 'hsl(var(--card))' : '#fff', borderRadius: '0.5rem' }}/>
            <Legend wrapperStyle={{ fontSize: '12px' }}/>
            <Bar dataKey="aprovacoes" fill={primaryColor} radius={[4, 4, 0, 0]} name="Aprovações no Estado" />
          </BarChart>
        </ResponsiveContainer>
      )}
    </DashboardCard>
  );
};

export default RegionalAnalysisSection;