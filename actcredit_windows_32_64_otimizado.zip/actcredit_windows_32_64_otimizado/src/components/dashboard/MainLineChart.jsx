import React from 'react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend, ReferenceDot } from 'recharts';
import { useTheme } from '@/contexts/ThemeContext';

const data = [
  { name: 'Jan', value: 1200 },
  { name: 'Feb', value: 2100 },
  { name: 'Mar', value: 1800 },
  { name: 'Apr', value: 3500 },
  { name: 'May', value: 3000 },
  { name: 'Jun', value: 4340 },
  { name: 'Jul', value: 3800 },
  { name: 'Aug', value: 2500 },
];

const MainLineChart = () => {
  const { theme } = useTheme();
  const primaryColor = theme === 'dark' ? 'hsl(var(--dashboard-accent-pink))' : 'hsl(var(--primary))';
  const secondaryColor = theme === 'dark' ? 'hsl(var(--dashboard-accent-purple))' : 'hsl(var(--secondary))';
  const textColor = theme === 'dark' ? 'hsl(var(--dashboard-text-secondary))' : 'hsl(var(--muted-foreground))';
  const gridColor = theme === 'dark' ? 'hsla(var(--dashboard-text-secondary), 0.1)' : 'hsla(var(--muted-foreground), 0.1)';


  return (
    <DashboardCard className="h-full">
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
          <XAxis dataKey="name" stroke={textColor} tick={{ fontSize: 12 }} />
          <YAxis stroke={textColor} domain={[0, 5000]} tick={{ fontSize: 12 }} />
          <Tooltip
            contentStyle={{
              backgroundColor: theme === 'dark' ? 'hsl(var(--card))' : '#fff',
              borderColor: theme === 'dark' ? 'hsl(var(--border))' : '#ccc',
              borderRadius: '0.5rem',
            }}
            labelStyle={{ color: textColor }}
          />
          <Legend wrapperStyle={{ fontSize: '12px' }} />
          <Line type="monotone" dataKey="value" stroke={primaryColor} strokeWidth={2} dot={{ r: 4, fill: primaryColor }} activeDot={{ r: 6 }} name="Vendas" />
          <Line type="monotone" dataKey="value" stroke={secondaryColor} strokeWidth={2} dot={false} activeDot={false} name="Projeção" transform="translate(0, -500)" />
           <ReferenceDot x="Jun" y={4340} r={6} fill={primaryColor} stroke="white" strokeWidth={2} isFront={true} />
        </LineChart>
      </ResponsiveContainer>
    </DashboardCard>
  );
};

export default MainLineChart;