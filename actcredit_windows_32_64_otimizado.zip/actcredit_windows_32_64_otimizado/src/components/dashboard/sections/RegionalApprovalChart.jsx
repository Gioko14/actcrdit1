import React from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import { DashboardPanel } from '@/components/dashboard/DashboardPanel'; 
import { CustomTooltip } from '@/components/dashboard/CustomTooltip';

const aprovacoesRegiaoData = [
  { name: 'Sudeste', Aprovações: 4200 }, { name: 'Sul', Aprovações: 3000 },
  { name: 'Nordeste', Aprovações: 2500 }, { name: 'Centro-Oeste', Aprovações: 1800 },
  { name: 'Norte', Aprovações: 900 },
];

const RegionalApprovalChart = () => {
  return (
    <DashboardPanel title="Aprovações por Região">
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={aprovacoesRegiaoData} margin={{ top: 10, right: 5, left: -20, bottom: 5 }}>
          <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={{ stroke: 'hsl(var(--border)/0.5)' }} />
          <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={{ stroke: 'hsl(var(--border)/0.5)' }} />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'hsl(var(--primary)/0.05)' }}/>
          <Bar dataKey="Aprovações" fill="url(#barGradientBlue)" radius={[5, 5, 0, 0]} barSize={35} />
          <defs>
            <linearGradient id="barGradientBlue" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="hsl(var(--chart-blue))" stopOpacity={0.9}/>
              <stop offset="100%" stopColor="hsl(var(--chart-blue))" stopOpacity={0.3}/>
            </linearGradient>
          </defs>
        </BarChart>
      </ResponsiveContainer>
    </DashboardPanel>
  );
};

export default RegionalApprovalChart;