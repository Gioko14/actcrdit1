import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { FileText, Image, FileSpreadsheet, FileCode, Upload, CheckCircle, AlertCircle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

/**
 * Componente para suporte a múltiplos formatos de arquivo
 * Permite upload e processamento de diversos tipos de documentos
 */
const MultiFormatSupport = ({
  onFileProcessed,
  supportedFormats = {
    images: ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.tiff'],
    documents: ['.pdf', '.docx', '.doc', '.rtf', '.txt', '.odt'],
    spreadsheets: ['.xlsx', '.xls', '.csv', '.ods'],
    data: ['.json', '.xml']
  }
}) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const fileInputRef = React.useRef(null);

  // Obter todos os formatos suportados
  const allSupportedFormats = Object.values(supportedFormats).flat();

  // Determinar o tipo de arquivo
  const getFileType = (filename) => {
    const extension = '.' + filename.split('.').pop().toLowerCase();
    
    if (supportedFormats.images.includes(extension)) return 'image';
    if (supportedFormats.documents.includes(extension)) return 'document';
    if (supportedFormats.spreadsheets.includes(extension)) return 'spreadsheet';
    if (supportedFormats.data.includes(extension)) return 'data';
    
    return 'unknown';
  };

  // Obter ícone com base no tipo de arquivo
  const getFileIcon = (fileType) => {
    switch (fileType) {
      case 'image': return <Image className="h-6 w-6" />;
      case 'document': return <FileText className="h-6 w-6" />;
      case 'spreadsheet': return <FileSpreadsheet className="h-6 w-6" />;
      case 'data': return <FileCode className="h-6 w-6" />;
      default: return <FileText className="h-6 w-6" />;
    }
  };

  // Manipular seleção de arquivo
  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    
    if (!file) return;
    
    const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
    
    // Verificar se o formato é suportado
    if (!allSupportedFormats.includes(fileExtension)) {
      setError({
        message: `Formato não suportado. Formatos aceitos: ${allSupportedFormats.join(', ')}`
      });
      return;
    }
    
    setSelectedFile(file);
    setError(null);
    setResult(null);
  };

  // Processar arquivo
  const processFile = () => {
    if (!selectedFile) return;
    
    setProcessing(true);
    setProgress(0);
    setError(null);
    setResult(null);
    
    // Simular progresso
    const interval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + 5;
        if (newProgress >= 100) {
          clearInterval(interval);
          
          // Processar arquivo com base no tipo
          const fileType = getFileType(selectedFile.name);
          processFileByType(fileType);
          
          return 100;
        }
        return newProgress;
      });
    }, 100);
  };

  // Processar arquivo com base no tipo
  const processFileByType = (fileType) => {
    // Aqui seria implementada a lógica real de processamento para cada tipo
    // Por enquanto, apenas simulamos o resultado
    
    setTimeout(() => {
      setResult({
        name: selectedFile.name,
        type: fileType,
        size: selectedFile.size,
        processedAt: new Date().toISOString(),
        extractedData: {
          // Dados simulados com base no tipo de arquivo
          contentType: selectedFile.type,
          pages: fileType === 'document' ? Math.floor(Math.random() * 10) + 1 : null,
          rows: fileType === 'spreadsheet' ? Math.floor(Math.random() * 100) + 1 : null,
          fields: Math.floor(Math.random() * 20) + 1
        }
      });
      
      setProcessing(false);
      
      // Notificar componente pai
      if (onFileProcessed) {
        onFileProcessed({
          file: selectedFile,
          result: {
            name: selectedFile.name,
            type: fileType,
            size: selectedFile.size,
            processedAt: new Date().toISOString()
          }
        });
      }
    }, 500);
  };

  // Limpar seleção
  const clearSelection = () => {
    setSelectedFile(null);
    setResult(null);
    setError(null);
    setProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="w-full p-6 border border-border rounded-lg bg-card">
      <h3 className="text-lg font-semibold mb-4">Suporte a Múltiplos Formatos</h3>
      
      {/* Área de upload */}
      <div 
        className="border-2 border-dashed border-border rounded-lg p-8 text-center mb-4 hover:border-primary transition-colors cursor-pointer"
        onClick={() => fileInputRef.current?.click()}
      >
        <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
        <p className="text-muted-foreground mb-2">
          Clique para selecionar um arquivo
        </p>
        <p className="text-xs text-muted-foreground/70">
          Formatos suportados: {allSupportedFormats.join(', ')}
        </p>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          onChange={handleFileSelect}
          accept={allSupportedFormats.join(',')}
        />
      </div>
      
      {/* Arquivo selecionado */}
      {selectedFile && (
        <div className="mb-4 p-3 border border-border rounded-lg">
          <div className="flex items-center">
            {getFileIcon(getFileType(selectedFile.name))}
            <div className="ml-3 flex-1">
              <p className="font-medium text-sm">{selectedFile.name}</p>
              <p className="text-xs text-muted-foreground">
                {(selectedFile.size / 1024).toFixed(1)} KB • {getFileType(selectedFile.name)}
              </p>
            </div>
          </div>
        </div>
      )}
      
      {/* Barra de progresso */}
      {processing && (
        <div className="mb-4">
          <div className="flex justify-between text-sm mb-1">
            <span>Processando...</span>
            <span>{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
      )}
      
      {/* Resultado */}
      {result && (
        <div className="mb-4 p-3 border border-border rounded-lg bg-green-50 dark:bg-green-900/10">
          <div className="flex items-start">
            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
            <div className="ml-3 flex-1">
              <p className="font-medium text-sm">Arquivo processado com sucesso</p>
              <div className="mt-2 text-xs space-y-1">
                <p><span className="font-medium">Tipo:</span> {result.type}</p>
                <p><span className="font-medium">Tamanho:</span> {(result.size / 1024).toFixed(1)} KB</p>
                <p><span className="font-medium">Processado em:</span> {new Date(result.processedAt).toLocaleString()}</p>
                
                {result.extractedData.pages && (
                  <p><span className="font-medium">Páginas:</span> {result.extractedData.pages}</p>
                )}
                
                {result.extractedData.rows && (
                  <p><span className="font-medium">Linhas:</span> {result.extractedData.rows}</p>
                )}
                
                <p><span className="font-medium">Campos detectados:</span> {result.extractedData.fields}</p>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Erro */}
      {error && (
        <div className="mb-4 p-3 border border-border rounded-lg bg-red-50 dark:bg-red-900/10">
          <div className="flex items-center">
            <AlertCircle className="h-5 w-5 text-red-500" />
            <p className="ml-3 text-sm text-red-600 dark:text-red-400">{error.message}</p>
          </div>
        </div>
      )}
      
      {/* Botões de ação */}
      <div className="flex space-x-2">
        <Button 
          onClick={processFile} 
          disabled={processing || !selectedFile}
          className="flex-1"
        >
          {processing ? 'Processando...' : 'Processar Arquivo'}
        </Button>
        <Button 
          variant="outline" 
          onClick={clearSelection}
          disabled={processing}
        >
          Limpar
        </Button>
      </div>
    </div>
  );
};

export default MultiFormatSupport;
