/**
 * Utilitário de logging centralizado
 * Fornece funções para registrar eventos, erros e métricas de forma consistente
 */

const fs = require('fs');
const path = require('path');
const util = require('util');
const PathUtils = require('./PathUtils');

// Níveis de log
const LOG_LEVELS = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3,
  FATAL: 4
};

class Logger {
  constructor(options = {}) {
    // Configurações padrão
    this.options = {
      level: LOG_LEVELS.INFO,
      logToConsole: true,
      logToFile: true,
      logDir: path.join(process.cwd(), 'logs'),
      logFileName: 'actcredit.log',
      maxLogSize: 10 * 1024 * 1024, // 10MB
      maxLogFiles: 5,
      ...options
    };

    // Criar diretório de logs se não existir
    if (this.options.logToFile) {
      try {
        if (!fs.existsSync(this.options.logDir)) {
          fs.mkdirSync(this.options.logDir, { recursive: true });
        }
      } catch (error) {
        console.error(`Erro ao criar diretório de logs: ${error.message}`);
        this.options.logToFile = false;
      }
    }

    // Caminho completo do arquivo de log
    this.logFilePath = path.join(this.options.logDir, this.options.logFileName);
  }

  /**
   * Formata uma mensagem de log
   * @private
   * @param {string} level Nível do log
   * @param {string} message Mensagem do log
   * @param {Object} meta Metadados adicionais
   * @returns {string} Mensagem formatada
   */
  _formatLogMessage(level, message, meta = {}) {
    const timestamp = new Date().toISOString();
    let formattedMessage = `[${timestamp}] [${level}] ${message}`;
    
    if (Object.keys(meta).length > 0) {
      formattedMessage += `\n${util.inspect(meta, { depth: 4 })}`;
    }
    
    return formattedMessage;
  }

  /**
   * Escreve uma mensagem no arquivo de log
   * @private
   * @param {string} message Mensagem formatada
   */
  _writeToFile(message) {
    if (!this.options.logToFile) return;
    
    try {
      // Verificar tamanho do arquivo de log
      if (fs.existsSync(this.logFilePath)) {
        const stats = fs.statSync(this.logFilePath);
        
        // Rotacionar log se exceder tamanho máximo
        if (stats.size >= this.options.maxLogSize) {
          this._rotateLogFiles();
        }
      }
      
      // Adicionar quebra de linha e escrever no arquivo
      fs.appendFileSync(this.logFilePath, message + '\n');
    } catch (error) {
      console.error(`Erro ao escrever no arquivo de log: ${error.message}`);
    }
  }

  /**
   * Rotaciona arquivos de log
   * @private
   */
  _rotateLogFiles() {
    try {
      // Remover arquivo de log mais antigo se necessário
      const oldestLogFile = path.join(
        this.options.logDir,
        `${path.basename(this.options.logFileName, path.extname(this.options.logFileName))}.${this.options.maxLogFiles}${path.extname(this.options.logFileName)}`
      );
      
      if (fs.existsSync(oldestLogFile)) {
        fs.unlinkSync(oldestLogFile);
      }
      
      // Rotacionar arquivos existentes
      for (let i = this.options.maxLogFiles - 1; i >= 1; i--) {
        const oldFile = path.join(
          this.options.logDir,
          `${path.basename(this.options.logFileName, path.extname(this.options.logFileName))}.${i}${path.extname(this.options.logFileName)}`
        );
        
        const newFile = path.join(
          this.options.logDir,
          `${path.basename(this.options.logFileName, path.extname(this.options.logFileName))}.${i + 1}${path.extname(this.options.logFileName)}`
        );
        
        if (fs.existsSync(oldFile)) {
          fs.renameSync(oldFile, newFile);
        }
      }
      
      // Renomear arquivo atual
      const newFile = path.join(
        this.options.logDir,
        `${path.basename(this.options.logFileName, path.extname(this.options.logFileName))}.1${path.extname(this.options.logFileName)}`
      );
      
      if (fs.existsSync(this.logFilePath)) {
        fs.renameSync(this.logFilePath, newFile);
      }
    } catch (error) {
      console.error(`Erro ao rotacionar arquivos de log: ${error.message}`);
    }
  }

  /**
   * Registra uma mensagem de log
   * @private
   * @param {number} level Nível do log
   * @param {string} message Mensagem do log
   * @param {Object} meta Metadados adicionais
   */
  _log(level, message, meta = {}) {
    // Verificar se o nível de log está habilitado
    if (level < this.options.level) return;
    
    // Obter nome do nível
    const levelName = Object.keys(LOG_LEVELS).find(key => LOG_LEVELS[key] === level) || 'UNKNOWN';
    
    // Formatar mensagem
    const formattedMessage = this._formatLogMessage(levelName, message, meta);
    
    // Registrar no console
    if (this.options.logToConsole) {
      if (level >= LOG_LEVELS.ERROR) {
        console.error(formattedMessage);
      } else if (level === LOG_LEVELS.WARN) {
        console.warn(formattedMessage);
      } else {
        console.log(formattedMessage);
      }
    }
    
    // Registrar no arquivo
    this._writeToFile(formattedMessage);
  }

  /**
   * Registra uma mensagem de debug
   * @param {string} message Mensagem do log
   * @param {Object} meta Metadados adicionais
   */
  debug(message, meta = {}) {
    this._log(LOG_LEVELS.DEBUG, message, meta);
  }

  /**
   * Registra uma mensagem informativa
   * @param {string} message Mensagem do log
   * @param {Object} meta Metadados adicionais
   */
  info(message, meta = {}) {
    this._log(LOG_LEVELS.INFO, message, meta);
  }

  /**
   * Registra uma mensagem de aviso
   * @param {string} message Mensagem do log
   * @param {Object} meta Metadados adicionais
   */
  warn(message, meta = {}) {
    this._log(LOG_LEVELS.WARN, message, meta);
  }

  /**
   * Registra uma mensagem de erro
   * @param {string} message Mensagem do log
   * @param {Error} error Objeto de erro
   * @param {Object} meta Metadados adicionais
   */
  error(message, error = null, meta = {}) {
    const errorMeta = { ...meta };
    
    if (error) {
      errorMeta.error = {
        message: error.message,
        stack: error.stack,
        name: error.name
      };
    }
    
    this._log(LOG_LEVELS.ERROR, message, errorMeta);
  }

  /**
   * Registra uma mensagem de erro fatal
   * @param {string} message Mensagem do log
   * @param {Error} error Objeto de erro
   * @param {Object} meta Metadados adicionais
   */
  fatal(message, error = null, meta = {}) {
    const errorMeta = { ...meta };
    
    if (error) {
      errorMeta.error = {
        message: error.message,
        stack: error.stack,
        name: error.name
      };
    }
    
    this._log(LOG_LEVELS.FATAL, message, errorMeta);
  }

  /**
   * Registra início de operação para monitoramento
   * @param {string} operation Nome da operação
   * @param {Object} meta Metadados adicionais
   * @returns {Object} Objeto de contexto para finalização
   */
  startOperation(operation, meta = {}) {
    const startTime = Date.now();
    const operationId = `op_${startTime}_${Math.random().toString(36).substr(2, 9)}`;
    
    this.info(`Iniciando operação: ${operation}`, {
      operation,
      operationId,
      startTime,
      ...meta
    });
    
    return {
      operation,
      operationId,
      startTime,
      meta
    };
  }

  /**
   * Registra fim de operação para monitoramento
   * @param {Object} context Objeto de contexto retornado por startOperation
   * @param {Object} result Resultado da operação
   * @param {Error} error Erro da operação (se houver)
   */
  endOperation(context, result = null, error = null) {
    const endTime = Date.now();
    const duration = endTime - context.startTime;
    
    const meta = {
      operation: context.operation,
      operationId: context.operationId,
      startTime: context.startTime,
      endTime,
      duration,
      ...context.meta
    };
    
    if (result) {
      meta.result = result;
    }
    
    if (error) {
      this.error(`Erro na operação: ${context.operation}`, error, meta);
    } else {
      this.info(`Operação concluída: ${context.operation}`, meta);
    }
    
    return {
      operation: context.operation,
      duration,
      success: !error
    };
  }

  /**
   * Registra uma métrica para monitoramento
   * @param {string} name Nome da métrica
   * @param {number} value Valor da métrica
   * @param {Object} meta Metadados adicionais
   */
  metric(name, value, meta = {}) {
    this.info(`Métrica: ${name}`, {
      metric: name,
      value,
      timestamp: Date.now(),
      ...meta
    });
  }
}

// Exportar instância única do logger
const logger = new Logger();

module.exports = logger;
