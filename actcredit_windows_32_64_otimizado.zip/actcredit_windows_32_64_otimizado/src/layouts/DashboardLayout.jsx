import React, { useState, useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { LayoutDashboard, FileText, Settings, Menu, X, ShieldCheck, Building, Users, LogOut, ChevronsLeft, ChevronsRight, Sun, Moon, SearchCheck, Briefcase } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext'; 
import { useTheme } from '@/contexts/ThemeContext';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import ThemeSwitcher from '@/components/ui/ThemeSwitcher';

const DashboardLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const { getCurrentUser } = useAuth(); 
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  const user = getCurrentUser();

  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
    { icon: SearchCheck, label: 'Análises', path: '/analises' },
    { icon: Building, label: 'Empresas', path: '/empresas' },
    { icon: Users, label: 'Clientes', path: '/clientes' },
    { icon: FileText, label: 'Relatórios', path: '/relatorios' },
    { icon: Briefcase, label: 'Setores', path: '/setores' },
    { icon: ShieldCheck, label: 'Políticas', path: '/politicas-de-credito' },
    { icon: Settings, label: 'Configurações', path: '/configuracoes' },
  ];

  const toggleMobileSidebar = () => setSidebarOpen(!sidebarOpen);
  const toggleDesktopSidebar = () => setIsSidebarCollapsed(!isSidebarCollapsed);

  const isActive = (path) => {
    if (path === "/") return location.pathname === "/" || location.pathname === "/dashboard";
    return location.pathname.startsWith(path);
  };
  
  const sidebarWidth = isSidebarCollapsed ? "w-[88px]" : "w-[270px]"; // Slightly wider for collapsed icons
  const mobileSidebarWidth = "w-[270px]";

  const sidebarVariants = {
    open: { x: 0, transition: { type: "spring", stiffness: 350, damping: 35 } },
    closed: { x: "-100%", transition: { type: "spring", stiffness: 350, damping: 30 } }
  };
  
  const SidebarContent = ({ mobile = false }) => (
    <div className={cn(
      "flex flex-col h-full text-card-foreground transition-all duration-300 ease-in-out",
      mobile ? mobileSidebarWidth : sidebarWidth,
      "bg-card/80 dark:bg-card/60 acrylic-surface" // Apply acrylic effect
    )}>
      <div className={cn(
          "flex items-center border-b border-border/50 dark:border-border/30",
          isSidebarCollapsed && !mobile ? "justify-center h-[70px]" : "justify-between h-[70px] px-5"
        )}>
        {!isSidebarCollapsed || mobile ? (
          <Link to="/" className="flex items-center space-x-3 group">
            <span className="text-2xl font-bold text-primary group-hover:text-primary/80 transition-colors tracking-tight">
              ActCredit
            </span>
          </Link>
        ) : (
          <span className="text-xl font-bold text-primary">AC</span>
        )}
        {mobile && (
          <Button variant="ghost" size="icon" onClick={toggleMobileSidebar} aria-label="Fechar Menu" className="text-muted-foreground hover:text-primary">
            <X className="h-6 w-6" />
          </Button>
        )}
      </div>
      
      <nav className="flex-1 p-3.5 space-y-2 overflow-y-auto">
        {menuItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={cn(
              "flex items-center py-3 rounded-lg transition-all duration-200 group text-sm font-medium relative overflow-hidden",
              isSidebarCollapsed && !mobile ? "justify-center px-2.5 h-12" : "px-4",
              isActive(item.path) 
                ? "bg-primary/20 dark:bg-primary/25 text-primary shadow-inner-glow" 
                : "text-muted-foreground hover:text-primary hover:bg-primary/5 dark:hover:bg-primary/10"
            )}
            onClick={mobile ? () => setSidebarOpen(false) : undefined}
            title={isSidebarCollapsed && !mobile ? item.label : undefined}
          >
            {isActive(item.path) && (
              <motion.div 
                className="absolute inset-y-0 left-0 w-1 bg-primary"
                layoutId="activeMenuHighlight"
                transition={{ type: "spring", stiffness: 300, damping: 25 }}
              />
            )}
            <item.icon className={cn("h-5 w-5 shrink-0", isSidebarCollapsed && !mobile ? "" : "mr-4")} />
            {(!isSidebarCollapsed || mobile) && <span className="truncate">{item.label}</span>}
          </Link>
        ))}
      </nav>
      
      <div className={cn("p-4 border-t border-border/50 dark:border-border/30", isSidebarCollapsed && !mobile ? "py-4" : "")}>
        {(!isSidebarCollapsed || mobile) ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center min-w-0">
              <Avatar className="h-10 w-10 mr-3 border-2 border-primary/30 hover:border-primary/60 transition-all shadow-md">
                <AvatarImage src={user?.avatar || "https://avatar.vercel.sh/admin-pro.png"} alt={user?.name || 'Admin Pro'} />
                <AvatarFallback className="bg-gradient-to-br from-primary/20 to-accent/20 text-primary font-semibold">
                  {user?.name?.charAt(0)?.toUpperCase() || 'A'}
                </AvatarFallback>
              </Avatar>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{user?.name || 'Administrador Pro'}</p>
                <p className="text-xs text-muted-foreground truncate">{user?.email || 'admin.pro@actcredit.com'}</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive/80 ml-2">
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        ) : (
          <div className="flex flex-col items-center space-y-3">
            <Avatar className="h-10 w-10 border-2 border-primary/30 hover:border-primary/60 transition-all shadow-md">
               <AvatarImage src={user?.avatar || "https://avatar.vercel.sh/admin-pro.png"} alt={user?.name || 'Admin Pro'} />
               <AvatarFallback className="bg-gradient-to-br from-primary/20 to-accent/20 text-primary font-semibold">
                {user?.name?.charAt(0)?.toUpperCase() || 'A'}
              </AvatarFallback>
            </Avatar>
             <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive/80">
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">
      <motion.aside 
        className={cn("hidden md:flex flex-col border-r border-border/40 dark:border-border/20 shadow-2xl fixed inset-y-0 left-0 z-30 transition-all duration-300 ease-in-out")}
        animate={{ width: isSidebarCollapsed ? 88 : 270 }}
      >
        <SidebarContent />
      </motion.aside>
      
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            className="fixed inset-0 bg-black/70 backdrop-blur-md z-40 md:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>
      
      <motion.aside
        className="fixed inset-y-0 left-0 z-50 border-r border-border/40 dark:border-border/20 shadow-2xl md:hidden flex flex-col"
        variants={sidebarVariants}
        initial="closed"
        animate={sidebarOpen ? "open" : "closed"}
      >
        <SidebarContent mobile={true} />
      </motion.aside>
      
      <div className={cn("flex-1 flex flex-col overflow-hidden transition-all duration-300 ease-in-out", isSidebarCollapsed ? "md:ml-[88px]" : "md:ml-[270px]")}>
        <header className="h-[70px] border-b border-border/50 dark:border-border/30 bg-background flex items-center justify-between px-4 md:px-6 sticky top-0 z-20">
          <div className="flex items-center">
            <Button variant="ghost" size="icon" className="md:hidden mr-2 text-muted-foreground hover:text-primary" onClick={toggleMobileSidebar}>
              <Menu className="h-6 w-6" />
            </Button>
            <Button variant="ghost" size="icon" className="hidden md:inline-flex mr-3 text-muted-foreground hover:text-primary" onClick={toggleDesktopSidebar}>
              {isSidebarCollapsed ? <ChevronsRight className="h-5 w-5" /> : <ChevronsLeft className="h-5 w-5" />}
            </Button>
            <motion.h1 
                key={location.pathname + (menuItems.find(item => isActive(item.path))?.label || "ActCredit")} 
                initial={{ opacity: 0, x: -15 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.35, ease: "circOut" }}
                className="text-xl font-semibold text-foreground hidden sm:block tracking-tight"
            >
                {menuItems.find(item => isActive(item.path))?.label || "ActCredit"}
            </motion.h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <ThemeSwitcher />
            {/* Placeholder for future search or notifications */}
          </div>
        </header>
        
        <main className="flex-1 overflow-y-auto p-5 sm:p-6 md:p-8 bg-background relative">
           {/* Subtle background pattern for dark mode */}
          <div className="absolute inset-0 z-[-1] dark:opacity-20 opacity-0 transition-opacity duration-500" 
               style={{backgroundImage: 'radial-gradient(hsl(var(--muted-foreground)) 0.5px, transparent 0.5px)', backgroundSize: '15px 15px'}}>
          </div>
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;