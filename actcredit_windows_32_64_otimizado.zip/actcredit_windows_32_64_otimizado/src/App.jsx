import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import DashboardLayout from '@/layouts/DashboardLayout';
import Dashboard from '@/pages/Dashboard';
import ClientsPage from '@/pages/ClientsPage';
import ReportsPage from '@/pages/ReportsPage';
import DemoPage from '@/pages/demo/DemoPage';
import PWAManager from '@/components/ui/PWAManager';
import { AuthProvider } from '@/contexts/AuthContext';
import '@/css/pwa.css';

/**
 * Componente principal da aplicação
 * Configura rotas e layouts
 */
function App() {
  return (
    <AuthProvider>
      <PWAManager>
        <Router>
          <Routes>
            <Route path="/" element={<DashboardLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="clients" element={<ClientsPage />} />
              <Route path="reports" element={<ReportsPage />} />
              <Route path="demo" element={<DemoPage />} />
            </Route>
          </Routes>
        </Router>
      </PWAManager>
    </AuthProvider>
  );
}

export default App;
