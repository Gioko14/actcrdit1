import sys
import json
import os
from paddleocr import PaddleOCR

# Script simplificado para testar o PaddleOCR
try:
    # Caminho da imagem de teste
    image_path = sys.argv[1] if len(sys.argv) > 1 else '/home/ubuntu/actcredit/actcredit/src/tests/test_ocr/test_text.png'
    
    # Verificar se o arquivo existe
    if not os.path.exists(image_path):
        print(json.dumps({"success": False, "error": f"Arquivo não encontrado: {image_path}"}))
        sys.exit(1)
    
    # Inicializar PaddleOCR com configurações básicas
    ocr = PaddleOCR(lang='por')
    
    # Realizar OCR na imagem
    result = ocr.predict(image_path)
    
    # Extrair texto
    extracted_text = ""
    if result:
        for idx in range(len(result)):
            res = result[idx]
            for line in res:
                extracted_text += line[1][0] + "\n"
    
    # Imprimir resultado como JSON
    output = {
        "success": True,
        "text": extracted_text,
        "result_length": len(result) if result else 0
    }
    print(json.dumps(output))
    sys.exit(0)
except Exception as e:
    # Imprimir erro como JSON
    error_output = {
        "success": False,
        "error": str(e)
    }
    print(json.dumps(error_output))
    sys.exit(1)
