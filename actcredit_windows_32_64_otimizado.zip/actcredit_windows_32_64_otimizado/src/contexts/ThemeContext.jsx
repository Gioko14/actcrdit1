import React, { createContext, useContext, useEffect, useState } from 'react';

const ThemeContext = createContext();

export function ThemeProvider({ children }) {
  // Estado para o tema atual
  const [theme, setTheme] = useState(() => {
    // Verificar tema salvo no localStorage
    const savedTheme = localStorage.getItem('actcred-theme');
    
    // Se não houver tema salvo, verificar preferência do sistema
    if (!savedTheme) {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    
    return savedTheme;
  });
  
  // Estado para animação de transição
  const [isTransitioning, setIsTransitioning] = useState(false);

  // Aplicar tema ao documento HTML
  useEffect(() => {
    const root = window.document.documentElement;
    
    // Adicionar classe de transição
    if (!root.classList.contains('theme-transition')) {
      root.classList.add('theme-transition');
    }
    
    // Remover temas anteriores e aplicar o atual
    root.classList.remove('light', 'dark');
    root.classList.add(theme);
    
    // Salvar no localStorage
    localStorage.setItem('actcred-theme', theme);
  }, [theme]);
  
  // Detectar mudanças na preferência do sistema
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    const handleChange = (e) => {
      // Só atualizar automaticamente se o usuário não tiver escolhido manualmente
      const userChoseTheme = localStorage.getItem('user-chose-theme');
      if (!userChoseTheme) {
        setTheme(e.matches ? 'dark' : 'light');
      }
    };
    
    // Adicionar listener para mudanças na preferência do sistema
    mediaQuery.addEventListener('change', handleChange);
    
    // Cleanup
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  // Alternar entre temas com animação
  const toggleTheme = () => {
    setIsTransitioning(true);
    
    // Marcar que o usuário escolheu manualmente
    localStorage.setItem('user-chose-theme', 'true');
    
    // Alternar tema
    setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light');
    
    // Finalizar animação após transição
    setTimeout(() => {
      setIsTransitioning(false);
    }, 500); // Duração da transição CSS
  };
  
  // Resetar para preferência do sistema
  const resetToSystemPreference = () => {
    localStorage.removeItem('user-chose-theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    setTheme(systemPrefersDark ? 'dark' : 'light');
  };

  return (
    <ThemeContext.Provider value={{ 
      theme, 
      setTheme, 
      toggleTheme, 
      isTransitioning,
      resetToSystemPreference
    }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
