/**
 * Serviço de integração com Open Finance e dados alternativos
 * Implementa fluxos de consentimento, consulta e processamento de dados financeiros
 */

import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
import { jwtDecode, jwtVerify } from 'jose';
import { createHash, randomBytes } from 'crypto';

/**
 * Classe para integração com Open Finance
 */
export class OpenFinanceService {
  constructor(config = {}) {
    this.config = {
      apiBaseUrl: config.apiBaseUrl || process.env.OPEN_FINANCE_API_URL || 'https://api.openfinance.org.br',
      clientId: config.clientId || process.env.OPEN_FINANCE_CLIENT_ID,
      clientSecret: config.clientSecret || process.env.OPEN_FINANCE_CLIENT_SECRET,
      redirectUri: config.redirectUri || process.env.OPEN_FINANCE_REDIRECT_URI,
      certificatePath: config.certificatePath || process.env.OPEN_FINANCE_CERT_PATH,
      privateKeyPath: config.privateKeyPath || process.env.OPEN_FINANCE_KEY_PATH,
      scopes: config.scopes || [
        'openid',
        'consent:urn:brasil:openfinance:accounts:v1',
        'consent:urn:brasil:openfinance:credit-cards-accounts:v1',
        'consent:urn:brasil:openfinance:loans:v1',
        'consent:urn:brasil:openfinance:financings:v1',
        'consent:urn:brasil:openfinance:resources:v1'
      ],
      timeout: config.timeout || 30000,
      retryAttempts: config.retryAttempts || 3,
      retryDelay: config.retryDelay || 1000,
      ...config
    };

    // Validar configuração
    this._validateConfig();

    // Inicializar cliente HTTP
    this.httpClient = axios.create({
      baseURL: this.config.apiBaseUrl,
      timeout: this.config.timeout,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    // Adicionar interceptor para retry
    this.httpClient.interceptors.response.use(
      response => response,
      async error => {
        const { config, response } = error;
        
        // Se não for um erro de resposta ou já atingiu o número máximo de tentativas, rejeita
        if (!response || !config || config.retryCount >= this.config.retryAttempts) {
          return Promise.reject(error);
        }
        
        // Incrementar contador de tentativas
        config.retryCount = config.retryCount || 0;
        config.retryCount++;
        
        // Calcular delay com backoff exponencial
        const delay = this.config.retryDelay * Math.pow(2, config.retryCount - 1);
        
        // Aguardar antes de tentar novamente
        await new Promise(resolve => setTimeout(resolve, delay));
        
        // Tentar novamente
        return this.httpClient(config);
      }
    );

    // Cache para tokens
    this.tokenCache = {};
  }

  /**
   * Valida a configuração do serviço
   * @private
   */
  _validateConfig() {
    const requiredFields = ['apiBaseUrl', 'clientId', 'clientSecret', 'redirectUri'];
    const missingFields = requiredFields.filter(field => !this.config[field]);
    
    if (missingFields.length > 0) {
      throw new Error(`Configuração incompleta. Campos obrigatórios ausentes: ${missingFields.join(', ')}`);
    }
  }

  /**
   * Gera um código de desafio PKCE para autenticação
   * @returns {Object} Objeto com code_verifier e code_challenge
   */
  generatePkceChallenge() {
    // Gerar code_verifier
    const codeVerifier = randomBytes(32).toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=/g, '');
    
    // Gerar code_challenge
    const codeChallenge = createHash('sha256')
      .update(codeVerifier)
      .digest('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=/g, '');
    
    return {
      code_verifier: codeVerifier,
      code_challenge: codeChallenge,
      code_challenge_method: 'S256'
    };
  }

  /**
   * Gera URL de autorização para consentimento do usuário
   * @param {Object} options Opções para a URL de autorização
   * @returns {Object} Objeto com URL de autorização e state
   */
  generateAuthorizationUrl(options = {}) {
    const state = options.state || uuidv4();
    const pkce = this.generatePkceChallenge();
    
    // Armazenar PKCE para uso posterior
    this.tokenCache[state] = { pkce };
    
    // Construir URL de autorização
    const authUrl = new URL(`${this.config.apiBaseUrl}/auth/authorize`);
    authUrl.searchParams.append('response_type', 'code');
    authUrl.searchParams.append('client_id', this.config.clientId);
    authUrl.searchParams.append('redirect_uri', this.config.redirectUri);
    authUrl.searchParams.append('scope', this.config.scopes.join(' '));
    authUrl.searchParams.append('state', state);
    authUrl.searchParams.append('code_challenge', pkce.code_challenge);
    authUrl.searchParams.append('code_challenge_method', pkce.code_challenge_method);
    
    return {
      url: authUrl.toString(),
      state
    };
  }

  /**
   * Troca o código de autorização por tokens de acesso
   * @param {string} code Código de autorização
   * @param {string} state State usado na requisição de autorização
   * @returns {Promise<Object>} Tokens de acesso
   */
  async exchangeCodeForTokens(code, state) {
    if (!this.tokenCache[state]) {
      throw new Error('State inválido ou expirado');
    }
    
    const { pkce } = this.tokenCache[state];
    
    try {
      const response = await this.httpClient.post('/auth/token', {
        grant_type: 'authorization_code',
        code,
        redirect_uri: this.config.redirectUri,
        client_id: this.config.clientId,
        client_secret: this.config.clientSecret,
        code_verifier: pkce.code_verifier
      });
      
      const tokens = response.data;
      
      // Armazenar tokens no cache
      this.tokenCache[state] = {
        ...this.tokenCache[state],
        tokens,
        expiresAt: Date.now() + (tokens.expires_in * 1000)
      };
      
      return tokens;
    } catch (error) {
      throw new Error(`Erro ao trocar código por tokens: ${error.message}`);
    } finally {
      // Limpar PKCE do cache
      if (this.tokenCache[state]) {
        delete this.tokenCache[state].pkce;
      }
    }
  }

  /**
   * Atualiza o token de acesso usando o refresh token
   * @param {string} refreshToken Token de atualização
   * @returns {Promise<Object>} Novos tokens de acesso
   */
  async refreshAccessToken(refreshToken) {
    try {
      const response = await this.httpClient.post('/auth/token', {
        grant_type: 'refresh_token',
        refresh_token: refreshToken,
        client_id: this.config.clientId,
        client_secret: this.config.clientSecret
      });
      
      return response.data;
    } catch (error) {
      throw new Error(`Erro ao atualizar token de acesso: ${error.message}`);
    }
  }

  /**
   * Obtém token de acesso válido
   * @param {string} state State associado aos tokens
   * @returns {Promise<string>} Token de acesso válido
   */
  async getAccessToken(state) {
    const cacheEntry = this.tokenCache[state];
    
    if (!cacheEntry || !cacheEntry.tokens) {
      throw new Error('Nenhum token disponível para este state');
    }
    
    // Verificar se o token ainda é válido
    if (cacheEntry.expiresAt > Date.now() + 60000) { // 1 minuto de margem
      return cacheEntry.tokens.access_token;
    }
    
    // Token expirado, atualizar usando refresh token
    if (cacheEntry.tokens.refresh_token) {
      const newTokens = await this.refreshAccessToken(cacheEntry.tokens.refresh_token);
      
      // Atualizar cache
      this.tokenCache[state] = {
        ...cacheEntry,
        tokens: newTokens,
        expiresAt: Date.now() + (newTokens.expires_in * 1000)
      };
      
      return newTokens.access_token;
    }
    
    throw new Error('Token expirado e nenhum refresh token disponível');
  }

  /**
   * Cria um consentimento para acesso aos dados do usuário
   * @param {Object} consentData Dados do consentimento
   * @param {string} state State associado aos tokens
   * @returns {Promise<Object>} Dados do consentimento criado
   */
  async createConsent(consentData, state) {
    try {
      const accessToken = await this.getAccessToken(state);
      
      const response = await this.httpClient.post('/consents/v1/consents', consentData, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      
      return response.data;
    } catch (error) {
      throw new Error(`Erro ao criar consentimento: ${error.message}`);
    }
  }

  /**
   * Obtém detalhes de um consentimento
   * @param {string} consentId ID do consentimento
   * @param {string} state State associado aos tokens
   * @returns {Promise<Object>} Detalhes do consentimento
   */
  async getConsent(consentId, state) {
    try {
      const accessToken = await this.getAccessToken(state);
      
      const response = await this.httpClient.get(`/consents/v1/consents/${consentId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      
      return response.data;
    } catch (error) {
      throw new Error(`Erro ao obter consentimento: ${error.message}`);
    }
  }

  /**
   * Obtém lista de contas do usuário
   * @param {string} consentId ID do consentimento
   * @param {string} state State associado aos tokens
   * @returns {Promise<Object>} Lista de contas
   */
  async getAccounts(consentId, state) {
    try {
      const accessToken = await this.getAccessToken(state);
      
      const response = await this.httpClient.get('/accounts/v1/accounts', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'x-fapi-auth-date': new Date().toISOString(),
          'x-fapi-customer-ip-address': '127.0.0.1',
          'x-fapi-interaction-id': uuidv4(),
          'x-customer-user-agent': 'ActCredit/1.0',
          'x-consent-id': consentId
        }
      });
      
      return response.data;
    } catch (error) {
      throw new Error(`Erro ao obter contas: ${error.message}`);
    }
  }

  /**
   * Obtém transações de uma conta
   * @param {string} accountId ID da conta
   * @param {string} consentId ID do consentimento
   * @param {string} state State associado aos tokens
   * @param {Object} params Parâmetros adicionais (fromBookingDate, toBookingDate, etc.)
   * @returns {Promise<Object>} Lista de transações
   */
  async getAccountTransactions(accountId, consentId, state, params = {}) {
    try {
      const accessToken = await this.getAccessToken(state);
      
      const response = await this.httpClient.get(`/accounts/v1/accounts/${accountId}/transactions`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'x-fapi-auth-date': new Date().toISOString(),
          'x-fapi-customer-ip-address': '127.0.0.1',
          'x-fapi-interaction-id': uuidv4(),
          'x-customer-user-agent': 'ActCredit/1.0',
          'x-consent-id': consentId
        },
        params
      });
      
      return response.data;
    } catch (error) {
      throw new Error(`Erro ao obter transações: ${error.message}`);
    }
  }

  /**
   * Obtém cartões de crédito do usuário
   * @param {string} consentId ID do consentimento
   * @param {string} state State associado aos tokens
   * @returns {Promise<Object>} Lista de cartões de crédito
   */
  async getCreditCards(consentId, state) {
    try {
      const accessToken = await this.getAccessToken(state);
      
      const response = await this.httpClient.get('/credit-cards-accounts/v1/accounts', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'x-fapi-auth-date': new Date().toISOString(),
          'x-fapi-customer-ip-address': '127.0.0.1',
          'x-fapi-interaction-id': uuidv4(),
          'x-customer-user-agent': 'ActCredit/1.0',
          'x-consent-id': consentId
        }
      });
      
      return response.data;
    } catch (error) {
      throw new Error(`Erro ao obter cartões de crédito: ${error.message}`);
    }
  }

  /**
   * Obtém transações de cartão de crédito
   * @param {string} creditCardAccountId ID da conta de cartão de crédito
   * @param {string} consentId ID do consentimento
   * @param {string} state State associado aos tokens
   * @param {Object} params Parâmetros adicionais (fromTransactionDate, toTransactionDate, etc.)
   * @returns {Promise<Object>} Lista de transações de cartão de crédito
   */
  async getCreditCardTransactions(creditCardAccountId, consentId, state, params = {}) {
    try {
      const accessToken = await this.getAccessToken(state);
      
      const response = await this.httpClient.get(`/credit-cards-accounts/v1/accounts/${creditCardAccountId}/transactions`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'x-fapi-auth-date': new Date().toISOString(),
          'x-fapi-customer-ip-address': '127.0.0.1',
          'x-fapi-interaction-id': uuidv4(),
          'x-customer-user-agent': 'ActCredit/1.0',
          'x-consent-id': consentId
        },
        params
      });
      
      return response.data;
    } catch (error) {
      throw new Error(`Erro ao obter transações de cartão de crédito: ${error.message}`);
    }
  }

  /**
   * Obtém empréstimos do usuário
   * @param {string} consentId ID do consentimento
   * @param {string} state State associado aos tokens
   * @returns {Promise<Object>} Lista de empréstimos
   */
  async getLoans(consentId, state) {
    try {
      const accessToken = await this.getAccessToken(state);
      
      const response = await this.httpClient.get('/loans/v1/contracts', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'x-fapi-auth-date': new Date().toISOString(),
          'x-fapi-customer-ip-address': '127.0.0.1',
          'x-fapi-interaction-id': uuidv4(),
          'x-customer-user-agent': 'ActCredit/1.0',
          'x-consent-id': consentId
        }
      });
      
      return response.data;
    } catch (error) {
      throw new Error(`Erro ao obter empréstimos: ${error.message}`);
    }
  }

  /**
   * Obtém financiamentos do usuário
   * @param {string} consentId ID do consentimento
   * @param {string} state State associado aos tokens
   * @returns {Promise<Object>} Lista de financiamentos
   */
  async getFinancings(consentId, state) {
    try {
      const accessToken = await this.getAccessToken(state);
      
      const response = await this.httpClient.get('/financings/v1/contracts', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'x-fapi-auth-date': new Date().toISOString(),
          'x-fapi-customer-ip-address': '127.0.0.1',
          'x-fapi-interaction-id': uuidv4(),
          'x-customer-user-agent': 'ActCredit/1.0',
          'x-consent-id': consentId
        }
      });
      
      return response.data;
    } catch (error) {
      throw new Error(`Erro ao obter financiamentos: ${error.message}`);
    }
  }

  /**
   * Revoga um consentimento
   * @param {string} consentId ID do consentimento
   * @param {string} state State associado aos tokens
   * @returns {Promise<void>}
   */
  async revokeConsent(consentId, state) {
    try {
      const accessToken = await this.getAccessToken(state);
      
      await this.httpClient.delete(`/consents/v1/consents/${consentId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
    } catch (error) {
      throw new Error(`Erro ao revogar consentimento: ${error.message}`);
    }
  }

  /**
   * Processa e agrega dados financeiros do usuário
   * @param {string} consentId ID do consentimento
   * @param {string} state State associado aos tokens
   * @returns {Promise<Object>} Dados financeiros agregados
   */
  async processFinancialData(consentId, state) {
    try {
      // Obter dados de diferentes fontes
      const [accounts, creditCards, loans, financings] = await Promise.all([
        this.getAccounts(consentId, state).catch(e => ({ data: [] })),
        this.getCreditCards(consentId, state).catch(e => ({ data: [] })),
        this.getLoans(consentId, state).catch(e => ({ data: [] })),
        this.getFinancings(consentId, state).catch(e => ({ data: [] }))
      ]);
      
      // Processar e agregar dados
      const financialSummary = {
        totalBalance: 0,
        totalCreditLimit: 0,
        totalDebt: 0,
        accounts: accounts.data || [],
        creditCards: creditCards.data || [],
        loans: loans.data || [],
        financings: financings.data || [],
        metrics: {
          accountActivity: 0,
          creditUtilization: 0,
          debtToIncome: 0,
          paymentHistory: 0
        }
      };
      
      // Calcular saldo total
      if (accounts.data && accounts.data.length > 0) {
        accounts.data.forEach(account => {
          if (account.availableAmount) {
            financialSummary.totalBalance += parseFloat(account.availableAmount.amount);
          }
        });
      }
      
      // Calcular limite total de crédito
      if (creditCards.data && creditCards.data.length > 0) {
        creditCards.data.forEach(card => {
          if (card.limits && card.limits.total) {
            financialSummary.totalCreditLimit += parseFloat(card.limits.total.amount);
          }
        });
      }
      
      // Calcular dívida total
      if (loans.data && loans.data.length > 0) {
        loans.data.forEach(loan => {
          if (loan.contractAmount) {
            financialSummary.totalDebt += parseFloat(loan.contractAmount.amount);
          }
        });
      }
      
      if (financings.data && financings.data.length > 0) {
        financings.data.forEach(financing => {
          if (financing.contractAmount) {
            financialSummary.totalDebt += parseFloat(financing.contractAmount.amount);
          }
        });
      }
      
      // Calcular métricas
      // Utilização de crédito
      if (financialSummary.totalCreditLimit > 0) {
        const usedCredit = creditCards.data.reduce((total, card) => {
          if (card.balances && card.balances.available) {
            const limit = parseFloat(card.limits.total.amount);
            const available = parseFloat(card.balances.available.amount);
            return total + (limit - available);
          }
          return total;
        }, 0);
        
        financialSummary.metrics.creditUtilization = usedCredit / financialSummary.totalCreditLimit;
      }
      
      // Relação dívida/renda (estimativa)
      const estimatedMonthlyIncome = 5000; // Valor fictício, deve ser obtido de outra fonte
      const estimatedMonthlyDebt = financialSummary.totalDebt * 0.03; // Estimativa simplificada
      
      financialSummary.metrics.debtToIncome = estimatedMonthlyDebt / estimatedMonthlyIncome;
      
      // Atividade da conta (baseada em transações)
      // Implementação simplificada, deve ser expandida com dados reais
      financialSummary.metrics.accountActivity = 0.7;
      
      // Histórico de pagamentos (baseado em empréstimos)
      // Implementação simplificada, deve ser expandida com dados reais
      financialSummary.metrics.paymentHistory = 0.9;
      
      return financialSummary;
    } catch (error) {
      throw new Error(`Erro ao processar dados financeiros: ${error.message}`);
    }
  }

  /**
   * Gera um score de crédito baseado em dados do Open Finance
   * @param {Object} financialData Dados financeiros agregados
   * @returns {Object} Score de crédito e fatores
   */
  generateCreditScore(financialData) {
    // Pesos para cada métrica
    const weights = {
      accountActivity: 0.2,
      creditUtilization: 0.3,
      debtToIncome: 0.3,
      paymentHistory: 0.2
    };
    
    // Calcular score (escala de 0 a 1000)
    let score = 0;
    
    // Atividade da conta (maior é melhor)
    score += financialData.metrics.accountActivity * weights.accountActivity * 1000;
    
    // Utilização de crédito (menor é melhor)
    score += (1 - Math.min(financialData.metrics.creditUtilization, 1)) * weights.creditUtilization * 1000;
    
    // Relação dívida/renda (menor é melhor)
    score += (1 - Math.min(financialData.metrics.debtToIncome, 1)) * weights.debtToIncome * 1000;
    
    // Histórico de pagamentos (maior é melhor)
    score += financialData.metrics.paymentHistory * weights.paymentHistory * 1000;
    
    // Arredondar score
    score = Math.round(score);
    
    // Determinar faixa de risco
    let riskBand;
    if (score >= 800) {
      riskBand = 'Muito Baixo';
    } else if (score >= 600) {
      riskBand = 'Baixo';
    } else if (score >= 400) {
      riskBand = 'Médio';
    } else if (score >= 200) {
      riskBand = 'Alto';
    } else {
      riskBand = 'Muito Alto';
    }
    
    // Identificar fatores positivos e negativos
    const positiveFactors = [];
    const negativeFactors = [];
    
    if (financialData.metrics.accountActivity >= 0.7) {
      positiveFactors.push('Alta atividade nas contas');
    } else if (financialData.metrics.accountActivity < 0.3) {
      negativeFactors.push('Baixa atividade nas contas');
    }
    
    if (financialData.metrics.creditUtilization <= 0.3) {
      positiveFactors.push('Baixa utilização de crédito');
    } else if (financialData.metrics.creditUtilization > 0.7) {
      negativeFactors.push('Alta utilização de crédito');
    }
    
    if (financialData.metrics.debtToIncome <= 0.3) {
      positiveFactors.push('Baixa relação dívida/renda');
    } else if (financialData.metrics.debtToIncome > 0.5) {
      negativeFactors.push('Alta relação dívida/renda');
    }
    
    if (financialData.metrics.paymentHistory >= 0.9) {
      positiveFactors.push('Excelente histórico de pagamentos');
    } else if (financialData.metrics.paymentHistory < 0.7) {
      negativeFactors.push('Histórico de pagamentos abaixo do ideal');
    }
    
    return {
      score,
      riskBand,
      positiveFactors,
      negativeFactors,
      metrics: financialData.metrics
    };
  }
}

/**
 * Classe para integração com fontes de dados alternativas
 */
export class AlternativeDataService {
  constructor(config = {}) {
    this.config = {
      apiKeys: {
        serasa: config.serasaApiKey || process.env.SERASA_API_KEY,
        boaVista: config.boaVistaApiKey || process.env.BOA_VISTA_API_KEY,
        quod: config.quodApiKey || process.env.QUOD_API_KEY,
        receita: config.receitaApiKey || process.env.RECEITA_API_KEY,
        cepAberto: config.cepAbertoApiKey || process.env.CEP_ABERTO_API_KEY,
        googleMaps: config.googleMapsApiKey || process.env.GOOGLE_MAPS_API_KEY
      },
      timeout: config.timeout || 30000,
      retryAttempts: config.retryAttempts || 3,
      retryDelay: config.retryDelay || 1000,
      ...config
    };

    // Inicializar clientes HTTP
    this.httpClients = {
      serasa: axios.create({
        baseURL: 'https://api.serasa.com.br',
        timeout: this.config.timeout,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${this.config.apiKeys.serasa}`
        }
      }),
      boaVista: axios.create({
        baseURL: 'https://api.boavista.com.br',
        timeout: this.config.timeout,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${this.config.apiKeys.boaVista}`
        }
      }),
      quod: axios.create({
        baseURL: 'https://api.quod.com.br',
        timeout: this.config.timeout,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${this.config.apiKeys.quod}`
        }
      }),
      receita: axios.create({
        baseURL: 'https://api.receitaws.com.br',
        timeout: this.config.timeout,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      }),
      cepAberto: axios.create({
        baseURL: 'https://www.cepaberto.com/api/v3',
        timeout: this.config.timeout,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Token token=${this.config.apiKeys.cepAberto}`
        }
      }),
      googleMaps: axios.create({
        baseURL: 'https://maps.googleapis.com/maps/api',
        timeout: this.config.timeout,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      }),
      brasilApi: axios.create({
        baseURL: 'https://brasilapi.com.br/api',
        timeout: this.config.timeout,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      })
    };
  }

  /**
   * Consulta CPF na Receita Federal (simulado)
   * @param {string} cpf CPF a ser consultado
   * @returns {Promise<Object>} Dados do CPF
   */
  async consultCpf(cpf) {
    try {
      // Simulação - em produção, usaria API real
      return {
        cpf: cpf.replace(/\D/g, ''),
        nome: 'Nome Simulado',
        dataNascimento: '1980-01-01',
        situacaoCadastral: 'Regular',
        dataInscricao: '2000-01-01',
        digitoVerificador: cpf.slice(-2)
      };
    } catch (error) {
      throw new Error(`Erro ao consultar CPF: ${error.message}`);
    }
  }

  /**
   * Consulta CNPJ na Receita Federal
   * @param {string} cnpj CNPJ a ser consultado
   * @returns {Promise<Object>} Dados do CNPJ
   */
  async consultCnpj(cnpj) {
    try {
      // Usar Brasil API (gratuita) para consulta de CNPJ
      const response = await this.httpClients.brasilApi.get(`/cnpj/v1/${cnpj.replace(/\D/g, '')}`);
      return response.data;
    } catch (error) {
      throw new Error(`Erro ao consultar CNPJ: ${error.message}`);
    }
  }

  /**
   * Consulta CEP
   * @param {string} cep CEP a ser consultado
   * @returns {Promise<Object>} Dados do CEP
   */
  async consultCep(cep) {
    try {
      // Usar Brasil API (gratuita) para consulta de CEP
      const response = await this.httpClients.brasilApi.get(`/cep/v2/${cep.replace(/\D/g, '')}`);
      return response.data;
    } catch (error) {
      throw new Error(`Erro ao consultar CEP: ${error.message}`);
    }
  }

  /**
   * Consulta score de crédito no Serasa (simulado)
   * @param {string} cpfCnpj CPF ou CNPJ a ser consultado
   * @returns {Promise<Object>} Score de crédito
   */
  async consultCreditScore(cpfCnpj) {
    try {
      // Simulação - em produção, usaria API real
      const document = cpfCnpj.replace(/\D/g, '');
      const isPerson = document.length <= 11;
      
      // Gerar score aleatório entre 0 e 1000
      const score = Math.floor(Math.random() * 1000);
      
      // Determinar faixa de risco
      let riskBand;
      if (score >= 800) {
        riskBand = 'Muito Baixo';
      } else if (score >= 600) {
        riskBand = 'Baixo';
      } else if (score >= 400) {
        riskBand = 'Médio';
      } else if (score >= 200) {
        riskBand = 'Alto';
      } else {
        riskBand = 'Muito Alto';
      }
      
      return {
        document,
        score,
        riskBand,
        type: isPerson ? 'PF' : 'PJ',
        source: 'Serasa',
        consultDate: new Date().toISOString()
      };
    } catch (error) {
      throw new Error(`Erro ao consultar score de crédito: ${error.message}`);
    }
  }

  /**
   * Consulta restrições financeiras (simulado)
   * @param {string} cpfCnpj CPF ou CNPJ a ser consultado
   * @returns {Promise<Object>} Restrições financeiras
   */
  async consultRestrictions(cpfCnpj) {
    try {
      // Simulação - em produção, usaria API real
      const document = cpfCnpj.replace(/\D/g, '');
      const isPerson = document.length <= 11;
      
      // Gerar número aleatório de restrições (0 a 5)
      const restrictionsCount = Math.floor(Math.random() * 6);
      
      const restrictions = [];
      for (let i = 0; i < restrictionsCount; i++) {
        restrictions.push({
          type: ['Protesto', 'Cheque sem Fundos', 'Dívida Vencida', 'Ação Judicial', 'Negativação'][Math.floor(Math.random() * 5)],
          value: Math.floor(Math.random() * 10000) + 100,
          date: new Date(Date.now() - Math.floor(Math.random() * 365 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0],
          creditor: `Credor ${i + 1}`
        });
      }
      
      return {
        document,
        hasRestrictions: restrictionsCount > 0,
        restrictionsCount,
        restrictions,
        type: isPerson ? 'PF' : 'PJ',
        source: 'Serasa',
        consultDate: new Date().toISOString()
      };
    } catch (error) {
      throw new Error(`Erro ao consultar restrições: ${error.message}`);
    }
  }

  /**
   * Consulta histórico de crédito (simulado)
   * @param {string} cpfCnpj CPF ou CNPJ a ser consultado
   * @returns {Promise<Object>} Histórico de crédito
   */
  async consultCreditHistory(cpfCnpj) {
    try {
      // Simulação - em produção, usaria API real
      const document = cpfCnpj.replace(/\D/g, '');
      const isPerson = document.length <= 11;
      
      // Gerar número aleatório de consultas (1 a 10)
      const queriesCount = Math.floor(Math.random() * 10) + 1;
      
      const queries = [];
      for (let i = 0; i < queriesCount; i++) {
        queries.push({
          date: new Date(Date.now() - Math.floor(Math.random() * 365 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0],
          institution: `Instituição ${i + 1}`,
          segment: ['Banco', 'Financeira', 'Varejo', 'Telecomunicações', 'Serviços'][Math.floor(Math.random() * 5)]
        });
      }
      
      // Gerar número aleatório de operações de crédito (0 a 5)
      const operationsCount = Math.floor(Math.random() * 6);
      
      const operations = [];
      for (let i = 0; i < operationsCount; i++) {
        operations.push({
          type: ['Empréstimo Pessoal', 'Financiamento', 'Cartão de Crédito', 'Cheque Especial', 'Crédito Consignado'][Math.floor(Math.random() * 5)],
          institution: `Instituição ${i + 1}`,
          startDate: new Date(Date.now() - Math.floor(Math.random() * 365 * 2 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0],
          value: Math.floor(Math.random() * 50000) + 1000,
          installments: Math.floor(Math.random() * 36) + 6,
          status: ['Em Dia', 'Atrasado', 'Quitado'][Math.floor(Math.random() * 3)]
        });
      }
      
      return {
        document,
        queries,
        queriesCount,
        operations,
        operationsCount,
        type: isPerson ? 'PF' : 'PJ',
        source: 'Serasa',
        consultDate: new Date().toISOString()
      };
    } catch (error) {
      throw new Error(`Erro ao consultar histórico de crédito: ${error.message}`);
    }
  }

  /**
   * Consulta dados socioeconômicos por CEP (simulado)
   * @param {string} cep CEP a ser consultado
   * @returns {Promise<Object>} Dados socioeconômicos
   */
  async consultSocioeconomicData(cep) {
    try {
      // Primeiro, obter dados do CEP
      const cepData = await this.consultCep(cep);
      
      // Simulação de dados socioeconômicos
      return {
        cep: cep.replace(/\D/g, ''),
        region: {
          city: cepData.city || 'Cidade Simulada',
          state: cepData.state || 'UF',
          neighborhood: cepData.neighborhood || 'Bairro Simulado'
        },
        socioeconomic: {
          averageIncome: Math.floor(Math.random() * 10000) + 1000,
          populationDensity: Math.floor(Math.random() * 10000) + 100,
          urbanDevelopmentIndex: (Math.random() * 0.5 + 0.5).toFixed(2),
          economicActivityIndex: (Math.random() * 0.5 + 0.5).toFixed(2),
          defaultRate: (Math.random() * 0.2).toFixed(2)
        },
        source: 'Dados Simulados',
        consultDate: new Date().toISOString()
      };
    } catch (error) {
      throw new Error(`Erro ao consultar dados socioeconômicos: ${error.message}`);
    }
  }

  /**
   * Agrega dados de múltiplas fontes para enriquecer análise de crédito
   * @param {Object} baseData Dados base do cliente (CPF/CNPJ, CEP, etc.)
   * @returns {Promise<Object>} Dados agregados
   */
  async aggregateData(baseData) {
    try {
      const tasks = [];
      const results = {};
      
      // Consultar CPF/CNPJ
      if (baseData.cpfCnpj) {
        const document = baseData.cpfCnpj.replace(/\D/g, '');
        const isPerson = document.length <= 11;
        
        if (isPerson) {
          tasks.push(
            this.consultCpf(document)
              .then(data => { results.cpfData = data; })
              .catch(error => { results.cpfData = { error: error.message }; })
          );
        } else {
          tasks.push(
            this.consultCnpj(document)
              .then(data => { results.cnpjData = data; })
              .catch(error => { results.cnpjData = { error: error.message }; })
          );
        }
        
        // Consultar score de crédito
        tasks.push(
          this.consultCreditScore(document)
            .then(data => { results.creditScore = data; })
            .catch(error => { results.creditScore = { error: error.message }; })
        );
        
        // Consultar restrições
        tasks.push(
          this.consultRestrictions(document)
            .then(data => { results.restrictions = data; })
            .catch(error => { results.restrictions = { error: error.message }; })
        );
        
        // Consultar histórico de crédito
        tasks.push(
          this.consultCreditHistory(document)
            .then(data => { results.creditHistory = data; })
            .catch(error => { results.creditHistory = { error: error.message }; })
        );
      }
      
      // Consultar CEP
      if (baseData.cep) {
        tasks.push(
          this.consultCep(baseData.cep)
            .then(data => { results.cepData = data; })
            .catch(error => { results.cepData = { error: error.message }; })
        );
        
        // Consultar dados socioeconômicos
        tasks.push(
          this.consultSocioeconomicData(baseData.cep)
            .then(data => { results.socioeconomicData = data; })
            .catch(error => { results.socioeconomicData = { error: error.message }; })
        );
      }
      
      // Aguardar todas as consultas
      await Promise.all(tasks);
      
      // Processar e agregar dados
      const aggregatedData = {
        document: baseData.cpfCnpj ? baseData.cpfCnpj.replace(/\D/g, '') : null,
        documentType: baseData.cpfCnpj && baseData.cpfCnpj.replace(/\D/g, '').length <= 11 ? 'CPF' : 'CNPJ',
        name: results.cpfData?.nome || results.cnpjData?.nome || baseData.name || null,
        address: {
          cep: baseData.cep || null,
          street: results.cepData?.street || baseData.street || null,
          number: baseData.number || null,
          complement: baseData.complement || null,
          neighborhood: results.cepData?.neighborhood || baseData.neighborhood || null,
          city: results.cepData?.city || baseData.city || null,
          state: results.cepData?.state || baseData.state || null
        },
        creditAnalysis: {
          score: results.creditScore?.score || null,
          riskBand: results.creditScore?.riskBand || null,
          hasRestrictions: results.restrictions?.hasRestrictions || false,
          restrictionsCount: results.restrictions?.restrictionsCount || 0,
          restrictions: results.restrictions?.restrictions || [],
          queriesCount: results.creditHistory?.queriesCount || 0,
          operationsCount: results.creditHistory?.operationsCount || 0,
          operations: results.creditHistory?.operations || []
        },
        socioeconomic: results.socioeconomicData?.socioeconomic || null,
        rawData: {
          cpfData: results.cpfData || null,
          cnpjData: results.cnpjData || null,
          cepData: results.cepData || null,
          creditScore: results.creditScore || null,
          restrictions: results.restrictions || null,
          creditHistory: results.creditHistory || null,
          socioeconomicData: results.socioeconomicData || null
        }
      };
      
      return aggregatedData;
    } catch (error) {
      throw new Error(`Erro ao agregar dados: ${error.message}`);
    }
  }
}

/**
 * Classe para integração de dados do Open Finance com fontes alternativas
 */
export class DataIntegrationService {
  constructor(config = {}) {
    this.openFinanceService = new OpenFinanceService(config.openFinance);
    this.alternativeDataService = new AlternativeDataService(config.alternativeData);
  }

  /**
   * Inicia fluxo de consentimento do Open Finance
   * @param {Object} options Opções para o fluxo de consentimento
   * @returns {Promise<Object>} URL de autorização e state
   */
  async startConsentFlow(options = {}) {
    return this.openFinanceService.generateAuthorizationUrl(options);
  }

  /**
   * Processa callback do fluxo de consentimento
   * @param {string} code Código de autorização
   * @param {string} state State usado na requisição de autorização
   * @returns {Promise<Object>} Tokens de acesso
   */
  async processConsentCallback(code, state) {
    return this.openFinanceService.exchangeCodeForTokens(code, state);
  }

  /**
   * Cria consentimento para acesso aos dados do usuário
   * @param {Object} consentData Dados do consentimento
   * @param {string} state State associado aos tokens
   * @returns {Promise<Object>} Dados do consentimento criado
   */
  async createConsent(consentData, state) {
    return this.openFinanceService.createConsent(consentData, state);
  }

  /**
   * Obtém e processa dados financeiros do Open Finance
   * @param {string} consentId ID do consentimento
   * @param {string} state State associado aos tokens
   * @returns {Promise<Object>} Dados financeiros processados
   */
  async getFinancialData(consentId, state) {
    return this.openFinanceService.processFinancialData(consentId, state);
  }

  /**
   * Obtém dados alternativos para enriquecer análise
   * @param {Object} baseData Dados base do cliente
   * @returns {Promise<Object>} Dados alternativos agregados
   */
  async getAlternativeData(baseData) {
    return this.alternativeDataService.aggregateData(baseData);
  }

  /**
   * Integra dados do Open Finance com fontes alternativas
   * @param {Object} financialData Dados do Open Finance
   * @param {Object} alternativeData Dados de fontes alternativas
   * @returns {Object} Dados integrados
   */
  integrateData(financialData, alternativeData) {
    // Integrar dados de diferentes fontes
    const integratedData = {
      document: alternativeData.document,
      documentType: alternativeData.documentType,
      name: alternativeData.name,
      address: alternativeData.address,
      financial: {
        accounts: financialData.accounts || [],
        creditCards: financialData.creditCards || [],
        loans: financialData.loans || [],
        financings: financialData.financings || [],
        totalBalance: financialData.totalBalance || 0,
        totalCreditLimit: financialData.totalCreditLimit || 0,
        totalDebt: financialData.totalDebt || 0
      },
      creditAnalysis: {
        openFinanceScore: this.openFinanceService.generateCreditScore(financialData),
        bureauScore: alternativeData.creditAnalysis.score,
        bureauRiskBand: alternativeData.creditAnalysis.riskBand,
        hasRestrictions: alternativeData.creditAnalysis.hasRestrictions,
        restrictionsCount: alternativeData.creditAnalysis.restrictionsCount,
        restrictions: alternativeData.creditAnalysis.restrictions,
        creditOperations: alternativeData.creditAnalysis.operations || []
      },
      socioeconomic: alternativeData.socioeconomic,
      metrics: {
        ...financialData.metrics,
        bureauScore: alternativeData.creditAnalysis.score ? alternativeData.creditAnalysis.score / 1000 : null,
        restrictionsFactor: alternativeData.creditAnalysis.hasRestrictions ? 0 : 1,
        socioeconomicFactor: alternativeData.socioeconomic ? 
          (parseFloat(alternativeData.socioeconomic.urbanDevelopmentIndex) + 
           parseFloat(alternativeData.socioeconomic.economicActivityIndex)) / 2 : null
      }
    };
    
    // Calcular score integrado
    integratedData.creditAnalysis.integratedScore = this.calculateIntegratedScore(integratedData);
    
    return integratedData;
  }

  /**
   * Calcula score integrado com base em múltiplas fontes
   * @param {Object} integratedData Dados integrados
   * @returns {Object} Score integrado e fatores
   */
  calculateIntegratedScore(integratedData) {
    // Pesos para cada fonte de dados
    const weights = {
      openFinanceScore: 0.4,
      bureauScore: 0.3,
      restrictionsFactor: 0.2,
      socioeconomicFactor: 0.1
    };
    
    // Normalizar scores para escala 0-1
    const normalizedScores = {
      openFinanceScore: integratedData.creditAnalysis.openFinanceScore ? 
        integratedData.creditAnalysis.openFinanceScore.score / 1000 : 0.5,
      bureauScore: integratedData.creditAnalysis.bureauScore ? 
        integratedData.creditAnalysis.bureauScore / 1000 : 0.5,
      restrictionsFactor: integratedData.metrics.restrictionsFactor || 0.5,
      socioeconomicFactor: integratedData.metrics.socioeconomicFactor || 0.5
    };
    
    // Calcular score ponderado
    let weightedScore = 0;
    let totalWeight = 0;
    
    for (const [key, weight] of Object.entries(weights)) {
      if (normalizedScores[key] !== null && normalizedScores[key] !== undefined) {
        weightedScore += normalizedScores[key] * weight;
        totalWeight += weight;
      }
    }
    
    // Ajustar para peso total
    if (totalWeight > 0) {
      weightedScore = weightedScore / totalWeight;
    }
    
    // Converter para escala 0-1000
    const score = Math.round(weightedScore * 1000);
    
    // Determinar faixa de risco
    let riskBand;
    if (score >= 800) {
      riskBand = 'Muito Baixo';
    } else if (score >= 600) {
      riskBand = 'Baixo';
    } else if (score >= 400) {
      riskBand = 'Médio';
    } else if (score >= 200) {
      riskBand = 'Alto';
    } else {
      riskBand = 'Muito Alto';
    }
    
    // Identificar fatores positivos e negativos
    const positiveFactors = [];
    const negativeFactors = [];
    
    // Fatores do Open Finance
    if (integratedData.creditAnalysis.openFinanceScore) {
      positiveFactors.push(...integratedData.creditAnalysis.openFinanceScore.positiveFactors);
      negativeFactors.push(...integratedData.creditAnalysis.openFinanceScore.negativeFactors);
    }
    
    // Fator de restrições
    if (integratedData.creditAnalysis.hasRestrictions) {
      negativeFactors.push(`${integratedData.creditAnalysis.restrictionsCount} restrições financeiras identificadas`);
    } else {
      positiveFactors.push('Sem restrições financeiras');
    }
    
    // Fator socioeconômico
    if (integratedData.metrics.socioeconomicFactor > 0.7) {
      positiveFactors.push('Região com bons indicadores socioeconômicos');
    } else if (integratedData.metrics.socioeconomicFactor < 0.3) {
      negativeFactors.push('Região com indicadores socioeconômicos abaixo da média');
    }
    
    return {
      score,
      riskBand,
      positiveFactors,
      negativeFactors,
      weights,
      normalizedScores
    };
  }

  /**
   * Gera recomendação de crédito com base nos dados integrados
   * @param {Object} integratedData Dados integrados
   * @param {Object} creditRequest Dados da solicitação de crédito
   * @returns {Object} Recomendação de crédito
   */
  generateCreditRecommendation(integratedData, creditRequest) {
    const { score } = integratedData.creditAnalysis.integratedScore;
    const { totalBalance, totalCreditLimit, totalDebt } = integratedData.financial;
    
    // Calcular capacidade de pagamento estimada
    const estimatedMonthlyIncome = creditRequest.declaredIncome || 5000; // Valor padrão se não informado
    const estimatedMonthlyDebt = totalDebt * 0.03; // Estimativa simplificada
    const availableIncome = Math.max(0, estimatedMonthlyIncome * 0.3 - estimatedMonthlyDebt);
    
    // Definir limites com base no score
    let approvalStatus;
    let maxAmount;
    let maxInstallments;
    let interestRate;
    
    if (score >= 800) {
      approvalStatus = 'Aprovado';
      maxAmount = Math.min(availableIncome * 36, creditRequest.requestedAmount * 1.2);
      maxInstallments = 36;
      interestRate = 0.015; // 1.5% ao mês
    } else if (score >= 600) {
      approvalStatus = 'Aprovado';
      maxAmount = Math.min(availableIncome * 24, creditRequest.requestedAmount);
      maxInstallments = 24;
      interestRate = 0.025; // 2.5% ao mês
    } else if (score >= 400) {
      approvalStatus = 'Aprovado com Restrições';
      maxAmount = Math.min(availableIncome * 12, creditRequest.requestedAmount * 0.8);
      maxInstallments = 12;
      interestRate = 0.035; // 3.5% ao mês
    } else if (score >= 200) {
      approvalStatus = 'Pendente de Análise Manual';
      maxAmount = Math.min(availableIncome * 6, creditRequest.requestedAmount * 0.5);
      maxInstallments = 6;
      interestRate = 0.045; // 4.5% ao mês
    } else {
      approvalStatus = 'Reprovado';
      maxAmount = 0;
      maxInstallments = 0;
      interestRate = 0;
    }
    
    // Verificar restrições
    if (integratedData.creditAnalysis.hasRestrictions && integratedData.creditAnalysis.restrictionsCount > 2) {
      approvalStatus = 'Reprovado';
      maxAmount = 0;
      maxInstallments = 0;
      interestRate = 0;
    }
    
    // Calcular valor da parcela
    let installmentValue = 0;
    if (maxAmount > 0 && maxInstallments > 0) {
      // Fórmula de prestação para juros compostos
      installmentValue = (maxAmount * interestRate * Math.pow(1 + interestRate, maxInstallments)) / 
                         (Math.pow(1 + interestRate, maxInstallments) - 1);
    }
    
    return {
      approvalStatus,
      maxAmount,
      maxInstallments,
      interestRate,
      installmentValue,
      availableIncome,
      estimatedMonthlyDebt,
      requestedAmount: creditRequest.requestedAmount,
      requestedInstallments: creditRequest.requestedInstallments,
      score,
      riskBand: integratedData.creditAnalysis.integratedScore.riskBand,
      positiveFactors: integratedData.creditAnalysis.integratedScore.positiveFactors,
      negativeFactors: integratedData.creditAnalysis.integratedScore.negativeFactors,
      analysisDate: new Date().toISOString()
    };
  }
}

export default {
  OpenFinanceService,
  AlternativeDataService,
  DataIntegrationService
};
