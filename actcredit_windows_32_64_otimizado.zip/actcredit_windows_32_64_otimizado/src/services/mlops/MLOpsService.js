/**
 * Serviço de MLOps e Monitoramento de Modelos
 * Implementa funcionalidades para gerenciar o ciclo de vida de modelos,
 * monitorar desempenho, detectar drift e automatizar retreinamento.
 */

import { v4 as uuidv4 } from 'uuid';
import { cloneDeep, get, set, merge } from 'lodash';

// Simulação de um registro de modelos (ex: MLflow, SageMaker Model Registry)
const modelRegistry = new Map();

// Simulação de um sistema de monitoramento (ex: Prometheus, Grafana, WhyLabs)
const monitoringData = new Map();

/**
 * Classe para Gerenciamento do Ciclo de Vida de Modelos (MLOps)
 */
export class MLOpsManager {
  constructor(config = {}) {
    this.config = {
      storageMethod: config.storageMethod || 'memory', // 'memory', 'database'
      defaultMonitoringInterval: config.defaultMonitoringInterval || 'daily', // 'hourly', 'daily', 'weekly'
      driftDetectionThreshold: config.driftDetectionThreshold || 0.1, // 10% de drift
      performanceDegradationThreshold: config.performanceDegradationThreshold || 0.05, // 5% de queda
      autoRetrainEnabled: config.autoRetrainEnabled !== undefined ? config.autoRetrainEnabled : true,
      autoDeployEnabled: config.autoDeployEnabled !== undefined ? config.autoDeployEnabled : false,
      minDataForRetrain: config.minDataForRetrain || 1000,
      deploymentStrategy: config.deploymentStrategy || 'shadow', // 'direct', 'shadow', 'blue_green', 'canary'
      canaryTrafficPercentage: config.canaryTrafficPercentage || 0.1, // 10% para canary
      ...config
    };

    // Armazenamento de modelos registrados
    this.registeredModels = modelRegistry;
    
    // Armazenamento de versões de modelos
    this.modelVersions = new Map();
    
    // Armazenamento de configurações de monitoramento
    this.monitoringConfigs = new Map();
    
    // Armazenamento de dados de monitoramento
    this.monitoringData = monitoringData;
    
    // Armazenamento de alertas
    this.alerts = new Map();
    
    // Armazenamento de jobs de retreinamento
    this.retrainJobs = new Map();
    
    // Armazenamento de status de implantação
    this.deployments = new Map();
  }

  /**
   * Registra um novo modelo
   * @param {Object} modelData Dados do modelo
   * @returns {Promise<Object>} Modelo registrado
   */
  async registerModel(modelData) {
    const modelId = modelData.id || uuidv4();
    
    const model = {
      id: modelId,
      name: modelData.name,
      description: modelData.description || '',
      task: modelData.task, // 'classification', 'regression', 'clustering'
      tags: modelData.tags || [],
      owner: modelData.owner,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      metadata: modelData.metadata || {}
    };
    
    // Validar modelo
    this._validateModel(model);
    
    // Armazenar modelo
    this.registeredModels.set(modelId, model);
    
    return cloneDeep(model);
  }

  /**
   * Cria uma nova versão de um modelo registrado
   * @param {string} modelId ID do modelo registrado
   * @param {Object} versionData Dados da versão
   * @returns {Promise<Object>} Versão do modelo criada
   */
  async createModelVersion(modelId, versionData) {
    if (!this.registeredModels.has(modelId)) {
      throw new Error(`Modelo não encontrado: ${modelId}`);
    }
    
    const model = this.registeredModels.get(modelId);
    const versionId = versionData.id || uuidv4();
    
    const version = {
      id: versionId,
      modelId,
      version: versionData.version || (this._getLastVersionNumber(modelId) + 1),
      description: versionData.description || '',
      sourceRunId: versionData.sourceRunId, // ID da execução do MLflow que gerou o modelo
      artifactUri: versionData.artifactUri, // URI do artefato do modelo
      metrics: versionData.metrics || {}, // Métricas de avaliação
      parameters: versionData.parameters || {}, // Hiperparâmetros
      tags: versionData.tags || [],
      stage: 'staging', // 'staging', 'production', 'archived'
      status: 'ready', // 'pending', 'ready', 'failed'
      createdBy: versionData.createdBy,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      metadata: versionData.metadata || {}
    };
    
    // Validar versão
    this._validateModelVersion(version);
    
    // Armazenar versão
    if (!this.modelVersions.has(modelId)) {
      this.modelVersions.set(modelId, new Map());
    }
    
    this.modelVersions.get(modelId).set(versionId, version);
    
    // Atualizar modelo
    model.updatedAt = new Date().toISOString();
    this.registeredModels.set(modelId, model);
    
    // Configurar monitoramento padrão
    await this.setupMonitoring(modelId, versionId, {});
    
    return cloneDeep(version);
  }

  /**
   * Atualiza o estágio de uma versão do modelo
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão
   * @param {string} stage Novo estágio ('staging', 'production', 'archived')
   * @param {Object} metadata Metadados adicionais
   * @returns {Promise<Object>} Versão atualizada
   */
  async transitionModelVersionStage(modelId, versionId, stage, metadata = {}) {
    if (!this.modelVersions.has(modelId) || !this.modelVersions.get(modelId).has(versionId)) {
      throw new Error(`Versão do modelo não encontrada: ${modelId}/${versionId}`);
    }
    
    const version = this.modelVersions.get(modelId).get(versionId);
    const currentStage = version.stage;
    
    // Validar transição de estágio
    this._validateStageTransition(currentStage, stage);
    
    // Atualizar estágio
    version.stage = stage;
    version.updatedAt = new Date().toISOString();
    version.metadata = {
      ...version.metadata,
      stageTransition: {
        timestamp: new Date().toISOString(),
        previousStage: currentStage,
        newStage: stage,
        actor: metadata.actor || 'system',
        reason: metadata.reason || `Transitioned to ${stage}`
      }
    };
    
    // Armazenar versão atualizada
    this.modelVersions.get(modelId).set(versionId, version);
    
    // Se mover para produção, arquivar versões anteriores em produção (opcional)
    if (stage === 'production') {
      const otherVersions = Array.from(this.modelVersions.get(modelId).values());
      for (const otherVersion of otherVersions) {
        if (otherVersion.id !== versionId && otherVersion.stage === 'production') {
          await this.transitionModelVersionStage(modelId, otherVersion.id, 'archived', {
            actor: 'system',
            reason: `New version ${version.version} promoted to production`
          });
        }
      }
      
      // Ativar monitoramento em produção
      await this.updateMonitoringStatus(modelId, versionId, 'active');
    } else {
      // Desativar monitoramento se sair de produção
      await this.updateMonitoringStatus(modelId, versionId, 'inactive');
    }
    
    return cloneDeep(version);
  }

  /**
   * Configura o monitoramento para uma versão do modelo
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão
   * @param {Object} configData Configurações de monitoramento
   * @returns {Promise<Object>} Configuração de monitoramento
   */
  async setupMonitoring(modelId, versionId, configData) {
    if (!this.modelVersions.has(modelId) || !this.modelVersions.get(modelId).has(versionId)) {
      throw new Error(`Versão do modelo não encontrada: ${modelId}/${versionId}`);
    }
    
    const version = this.modelVersions.get(modelId).get(versionId);
    const monitoringId = `${modelId}-${versionId}`;
    
    const config = {
      id: monitoringId,
      modelId,
      versionId,
      status: 'inactive', // 'active', 'inactive', 'paused'
      interval: configData.interval || this.config.defaultMonitoringInterval,
      metrics: configData.metrics || ['accuracy', 'precision', 'recall', 'f1', 'roc_auc'], // Métricas de desempenho
      driftMetrics: configData.driftMetrics || ['feature_drift', 'prediction_drift'], // Métricas de drift
      baselineDatasetId: configData.baselineDatasetId, // Dataset de referência
      driftDetectionThreshold: configData.driftDetectionThreshold || this.config.driftDetectionThreshold,
      performanceDegradationThreshold: configData.performanceDegradationThreshold || this.config.performanceDegradationThreshold,
      notificationChannels: configData.notificationChannels || ['email'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      metadata: configData.metadata || {}
    };
    
    // Validar configuração
    this._validateMonitoringConfig(config);
    
    // Armazenar configuração
    this.monitoringConfigs.set(monitoringId, config);
    
    return cloneDeep(config);
  }

  /**
   * Atualiza o status do monitoramento
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão
   * @param {string} status Novo status ('active', 'inactive', 'paused')
   * @returns {Promise<Object>} Configuração atualizada
   */
  async updateMonitoringStatus(modelId, versionId, status) {
    const monitoringId = `${modelId}-${versionId}`;
    
    if (!this.monitoringConfigs.has(monitoringId)) {
      throw new Error(`Configuração de monitoramento não encontrada: ${monitoringId}`);
    }
    
    const config = this.monitoringConfigs.get(monitoringId);
    
    // Validar status
    if (!['active', 'inactive', 'paused'].includes(status)) {
      throw new Error(`Status de monitoramento inválido: ${status}`);
    }
    
    // Atualizar status
    config.status = status;
    config.updatedAt = new Date().toISOString();
    
    // Armazenar configuração atualizada
    this.monitoringConfigs.set(monitoringId, config);
    
    return cloneDeep(config);
  }

  /**
   * Registra dados de monitoramento para uma versão do modelo
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão
   * @param {Object} data Dados de monitoramento
   * @returns {Promise<Object>} Dados registrados
   */
  async recordMonitoringData(modelId, versionId, data) {
    const monitoringId = `${modelId}-${versionId}`;
    
    if (!this.monitoringConfigs.has(monitoringId)) {
      throw new Error(`Configuração de monitoramento não encontrada: ${monitoringId}`);
    }
    
    const config = this.monitoringConfigs.get(monitoringId);
    
    // Verificar se o monitoramento está ativo
    if (config.status !== 'active') {
      console.warn(`Monitoramento inativo para ${monitoringId}. Dados não serão processados.`);
      return null;
    }
    
    const recordId = uuidv4();
    const timestamp = new Date().toISOString();
    
    const record = {
      id: recordId,
      monitoringId,
      modelId,
      versionId,
      timestamp,
      performanceMetrics: data.performanceMetrics || {},
      driftMetrics: data.driftMetrics || {},
      dataSlice: data.dataSlice || 'overall',
      sampleSize: data.sampleSize || 0,
      metadata: data.metadata || {}
    };
    
    // Validar dados
    this._validateMonitoringData(record, config);
    
    // Armazenar dados
    if (!this.monitoringData.has(monitoringId)) {
      this.monitoringData.set(monitoringId, []);
    }
    
    this.monitoringData.get(monitoringId).push(record);
    
    // Verificar alertas
    await this._checkAlerts(config, record);
    
    return cloneDeep(record);
  }

  /**
   * Verifica se alertas devem ser gerados
   * @param {Object} config Configuração de monitoramento
   * @param {Object} record Dados de monitoramento recentes
   * @private
   */
  async _checkAlerts(config, record) {
    const alertsToCreate = [];
    
    // Verificar drift
    for (const metric of config.driftMetrics) {
      if (record.driftMetrics[metric] !== undefined && 
          record.driftMetrics[metric] > config.driftDetectionThreshold) {
        alertsToCreate.push({
          type: 'drift_detected',
          severity: 'warning',
          message: `Drift detectado na métrica "${metric}" (${record.driftMetrics[metric].toFixed(3)} > ${config.driftDetectionThreshold.toFixed(3)}) para o modelo ${config.modelId} v${config.versionId}.`,
          metric,
          value: record.driftMetrics[metric],
          threshold: config.driftDetectionThreshold
        });
      }
    }
    
    // Verificar degradação de performance
    // Comparar com a métrica de baseline da versão (simplificado)
    const version = this.modelVersions.get(config.modelId).get(config.versionId);
    
    for (const metric of config.metrics) {
      if (record.performanceMetrics[metric] !== undefined && version.metrics[metric] !== undefined) {
        const baselineValue = version.metrics[metric];
        const currentValue = record.performanceMetrics[metric];
        const degradation = (baselineValue - currentValue) / Math.abs(baselineValue || 1);
        
        if (degradation > config.performanceDegradationThreshold) {
          alertsToCreate.push({
            type: 'performance_degradation',
            severity: 'critical',
            message: `Degradação de performance detectada na métrica "${metric}" (${currentValue.toFixed(3)} vs baseline ${baselineValue.toFixed(3)}, queda de ${(degradation * 100).toFixed(2)}%) para o modelo ${config.modelId} v${config.versionId}.`,
            metric,
            currentValue,
            baselineValue,
            degradation,
            threshold: config.performanceDegradationThreshold
          });
        }
      }
    }
    
    // Criar alertas
    for (const alertData of alertsToCreate) {
      await this.createAlert(config.modelId, config.versionId, alertData);
    }
  }

  /**
   * Cria um novo alerta
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão
   * @param {Object} alertData Dados do alerta
   * @returns {Promise<Object>} Alerta criado
   */
  async createAlert(modelId, versionId, alertData) {
    const alertId = uuidv4();
    const timestamp = new Date().toISOString();
    
    const alert = {
      id: alertId,
      modelId,
      versionId,
      timestamp,
      type: alertData.type, // 'drift_detected', 'performance_degradation', 'custom'
      severity: alertData.severity || 'info', // 'info', 'warning', 'critical'
      message: alertData.message,
      status: 'open', // 'open', 'acknowledged', 'resolved', 'closed'
      details: alertData.details || {},
      metadata: alertData.metadata || {}
    };
    
    // Adicionar detalhes específicos do tipo
    if (alertData.metric) alert.details.metric = alertData.metric;
    if (alertData.value !== undefined) alert.details.value = alertData.value;
    if (alertData.threshold !== undefined) alert.details.threshold = alertData.threshold;
    if (alertData.currentValue !== undefined) alert.details.currentValue = alertData.currentValue;
    if (alertData.baselineValue !== undefined) alert.details.baselineValue = alertData.baselineValue;
    if (alertData.degradation !== undefined) alert.details.degradation = alertData.degradation;
    
    // Armazenar alerta
    const monitoringId = `${modelId}-${versionId}`;
    if (!this.alerts.has(monitoringId)) {
      this.alerts.set(monitoringId, []);
    }
    
    this.alerts.get(monitoringId).push(alert);
    
    // Notificar canais (simulado)
    this._notifyChannels(modelId, versionId, alert);
    
    // Verificar se deve disparar retreinamento automático
    if (this.config.autoRetrainEnabled && alert.severity === 'critical') {
      await this.triggerRetraining(modelId, versionId, {
        triggerType: 'alert',
        triggerId: alertId,
        reason: `Retreinamento automático disparado por alerta crítico: ${alert.message}`
      });
    }
    
    return cloneDeep(alert);
  }

  /**
   * Atualiza o status de um alerta
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão
   * @param {string} alertId ID do alerta
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @returns {Promise<Object>} Alerta atualizado
   */
  async updateAlertStatus(modelId, versionId, alertId, status, metadata = {}) {
    const monitoringId = `${modelId}-${versionId}`;
    
    if (!this.alerts.has(monitoringId)) {
      throw new Error(`Nenhum alerta encontrado para ${monitoringId}`);
    }
    
    const alerts = this.alerts.get(monitoringId);
    const alertIndex = alerts.findIndex(alert => alert.id === alertId);
    
    if (alertIndex === -1) {
      throw new Error(`Alerta não encontrado: ${alertId}`);
    }
    
    const alert = alerts[alertIndex];
    const currentStatus = alert.status;
    
    // Validar status
    if (!['acknowledged', 'resolved', 'closed'].includes(status)) {
      throw new Error(`Status de alerta inválido: ${status}`);
    }
    
    // Validar transição
    if (currentStatus === 'closed') {
      throw new Error('Não é possível alterar o status de um alerta fechado');
    }
    
    // Atualizar status
    alert.status = status;
    alert.updatedAt = new Date().toISOString();
    alert.metadata = {
      ...alert.metadata,
      statusUpdate: {
        timestamp: new Date().toISOString(),
        previousStatus: currentStatus,
        newStatus: status,
        actor: metadata.actor || 'system',
        notes: metadata.notes || ''
      }
    };
    
    // Armazenar alerta atualizado
    alerts[alertIndex] = alert;
    this.alerts.set(monitoringId, alerts);
    
    return cloneDeep(alert);
  }

  /**
   * Dispara um job de retreinamento para um modelo
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão atual (opcional, para referência)
   * @param {Object} jobData Dados do job
   * @returns {Promise<Object>} Job de retreinamento criado
   */
  async triggerRetraining(modelId, versionId = null, jobData = {}) {
    if (!this.registeredModels.has(modelId)) {
      throw new Error(`Modelo não encontrado: ${modelId}`);
    }
    
    const jobId = uuidv4();
    const timestamp = new Date().toISOString();
    
    const job = {
      id: jobId,
      modelId,
      referenceVersionId: versionId,
      status: 'pending', // 'pending', 'running', 'completed', 'failed'
      triggerType: jobData.triggerType || 'manual', // 'manual', 'scheduled', 'alert'
      triggerId: jobData.triggerId, // ID do alerta ou schedule
      reason: jobData.reason || 'Retreinamento manual solicitado',
      parameters: jobData.parameters || {}, // Parâmetros para o retreinamento
      datasetInfo: jobData.datasetInfo || { type: 'latest' }, // Informações do dataset a ser usado
      createdAt: timestamp,
      startedAt: null,
      completedAt: null,
      failedAt: null,
      error: null,
      newVersionId: null, // ID da nova versão gerada
      metadata: jobData.metadata || {}
    };
    
    // Armazenar job
    if (!this.retrainJobs.has(modelId)) {
      this.retrainJobs.set(modelId, []);
    }
    
    this.retrainJobs.get(modelId).push(job);
    
    // Simular execução do job (em um sistema real, isso dispararia um pipeline)
    this._simulateRetrainingJob(job);
    
    return cloneDeep(job);
  }

  /**
   * Simula a execução de um job de retreinamento
   * @param {Object} job Job de retreinamento
   * @private
   */
  async _simulateRetrainingJob(job) {
    // Atualizar status para running
    job.status = 'running';
    job.startedAt = new Date().toISOString();
    
    // Simular tempo de execução
    await new Promise(resolve => setTimeout(resolve, 5000 + Math.random() * 10000));
    
    try {
      // Simular sucesso do retreinamento
      const success = Math.random() > 0.1; // 90% de chance de sucesso
      
      if (success) {
        // Simular criação de nova versão
        const newVersionData = {
          version: this._getLastVersionNumber(job.modelId) + 1,
          description: `Versão gerada por retreinamento automático (${job.triggerType})`, 
          sourceRunId: `retrain_run_${job.id}`,
          artifactUri: `/path/to/models/${job.modelId}/v${this._getLastVersionNumber(job.modelId) + 1}`,
          metrics: this._generateRandomMetrics(),
          parameters: job.parameters,
          createdBy: 'mlops_system',
          metadata: { retrainJobId: job.id }
        };
        
        const newVersion = await this.createModelVersion(job.modelId, newVersionData);
        
        // Atualizar job
        job.status = 'completed';
        job.completedAt = new Date().toISOString();
        job.newVersionId = newVersion.id;
        
        // Verificar se deve disparar deploy automático
        if (this.config.autoDeployEnabled) {
          await this.deployModelVersion(job.modelId, newVersion.id, {
            deployType: 'auto_deploy',
            reason: `Deploy automático após retreinamento bem-sucedido (Job ${job.id})`
          });
        }
      } else {
        // Simular falha
        throw new Error('Falha no pipeline de retreinamento: erro de convergência');
      }
    } catch (error) {
      // Atualizar job em caso de erro
      job.status = 'failed';
      job.failedAt = new Date().toISOString();
      job.error = error.message;
    }
  }

  /**
   * Implanta uma versão do modelo
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão
   * @param {Object} deployData Dados da implantação
   * @returns {Promise<Object>} Status da implantação
   */
  async deployModelVersion(modelId, versionId, deployData = {}) {
    if (!this.modelVersions.has(modelId) || !this.modelVersions.get(modelId).has(versionId)) {
      throw new Error(`Versão do modelo não encontrada: ${modelId}/${versionId}`);
    }
    
    const version = this.modelVersions.get(modelId).get(versionId);
    const deploymentId = `${modelId}-${versionId}-${deployData.environment || 'production'}`;
    
    // Verificar se a versão está pronta
    if (version.status !== 'ready') {
      throw new Error(`Versão ${versionId} não está pronta para implantação (status: ${version.status})`);
    }
    
    const deployment = {
      id: deploymentId,
      modelId,
      versionId,
      environment: deployData.environment || 'production',
      strategy: deployData.strategy || this.config.deploymentStrategy,
      status: 'pending', // 'pending', 'deploying', 'active', 'failed', 'rollback'
      startedAt: new Date().toISOString(),
      completedAt: null,
      failedAt: null,
      error: null,
      trafficPercentage: deployData.trafficPercentage, // Para canary
      metadata: deployData.metadata || {}
    };
    
    // Armazenar status da implantação
    this.deployments.set(deploymentId, deployment);
    
    // Simular processo de implantação
    this._simulateDeployment(deployment);
    
    return cloneDeep(deployment);
  }

  /**
   * Simula o processo de implantação
   * @param {Object} deployment Status da implantação
   * @private
   */
  async _simulateDeployment(deployment) {
    // Atualizar status para deploying
    deployment.status = 'deploying';
    
    // Simular tempo de implantação
    await new Promise(resolve => setTimeout(resolve, 3000 + Math.random() * 5000));
    
    try {
      // Simular sucesso da implantação
      const success = Math.random() > 0.05; // 95% de chance de sucesso
      
      if (success) {
        // Atualizar status para active
        deployment.status = 'active';
        deployment.completedAt = new Date().toISOString();
        
        // Atualizar estágio da versão para production
        await this.transitionModelVersionStage(deployment.modelId, deployment.versionId, 'production', {
          actor: 'mlops_system',
          reason: `Implantação bem-sucedida no ambiente ${deployment.environment}`
        });
      } else {
        // Simular falha
        throw new Error('Falha na implantação: erro de configuração do endpoint');
      }
    } catch (error) {
      // Atualizar status em caso de erro
      deployment.status = 'failed';
      deployment.failedAt = new Date().toISOString();
      deployment.error = error.message;
      
      // Simular rollback (opcional)
      // await this._simulateRollback(deployment);
    }
  }

  /**
   * Obtém o status de uma implantação
   * @param {string} deploymentId ID da implantação
   * @returns {Promise<Object>} Status da implantação
   */
  async getDeploymentStatus(deploymentId) {
    if (!this.deployments.has(deploymentId)) {
      throw new Error(`Implantação não encontrada: ${deploymentId}`);
    }
    
    return cloneDeep(this.deployments.get(deploymentId));
  }

  /**
   * Lista implantações
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de implantações
   */
  async listDeployments(filters = {}) {
    let deployments = Array.from(this.deployments.values());
    
    // Aplicar filtros
    if (filters.modelId) {
      deployments = deployments.filter(d => d.modelId === filters.modelId);
    }
    
    if (filters.versionId) {
      deployments = deployments.filter(d => d.versionId === filters.versionId);
    }
    
    if (filters.environment) {
      deployments = deployments.filter(d => d.environment === filters.environment);
    }
    
    if (filters.status) {
      deployments = deployments.filter(d => d.status === filters.status);
    }
    
    // Ordenar por data de início (mais recente primeiro)
    deployments.sort((a, b) => new Date(b.startedAt) - new Date(a.startedAt));
    
    // Limitar resultados
    if (filters.limit) {
      deployments = deployments.slice(0, filters.limit);
    }
    
    return cloneDeep(deployments);
  }

  /**
   * Obtém o número da última versão de um modelo
   * @param {string} modelId ID do modelo
   * @returns {number} Número da última versão
   * @private
   */
  _getLastVersionNumber(modelId) {
    if (!this.modelVersions.has(modelId)) {
      return 0;
    }
    
    const versions = Array.from(this.modelVersions.get(modelId).values());
    if (versions.length === 0) {
      return 0;
    }
    
    // Encontrar a maior versão numérica
    return Math.max(...versions.map(v => parseInt(v.version, 10) || 0));
  }

  /**
   * Gera métricas aleatórias para simulação
   * @returns {Object} Métricas aleatórias
   * @private
   */
  _generateRandomMetrics() {
    return {
      accuracy: 0.85 + Math.random() * 0.1, // 85-95%
      precision: 0.8 + Math.random() * 0.15, // 80-95%
      recall: 0.8 + Math.random() * 0.15, // 80-95%
      f1: 0.8 + Math.random() * 0.15, // 80-95%
      roc_auc: 0.9 + Math.random() * 0.08 // 90-98%
    };
  }

  /**
   * Notifica canais sobre um alerta (simulado)
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão
   * @param {Object} alert Alerta
   * @private
   */
  _notifyChannels(modelId, versionId, alert) {
    const monitoringId = `${modelId}-${versionId}`;
    const config = this.monitoringConfigs.get(monitoringId);
    
    if (!config || !config.notificationChannels) {
      return;
    }
    
    console.log(`[Notification] Sending alert ${alert.id} (${alert.severity}) to channels: ${config.notificationChannels.join(', ')}`);
    console.log(`[Notification] Message: ${alert.message}`);
    
    // Em um sistema real, aqui ocorreria a integração com Slack, PagerDuty, Email, etc.
  }

  /**
   * Valida dados do modelo
   * @param {Object} model Modelo
   * @private
   */
  _validateModel(model) {
    if (!model.name) throw new Error('Nome do modelo é obrigatório');
    if (!model.task) throw new Error('Tarefa do modelo é obrigatória');
    if (!model.owner) throw new Error('Proprietário do modelo é obrigatório');
  }

  /**
   * Valida dados da versão do modelo
   * @param {Object} version Versão do modelo
   * @private
   */
  _validateModelVersion(version) {
    if (!version.version) throw new Error('Número da versão é obrigatório');
    if (!version.artifactUri) throw new Error('URI do artefato é obrigatório');
    if (!version.createdBy) throw new Error('Criador da versão é obrigatório');
  }

  /**
   * Valida transição de estágio
   * @param {string} currentStage Estágio atual
   * @param {string} newStage Novo estágio
   * @private
   */
  _validateStageTransition(currentStage, newStage) {
    const validStages = ['staging', 'production', 'archived'];
    if (!validStages.includes(newStage)) {
      throw new Error(`Estágio inválido: ${newStage}`);
    }
    
    // Regras de transição (simplificadas)
    if (currentStage === 'archived' && newStage !== 'archived') {
      throw new Error('Não é possível mover uma versão arquivada para outro estágio');
    }
  }

  /**
   * Valida configuração de monitoramento
   * @param {Object} config Configuração
   * @private
   */
  _validateMonitoringConfig(config) {
    if (!config.interval) throw new Error('Intervalo de monitoramento é obrigatório');
    if (!config.metrics || config.metrics.length === 0) {
      throw new Error('Pelo menos uma métrica de performance deve ser definida');
    }
    if (!config.driftMetrics || config.driftMetrics.length === 0) {
      throw new Error('Pelo menos uma métrica de drift deve ser definida');
    }
  }

  /**
   * Valida dados de monitoramento
   * @param {Object} record Dados
   * @param {Object} config Configuração
   * @private
   */
  _validateMonitoringData(record, config) {
    if (record.sampleSize <= 0) {
      throw new Error('Tamanho da amostra deve ser maior que zero');
    }
    
    // Verificar se as métricas reportadas estão na configuração
    for (const key of Object.keys(record.performanceMetrics)) {
      if (!config.metrics.includes(key)) {
        console.warn(`Métrica de performance não configurada recebida: ${key}`);
      }
    }
    
    for (const key of Object.keys(record.driftMetrics)) {
      if (!config.driftMetrics.includes(key)) {
        console.warn(`Métrica de drift não configurada recebida: ${key}`);
      }
    }
  }
}

export default MLOpsManager;
