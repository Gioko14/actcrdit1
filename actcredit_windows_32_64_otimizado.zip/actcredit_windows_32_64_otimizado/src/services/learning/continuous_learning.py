import os
import sys
import json
import logging
import numpy as np
import time
import hashlib
import sqlite3
from typing import Dict, List, Any, Optional, Tuple, Union
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("learning.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("continuous_learning")

class ContinuousLearningSystem:
    """
    Sistema de aprendizado contínuo com feedback para auto-aprimoramento
    Permite que o sistema melhore com base em correções e feedback do usuário
    """
    
    def __init__(self, db_path: Optional[str] = None):
        """
        Inicializa o sistema de aprendizado contínuo
        
        Args:
            db_path: Caminho para o banco de dados SQLite (opcional)
        """
        # Configurar banco de dados
        if db_path:
            self.db_path = db_path
        else:
            # Usar diretório padrão
            data_dir = Path(os.path.dirname(os.path.abspath(__file__))) / "data"
            os.makedirs(data_dir, exist_ok=True)
            self.db_path = str(data_dir / "learning.db")
        
        # Inicializar banco de dados
        self._initialize_database()
        
        logger.info(f"Sistema de aprendizado contínuo inicializado. DB: {self.db_path}")
    
    def _initialize_database(self):
        """Inicializa o banco de dados SQLite para armazenar dados de aprendizado"""
        try:
            # Conectar ao banco de dados
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Criar tabelas se não existirem
            
            # Tabela de documentos processados
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS documents (
                id TEXT PRIMARY KEY,
                path TEXT,
                type TEXT,
                processed_date TEXT,
                original_confidence REAL,
                current_confidence REAL,
                feedback_count INTEGER DEFAULT 0,
                last_feedback_date TEXT
            )
            ''')
            
            # Tabela de entidades extraídas
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS entities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                document_id TEXT,
                entity_type TEXT,
                original_value TEXT,
                corrected_value TEXT,
                confidence REAL,
                feedback_count INTEGER DEFAULT 0,
                is_correct BOOLEAN DEFAULT NULL,
                FOREIGN KEY (document_id) REFERENCES documents(id)
            )
            ''')
            
            # Tabela de correções e feedback
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                document_id TEXT,
                entity_id INTEGER,
                original_value TEXT,
                corrected_value TEXT,
                feedback_date TEXT,
                feedback_type TEXT,
                confidence_impact REAL,
                FOREIGN KEY (document_id) REFERENCES documents(id),
                FOREIGN KEY (entity_id) REFERENCES entities(id)
            )
            ''')
            
            # Tabela de regras de aprendizado
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS learning_rules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                rule_type TEXT,
                pattern TEXT,
                replacement TEXT,
                confidence REAL,
                application_count INTEGER DEFAULT 0,
                created_date TEXT,
                last_applied_date TEXT
            )
            ''')
            
            # Tabela de estatísticas de aprendizado
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS learning_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                stat_date TEXT,
                documents_processed INTEGER DEFAULT 0,
                entities_corrected INTEGER DEFAULT 0,
                rules_created INTEGER DEFAULT 0,
                rules_applied INTEGER DEFAULT 0,
                avg_confidence_before REAL,
                avg_confidence_after REAL
            )
            ''')
            
            # Commit e fechar conexão
            conn.commit()
            conn.close()
            
            logger.info("Banco de dados inicializado com sucesso")
        
        except Exception as e:
            logger.error(f"Erro ao inicializar banco de dados: {str(e)}")
    
    def register_document(self, document_path: str, extraction_result: Dict[str, Any]) -> str:
        """
        Registra um documento processado no sistema de aprendizado
        
        Args:
            document_path: Caminho para o documento
            extraction_result: Resultado da extração
            
        Returns:
            ID do documento registrado
        """
        try:
            # Gerar ID único para o documento
            document_id = self._generate_document_id(document_path)
            
            # Extrair informações relevantes
            doc_type = extraction_result.get("document_type", "desconhecido")
            confidence = extraction_result.get("confidence", {}).get("overall", 0.0)
            
            # Conectar ao banco de dados
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Verificar se o documento já existe
            cursor.execute("SELECT id FROM documents WHERE id = ?", (document_id,))
            existing = cursor.fetchone()
            
            current_date = time.strftime("%Y-%m-%d %H:%M:%S")
            
            if existing:
                # Atualizar documento existente
                cursor.execute('''
                UPDATE documents 
                SET processed_date = ?, current_confidence = ?
                WHERE id = ?
                ''', (current_date, confidence, document_id))
                
                # Limpar entidades existentes
                cursor.execute("DELETE FROM entities WHERE document_id = ?", (document_id,))
            else:
                # Inserir novo documento
                cursor.execute('''
                INSERT INTO documents 
                (id, path, type, processed_date, original_confidence, current_confidence, feedback_count)
                VALUES (?, ?, ?, ?, ?, ?, 0)
                ''', (document_id, document_path, doc_type, current_date, confidence, confidence))
            
            # Registrar entidades extraídas
            self._register_entities(cursor, document_id, extraction_result)
            
            # Aplicar regras de aprendizado existentes
            improved_result = self._apply_learning_rules(extraction_result)
            
            # Atualizar confiança se melhorou
            if improved_result.get("confidence", {}).get("overall", 0.0) > confidence:
                cursor.execute('''
                UPDATE documents 
                SET current_confidence = ?
                WHERE id = ?
                ''', (improved_result["confidence"]["overall"], document_id))
            
            # Atualizar estatísticas
            self._update_learning_stats(cursor, 1, 0, 0, 0, confidence, confidence)
            
            # Commit e fechar conexão
            conn.commit()
            conn.close()
            
            logger.info(f"Documento registrado com sucesso: {document_id}")
            return document_id
        
        except Exception as e:
            logger.error(f"Erro ao registrar documento: {str(e)}")
            return ""
    
    def _generate_document_id(self, document_path: str) -> str:
        """
        Gera ID único para um documento
        
        Args:
            document_path: Caminho para o documento
            
        Returns:
            ID único do documento
        """
        # Usar hash do caminho e data de modificação
        try:
            mod_time = os.path.getmtime(document_path)
            file_size = os.path.getsize(document_path)
            
            # Combinar caminho, tamanho e data de modificação
            unique_string = f"{document_path}|{file_size}|{mod_time}"
            
            # Gerar hash
            return hashlib.md5(unique_string.encode()).hexdigest()
        
        except Exception as e:
            logger.warning(f"Erro ao gerar ID de documento: {str(e)}")
            # Fallback: usar apenas o caminho
            return hashlib.md5(document_path.encode()).hexdigest()
    
    def _register_entities(self, cursor, document_id: str, extraction_result: Dict[str, Any]):
        """
        Registra entidades extraídas no banco de dados
        
        Args:
            cursor: Cursor do banco de dados
            document_id: ID do documento
            extraction_result: Resultado da extração
        """
        # Extrair entidades
        entities = extraction_result.get("entities", {})
        
        # Registrar CNPJs
        for cnpj in entities.get("cnpj", []):
            cursor.execute('''
            INSERT INTO entities 
            (document_id, entity_type, original_value, confidence)
            VALUES (?, ?, ?, ?)
            ''', (document_id, "cnpj", cnpj, extraction_result.get("confidence", {}).get("entities", 0.7)))
        
        # Registrar valores monetários
        for valor in entities.get("valores", []):
            cursor.execute('''
            INSERT INTO entities 
            (document_id, entity_type, original_value, confidence)
            VALUES (?, ?, ?, ?)
            ''', (document_id, "valor", valor, extraction_result.get("confidence", {}).get("entities", 0.7)))
        
        # Registrar datas
        for data in entities.get("datas", []):
            cursor.execute('''
            INSERT INTO entities 
            (document_id, entity_type, original_value, confidence)
            VALUES (?, ?, ?, ?)
            ''', (document_id, "data", data, extraction_result.get("confidence", {}).get("entities", 0.7)))
        
        # Registrar nome da empresa
        empresa = entities.get("empresa", "")
        if empresa:
            cursor.execute('''
            INSERT INTO entities 
            (document_id, entity_type, original_value, confidence)
            VALUES (?, ?, ?, ?)
            ''', (document_id, "empresa", empresa, extraction_result.get("confidence", {}).get("entities", 0.7)))
    
    def process_feedback(self, document_id: str, feedback_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Processa feedback do usuário para um documento
        
        Args:
            document_id: ID do documento
            feedback_data: Dados de feedback
            
        Returns:
            Resultado do processamento de feedback
        """
        try:
            # Conectar ao banco de dados
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Verificar se o documento existe
            cursor.execute("SELECT id, current_confidence FROM documents WHERE id = ?", (document_id,))
            document = cursor.fetchone()
            
            if not document:
                conn.close()
                return {"error": f"Documento não encontrado: {document_id}"}
            
            current_confidence = document[1]
            
            # Processar correções de entidades
            entity_corrections = feedback_data.get("entity_corrections", [])
            processed_corrections = []
            
            for correction in entity_corrections:
                entity_type = correction.get("entity_type")
                original_value = correction.get("original_value")
                corrected_value = correction.get("corrected_value")
                
                if not entity_type or not original_value or corrected_value is None:
                    continue
                
                # Buscar entidade no banco de dados
                cursor.execute('''
                SELECT id, confidence FROM entities 
                WHERE document_id = ? AND entity_type = ? AND original_value = ?
                ''', (document_id, entity_type, original_value))
                
                entity = cursor.fetchone()
                
                if entity:
                    entity_id = entity[0]
                    entity_confidence = entity[1]
                    
                    # Registrar correção
                    current_date = time.strftime("%Y-%m-%d %H:%M:%S")
                    
                    # Calcular impacto na confiança
                    confidence_impact = 0.05  # Impacto base
                    
                    # Atualizar entidade
                    cursor.execute('''
                    UPDATE entities 
                    SET corrected_value = ?, feedback_count = feedback_count + 1, is_correct = ?
                    WHERE id = ?
                    ''', (corrected_value, original_value == corrected_value, entity_id))
                    
                    # Registrar feedback
                    cursor.execute('''
                    INSERT INTO feedback 
                    (document_id, entity_id, original_value, corrected_value, feedback_date, feedback_type, confidence_impact)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (document_id, entity_id, original_value, corrected_value, current_date, "correction", confidence_impact))
                    
                    # Criar regra de aprendizado
                    rule_id = self._create_learning_rule(cursor, entity_type, original_value, corrected_value)
                    
                    processed_corrections.append({
                        "entity_type": entity_type,
                        "original_value": original_value,
                        "corrected_value": corrected_value,
                        "rule_created": rule_id is not None
                    })
                else:
                    # Entidade não encontrada, criar nova
                    cursor.execute('''
                    INSERT INTO entities 
                    (document_id, entity_type, original_value, corrected_value, confidence, feedback_count, is_correct)
                    VALUES (?, ?, ?, ?, ?, 1, ?)
                    ''', (document_id, entity_type, original_value, corrected_value, 0.5, original_value == corrected_value))
                    
                    entity_id = cursor.lastrowid
                    
                    # Registrar feedback
                    current_date = time.strftime("%Y-%m-%d %H:%M:%S")
                    cursor.execute('''
                    INSERT INTO feedback 
                    (document_id, entity_id, original_value, corrected_value, feedback_date, feedback_type, confidence_impact)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (document_id, entity_id, original_value, corrected_value, current_date, "addition", 0.05))
                    
                    # Criar regra de aprendizado
                    rule_id = self._create_learning_rule(cursor, entity_type, original_value, corrected_value)
                    
                    processed_corrections.append({
                        "entity_type": entity_type,
                        "original_value": original_value,
                        "corrected_value": corrected_value,
                        "rule_created": rule_id is not None
                    })
            
            # Atualizar documento
            current_date = time.strftime("%Y-%m-%d %H:%M:%S")
            
            # Calcular nova confiança
            new_confidence = min(current_confidence + (0.02 * len(processed_corrections)), 0.99)
            
            cursor.execute('''
            UPDATE documents 
            SET feedback_count = feedback_count + ?, last_feedback_date = ?, current_confidence = ?
            WHERE id = ?
            ''', (len(processed_corrections), current_date, new_confidence, document_id))
            
            # Atualizar estatísticas
            self._update_learning_stats(cursor, 0, len(processed_corrections), len(processed_corrections), 0, current_confidence, new_confidence)
            
            # Commit e fechar conexão
            conn.commit()
            conn.close()
            
            result = {
                "document_id": document_id,
                "processed_corrections": len(processed_corrections),
                "corrections": processed_corrections,
                "confidence_before": current_confidence,
                "confidence_after": new_confidence
            }
            
            logger.info(f"Feedback processado com sucesso: {len(processed_corrections)} correções")
            return result
        
        except Exception as e:
            logger.error(f"Erro ao processar feedback: {str(e)}")
            return {"error": str(e)}
    
    def _create_learning_rule(self, cursor, entity_type: str, original_value: str, corrected_value: str) -> Optional[int]:
        """
        Cria regra de aprendizado com base em correção
        
        Args:
            cursor: Cursor do banco de dados
            entity_type: Tipo de entidade
            original_value: Valor original
            corrected_value: Valor corrigido
            
        Returns:
            ID da regra criada ou None se não foi possível criar
        """
        # Se os valores são iguais, não criar regra
        if original_value == corrected_value:
            return None
        
        try:
            # Verificar se já existe regra similar
            cursor.execute('''
            SELECT id, application_count, confidence FROM learning_rules 
            WHERE rule_type = ? AND pattern = ? AND replacement = ?
            ''', (entity_type, original_value, corrected_value))
            
            existing_rule = cursor.fetchone()
            
            current_date = time.strftime("%Y-%m-%d %H:%M:%S")
            
            if existing_rule:
                # Atualizar regra existente
                rule_id = existing_rule[0]
                application_count = existing_rule[1]
                confidence = existing_rule[2]
                
                # Aumentar confiança com base no número de aplicações
                new_confidence = min(confidence + (0.05 / (application_count + 1)), 0.95)
                
                cursor.execute('''
                UPDATE learning_rules 
                SET confidence = ?, last_applied_date = ?
                WHERE id = ?
                ''', (new_confidence, current_date, rule_id))
                
                return rule_id
            else:
                # Criar nova regra
                cursor.execute('''
                INSERT INTO learning_rules 
                (rule_type, pattern, replacement, confidence, application_count, created_date, last_applied_date)
                VALUES (?, ?, ?, ?, 1, ?, ?)
                ''', (entity_type, original_value, corrected_value, 0.7, current_date, current_date))
                
                return cursor.lastrowid
        
        except Exception as e:
            logger.warning(f"Erro ao criar regra de aprendizado: {str(e)}")
            return None
    
    def _apply_learning_rules(self, extraction_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Aplica regras de aprendizado a um resultado de extração
        
        Args:
            extraction_result: Resultado da extração
            
        Returns:
            Resultado melhorado após aplicação de regras
        """
        try:
            # Criar cópia do resultado para não modificar o original
            improved_result = extraction_result.copy()
            
            # Extrair entidades
            entities = improved_result.get("entities", {}).copy()
            improved_result["entities"] = entities
            
            # Conectar ao banco de dados
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Buscar regras de aprendizado
            cursor.execute("SELECT id, rule_type, pattern, replacement, confidence FROM learning_rules")
            rules = cursor.fetchall()
            
            # Aplicar regras
            rules_applied = 0
            confidence_impact = 0.0
            
            for rule in rules:
                rule_id, rule_type, pattern, replacement, rule_confidence = rule
                
                if rule_type == "cnpj" and "cnpj" in entities:
                    # Aplicar a CNPJs
                    new_cnpjs = []
                    for cnpj in entities["cnpj"]:
                        if cnpj == pattern:
                            new_cnpjs.append(replacement)
                            rules_applied += 1
                            confidence_impact += rule_confidence * 0.01
                            
                            # Atualizar contagem de aplicações
                            cursor.execute('''
                            UPDATE learning_rules 
                            SET application_count = application_count + 1, last_applied_date = ?
                            WHERE id = ?
                            ''', (time.strftime("%Y-%m-%d %H:%M:%S"), rule_id))
                        else:
                            new_cnpjs.append(cnpj)
                    
                    entities["cnpj"] = new_cnpjs
                
                elif rule_type == "valor" and "valores" in entities:
                    # Aplicar a valores monetários
                    new_valores = []
                    for valor in entities["valores"]:
                        if valor == pattern:
                            new_valores.append(replacement)
                            rules_applied += 1
                            confidence_impact += rule_confidence * 0.01
                            
                            # Atualizar contagem de aplicações
                            cursor.execute('''
                            UPDATE learning_rules 
                            SET application_count = application_count + 1, last_applied_date = ?
                            WHERE id = ?
                            ''', (time.strftime("%Y-%m-%d %H:%M:%S"), rule_id))
                        else:
                            new_valores.append(valor)
                    
                    entities["valores"] = new_valores
                
                elif rule_type == "data" and "datas" in entities:
                    # Aplicar a datas
                    new_datas = []
                    for data in entities["datas"]:
                        if data == pattern:
                            new_datas.append(replacement)
                            rules_applied += 1
                            confidence_impact += rule_confidence * 0.01
                            
                            # Atualizar contagem de aplicações
                            cursor.execute('''
                            UPDATE learning_rules 
                            SET application_count = application_count + 1, last_applied_date = ?
                            WHERE id = ?
                            ''', (time.strftime("%Y-%m-%d %H:%M:%S"), rule_id))
                        else:
                            new_datas.append(data)
                    
                    entities["datas"] = new_datas
                
                elif rule_type == "empresa" and "empresa" in entities:
                    # Aplicar a nome de empresa
                    if entities["empresa"] == pattern:
                        entities["empresa"] = replacement
                        rules_applied += 1
                        confidence_impact += rule_confidence * 0.01
                        
                        # Atualizar contagem de aplicações
                        cursor.execute('''
                        UPDATE learning_rules 
                        SET application_count = application_count + 1, last_applied_date = ?
                        WHERE id = ?
                        ''', (time.strftime("%Y-%m-%d %H:%M:%S"), rule_id))
            
            # Atualizar confiança
            if "confidence" in improved_result:
                confidence = improved_result["confidence"].copy()
                
                # Aumentar confiança de entidades
                if "entities" in confidence:
                    confidence["entities"] = min(confidence["entities"] + confidence_impact, 0.99)
                
                # Aumentar confiança geral
                if "overall" in confidence:
                    confidence["overall"] = min(confidence["overall"] + (confidence_impact / 2), 0.99)
                
                improved_result["confidence"] = confidence
            
            # Atualizar estatísticas se regras foram aplicadas
            if rules_applied > 0:
                self._update_learning_stats(
                    cursor, 0, 0, 0, rules_applied,
                    extraction_result.get("confidence", {}).get("overall", 0.0),
                    improved_result.get("confidence", {}).get("overall", 0.0)
                )
            
            # Commit e fechar conexão
            conn.commit()
            conn.close()
            
            # Adicionar metadados de aprendizado
            improved_result["learning"] = {
                "rules_applied": rules_applied,
                "confidence_impact": confidence_impact
            }
            
            return improved_result
        
        except Exception as e:
            logger.error(f"Erro ao aplicar regras de aprendizado: {str(e)}")
            return extraction_result
    
    def _update_learning_stats(self, cursor, docs_processed: int, entities_corrected: int, 
                              rules_created: int, rules_applied: int, 
                              confidence_before: float, confidence_after: float):
        """
        Atualiza estatísticas de aprendizado
        
        Args:
            cursor: Cursor do banco de dados
            docs_processed: Número de documentos processados
            entities_corrected: Número de entidades corrigidas
            rules_created: Número de regras criadas
            rules_applied: Número de regras aplicadas
            confidence_before: Confiança antes
            confidence_after: Confiança depois
        """
        try:
            # Obter data atual (apenas data, sem hora)
            current_date = time.strftime("%Y-%m-%d")
            
            # Verificar se já existe estatística para hoje
            cursor.execute("SELECT id FROM learning_stats WHERE stat_date = ?", (current_date,))
            stat = cursor.fetchone()
            
            if stat:
                # Atualizar estatística existente
                cursor.execute('''
                UPDATE learning_stats 
                SET documents_processed = documents_processed + ?,
                    entities_corrected = entities_corrected + ?,
                    rules_created = rules_created + ?,
                    rules_applied = rules_applied + ?,
                    avg_confidence_before = (avg_confidence_before + ?) / 2,
                    avg_confidence_after = (avg_confidence_after + ?) / 2
                WHERE stat_date = ?
                ''', (docs_processed, entities_corrected, rules_created, rules_applied, 
                     confidence_before, confidence_after, current_date))
            else:
                # Criar nova estatística
                cursor.execute('''
                INSERT INTO learning_stats 
                (stat_date, documents_processed, entities_corrected, rules_created, rules_applied, 
                 avg_confidence_before, avg_confidence_after)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (current_date, docs_processed, entities_corrected, rules_created, rules_applied, 
                     confidence_before, confidence_after))
        
        except Exception as e:
            logger.warning(f"Erro ao atualizar estatísticas de aprendizado: {str(e)}")
    
    def get_learning_stats(self, days: int = 30) -> Dict[str, Any]:
        """
        Obtém estatísticas de aprendizado
        
        Args:
            days: Número de dias para obter estatísticas
            
        Returns:
            Dicionário com estatísticas de aprendizado
        """
        try:
            # Conectar ao banco de dados
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Calcular data limite
            import datetime
            limit_date = (datetime.datetime.now() - datetime.timedelta(days=days)).strftime("%Y-%m-%d")
            
            # Obter estatísticas
            cursor.execute('''
            SELECT stat_date, documents_processed, entities_corrected, rules_created, rules_applied, 
                   avg_confidence_before, avg_confidence_after
            FROM learning_stats
            WHERE stat_date >= ?
            ORDER BY stat_date
            ''', (limit_date,))
            
            stats = cursor.fetchall()
            
            # Obter contagens totais
            cursor.execute('''
            SELECT COUNT(*) FROM documents
            ''')
            total_documents = cursor.fetchone()[0]
            
            cursor.execute('''
            SELECT COUNT(*) FROM entities
            ''')
            total_entities = cursor.fetchone()[0]
            
            cursor.execute('''
            SELECT COUNT(*) FROM learning_rules
            ''')
            total_rules = cursor.fetchone()[0]
            
            # Obter média de confiança atual
            cursor.execute('''
            SELECT AVG(current_confidence) FROM documents
            ''')
            avg_confidence = cursor.fetchone()[0] or 0.0
            
            # Fechar conexão
            conn.close()
            
            # Formatar resultados
            daily_stats = []
            for stat in stats:
                daily_stats.append({
                    "date": stat[0],
                    "documents_processed": stat[1],
                    "entities_corrected": stat[2],
                    "rules_created": stat[3],
                    "rules_applied": stat[4],
                    "confidence_before": stat[5],
                    "confidence_after": stat[6],
                    "confidence_improvement": stat[6] - stat[5]
                })
            
            # Calcular totais do período
            period_docs_processed = sum(stat["documents_processed"] for stat in daily_stats)
            period_entities_corrected = sum(stat["entities_corrected"] for stat in daily_stats)
            period_rules_created = sum(stat["rules_created"] for stat in daily_stats)
            period_rules_applied = sum(stat["rules_applied"] for stat in daily_stats)
            
            # Calcular média de melhoria de confiança
            if daily_stats:
                avg_improvement = sum(stat["confidence_improvement"] for stat in daily_stats) / len(daily_stats)
            else:
                avg_improvement = 0.0
            
            result = {
                "period_days": days,
                "daily_stats": daily_stats,
                "period_summary": {
                    "documents_processed": period_docs_processed,
                    "entities_corrected": period_entities_corrected,
                    "rules_created": period_rules_created,
                    "rules_applied": period_rules_applied,
                    "avg_confidence_improvement": avg_improvement
                },
                "overall_stats": {
                    "total_documents": total_documents,
                    "total_entities": total_entities,
                    "total_rules": total_rules,
                    "current_avg_confidence": avg_confidence
                }
            }
            
            return result
        
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas de aprendizado: {str(e)}")
            return {"error": str(e)}
    
    def export_learning_data(self, export_path: str) -> Dict[str, Any]:
        """
        Exporta dados de aprendizado para arquivo JSON
        
        Args:
            export_path: Caminho para salvar o arquivo
            
        Returns:
            Resultado da exportação
        """
        try:
            # Conectar ao banco de dados
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # Para obter resultados como dicionários
            cursor = conn.cursor()
            
            # Obter regras de aprendizado
            cursor.execute('''
            SELECT rule_type, pattern, replacement, confidence, application_count, 
                   created_date, last_applied_date
            FROM learning_rules
            ORDER BY rule_type, confidence DESC
            ''')
            
            rules = [dict(row) for row in cursor.fetchall()]
            
            # Obter estatísticas
            cursor.execute('''
            SELECT stat_date, documents_processed, entities_corrected, rules_created, rules_applied, 
                   avg_confidence_before, avg_confidence_after
            FROM learning_stats
            ORDER BY stat_date DESC
            LIMIT 30
            ''')
            
            stats = [dict(row) for row in cursor.fetchall()]
            
            # Obter contagens
            cursor.execute('SELECT COUNT(*) as count FROM documents')
            doc_count = cursor.fetchone()['count']
            
            cursor.execute('SELECT COUNT(*) as count FROM entities')
            entity_count = cursor.fetchone()['count']
            
            cursor.execute('SELECT COUNT(*) as count FROM feedback')
            feedback_count = cursor.fetchone()['count']
            
            # Fechar conexão
            conn.close()
            
            # Criar dados de exportação
            export_data = {
                "metadata": {
                    "export_date": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "version": "1.0",
                    "counts": {
                        "documents": doc_count,
                        "entities": entity_count,
                        "feedback": feedback_count,
                        "rules": len(rules)
                    }
                },
                "learning_rules": rules,
                "recent_stats": stats
            }
            
            # Salvar arquivo
            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            return {
                "success": True,
                "path": export_path,
                "rules_exported": len(rules),
                "stats_exported": len(stats)
            }
        
        except Exception as e:
            logger.error(f"Erro ao exportar dados de aprendizado: {str(e)}")
            return {"error": str(e)}
    
    def import_learning_data(self, import_path: str) -> Dict[str, Any]:
        """
        Importa dados de aprendizado de arquivo JSON
        
        Args:
            import_path: Caminho do arquivo a importar
            
        Returns:
            Resultado da importação
        """
        try:
            # Carregar arquivo
            with open(import_path, 'r', encoding='utf-8') as f:
                import_data = json.load(f)
            
            # Verificar formato
            if "learning_rules" not in import_data or "metadata" not in import_data:
                return {"error": "Formato de arquivo inválido"}
            
            # Conectar ao banco de dados
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Importar regras
            rules_imported = 0
            rules_updated = 0
            
            for rule in import_data["learning_rules"]:
                # Verificar campos obrigatórios
                if not all(k in rule for k in ["rule_type", "pattern", "replacement", "confidence"]):
                    continue
                
                # Verificar se regra já existe
                cursor.execute('''
                SELECT id FROM learning_rules 
                WHERE rule_type = ? AND pattern = ? AND replacement = ?
                ''', (rule["rule_type"], rule["pattern"], rule["replacement"]))
                
                existing = cursor.fetchone()
                
                if existing:
                    # Atualizar regra existente se a confiança for maior
                    cursor.execute('''
                    UPDATE learning_rules 
                    SET confidence = MAX(confidence, ?),
                        application_count = application_count + ?,
                        last_applied_date = ?
                    WHERE id = ?
                    ''', (rule["confidence"], rule.get("application_count", 1), 
                         rule.get("last_applied_date", time.strftime("%Y-%m-%d %H:%M:%S")), 
                         existing[0]))
                    
                    rules_updated += 1
                else:
                    # Inserir nova regra
                    cursor.execute('''
                    INSERT INTO learning_rules 
                    (rule_type, pattern, replacement, confidence, application_count, created_date, last_applied_date)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (rule["rule_type"], rule["pattern"], rule["replacement"], rule["confidence"],
                         rule.get("application_count", 1),
                         rule.get("created_date", time.strftime("%Y-%m-%d %H:%M:%S")),
                         rule.get("last_applied_date", time.strftime("%Y-%m-%d %H:%M:%S"))))
                    
                    rules_imported += 1
            
            # Commit e fechar conexão
            conn.commit()
            conn.close()
            
            return {
                "success": True,
                "rules_imported": rules_imported,
                "rules_updated": rules_updated,
                "total_rules": rules_imported + rules_updated
            }
        
        except Exception as e:
            logger.error(f"Erro ao importar dados de aprendizado: {str(e)}")
            return {"error": str(e)}
    
    def get_document_history(self, document_id: str) -> Dict[str, Any]:
        """
        Obtém histórico de processamento e feedback de um documento
        
        Args:
            document_id: ID do documento
            
        Returns:
            Histórico do documento
        """
        try:
            # Conectar ao banco de dados
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # Para obter resultados como dicionários
            cursor = conn.cursor()
            
            # Obter informações do documento
            cursor.execute('''
            SELECT id, path, type, processed_date, original_confidence, current_confidence, 
                   feedback_count, last_feedback_date
            FROM documents
            WHERE id = ?
            ''', (document_id,))
            
            document = cursor.fetchone()
            
            if not document:
                conn.close()
                return {"error": f"Documento não encontrado: {document_id}"}
            
            document = dict(document)
            
            # Obter entidades
            cursor.execute('''
            SELECT id, entity_type, original_value, corrected_value, confidence, 
                   feedback_count, is_correct
            FROM entities
            WHERE document_id = ?
            ''', (document_id,))
            
            entities = [dict(row) for row in cursor.fetchall()]
            
            # Obter feedback
            cursor.execute('''
            SELECT id, entity_id, original_value, corrected_value, feedback_date, 
                   feedback_type, confidence_impact
            FROM feedback
            WHERE document_id = ?
            ORDER BY feedback_date DESC
            ''', (document_id,))
            
            feedback = [dict(row) for row in cursor.fetchall()]
            
            # Fechar conexão
            conn.close()
            
            # Calcular melhoria de confiança
            confidence_improvement = document["current_confidence"] - document["original_confidence"]
            
            result = {
                "document": document,
                "entities": entities,
                "feedback_history": feedback,
                "summary": {
                    "total_entities": len(entities),
                    "total_feedback": len(feedback),
                    "confidence_improvement": confidence_improvement,
                    "confidence_improvement_percent": confidence_improvement * 100
                }
            }
            
            return result
        
        except Exception as e:
            logger.error(f"Erro ao obter histórico de documento: {str(e)}")
            return {"error": str(e)}

# Função principal para registrar documento no sistema de aprendizado
def register_document_for_learning(document_path: str, extraction_result: Dict[str, Any], db_path: Optional[str] = None) -> str:
    """
    Função principal para registrar um documento no sistema de aprendizado
    
    Args:
        document_path: Caminho para o documento
        extraction_result: Resultado da extração
        db_path: Caminho para o banco de dados SQLite (opcional)
        
    Returns:
        ID do documento registrado
    """
    try:
        # Inicializar sistema de aprendizado
        learning_system = ContinuousLearningSystem(db_path=db_path)
        
        # Registrar documento
        document_id = learning_system.register_document(document_path, extraction_result)
        
        return document_id
    except Exception as e:
        logger.error(f"Erro ao registrar documento para aprendizado: {str(e)}")
        return ""

# Função principal para processar feedback do usuário
def process_user_feedback(document_id: str, feedback_data: Dict[str, Any], db_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Função principal para processar feedback do usuário
    
    Args:
        document_id: ID do documento
        feedback_data: Dados de feedback
        db_path: Caminho para o banco de dados SQLite (opcional)
        
    Returns:
        Resultado do processamento de feedback
    """
    try:
        # Inicializar sistema de aprendizado
        learning_system = ContinuousLearningSystem(db_path=db_path)
        
        # Processar feedback
        result = learning_system.process_feedback(document_id, feedback_data)
        
        return result
    except Exception as e:
        logger.error(f"Erro ao processar feedback do usuário: {str(e)}")
        return {"error": str(e)}

# Função principal para aplicar aprendizado a novos documentos
def apply_learning_to_extraction(extraction_result: Dict[str, Any], db_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Função principal para aplicar aprendizado a um resultado de extração
    
    Args:
        extraction_result: Resultado da extração
        db_path: Caminho para o banco de dados SQLite (opcional)
        
    Returns:
        Resultado melhorado após aplicação de regras de aprendizado
    """
    try:
        # Inicializar sistema de aprendizado
        learning_system = ContinuousLearningSystem(db_path=db_path)
        
        # Aplicar regras de aprendizado
        improved_result = learning_system._apply_learning_rules(extraction_result)
        
        return improved_result
    except Exception as e:
        logger.error(f"Erro ao aplicar aprendizado a extração: {str(e)}")
        return extraction_result

# Função para instalação de dependências em ambiente Windows
def install_dependencies_windows():
    """
    Instala dependências necessárias em ambiente Windows
    
    Returns:
        True se sucesso, False caso contrário
    """
    try:
        import subprocess
        import sys
        
        # Verificar se pip está disponível
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "--version"])
        except:
            logger.error("Pip não está disponível. Por favor, instale o pip primeiro.")
            return False
        
        # Instalar dependências
        dependencies = [
            "numpy",
            "sqlite3"
        ]
        
        for dep in dependencies:
            logger.info(f"Instalando {dep}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", dep])
        
        logger.info("Todas as dependências Python foram instaladas com sucesso!")
        return True
    except Exception as e:
        logger.error(f"Erro ao instalar dependências: {str(e)}")
        return False

if __name__ == "__main__":
    # Exemplo de uso
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == "stats" and len(sys.argv) > 2:
            # Obter estatísticas
            days = int(sys.argv[2])
            learning_system = ContinuousLearningSystem()
            stats = learning_system.get_learning_stats(days=days)
            print(json.dumps(stats, ensure_ascii=False, indent=2))
        
        elif command == "export" and len(sys.argv) > 2:
            # Exportar dados
            export_path = sys.argv[2]
            learning_system = ContinuousLearningSystem()
            result = learning_system.export_learning_data(export_path)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        
        elif command == "import" and len(sys.argv) > 2:
            # Importar dados
            import_path = sys.argv[2]
            learning_system = ContinuousLearningSystem()
            result = learning_system.import_learning_data(import_path)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        
        elif command == "history" and len(sys.argv) > 2:
            # Obter histórico de documento
            document_id = sys.argv[2]
            learning_system = ContinuousLearningSystem()
            history = learning_system.get_document_history(document_id)
            print(json.dumps(history, ensure_ascii=False, indent=2))
        
        else:
            print("Comando desconhecido ou parâmetros insuficientes")
    else:
        print("Uso: python continuous_learning.py <comando> [parâmetros]")
        print("Comandos disponíveis:")
        print("  stats <dias>           - Obter estatísticas de aprendizado")
        print("  export <caminho>       - Exportar dados de aprendizado")
        print("  import <caminho>       - Importar dados de aprendizado")
        print("  history <document_id>  - Obter histórico de documento")
