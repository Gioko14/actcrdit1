/**
 * Serviço de RBAC (Role-Based Access Control) Granular e DLP (Data Loss Prevention)
 * Implementa funcionalidades para controle de acesso baseado em papéis e prevenção de perda de dados.
 */

import { v4 as uuidv4 } from 'uuid';
import { cloneDeep, get, set, merge, intersection, difference } from 'lodash';
import crypto from 'crypto';

/**
 * Classe para Gerenciamento de RBAC Granular
 */
export class RbacManager {
  constructor(config = {}) {
    this.config = {
      defaultRole: config.defaultRole || 'user',
      superAdminRole: config.superAdminRole || 'super_admin',
      permissionSeparator: config.permissionSeparator || ':',
      wildcardPermission: config.wildcardPermission || '*',
      cacheEnabled: config.cacheEnabled !== undefined ? config.cacheEnabled : true,
      cacheTTL: config.cacheTTL || 300000, // 5 minutos em ms
      auditEnabled: config.auditEnabled !== undefined ? config.auditEnabled : true,
      ...config
    };

    // Armazenamento de papéis (roles)
    this.roles = new Map();
    
    // Armazenamento de permissões
    this.permissions = new Map();
    
    // Armazenamento de usuários
    this.users = new Map();
    
    // Armazenamento de grupos
    this.groups = new Map();
    
    // Cache de verificações de permissão
    this.permissionCache = new Map();
    
    // Armazenamento de logs de auditoria
    this.auditLogs = [];
    
    // Inicializar papéis padrão
    this._initializeDefaultRoles();
  }

  /**
   * Inicializa papéis padrão
   * @private
   */
  _initializeDefaultRoles() {
    // Papel de super administrador
    this.createRole({
      name: this.config.superAdminRole,
      description: 'Super administrador com acesso total ao sistema',
      permissions: [this.config.wildcardPermission],
      isSystem: true
    });
    
    // Papel de usuário padrão
    this.createRole({
      name: this.config.defaultRole,
      description: 'Usuário padrão com acesso básico',
      permissions: [
        'dashboard:view',
        'profile:view',
        'profile:edit'
      ],
      isSystem: true
    });
    
    // Papel de administrador
    this.createRole({
      name: 'admin',
      description: 'Administrador com acesso avançado',
      permissions: [
        'dashboard:view',
        'dashboard:edit',
        'users:view',
        'users:create',
        'users:edit',
        'roles:view',
        'groups:view',
        'reports:view',
        'reports:create',
        'reports:export',
        'settings:view',
        'settings:edit'
      ],
      isSystem: true
    });
    
    // Papel de analista
    this.createRole({
      name: 'analyst',
      description: 'Analista de crédito',
      permissions: [
        'dashboard:view',
        'clients:view',
        'clients:create',
        'clients:edit',
        'credit_analysis:view',
        'credit_analysis:create',
        'credit_analysis:edit',
        'reports:view',
        'reports:create',
        'reports:export'
      ],
      isSystem: true
    });
    
    // Papel de gerente
    this.createRole({
      name: 'manager',
      description: 'Gerente de crédito',
      permissions: [
        'dashboard:view',
        'clients:view',
        'clients:create',
        'clients:edit',
        'clients:approve',
        'credit_analysis:view',
        'credit_analysis:create',
        'credit_analysis:edit',
        'credit_analysis:approve',
        'reports:view',
        'reports:create',
        'reports:export',
        'settings:view'
      ],
      isSystem: true
    });
    
    // Papel de auditor
    this.createRole({
      name: 'auditor',
      description: 'Auditor com acesso somente leitura',
      permissions: [
        'dashboard:view',
        'clients:view',
        'credit_analysis:view',
        'reports:view',
        'audit:view'
      ],
      isSystem: true
    });
  }

  /**
   * Cria um novo papel (role)
   * @param {Object} roleData Dados do papel
   * @returns {Object} Papel criado
   */
  createRole(roleData) {
    const roleName = roleData.name.toLowerCase();
    
    if (this.roles.has(roleName)) {
      throw new Error(`Papel já existe: ${roleName}`);
    }
    
    const role = {
      name: roleName,
      description: roleData.description || '',
      permissions: roleData.permissions || [],
      isSystem: roleData.isSystem || false,
      metadata: roleData.metadata || {},
      createdAt: new Date().toISOString(),
      createdBy: roleData.createdBy || 'system'
    };
    
    // Validar papel
    this._validateRole(role);
    
    // Armazenar papel
    this.roles.set(roleName, role);
    
    // Registrar evento de auditoria
    if (this.config.auditEnabled) {
      this._logAuditEvent({
        action: 'role_created',
        actor: roleData.createdBy || 'system',
        target: { type: 'role', id: roleName },
        details: { role }
      });
    }
    
    // Limpar cache
    if (this.config.cacheEnabled) {
      this.clearPermissionCache();
    }
    
    return cloneDeep(role);
  }

  /**
   * Atualiza um papel existente
   * @param {string} roleName Nome do papel
   * @param {Object} roleData Novos dados do papel
   * @returns {Object} Papel atualizado
   */
  updateRole(roleName, roleData) {
    roleName = roleName.toLowerCase();
    
    if (!this.roles.has(roleName)) {
      throw new Error(`Papel não encontrado: ${roleName}`);
    }
    
    const currentRole = this.roles.get(roleName);
    
    // Verificar se é um papel do sistema
    if (currentRole.isSystem && roleData.permissions) {
      throw new Error(`Não é possível modificar permissões de um papel do sistema: ${roleName}`);
    }
    
    // Campos que não podem ser atualizados diretamente
    const protectedFields = ['name', 'isSystem', 'createdAt', 'createdBy'];
    
    const updatedRole = {
      ...currentRole,
      ...Object.fromEntries(
        Object.entries(roleData).filter(([key]) => !protectedFields.includes(key))
      ),
      updatedAt: new Date().toISOString(),
      updatedBy: roleData.updatedBy || 'system'
    };
    
    // Validar papel
    this._validateRole(updatedRole);
    
    // Armazenar papel atualizado
    this.roles.set(roleName, updatedRole);
    
    // Registrar evento de auditoria
    if (this.config.auditEnabled) {
      this._logAuditEvent({
        action: 'role_updated',
        actor: roleData.updatedBy || 'system',
        target: { type: 'role', id: roleName },
        details: { 
          before: currentRole,
          after: updatedRole,
          changes: this._getChanges(currentRole, updatedRole)
        }
      });
    }
    
    // Limpar cache
    if (this.config.cacheEnabled) {
      this.clearPermissionCache();
    }
    
    return cloneDeep(updatedRole);
  }

  /**
   * Remove um papel
   * @param {string} roleName Nome do papel
   * @param {Object} metadata Metadados adicionais
   * @returns {boolean} Sucesso da remoção
   */
  removeRole(roleName, metadata = {}) {
    roleName = roleName.toLowerCase();
    
    if (!this.roles.has(roleName)) {
      throw new Error(`Papel não encontrado: ${roleName}`);
    }
    
    const role = this.roles.get(roleName);
    
    // Verificar se é um papel do sistema
    if (role.isSystem) {
      throw new Error(`Não é possível remover um papel do sistema: ${roleName}`);
    }
    
    // Verificar se há usuários com este papel
    const usersWithRole = Array.from(this.users.values())
      .filter(user => user.roles.includes(roleName));
    
    if (usersWithRole.length > 0) {
      throw new Error(`Não é possível remover um papel em uso por ${usersWithRole.length} usuários`);
    }
    
    // Verificar se há grupos com este papel
    const groupsWithRole = Array.from(this.groups.values())
      .filter(group => group.roles.includes(roleName));
    
    if (groupsWithRole.length > 0) {
      throw new Error(`Não é possível remover um papel em uso por ${groupsWithRole.length} grupos`);
    }
    
    // Remover papel
    const success = this.roles.delete(roleName);
    
    // Registrar evento de auditoria
    if (success && this.config.auditEnabled) {
      this._logAuditEvent({
        action: 'role_removed',
        actor: metadata.actor || 'system',
        target: { type: 'role', id: roleName },
        details: { role }
      });
    }
    
    // Limpar cache
    if (this.config.cacheEnabled) {
      this.clearPermissionCache();
    }
    
    return success;
  }

  /**
   * Cria uma nova permissão
   * @param {Object} permissionData Dados da permissão
   * @returns {Object} Permissão criada
   */
  createPermission(permissionData) {
    const permissionName = permissionData.name.toLowerCase();
    
    if (this.permissions.has(permissionName)) {
      throw new Error(`Permissão já existe: ${permissionName}`);
    }
    
    const permission = {
      name: permissionName,
      description: permissionData.description || '',
      resource: permissionData.resource,
      action: permissionData.action,
      conditions: permissionData.conditions || [],
      isSystem: permissionData.isSystem || false,
      metadata: permissionData.metadata || {},
      createdAt: new Date().toISOString(),
      createdBy: permissionData.createdBy || 'system'
    };
    
    // Validar permissão
    this._validatePermission(permission);
    
    // Armazenar permissão
    this.permissions.set(permissionName, permission);
    
    // Registrar evento de auditoria
    if (this.config.auditEnabled) {
      this._logAuditEvent({
        action: 'permission_created',
        actor: permissionData.createdBy || 'system',
        target: { type: 'permission', id: permissionName },
        details: { permission }
      });
    }
    
    return cloneDeep(permission);
  }

  /**
   * Cria um novo usuário
   * @param {Object} userData Dados do usuário
   * @returns {Object} Usuário criado
   */
  createUser(userData) {
    const userId = userData.id || uuidv4();
    
    if (this.users.has(userId)) {
      throw new Error(`Usuário já existe: ${userId}`);
    }
    
    const user = {
      id: userId,
      username: userData.username,
      email: userData.email,
      roles: userData.roles || [this.config.defaultRole],
      groups: userData.groups || [],
      directPermissions: userData.directPermissions || [],
      active: userData.active !== undefined ? userData.active : true,
      metadata: userData.metadata || {},
      createdAt: new Date().toISOString(),
      createdBy: userData.createdBy || 'system'
    };
    
    // Validar usuário
    this._validateUser(user);
    
    // Armazenar usuário
    this.users.set(userId, user);
    
    // Registrar evento de auditoria
    if (this.config.auditEnabled) {
      this._logAuditEvent({
        action: 'user_created',
        actor: userData.createdBy || 'system',
        target: { type: 'user', id: userId },
        details: { user: this._sanitizeUserForLogs(user) }
      });
    }
    
    // Limpar cache
    if (this.config.cacheEnabled) {
      this.clearPermissionCache(userId);
    }
    
    return cloneDeep(user);
  }

  /**
   * Atualiza um usuário existente
   * @param {string} userId ID do usuário
   * @param {Object} userData Novos dados do usuário
   * @returns {Object} Usuário atualizado
   */
  updateUser(userId, userData) {
    if (!this.users.has(userId)) {
      throw new Error(`Usuário não encontrado: ${userId}`);
    }
    
    const currentUser = this.users.get(userId);
    
    // Campos que não podem ser atualizados diretamente
    const protectedFields = ['id', 'createdAt', 'createdBy'];
    
    const updatedUser = {
      ...currentUser,
      ...Object.fromEntries(
        Object.entries(userData).filter(([key]) => !protectedFields.includes(key))
      ),
      updatedAt: new Date().toISOString(),
      updatedBy: userData.updatedBy || 'system'
    };
    
    // Validar usuário
    this._validateUser(updatedUser);
    
    // Armazenar usuário atualizado
    this.users.set(userId, updatedUser);
    
    // Registrar evento de auditoria
    if (this.config.auditEnabled) {
      this._logAuditEvent({
        action: 'user_updated',
        actor: userData.updatedBy || 'system',
        target: { type: 'user', id: userId },
        details: { 
          before: this._sanitizeUserForLogs(currentUser),
          after: this._sanitizeUserForLogs(updatedUser),
          changes: this._getChanges(currentUser, updatedUser)
        }
      });
    }
    
    // Limpar cache
    if (this.config.cacheEnabled) {
      this.clearPermissionCache(userId);
    }
    
    return cloneDeep(updatedUser);
  }

  /**
   * Cria um novo grupo
   * @param {Object} groupData Dados do grupo
   * @returns {Object} Grupo criado
   */
  createGroup(groupData) {
    const groupId = groupData.id || uuidv4();
    
    if (this.groups.has(groupId)) {
      throw new Error(`Grupo já existe: ${groupId}`);
    }
    
    const group = {
      id: groupId,
      name: groupData.name,
      description: groupData.description || '',
      roles: groupData.roles || [],
      directPermissions: groupData.directPermissions || [],
      parentGroups: groupData.parentGroups || [],
      metadata: groupData.metadata || {},
      createdAt: new Date().toISOString(),
      createdBy: groupData.createdBy || 'system'
    };
    
    // Validar grupo
    this._validateGroup(group);
    
    // Armazenar grupo
    this.groups.set(groupId, group);
    
    // Registrar evento de auditoria
    if (this.config.auditEnabled) {
      this._logAuditEvent({
        action: 'group_created',
        actor: groupData.createdBy || 'system',
        target: { type: 'group', id: groupId },
        details: { group }
      });
    }
    
    // Limpar cache
    if (this.config.cacheEnabled) {
      this.clearPermissionCache();
    }
    
    return cloneDeep(group);
  }

  /**
   * Atualiza um grupo existente
   * @param {string} groupId ID do grupo
   * @param {Object} groupData Novos dados do grupo
   * @returns {Object} Grupo atualizado
   */
  updateGroup(groupId, groupData) {
    if (!this.groups.has(groupId)) {
      throw new Error(`Grupo não encontrado: ${groupId}`);
    }
    
    const currentGroup = this.groups.get(groupId);
    
    // Campos que não podem ser atualizados diretamente
    const protectedFields = ['id', 'createdAt', 'createdBy'];
    
    const updatedGroup = {
      ...currentGroup,
      ...Object.fromEntries(
        Object.entries(groupData).filter(([key]) => !protectedFields.includes(key))
      ),
      updatedAt: new Date().toISOString(),
      updatedBy: groupData.updatedBy || 'system'
    };
    
    // Validar grupo
    this._validateGroup(updatedGroup);
    
    // Armazenar grupo atualizado
    this.groups.set(groupId, updatedGroup);
    
    // Registrar evento de auditoria
    if (this.config.auditEnabled) {
      this._logAuditEvent({
        action: 'group_updated',
        actor: groupData.updatedBy || 'system',
        target: { type: 'group', id: groupId },
        details: { 
          before: currentGroup,
          after: updatedGroup,
          changes: this._getChanges(currentGroup, updatedGroup)
        }
      });
    }
    
    // Limpar cache
    if (this.config.cacheEnabled) {
      this.clearPermissionCache();
    }
    
    return cloneDeep(updatedGroup);
  }

  /**
   * Adiciona um usuário a um grupo
   * @param {string} userId ID do usuário
   * @param {string} groupId ID do grupo
   * @param {Object} metadata Metadados adicionais
   * @returns {Object} Usuário atualizado
   */
  addUserToGroup(userId, groupId, metadata = {}) {
    if (!this.users.has(userId)) {
      throw new Error(`Usuário não encontrado: ${userId}`);
    }
    
    if (!this.groups.has(groupId)) {
      throw new Error(`Grupo não encontrado: ${groupId}`);
    }
    
    const user = this.users.get(userId);
    
    // Verificar se o usuário já está no grupo
    if (user.groups.includes(groupId)) {
      return cloneDeep(user);
    }
    
    // Adicionar grupo ao usuário
    user.groups.push(groupId);
    user.updatedAt = new Date().toISOString();
    user.updatedBy = metadata.actor || 'system';
    
    // Armazenar usuário atualizado
    this.users.set(userId, user);
    
    // Registrar evento de auditoria
    if (this.config.auditEnabled) {
      this._logAuditEvent({
        action: 'user_added_to_group',
        actor: metadata.actor || 'system',
        target: { type: 'user', id: userId },
        details: { 
          userId,
          groupId,
          groupName: this.groups.get(groupId).name
        }
      });
    }
    
    // Limpar cache
    if (this.config.cacheEnabled) {
      this.clearPermissionCache(userId);
    }
    
    return cloneDeep(user);
  }

  /**
   * Remove um usuário de um grupo
   * @param {string} userId ID do usuário
   * @param {string} groupId ID do grupo
   * @param {Object} metadata Metadados adicionais
   * @returns {Object} Usuário atualizado
   */
  removeUserFromGroup(userId, groupId, metadata = {}) {
    if (!this.users.has(userId)) {
      throw new Error(`Usuário não encontrado: ${userId}`);
    }
    
    const user = this.users.get(userId);
    
    // Verificar se o usuário está no grupo
    if (!user.groups.includes(groupId)) {
      return cloneDeep(user);
    }
    
    // Remover grupo do usuário
    user.groups = user.groups.filter(g => g !== groupId);
    user.updatedAt = new Date().toISOString();
    user.updatedBy = metadata.actor || 'system';
    
    // Armazenar usuário atualizado
    this.users.set(userId, user);
    
    // Registrar evento de auditoria
    if (this.config.auditEnabled) {
      this._logAuditEvent({
        action: 'user_removed_from_group',
        actor: metadata.actor || 'system',
        target: { type: 'user', id: userId },
        details: { 
          userId,
          groupId,
          groupName: this.groups.has(groupId) ? this.groups.get(groupId).name : 'unknown'
        }
      });
    }
    
    // Limpar cache
    if (this.config.cacheEnabled) {
      this.clearPermissionCache(userId);
    }
    
    return cloneDeep(user);
  }

  /**
   * Verifica se um usuário tem uma permissão específica
   * @param {string} userId ID do usuário
   * @param {string} permission Permissão a verificar
   * @param {Object} context Contexto da verificação
   * @returns {Promise<boolean>} Se o usuário tem a permissão
   */
  async hasPermission(userId, permission, context = {}) {
    if (!this.users.has(userId)) {
      return false;
    }
    
    // Verificar cache
    if (this.config.cacheEnabled) {
      const cacheKey = `${userId}:${permission}:${JSON.stringify(context)}`;
      const cachedResult = this.permissionCache.get(cacheKey);
      
      if (cachedResult && cachedResult.expiresAt > Date.now()) {
        return cachedResult.result;
      }
    }
    
    const user = this.users.get(userId);
    
    // Verificar se o usuário está ativo
    if (!user.active) {
      return false;
    }
    
    // Verificar permissões diretas do usuário
    if (user.directPermissions.includes(permission) || user.directPermissions.includes(this.config.wildcardPermission)) {
      return this._cachePermissionResult(userId, permission, context, true);
    }
    
    // Verificar papéis do usuário
    for (const roleName of user.roles) {
      if (this.roles.has(roleName)) {
        const role = this.roles.get(roleName);
        if (role.permissions.includes(permission) || role.permissions.includes(this.config.wildcardPermission)) {
          return this._cachePermissionResult(userId, permission, context, true);
        }
      }
    }
    
    // Verificar grupos do usuário (incluindo grupos aninhados)
    const allGroups = await this._getAllUserGroups(userId);
    
    for (const groupId of allGroups) {
      if (this.groups.has(groupId)) {
        const group = this.groups.get(groupId);
        
        // Verificar permissões diretas do grupo
        if (group.directPermissions.includes(permission) || group.directPermissions.includes(this.config.wildcardPermission)) {
          return this._cachePermissionResult(userId, permission, context, true);
        }
        
        // Verificar papéis do grupo
        for (const roleName of group.roles) {
          if (this.roles.has(roleName)) {
            const role = this.roles.get(roleName);
            if (role.permissions.includes(permission) || role.permissions.includes(this.config.wildcardPermission)) {
              return this._cachePermissionResult(userId, permission, context, true);
            }
          }
        }
      }
    }
    
    // Verificar permissões hierárquicas (ex: se tem 'resource:*' ou 'resource:action:*')
    const permissionParts = permission.split(this.config.permissionSeparator);
    
    if (permissionParts.length > 1) {
      // Construir permissões hierárquicas para verificar
      const hierarchicalPermissions = [];
      
      for (let i = 1; i < permissionParts.length; i++) {
        const partialPermission = [
          ...permissionParts.slice(0, i),
          this.config.wildcardPermission
        ].join(this.config.permissionSeparator);
        
        hierarchicalPermissions.push(partialPermission);
      }
      
      // Verificar cada permissão hierárquica
      for (const hierarchicalPermission of hierarchicalPermissions) {
        if (await this.hasPermission(userId, hierarchicalPermission, context)) {
          return this._cachePermissionResult(userId, permission, context, true);
        }
      }
    }
    
    return this._cachePermissionResult(userId, permission, context, false);
  }

  /**
   * Obtém todas as permissões de um usuário
   * @param {string} userId ID do usuário
   * @returns {Promise<Array>} Lista de permissões
   */
  async getUserPermissions(userId) {
    if (!this.users.has(userId)) {
      return [];
    }
    
    const user = this.users.get(userId);
    
    // Verificar se o usuário está ativo
    if (!user.active) {
      return [];
    }
    
    const allPermissions = new Set();
    
    // Adicionar permissões diretas do usuário
    for (const permission of user.directPermissions) {
      allPermissions.add(permission);
    }
    
    // Adicionar permissões dos papéis do usuário
    for (const roleName of user.roles) {
      if (this.roles.has(roleName)) {
        const role = this.roles.get(roleName);
        for (const permission of role.permissions) {
          allPermissions.add(permission);
        }
      }
    }
    
    // Adicionar permissões dos grupos do usuário (incluindo grupos aninhados)
    const allGroups = await this._getAllUserGroups(userId);
    
    for (const groupId of allGroups) {
      if (this.groups.has(groupId)) {
        const group = this.groups.get(groupId);
        
        // Adicionar permissões diretas do grupo
        for (const permission of group.directPermissions) {
          allPermissions.add(permission);
        }
        
        // Adicionar permissões dos papéis do grupo
        for (const roleName of group.roles) {
          if (this.roles.has(roleName)) {
            const role = this.roles.get(roleName);
            for (const permission of role.permissions) {
              allPermissions.add(permission);
            }
          }
        }
      }
    }
    
    // Expandir permissões com wildcard
    if (allPermissions.has(this.config.wildcardPermission)) {
      // Se tem permissão total, adicionar todas as permissões conhecidas
      for (const permission of this.permissions.keys()) {
        allPermissions.add(permission);
      }
    } else {
      // Expandir permissões hierárquicas
      const expandedPermissions = new Set(allPermissions);
      
      for (const permission of allPermissions) {
        if (permission.includes(this.config.wildcardPermission)) {
          const prefix = permission.split(this.config.wildcardPermission)[0];
          
          // Adicionar todas as permissões que começam com este prefixo
          for (const knownPermission of this.permissions.keys()) {
            if (knownPermission.startsWith(prefix)) {
              expandedPermissions.add(knownPermission);
            }
          }
        }
      }
      
      // Atualizar conjunto de permissões
      allPermissions = expandedPermissions;
    }
    
    return Array.from(allPermissions);
  }

  /**
   * Limpa o cache de permissões
   * @param {string} userId ID do usuário (opcional, para limpar apenas o cache deste usuário)
   */
  clearPermissionCache(userId = null) {
    if (!this.config.cacheEnabled) {
      return;
    }
    
    if (userId) {
      // Limpar apenas o cache do usuário específico
      for (const key of this.permissionCache.keys()) {
        if (key.startsWith(`${userId}:`)) {
          this.permissionCache.delete(key);
        }
      }
    } else {
      // Limpar todo o cache
      this.permissionCache.clear();
    }
  }

  /**
   * Obtém todos os grupos de um usuário (incluindo grupos aninhados)
   * @param {string} userId ID do usuário
   * @returns {Promise<Array>} Lista de IDs de grupos
   * @private
   */
  async _getAllUserGroups(userId) {
    if (!this.users.has(userId)) {
      return [];
    }
    
    const user = this.users.get(userId);
    const directGroups = user.groups;
    const allGroups = new Set(directGroups);
    
    // Função recursiva para adicionar grupos pais
    const addParentGroups = (groupIds) => {
      let newGroups = false;
      
      for (const groupId of groupIds) {
        if (this.groups.has(groupId)) {
          const group = this.groups.get(groupId);
          
          for (const parentGroupId of group.parentGroups) {
            if (!allGroups.has(parentGroupId)) {
              allGroups.add(parentGroupId);
              newGroups = true;
            }
          }
        }
      }
      
      // Continuar recursivamente se novos grupos foram adicionados
      if (newGroups) {
        addParentGroups(Array.from(allGroups));
      }
    };
    
    // Iniciar recursão
    addParentGroups(directGroups);
    
    return Array.from(allGroups);
  }

  /**
   * Armazena o resultado de uma verificação de permissão no cache
   * @param {string} userId ID do usuário
   * @param {string} permission Permissão verificada
   * @param {Object} context Contexto da verificação
   * @param {boolean} result Resultado da verificação
   * @returns {boolean} Resultado da verificação
   * @private
   */
  _cachePermissionResult(userId, permission, context, result) {
    if (this.config.cacheEnabled) {
      const cacheKey = `${userId}:${permission}:${JSON.stringify(context)}`;
      
      this.permissionCache.set(cacheKey, {
        result,
        expiresAt: Date.now() + this.config.cacheTTL
      });
    }
    
    return result;
  }

  /**
   * Registra um evento de auditoria
   * @param {Object} eventData Dados do evento
   * @private
   */
  _logAuditEvent(eventData) {
    const event = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      action: eventData.action,
      actor: eventData.actor,
      target: eventData.target,
      details: eventData.details,
      ip: eventData.ip,
      userAgent: eventData.userAgent
    };
    
    this.auditLogs.push(event);
    
    // Limitar tamanho do log
    if (this.auditLogs.length > 10000) {
      this.auditLogs.shift();
    }
    
    return event;
  }

  /**
   * Obtém logs de auditoria
   * @param {Object} filters Filtros para consulta
   * @returns {Array} Logs de auditoria
   */
  getAuditLogs(filters = {}) {
    let logs = this.auditLogs;
    
    // Aplicar filtros
    if (filters.action) {
      logs = logs.filter(log => log.action === filters.action);
    }
    
    if (filters.actor) {
      logs = logs.filter(log => log.actor === filters.actor);
    }
    
    if (filters.targetType) {
      logs = logs.filter(log => log.target && log.target.type === filters.targetType);
    }
    
    if (filters.targetId) {
      logs = logs.filter(log => log.target && log.target.id === filters.targetId);
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      logs = logs.filter(log => new Date(log.timestamp) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      logs = logs.filter(log => new Date(log.timestamp) <= endDate);
    }
    
    // Ordenar por timestamp (mais recente primeiro)
    logs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    // Limitar resultados
    if (filters.limit) {
      logs = logs.slice(0, filters.limit);
    }
    
    return cloneDeep(logs);
  }

  /**
   * Obtém as diferenças entre dois objetos
   * @param {Object} oldObj Objeto antigo
   * @param {Object} newObj Objeto novo
   * @returns {Object} Diferenças
   * @private
   */
  _getChanges(oldObj, newObj) {
    const changes = {};
    
    // Campos que foram adicionados ou modificados
    for (const [key, value] of Object.entries(newObj)) {
      if (key in oldObj) {
        if (JSON.stringify(oldObj[key]) !== JSON.stringify(value)) {
          changes[key] = {
            old: oldObj[key],
            new: value
          };
        }
      } else {
        changes[key] = {
          old: undefined,
          new: value
        };
      }
    }
    
    // Campos que foram removidos
    for (const key of Object.keys(oldObj)) {
      if (!(key in newObj)) {
        changes[key] = {
          old: oldObj[key],
          new: undefined
        };
      }
    }
    
    return changes;
  }

  /**
   * Sanitiza dados do usuário para logs
   * @param {Object} user Usuário
   * @returns {Object} Usuário sanitizado
   * @private
   */
  _sanitizeUserForLogs(user) {
    const sanitized = cloneDeep(user);
    
    // Remover campos sensíveis
    const sensitiveFields = ['password', 'passwordHash', 'secret', 'token'];
    
    for (const field of sensitiveFields) {
      if (field in sanitized) {
        sanitized[field] = '******';
      }
      
      if (sanitized.metadata && field in sanitized.metadata) {
        sanitized.metadata[field] = '******';
      }
    }
    
    return sanitized;
  }

  /**
   * Valida um papel
   * @param {Object} role Papel
   * @private
   */
  _validateRole(role) {
    if (!role.name) {
      throw new Error('Nome do papel é obrigatório');
    }
    
    if (!Array.isArray(role.permissions)) {
      throw new Error('Permissões do papel devem ser um array');
    }
  }

  /**
   * Valida uma permissão
   * @param {Object} permission Permissão
   * @private
   */
  _validatePermission(permission) {
    if (!permission.name) {
      throw new Error('Nome da permissão é obrigatório');
    }
    
    if (!permission.resource) {
      throw new Error('Recurso da permissão é obrigatório');
    }
    
    if (!permission.action) {
      throw new Error('Ação da permissão é obrigatória');
    }
  }

  /**
   * Valida um usuário
   * @param {Object} user Usuário
   * @private
   */
  _validateUser(user) {
    if (!user.id) {
      throw new Error('ID do usuário é obrigatório');
    }
    
    if (!user.username) {
      throw new Error('Nome de usuário é obrigatório');
    }
    
    if (!Array.isArray(user.roles)) {
      throw new Error('Papéis do usuário devem ser um array');
    }
    
    if (!Array.isArray(user.groups)) {
      throw new Error('Grupos do usuário devem ser um array');
    }
    
    if (!Array.isArray(user.directPermissions)) {
      throw new Error('Permissões diretas do usuário devem ser um array');
    }
    
    // Verificar se os papéis existem
    for (const roleName of user.roles) {
      if (!this.roles.has(roleName)) {
        throw new Error(`Papel não encontrado: ${roleName}`);
      }
    }
    
    // Verificar se os grupos existem
    for (const groupId of user.groups) {
      if (!this.groups.has(groupId)) {
        throw new Error(`Grupo não encontrado: ${groupId}`);
      }
    }
  }

  /**
   * Valida um grupo
   * @param {Object} group Grupo
   * @private
   */
  _validateGroup(group) {
    if (!group.id) {
      throw new Error('ID do grupo é obrigatório');
    }
    
    if (!group.name) {
      throw new Error('Nome do grupo é obrigatório');
    }
    
    if (!Array.isArray(group.roles)) {
      throw new Error('Papéis do grupo devem ser um array');
    }
    
    if (!Array.isArray(group.directPermissions)) {
      throw new Error('Permissões diretas do grupo devem ser um array');
    }
    
    if (!Array.isArray(group.parentGroups)) {
      throw new Error('Grupos pais devem ser um array');
    }
    
    // Verificar se os papéis existem
    for (const roleName of group.roles) {
      if (!this.roles.has(roleName)) {
        throw new Error(`Papel não encontrado: ${roleName}`);
      }
    }
    
    // Verificar se os grupos pais existem
    for (const parentGroupId of group.parentGroups) {
      if (!this.groups.has(parentGroupId)) {
        throw new Error(`Grupo pai não encontrado: ${parentGroupId}`);
      }
      
      // Verificar ciclos
      if (parentGroupId === group.id) {
        throw new Error('Um grupo não pode ser pai de si mesmo');
      }
    }
  }
}

/**
 * Classe para Gerenciamento de DLP (Data Loss Prevention)
 */
export class DlpManager {
  constructor(config = {}) {
    this.config = {
      scanEnabled: config.scanEnabled !== undefined ? config.scanEnabled : true,
      blockEnabled: config.blockEnabled !== undefined ? config.blockEnabled : true,
      logEnabled: config.logEnabled !== undefined ? config.logEnabled : true,
      alertEnabled: config.alertEnabled !== undefined ? config.alertEnabled : true,
      redactionEnabled: config.redactionEnabled !== undefined ? config.redactionEnabled : true,
      redactionChar: config.redactionChar || '*',
      sensitiveDataPatterns: config.sensitiveDataPatterns || {},
      ...config
    };

    // Armazenamento de políticas
    this.policies = new Map();
    
    // Armazenamento de regras
    this.rules = new Map();
    
    // Armazenamento de logs de violações
    this.violationLogs = [];
    
    // Armazenamento de alertas
    this.alerts = [];
    
    // Inicializar padrões de dados sensíveis
    this._initializeSensitiveDataPatterns();
    
    // Inicializar políticas padrão
    this._initializeDefaultPolicies();
  }

  /**
   * Inicializa padrões de dados sensíveis
   * @private
   */
  _initializeSensitiveDataPatterns() {
    // Mesclar padrões padrão com os fornecidos na configuração
    this.sensitiveDataPatterns = {
      // Padrões de dados pessoais
      cpf: {
        regex: /(\d{3}\.?\d{3}\.?\d{3}-?\d{2})/g,
        description: 'CPF (Cadastro de Pessoas Físicas)'
      },
      cnpj: {
        regex: /(\d{2}\.?\d{3}\.?\d{3}\/?0001-?\d{2})/g,
        description: 'CNPJ (Cadastro Nacional da Pessoa Jurídica)'
      },
      rg: {
        regex: /(\d{1,2}\.?\d{3}\.?\d{3}-?[0-9X])/g,
        description: 'RG (Registro Geral)'
      },
      email: {
        regex: /([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/g,
        description: 'Endereço de e-mail'
      },
      phone: {
        regex: /(\(?[0-9]{2}\)?\s?[0-9]{4,5}-?[0-9]{4})/g,
        description: 'Número de telefone'
      },
      
      // Padrões de dados financeiros
      credit_card: {
        regex: /(\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4})/g,
        description: 'Número de cartão de crédito'
      },
      bank_account: {
        regex: /(Ag[êe]ncia:?\s*\d{1,5}[-\s]?\d{0,1}\s*(?:\/|,|\.|\s+)?\s*C(?:\/|[oô]n)?(?:ta)?:?\s*\d{5,15}[-\s]?\d{0,1})/gi,
        description: 'Conta bancária'
      },
      
      // Padrões de dados de saúde
      health_info: {
        regex: /(CID-?10:?\s*[A-Z]\d{2}(?:\.\d{1,2})?)/g,
        description: 'Informação de saúde (CID)'
      },
      
      // Padrões de credenciais
      password: {
        regex: /(senha|password|passcode|passphrase|secret)[\s:=]+\S+/gi,
        description: 'Senha ou credencial'
      },
      api_key: {
        regex: /(api[_-]?key|access[_-]?key|secret[_-]?key|token)[\s:=]+\S+/gi,
        description: 'Chave de API ou token'
      },
      
      ...this.config.sensitiveDataPatterns
    };
  }

  /**
   * Inicializa políticas padrão
   * @private
   */
  _initializeDefaultPolicies() {
    // Política para dados pessoais
    this.createPolicy({
      name: 'personal_data_protection',
      description: 'Proteção de dados pessoais',
      enabled: true,
      severity: 'high',
      dataTypes: ['cpf', 'cnpj', 'rg', 'email', 'phone'],
      actions: ['log', 'alert', 'redact'],
      isSystem: true
    });
    
    // Política para dados financeiros
    this.createPolicy({
      name: 'financial_data_protection',
      description: 'Proteção de dados financeiros',
      enabled: true,
      severity: 'critical',
      dataTypes: ['credit_card', 'bank_account'],
      actions: ['log', 'alert', 'block', 'redact'],
      isSystem: true
    });
    
    // Política para dados de saúde
    this.createPolicy({
      name: 'health_data_protection',
      description: 'Proteção de dados de saúde',
      enabled: true,
      severity: 'high',
      dataTypes: ['health_info'],
      actions: ['log', 'alert', 'redact'],
      isSystem: true
    });
    
    // Política para credenciais
    this.createPolicy({
      name: 'credentials_protection',
      description: 'Proteção de credenciais',
      enabled: true,
      severity: 'critical',
      dataTypes: ['password', 'api_key'],
      actions: ['log', 'alert', 'block', 'redact'],
      isSystem: true
    });
  }

  /**
   * Cria uma nova política de DLP
   * @param {Object} policyData Dados da política
   * @returns {Object} Política criada
   */
  createPolicy(policyData) {
    const policyName = policyData.name.toLowerCase();
    
    if (this.policies.has(policyName)) {
      throw new Error(`Política já existe: ${policyName}`);
    }
    
    const policy = {
      name: policyName,
      description: policyData.description || '',
      enabled: policyData.enabled !== undefined ? policyData.enabled : true,
      severity: policyData.severity || 'medium', // 'low', 'medium', 'high', 'critical'
      dataTypes: policyData.dataTypes || [],
      actions: policyData.actions || ['log'],
      exceptions: policyData.exceptions || [],
      isSystem: policyData.isSystem || false,
      metadata: policyData.metadata || {},
      createdAt: new Date().toISOString(),
      createdBy: policyData.createdBy || 'system'
    };
    
    // Validar política
    this._validatePolicy(policy);
    
    // Armazenar política
    this.policies.set(policyName, policy);
    
    return cloneDeep(policy);
  }

  /**
   * Atualiza uma política existente
   * @param {string} policyName Nome da política
   * @param {Object} policyData Novos dados da política
   * @returns {Object} Política atualizada
   */
  updatePolicy(policyName, policyData) {
    policyName = policyName.toLowerCase();
    
    if (!this.policies.has(policyName)) {
      throw new Error(`Política não encontrada: ${policyName}`);
    }
    
    const currentPolicy = this.policies.get(policyName);
    
    // Verificar se é uma política do sistema
    if (currentPolicy.isSystem && (
      policyData.dataTypes !== undefined ||
      policyData.actions !== undefined ||
      policyData.name !== undefined
    )) {
      throw new Error(`Não é possível modificar tipos de dados ou ações de uma política do sistema: ${policyName}`);
    }
    
    // Campos que não podem ser atualizados diretamente
    const protectedFields = ['name', 'isSystem', 'createdAt', 'createdBy'];
    
    const updatedPolicy = {
      ...currentPolicy,
      ...Object.fromEntries(
        Object.entries(policyData).filter(([key]) => !protectedFields.includes(key))
      ),
      updatedAt: new Date().toISOString(),
      updatedBy: policyData.updatedBy || 'system'
    };
    
    // Validar política
    this._validatePolicy(updatedPolicy);
    
    // Armazenar política atualizada
    this.policies.set(policyName, updatedPolicy);
    
    return cloneDeep(updatedPolicy);
  }

  /**
   * Cria uma nova regra de DLP
   * @param {Object} ruleData Dados da regra
   * @returns {Object} Regra criada
   */
  createRule(ruleData) {
    const ruleId = ruleData.id || uuidv4();
    
    if (this.rules.has(ruleId)) {
      throw new Error(`Regra já existe: ${ruleId}`);
    }
    
    const rule = {
      id: ruleId,
      name: ruleData.name,
      description: ruleData.description || '',
      enabled: ruleData.enabled !== undefined ? ruleData.enabled : true,
      policies: ruleData.policies || [],
      conditions: ruleData.conditions || [],
      priority: ruleData.priority || 100,
      metadata: ruleData.metadata || {},
      createdAt: new Date().toISOString(),
      createdBy: ruleData.createdBy || 'system'
    };
    
    // Validar regra
    this._validateRule(rule);
    
    // Armazenar regra
    this.rules.set(ruleId, rule);
    
    return cloneDeep(rule);
  }

  /**
   * Atualiza uma regra existente
   * @param {string} ruleId ID da regra
   * @param {Object} ruleData Novos dados da regra
   * @returns {Object} Regra atualizada
   */
  updateRule(ruleId, ruleData) {
    if (!this.rules.has(ruleId)) {
      throw new Error(`Regra não encontrada: ${ruleId}`);
    }
    
    const currentRule = this.rules.get(ruleId);
    
    // Campos que não podem ser atualizados diretamente
    const protectedFields = ['id', 'createdAt', 'createdBy'];
    
    const updatedRule = {
      ...currentRule,
      ...Object.fromEntries(
        Object.entries(ruleData).filter(([key]) => !protectedFields.includes(key))
      ),
      updatedAt: new Date().toISOString(),
      updatedBy: ruleData.updatedBy || 'system'
    };
    
    // Validar regra
    this._validateRule(updatedRule);
    
    // Armazenar regra atualizada
    this.rules.set(ruleId, updatedRule);
    
    return cloneDeep(updatedRule);
  }

  /**
   * Escaneia dados em busca de informações sensíveis
   * @param {string|Object} data Dados a serem escaneados
   * @param {Object} context Contexto do escaneamento
   * @returns {Promise<Object>} Resultado do escaneamento
   */
  async scanData(data, context = {}) {
    if (!this.config.scanEnabled) {
      return { violations: [], actions: [] };
    }
    
    // Converter objeto para string, se necessário
    const dataString = typeof data === 'string' ? data : JSON.stringify(data);
    
    // Encontrar regras aplicáveis ao contexto
    const applicableRules = this._getApplicableRules(context);
    
    if (applicableRules.length === 0) {
      return { violations: [], actions: [] };
    }
    
    // Coletar políticas das regras aplicáveis
    const policies = new Set();
    for (const rule of applicableRules) {
      for (const policyName of rule.policies) {
        if (this.policies.has(policyName)) {
          const policy = this.policies.get(policyName);
          if (policy.enabled) {
            policies.add(policy);
          }
        }
      }
    }
    
    // Escanear dados para cada política
    const violations = [];
    const actions = new Set();
    
    for (const policy of policies) {
      // Verificar exceções
      if (this._matchesExceptions(dataString, policy.exceptions, context)) {
        continue;
      }
      
      // Escanear para cada tipo de dado sensível
      for (const dataType of policy.dataTypes) {
        if (this.sensitiveDataPatterns[dataType]) {
          const pattern = this.sensitiveDataPatterns[dataType];
          const matches = this._findMatches(dataString, pattern.regex);
          
          if (matches.length > 0) {
            // Criar violação
            const violation = {
              id: uuidv4(),
              policyName: policy.name,
              dataType,
              severity: policy.severity,
              matches,
              timestamp: new Date().toISOString(),
              context: {
                ...context,
                dataLength: dataString.length
              }
            };
            
            violations.push(violation);
            
            // Coletar ações
            for (const action of policy.actions) {
              actions.add(action);
            }
            
            // Registrar violação
            if (policy.actions.includes('log') && this.config.logEnabled) {
              this._logViolation(violation);
            }
            
            // Criar alerta
            if (policy.actions.includes('alert') && this.config.alertEnabled) {
              this._createAlert(violation);
            }
          }
        }
      }
    }
    
    return {
      violations,
      actions: Array.from(actions)
    };
  }

  /**
   * Processa dados de acordo com as políticas de DLP
   * @param {string|Object} data Dados a serem processados
   * @param {Object} context Contexto do processamento
   * @returns {Promise<Object>} Resultado do processamento
   */
  async processData(data, context = {}) {
    // Escanear dados
    const scanResult = await this.scanData(data, context);
    
    // Se não houver violações, retornar dados originais
    if (scanResult.violations.length === 0) {
      return {
        data,
        processed: false,
        blocked: false,
        violations: []
      };
    }
    
    // Verificar se deve bloquear
    const shouldBlock = scanResult.actions.includes('block') && this.config.blockEnabled;
    
    // Verificar se deve redactar
    const shouldRedact = scanResult.actions.includes('redact') && this.config.redactionEnabled;
    
    // Se deve bloquear, retornar sem dados
    if (shouldBlock) {
      return {
        data: null,
        processed: true,
        blocked: true,
        violations: scanResult.violations
      };
    }
    
    // Se deve redactar, aplicar redação
    if (shouldRedact) {
      let processedData = data;
      
      if (typeof data === 'string') {
        // Redactar string
        processedData = this._redactString(data, scanResult.violations);
      } else {
        // Redactar objeto
        const dataString = JSON.stringify(data);
        const redactedString = this._redactString(dataString, scanResult.violations);
        
        try {
          processedData = JSON.parse(redactedString);
        } catch (error) {
          // Se não for possível analisar o JSON redactado, usar a string
          processedData = redactedString;
        }
      }
      
      return {
        data: processedData,
        processed: true,
        blocked: false,
        violations: scanResult.violations
      };
    }
    
    // Se não deve bloquear nem redactar, retornar dados originais
    return {
      data,
      processed: false,
      blocked: false,
      violations: scanResult.violations
    };
  }

  /**
   * Obtém logs de violações
   * @param {Object} filters Filtros para consulta
   * @returns {Array} Logs de violações
   */
  getViolationLogs(filters = {}) {
    let logs = this.violationLogs;
    
    // Aplicar filtros
    if (filters.policyName) {
      logs = logs.filter(log => log.policyName === filters.policyName);
    }
    
    if (filters.dataType) {
      logs = logs.filter(log => log.dataType === filters.dataType);
    }
    
    if (filters.severity) {
      logs = logs.filter(log => log.severity === filters.severity);
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      logs = logs.filter(log => new Date(log.timestamp) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      logs = logs.filter(log => new Date(log.timestamp) <= endDate);
    }
    
    // Ordenar por timestamp (mais recente primeiro)
    logs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    // Limitar resultados
    if (filters.limit) {
      logs = logs.slice(0, filters.limit);
    }
    
    return cloneDeep(logs);
  }

  /**
   * Obtém alertas
   * @param {Object} filters Filtros para consulta
   * @returns {Array} Alertas
   */
  getAlerts(filters = {}) {
    let alerts = this.alerts;
    
    // Aplicar filtros
    if (filters.policyName) {
      alerts = alerts.filter(alert => alert.policyName === filters.policyName);
    }
    
    if (filters.dataType) {
      alerts = alerts.filter(alert => alert.dataType === filters.dataType);
    }
    
    if (filters.severity) {
      alerts = alerts.filter(alert => alert.severity === filters.severity);
    }
    
    if (filters.status) {
      alerts = alerts.filter(alert => alert.status === filters.status);
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      alerts = alerts.filter(alert => new Date(alert.timestamp) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      alerts = alerts.filter(alert => new Date(alert.timestamp) <= endDate);
    }
    
    // Ordenar por timestamp (mais recente primeiro)
    alerts.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    // Limitar resultados
    if (filters.limit) {
      alerts = alerts.slice(0, filters.limit);
    }
    
    return cloneDeep(alerts);
  }

  /**
   * Atualiza o status de um alerta
   * @param {string} alertId ID do alerta
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @returns {Object} Alerta atualizado
   */
  updateAlertStatus(alertId, status, metadata = {}) {
    const alertIndex = this.alerts.findIndex(alert => alert.id === alertId);
    
    if (alertIndex === -1) {
      throw new Error(`Alerta não encontrado: ${alertId}`);
    }
    
    const alert = this.alerts[alertIndex];
    
    // Validar status
    if (!['open', 'acknowledged', 'resolved', 'false_positive'].includes(status)) {
      throw new Error(`Status inválido: ${status}`);
    }
    
    // Atualizar status
    alert.status = status;
    alert.updatedAt = new Date().toISOString();
    alert.updatedBy = metadata.actor || 'system';
    alert.notes = metadata.notes || alert.notes;
    
    // Armazenar alerta atualizado
    this.alerts[alertIndex] = alert;
    
    return cloneDeep(alert);
  }

  /**
   * Obtém regras aplicáveis a um contexto
   * @param {Object} context Contexto
   * @returns {Array} Regras aplicáveis
   * @private
   */
  _getApplicableRules(context) {
    // Filtrar regras habilitadas
    const enabledRules = Array.from(this.rules.values())
      .filter(rule => rule.enabled);
    
    // Filtrar regras que correspondem às condições do contexto
    const applicableRules = enabledRules.filter(rule => {
      // Se não houver condições, a regra é sempre aplicável
      if (!rule.conditions || rule.conditions.length === 0) {
        return true;
      }
      
      // Verificar cada condição
      return rule.conditions.every(condition => {
        const contextValue = get(context, condition.field);
        
        switch (condition.operator) {
          case 'equals':
            return contextValue === condition.value;
          case 'not_equals':
            return contextValue !== condition.value;
          case 'contains':
            return typeof contextValue === 'string' && contextValue.includes(condition.value);
          case 'not_contains':
            return typeof contextValue !== 'string' || !contextValue.includes(condition.value);
          case 'starts_with':
            return typeof contextValue === 'string' && contextValue.startsWith(condition.value);
          case 'ends_with':
            return typeof contextValue === 'string' && contextValue.endsWith(condition.value);
          case 'greater_than':
            return contextValue > condition.value;
          case 'less_than':
            return contextValue < condition.value;
          case 'in':
            return Array.isArray(condition.value) && condition.value.includes(contextValue);
          case 'not_in':
            return !Array.isArray(condition.value) || !condition.value.includes(contextValue);
          case 'exists':
            return contextValue !== undefined && contextValue !== null;
          case 'not_exists':
            return contextValue === undefined || contextValue === null;
          default:
            return false;
        }
      });
    });
    
    // Ordenar por prioridade (menor número = maior prioridade)
    return applicableRules.sort((a, b) => a.priority - b.priority);
  }

  /**
   * Verifica se os dados correspondem a alguma exceção
   * @param {string} data Dados
   * @param {Array} exceptions Exceções
   * @param {Object} context Contexto
   * @returns {boolean} Se corresponde a alguma exceção
   * @private
   */
  _matchesExceptions(data, exceptions, context) {
    if (!exceptions || exceptions.length === 0) {
      return false;
    }
    
    return exceptions.some(exception => {
      // Verificar condições de contexto
      if (exception.conditions) {
        const contextMatches = exception.conditions.every(condition => {
          const contextValue = get(context, condition.field);
          
          switch (condition.operator) {
            case 'equals':
              return contextValue === condition.value;
            case 'not_equals':
              return contextValue !== condition.value;
            case 'contains':
              return typeof contextValue === 'string' && contextValue.includes(condition.value);
            case 'not_contains':
              return typeof contextValue !== 'string' || !contextValue.includes(condition.value);
            case 'starts_with':
              return typeof contextValue === 'string' && contextValue.startsWith(condition.value);
            case 'ends_with':
              return typeof contextValue === 'string' && contextValue.endsWith(condition.value);
            case 'greater_than':
              return contextValue > condition.value;
            case 'less_than':
              return contextValue < condition.value;
            case 'in':
              return Array.isArray(condition.value) && condition.value.includes(contextValue);
            case 'not_in':
              return !Array.isArray(condition.value) || !condition.value.includes(contextValue);
            case 'exists':
              return contextValue !== undefined && contextValue !== null;
            case 'not_exists':
              return contextValue === undefined || contextValue === null;
            default:
              return false;
          }
        });
        
        if (!contextMatches) {
          return false;
        }
      }
      
      // Verificar padrão
      if (exception.pattern) {
        try {
          const regex = new RegExp(exception.pattern, exception.flags || 'g');
          return regex.test(data);
        } catch (error) {
          console.error(`Erro ao compilar regex de exceção: ${error.message}`);
          return false;
        }
      }
      
      // Verificar valor exato
      if (exception.value) {
        return data === exception.value;
      }
      
      return false;
    });
  }

  /**
   * Encontra correspondências de um padrão em dados
   * @param {string} data Dados
   * @param {RegExp} pattern Padrão
   * @returns {Array} Correspondências
   * @private
   */
  _findMatches(data, pattern) {
    const matches = [];
    let match;
    
    // Resetar regex para garantir que todas as correspondências sejam encontradas
    pattern.lastIndex = 0;
    
    while ((match = pattern.exec(data)) !== null) {
      matches.push({
        value: match[0],
        index: match.index,
        length: match[0].length
      });
    }
    
    return matches;
  }

  /**
   * Redacta informações sensíveis em uma string
   * @param {string} data String a ser redactada
   * @param {Array} violations Violações
   * @returns {string} String redactada
   * @private
   */
  _redactString(data, violations) {
    // Ordenar correspondências por índice (decrescente)
    // Isso garante que a substituição não afete os índices de outras correspondências
    const allMatches = violations.flatMap(violation => violation.matches)
      .sort((a, b) => b.index - a.index);
    
    let redactedData = data;
    
    for (const match of allMatches) {
      const redactedValue = this.config.redactionChar.repeat(match.length);
      redactedData = redactedData.substring(0, match.index) + redactedValue + redactedData.substring(match.index + match.length);
    }
    
    return redactedData;
  }

  /**
   * Registra uma violação
   * @param {Object} violation Violação
   * @private
   */
  _logViolation(violation) {
    this.violationLogs.push(violation);
    
    // Limitar tamanho do log
    if (this.violationLogs.length > 10000) {
      this.violationLogs.shift();
    }
  }

  /**
   * Cria um alerta
   * @param {Object} violation Violação
   * @private
   */
  _createAlert(violation) {
    const alert = {
      id: uuidv4(),
      violationId: violation.id,
      policyName: violation.policyName,
      dataType: violation.dataType,
      severity: violation.severity,
      timestamp: new Date().toISOString(),
      status: 'open',
      context: violation.context,
      matchCount: violation.matches.length
    };
    
    this.alerts.push(alert);
    
    // Limitar tamanho dos alertas
    if (this.alerts.length > 10000) {
      this.alerts.shift();
    }
    
    return alert;
  }

  /**
   * Valida uma política
   * @param {Object} policy Política
   * @private
   */
  _validatePolicy(policy) {
    if (!policy.name) {
      throw new Error('Nome da política é obrigatório');
    }
    
    if (!Array.isArray(policy.dataTypes) || policy.dataTypes.length === 0) {
      throw new Error('Pelo menos um tipo de dado deve ser especificado');
    }
    
    if (!Array.isArray(policy.actions) || policy.actions.length === 0) {
      throw new Error('Pelo menos uma ação deve ser especificada');
    }
    
    // Verificar se os tipos de dados existem
    for (const dataType of policy.dataTypes) {
      if (!this.sensitiveDataPatterns[dataType]) {
        throw new Error(`Tipo de dado não encontrado: ${dataType}`);
      }
    }
    
    // Verificar se as ações são válidas
    const validActions = ['log', 'alert', 'block', 'redact'];
    for (const action of policy.actions) {
      if (!validActions.includes(action)) {
        throw new Error(`Ação inválida: ${action}`);
      }
    }
    
    // Verificar severidade
    const validSeverities = ['low', 'medium', 'high', 'critical'];
    if (!validSeverities.includes(policy.severity)) {
      throw new Error(`Severidade inválida: ${policy.severity}`);
    }
  }

  /**
   * Valida uma regra
   * @param {Object} rule Regra
   * @private
   */
  _validateRule(rule) {
    if (!rule.id) {
      throw new Error('ID da regra é obrigatório');
    }
    
    if (!rule.name) {
      throw new Error('Nome da regra é obrigatório');
    }
    
    if (!Array.isArray(rule.policies) || rule.policies.length === 0) {
      throw new Error('Pelo menos uma política deve ser especificada');
    }
    
    // Verificar se as políticas existem
    for (const policyName of rule.policies) {
      if (!this.policies.has(policyName)) {
        throw new Error(`Política não encontrada: ${policyName}`);
      }
    }
    
    // Verificar condições
    if (rule.conditions) {
      for (const condition of rule.conditions) {
        if (!condition.field) {
          throw new Error('Campo da condição é obrigatório');
        }
        
        if (!condition.operator) {
          throw new Error('Operador da condição é obrigatório');
        }
        
        // Verificar operador
        const validOperators = [
          'equals', 'not_equals', 'contains', 'not_contains',
          'starts_with', 'ends_with', 'greater_than', 'less_than',
          'in', 'not_in', 'exists', 'not_exists'
        ];
        
        if (!validOperators.includes(condition.operator)) {
          throw new Error(`Operador inválido: ${condition.operator}`);
        }
        
        // Verificar valor (exceto para operadores exists/not_exists)
        if (!['exists', 'not_exists'].includes(condition.operator) && condition.value === undefined) {
          throw new Error(`Valor da condição é obrigatório para o operador ${condition.operator}`);
        }
      }
    }
  }
}

/**
 * Serviço Integrado de RBAC e DLP
 */
export class RbacDlpService {
  constructor(config = {}) {
    this.rbacManager = new RbacManager(config.rbac);
    this.dlpManager = new DlpManager(config.dlp);
  }

  /**
   * Verifica se um usuário tem permissão para acessar um recurso
   * @param {string} userId ID do usuário
   * @param {string} permission Permissão necessária
   * @param {Object} context Contexto da verificação
   * @returns {Promise<boolean>} Se o usuário tem permissão
   */
  async checkPermission(userId, permission, context = {}) {
    return this.rbacManager.hasPermission(userId, permission, context);
  }

  /**
   * Processa dados de acordo com as políticas de DLP
   * @param {string|Object} data Dados a serem processados
   * @param {Object} context Contexto do processamento
   * @returns {Promise<Object>} Resultado do processamento
   */
  async processData(data, context = {}) {
    return this.dlpManager.processData(data, context);
  }

  /**
   * Verifica se um usuário tem permissão para acessar dados e processa os dados de acordo com as políticas de DLP
   * @param {string} userId ID do usuário
   * @param {string} permission Permissão necessária
   * @param {string|Object} data Dados a serem processados
   * @param {Object} context Contexto da verificação e processamento
   * @returns {Promise<Object>} Resultado da verificação e processamento
   */
  async checkAndProcessData(userId, permission, data, context = {}) {
    // Verificar permissão
    const hasPermission = await this.rbacManager.hasPermission(userId, permission, context);
    
    if (!hasPermission) {
      return {
        allowed: false,
        data: null,
        processed: false,
        blocked: false,
        violations: []
      };
    }
    
    // Processar dados
    const processResult = await this.dlpManager.processData(data, {
      ...context,
      userId,
      permission
    });
    
    return {
      allowed: true,
      ...processResult
    };
  }

  /**
   * Cria um novo papel (role)
   * @param {Object} roleData Dados do papel
   * @returns {Object} Papel criado
   */
  createRole(roleData) {
    return this.rbacManager.createRole(roleData);
  }

  /**
   * Cria um novo usuário
   * @param {Object} userData Dados do usuário
   * @returns {Object} Usuário criado
   */
  createUser(userData) {
    return this.rbacManager.createUser(userData);
  }

  /**
   * Cria uma nova política de DLP
   * @param {Object} policyData Dados da política
   * @returns {Object} Política criada
   */
  createDlpPolicy(policyData) {
    return this.dlpManager.createPolicy(policyData);
  }

  /**
   * Obtém logs de auditoria do RBAC
   * @param {Object} filters Filtros para consulta
   * @returns {Array} Logs de auditoria
   */
  getRbacAuditLogs(filters = {}) {
    return this.rbacManager.getAuditLogs(filters);
  }

  /**
   * Obtém logs de violações do DLP
   * @param {Object} filters Filtros para consulta
   * @returns {Array} Logs de violações
   */
  getDlpViolationLogs(filters = {}) {
    return this.dlpManager.getViolationLogs(filters);
  }

  /**
   * Obtém alertas do DLP
   * @param {Object} filters Filtros para consulta
   * @returns {Array} Alertas
   */
  getDlpAlerts(filters = {}) {
    return this.dlpManager.getAlerts(filters);
  }
}

export default RbacDlpService;
