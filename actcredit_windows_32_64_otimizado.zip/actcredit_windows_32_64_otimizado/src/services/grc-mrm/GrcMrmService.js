/**
 * Serviço de Governança, Risco e Conformidade (GRC) e Gestão do Ciclo de Vida de Modelos (MRM)
 * Implementa funcionalidades para governança avançada, gestão de riscos, conformidade regulatória
 * e gestão completa do ciclo de vida de modelos de machine learning.
 */

import { v4 as uuidv4 } from 'uuid';
import { cloneDeep, get, set, merge } from 'lodash';

/**
 * Classe para Gestão do Ciclo de Vida de Modelos (MRM)
 */
export class ModelLifecycleManager {
  constructor(config = {}) {
    this.config = {
      storageMethod: config.storageMethod || 'memory', // 'memory', 'database'
      modelVersioningEnabled: config.modelVersioningEnabled !== undefined ? config.modelVersioningEnabled : true,
      approvalWorkflowEnabled: config.approvalWorkflowEnabled !== undefined ? config.approvalWorkflowEnabled : true,
      monitoringFrequency: config.monitoringFrequency || 'daily', // 'hourly', 'daily', 'weekly', 'monthly'
      ...config
    };

    // Armazenamento de modelos
    this.models = new Map();
    
    // Armazenamento de versões de modelos
    this.modelVersions = new Map();
    
    // Armazenamento de métricas de modelos
    this.modelMetrics = new Map();
    
    // Armazenamento de alertas de modelos
    this.modelAlerts = new Map();
  }

  /**
   * Registra um novo modelo
   * @param {Object} modelData Dados do modelo
   * @returns {Promise<Object>} Modelo registrado
   */
  async registerModel(modelData) {
    const modelId = modelData.id || uuidv4();
    
    const model = {
      id: modelId,
      name: modelData.name,
      description: modelData.description || '',
      type: modelData.type, // 'classification', 'regression', 'clustering', 'ranking', etc.
      algorithm: modelData.algorithm,
      features: modelData.features || [],
      target: modelData.target,
      owner: modelData.owner,
      team: modelData.team || [],
      tags: modelData.tags || [],
      status: 'draft', // 'draft', 'in_review', 'approved', 'deployed', 'deprecated', 'archived'
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      metadata: modelData.metadata || {}
    };
    
    // Validar modelo
    this._validateModel(model);
    
    // Armazenar modelo
    this.models.set(modelId, model);
    
    // Criar primeira versão do modelo
    if (this.config.modelVersioningEnabled) {
      await this.createModelVersion(modelId, {
        versionNumber: '0.1.0',
        description: 'Initial draft version',
        artifacts: modelData.artifacts || {},
        hyperparameters: modelData.hyperparameters || {},
        metrics: modelData.metrics || {}
      });
    }
    
    return cloneDeep(model);
  }

  /**
   * Atualiza um modelo existente
   * @param {string} modelId ID do modelo
   * @param {Object} modelData Novos dados do modelo
   * @returns {Promise<Object>} Modelo atualizado
   */
  async updateModel(modelId, modelData) {
    if (!this.models.has(modelId)) {
      throw new Error(`Modelo não encontrado: ${modelId}`);
    }
    
    const currentModel = this.models.get(modelId);
    
    // Campos que não podem ser atualizados diretamente
    const protectedFields = ['id', 'createdAt', 'status'];
    
    const updatedModel = {
      ...currentModel,
      ...Object.fromEntries(
        Object.entries(modelData).filter(([key]) => !protectedFields.includes(key))
      ),
      updatedAt: new Date().toISOString()
    };
    
    // Validar modelo
    this._validateModel(updatedModel);
    
    // Armazenar modelo atualizado
    this.models.set(modelId, updatedModel);
    
    return cloneDeep(updatedModel);
  }

  /**
   * Atualiza o status de um modelo
   * @param {string} modelId ID do modelo
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @returns {Promise<Object>} Modelo atualizado
   */
  async updateModelStatus(modelId, status, metadata = {}) {
    if (!this.models.has(modelId)) {
      throw new Error(`Modelo não encontrado: ${modelId}`);
    }
    
    const model = this.models.get(modelId);
    
    // Validar transição de status
    this._validateStatusTransition(model.status, status);
    
    // Atualizar status
    model.status = status;
    model.updatedAt = new Date().toISOString();
    
    // Adicionar metadados específicos do status
    if (status === 'in_review') {
      model.reviewStartedAt = new Date().toISOString();
      model.reviewers = metadata.reviewers || [];
    } else if (status === 'approved') {
      model.approvedAt = new Date().toISOString();
      model.approvedBy = metadata.approvedBy;
      model.approvalNotes = metadata.approvalNotes;
    } else if (status === 'deployed') {
      model.deployedAt = new Date().toISOString();
      model.deployedBy = metadata.deployedBy;
      model.deploymentEnvironment = metadata.deploymentEnvironment;
    } else if (status === 'deprecated') {
      model.deprecatedAt = new Date().toISOString();
      model.deprecatedBy = metadata.deprecatedBy;
      model.deprecationReason = metadata.deprecationReason;
    } else if (status === 'archived') {
      model.archivedAt = new Date().toISOString();
      model.archivedBy = metadata.archivedBy;
      model.archivalReason = metadata.archivalReason;
    }
    
    // Atualizar metadados
    model.metadata = {
      ...model.metadata,
      ...metadata
    };
    
    // Armazenar modelo atualizado
    this.models.set(modelId, model);
    
    return cloneDeep(model);
  }

  /**
   * Cria uma nova versão de um modelo
   * @param {string} modelId ID do modelo
   * @param {Object} versionData Dados da versão
   * @returns {Promise<Object>} Versão do modelo
   */
  async createModelVersion(modelId, versionData) {
    if (!this.models.has(modelId)) {
      throw new Error(`Modelo não encontrado: ${modelId}`);
    }
    
    const model = this.models.get(modelId);
    
    // Gerar ID da versão
    const versionId = uuidv4();
    
    // Criar versão
    const version = {
      id: versionId,
      modelId,
      versionNumber: versionData.versionNumber,
      description: versionData.description || '',
      artifacts: versionData.artifacts || {},
      hyperparameters: versionData.hyperparameters || {},
      metrics: versionData.metrics || {},
      status: 'draft', // 'draft', 'in_review', 'approved', 'deployed', 'deprecated'
      createdAt: new Date().toISOString(),
      createdBy: versionData.createdBy || model.owner,
      metadata: versionData.metadata || {}
    };
    
    // Validar versão
    this._validateModelVersion(version);
    
    // Armazenar versão
    if (!this.modelVersions.has(modelId)) {
      this.modelVersions.set(modelId, new Map());
    }
    
    this.modelVersions.get(modelId).set(versionId, version);
    
    // Atualizar modelo com referência à nova versão
    model.latestVersionId = versionId;
    model.latestVersionNumber = versionData.versionNumber;
    model.updatedAt = new Date().toISOString();
    
    // Armazenar modelo atualizado
    this.models.set(modelId, model);
    
    return cloneDeep(version);
  }

  /**
   * Atualiza o status de uma versão de modelo
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @returns {Promise<Object>} Versão atualizada
   */
  async updateModelVersionStatus(modelId, versionId, status, metadata = {}) {
    if (!this.modelVersions.has(modelId) || !this.modelVersions.get(modelId).has(versionId)) {
      throw new Error(`Versão de modelo não encontrada: ${modelId}/${versionId}`);
    }
    
    const version = this.modelVersions.get(modelId).get(versionId);
    
    // Validar transição de status
    this._validateVersionStatusTransition(version.status, status);
    
    // Atualizar status
    version.status = status;
    version.updatedAt = new Date().toISOString();
    
    // Adicionar metadados específicos do status
    if (status === 'in_review') {
      version.reviewStartedAt = new Date().toISOString();
      version.reviewers = metadata.reviewers || [];
    } else if (status === 'approved') {
      version.approvedAt = new Date().toISOString();
      version.approvedBy = metadata.approvedBy;
      version.approvalNotes = metadata.approvalNotes;
    } else if (status === 'deployed') {
      version.deployedAt = new Date().toISOString();
      version.deployedBy = metadata.deployedBy;
      version.deploymentEnvironment = metadata.deploymentEnvironment;
    } else if (status === 'deprecated') {
      version.deprecatedAt = new Date().toISOString();
      version.deprecatedBy = metadata.deprecatedBy;
      version.deprecationReason = metadata.deprecationReason;
    }
    
    // Atualizar metadados
    version.metadata = {
      ...version.metadata,
      ...metadata
    };
    
    // Armazenar versão atualizada
    this.modelVersions.get(modelId).set(versionId, version);
    
    // Se a versão foi aprovada ou implantada, atualizar o modelo
    if (status === 'approved' || status === 'deployed') {
      const model = this.models.get(modelId);
      
      if (status === 'deployed') {
        model.productionVersionId = versionId;
        model.productionVersionNumber = version.versionNumber;
        
        // Atualizar status do modelo para 'deployed' se ainda não estiver
        if (model.status !== 'deployed') {
          await this.updateModelStatus(modelId, 'deployed', {
            deployedBy: metadata.deployedBy,
            deploymentEnvironment: metadata.deploymentEnvironment
          });
        }
      }
      
      // Armazenar modelo atualizado
      this.models.set(modelId, model);
    }
    
    return cloneDeep(version);
  }

  /**
   * Registra métricas para um modelo
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão
   * @param {Object} metricsData Dados das métricas
   * @returns {Promise<Object>} Métricas registradas
   */
  async registerModelMetrics(modelId, versionId, metricsData) {
    if (!this.models.has(modelId)) {
      throw new Error(`Modelo não encontrado: ${modelId}`);
    }
    
    if (versionId && (!this.modelVersions.has(modelId) || !this.modelVersions.get(modelId).has(versionId))) {
      throw new Error(`Versão de modelo não encontrada: ${modelId}/${versionId}`);
    }
    
    // Gerar ID das métricas
    const metricsId = uuidv4();
    
    // Criar métricas
    const metrics = {
      id: metricsId,
      modelId,
      versionId,
      timestamp: new Date().toISOString(),
      environment: metricsData.environment || 'development', // 'development', 'staging', 'production'
      metrics: metricsData.metrics || {},
      datasetInfo: metricsData.datasetInfo || {},
      createdBy: metricsData.createdBy,
      metadata: metricsData.metadata || {}
    };
    
    // Armazenar métricas
    if (!this.modelMetrics.has(modelId)) {
      this.modelMetrics.set(modelId, new Map());
    }
    
    this.modelMetrics.get(modelId).set(metricsId, metrics);
    
    // Atualizar versão do modelo com as métricas mais recentes
    if (versionId) {
      const version = this.modelVersions.get(modelId).get(versionId);
      version.latestMetrics = metrics.metrics;
      version.updatedAt = new Date().toISOString();
      
      // Armazenar versão atualizada
      this.modelVersions.get(modelId).set(versionId, version);
    }
    
    return cloneDeep(metrics);
  }

  /**
   * Cria um alerta para um modelo
   * @param {string} modelId ID do modelo
   * @param {Object} alertData Dados do alerta
   * @returns {Promise<Object>} Alerta criado
   */
  async createModelAlert(modelId, alertData) {
    if (!this.models.has(modelId)) {
      throw new Error(`Modelo não encontrado: ${modelId}`);
    }
    
    // Gerar ID do alerta
    const alertId = uuidv4();
    
    // Criar alerta
    const alert = {
      id: alertId,
      modelId,
      versionId: alertData.versionId,
      type: alertData.type, // 'drift', 'performance_degradation', 'error', 'warning', 'info'
      severity: alertData.severity || 'medium', // 'low', 'medium', 'high', 'critical'
      title: alertData.title,
      description: alertData.description || '',
      metrics: alertData.metrics || {},
      status: 'open', // 'open', 'acknowledged', 'resolved', 'closed'
      createdAt: new Date().toISOString(),
      createdBy: alertData.createdBy || 'system',
      metadata: alertData.metadata || {}
    };
    
    // Validar alerta
    this._validateModelAlert(alert);
    
    // Armazenar alerta
    if (!this.modelAlerts.has(modelId)) {
      this.modelAlerts.set(modelId, new Map());
    }
    
    this.modelAlerts.get(modelId).set(alertId, alert);
    
    return cloneDeep(alert);
  }

  /**
   * Atualiza o status de um alerta
   * @param {string} modelId ID do modelo
   * @param {string} alertId ID do alerta
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @returns {Promise<Object>} Alerta atualizado
   */
  async updateAlertStatus(modelId, alertId, status, metadata = {}) {
    if (!this.modelAlerts.has(modelId) || !this.modelAlerts.get(modelId).has(alertId)) {
      throw new Error(`Alerta não encontrado: ${modelId}/${alertId}`);
    }
    
    const alert = this.modelAlerts.get(modelId).get(alertId);
    
    // Validar transição de status
    this._validateAlertStatusTransition(alert.status, status);
    
    // Atualizar status
    alert.status = status;
    alert.updatedAt = new Date().toISOString();
    
    // Adicionar metadados específicos do status
    if (status === 'acknowledged') {
      alert.acknowledgedAt = new Date().toISOString();
      alert.acknowledgedBy = metadata.acknowledgedBy;
      alert.acknowledgementNotes = metadata.acknowledgementNotes;
    } else if (status === 'resolved') {
      alert.resolvedAt = new Date().toISOString();
      alert.resolvedBy = metadata.resolvedBy;
      alert.resolutionNotes = metadata.resolutionNotes;
    } else if (status === 'closed') {
      alert.closedAt = new Date().toISOString();
      alert.closedBy = metadata.closedBy;
      alert.closureNotes = metadata.closureNotes;
    }
    
    // Atualizar metadados
    alert.metadata = {
      ...alert.metadata,
      ...metadata
    };
    
    // Armazenar alerta atualizado
    this.modelAlerts.get(modelId).set(alertId, alert);
    
    return cloneDeep(alert);
  }

  /**
   * Obtém um modelo pelo ID
   * @param {string} modelId ID do modelo
   * @returns {Promise<Object>} Modelo
   */
  async getModel(modelId) {
    if (!this.models.has(modelId)) {
      throw new Error(`Modelo não encontrado: ${modelId}`);
    }
    
    return cloneDeep(this.models.get(modelId));
  }

  /**
   * Lista todos os modelos
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de modelos
   */
  async listModels(filters = {}) {
    let models = Array.from(this.models.values());
    
    // Aplicar filtros
    if (filters.status) {
      models = models.filter(model => model.status === filters.status);
    }
    
    if (filters.type) {
      models = models.filter(model => model.type === filters.type);
    }
    
    if (filters.owner) {
      models = models.filter(model => model.owner === filters.owner);
    }
    
    if (filters.team) {
      models = models.filter(model => model.team.includes(filters.team));
    }
    
    if (filters.tag) {
      models = models.filter(model => model.tags.includes(filters.tag));
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      models = models.filter(model => new Date(model.createdAt) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      models = models.filter(model => new Date(model.createdAt) <= endDate);
    }
    
    // Ordenar por data de criação (mais recente primeiro)
    models.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Limitar resultados
    if (filters.limit) {
      models = models.slice(0, filters.limit);
    }
    
    return cloneDeep(models);
  }

  /**
   * Obtém uma versão de modelo
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão
   * @returns {Promise<Object>} Versão do modelo
   */
  async getModelVersion(modelId, versionId) {
    if (!this.modelVersions.has(modelId) || !this.modelVersions.get(modelId).has(versionId)) {
      throw new Error(`Versão de modelo não encontrada: ${modelId}/${versionId}`);
    }
    
    return cloneDeep(this.modelVersions.get(modelId).get(versionId));
  }

  /**
   * Lista todas as versões de um modelo
   * @param {string} modelId ID do modelo
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de versões
   */
  async listModelVersions(modelId, filters = {}) {
    if (!this.modelVersions.has(modelId)) {
      return [];
    }
    
    let versions = Array.from(this.modelVersions.get(modelId).values());
    
    // Aplicar filtros
    if (filters.status) {
      versions = versions.filter(version => version.status === filters.status);
    }
    
    // Ordenar por número de versão (decrescente)
    versions.sort((a, b) => {
      const [aMajor, aMinor, aPatch] = a.versionNumber.split('.').map(Number);
      const [bMajor, bMinor, bPatch] = b.versionNumber.split('.').map(Number);
      
      if (aMajor !== bMajor) return bMajor - aMajor;
      if (aMinor !== bMinor) return bMinor - aMinor;
      return bPatch - aPatch;
    });
    
    // Limitar resultados
    if (filters.limit) {
      versions = versions.slice(0, filters.limit);
    }
    
    return cloneDeep(versions);
  }

  /**
   * Lista métricas de um modelo
   * @param {string} modelId ID do modelo
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de métricas
   */
  async listModelMetrics(modelId, filters = {}) {
    if (!this.modelMetrics.has(modelId)) {
      return [];
    }
    
    let metrics = Array.from(this.modelMetrics.get(modelId).values());
    
    // Aplicar filtros
    if (filters.versionId) {
      metrics = metrics.filter(metric => metric.versionId === filters.versionId);
    }
    
    if (filters.environment) {
      metrics = metrics.filter(metric => metric.environment === filters.environment);
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      metrics = metrics.filter(metric => new Date(metric.timestamp) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      metrics = metrics.filter(metric => new Date(metric.timestamp) <= endDate);
    }
    
    // Ordenar por timestamp (mais recente primeiro)
    metrics.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    // Limitar resultados
    if (filters.limit) {
      metrics = metrics.slice(0, filters.limit);
    }
    
    return cloneDeep(metrics);
  }

  /**
   * Lista alertas de um modelo
   * @param {string} modelId ID do modelo
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de alertas
   */
  async listModelAlerts(modelId, filters = {}) {
    if (!this.modelAlerts.has(modelId)) {
      return [];
    }
    
    let alerts = Array.from(this.modelAlerts.get(modelId).values());
    
    // Aplicar filtros
    if (filters.versionId) {
      alerts = alerts.filter(alert => alert.versionId === filters.versionId);
    }
    
    if (filters.type) {
      alerts = alerts.filter(alert => alert.type === filters.type);
    }
    
    if (filters.severity) {
      alerts = alerts.filter(alert => alert.severity === filters.severity);
    }
    
    if (filters.status) {
      alerts = alerts.filter(alert => alert.status === filters.status);
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      alerts = alerts.filter(alert => new Date(alert.createdAt) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      alerts = alerts.filter(alert => new Date(alert.createdAt) <= endDate);
    }
    
    // Ordenar por severidade e data de criação
    alerts.sort((a, b) => {
      const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
      if (severityOrder[a.severity] !== severityOrder[b.severity]) {
        return severityOrder[a.severity] - severityOrder[b.severity];
      }
      return new Date(b.createdAt) - new Date(a.createdAt);
    });
    
    // Limitar resultados
    if (filters.limit) {
      alerts = alerts.slice(0, filters.limit);
    }
    
    return cloneDeep(alerts);
  }

  /**
   * Valida um modelo
   * @param {Object} model Modelo a ser validado
   * @private
   */
  _validateModel(model) {
    if (!model.name) {
      throw new Error('Nome do modelo é obrigatório');
    }
    
    if (!model.type) {
      throw new Error('Tipo do modelo é obrigatório');
    }
    
    if (!model.algorithm) {
      throw new Error('Algoritmo do modelo é obrigatório');
    }
    
    if (!model.owner) {
      throw new Error('Proprietário do modelo é obrigatório');
    }
  }

  /**
   * Valida uma versão de modelo
   * @param {Object} version Versão a ser validada
   * @private
   */
  _validateModelVersion(version) {
    if (!version.versionNumber) {
      throw new Error('Número de versão é obrigatório');
    }
    
    // Validar formato do número de versão (semver)
    const semverRegex = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/;
    if (!semverRegex.test(version.versionNumber)) {
      throw new Error(`Número de versão inválido: ${version.versionNumber}. Use o formato semver (x.y.z)`);
    }
  }

  /**
   * Valida um alerta de modelo
   * @param {Object} alert Alerta a ser validado
   * @private
   */
  _validateModelAlert(alert) {
    if (!alert.type) {
      throw new Error('Tipo do alerta é obrigatório');
    }
    
    if (!alert.title) {
      throw new Error('Título do alerta é obrigatório');
    }
    
    const validTypes = ['drift', 'performance_degradation', 'error', 'warning', 'info'];
    if (!validTypes.includes(alert.type)) {
      throw new Error(`Tipo de alerta inválido: ${alert.type}`);
    }
    
    const validSeverities = ['low', 'medium', 'high', 'critical'];
    if (!validSeverities.includes(alert.severity)) {
      throw new Error(`Severidade de alerta inválida: ${alert.severity}`);
    }
  }

  /**
   * Valida uma transição de status de modelo
   * @param {string} currentStatus Status atual
   * @param {string} newStatus Novo status
   * @private
   */
  _validateStatusTransition(currentStatus, newStatus) {
    const validStatuses = ['draft', 'in_review', 'approved', 'deployed', 'deprecated', 'archived'];
    
    if (!validStatuses.includes(newStatus)) {
      throw new Error(`Status inválido: ${newStatus}`);
    }
    
    // Regras de transição de status
    if (currentStatus === 'archived') {
      throw new Error('Não é possível alterar o status de um modelo arquivado');
    }
    
    const statusOrder = {
      draft: 0,
      in_review: 1,
      approved: 2,
      deployed: 3,
      deprecated: 4,
      archived: 5
    };
    
    // Regras específicas de transição
    if (currentStatus === 'draft' && !['in_review', 'archived'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'in_review' && !['draft', 'approved', 'archived'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'approved' && !['deployed', 'deprecated', 'archived'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'deployed' && !['deprecated', 'archived'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'deprecated' && newStatus !== 'archived') {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
  }

  /**
   * Valida uma transição de status de versão de modelo
   * @param {string} currentStatus Status atual
   * @param {string} newStatus Novo status
   * @private
   */
  _validateVersionStatusTransition(currentStatus, newStatus) {
    const validStatuses = ['draft', 'in_review', 'approved', 'deployed', 'deprecated'];
    
    if (!validStatuses.includes(newStatus)) {
      throw new Error(`Status inválido: ${newStatus}`);
    }
    
    // Regras de transição de status
    if (currentStatus === 'deprecated') {
      throw new Error('Não é possível alterar o status de uma versão depreciada');
    }
    
    // Regras específicas de transição (similares às do modelo)
    if (currentStatus === 'draft' && !['in_review'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'in_review' && !['draft', 'approved'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'approved' && !['deployed', 'deprecated'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'deployed' && newStatus !== 'deprecated') {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
  }

  /**
   * Valida uma transição de status de alerta
   * @param {string} currentStatus Status atual
   * @param {string} newStatus Novo status
   * @private
   */
  _validateAlertStatusTransition(currentStatus, newStatus) {
    const validStatuses = ['open', 'acknowledged', 'resolved', 'closed'];
    
    if (!validStatuses.includes(newStatus)) {
      throw new Error(`Status inválido: ${newStatus}`);
    }
    
    // Regras de transição de status
    if (currentStatus === 'closed') {
      throw new Error('Não é possível alterar o status de um alerta fechado');
    }
    
    const statusOrder = {
      open: 0,
      acknowledged: 1,
      resolved: 2,
      closed: 3
    };
    
    // Não permitir pular etapas (exceto para 'closed' que pode ser alcançado de qualquer status)
    if (newStatus !== 'closed' && statusOrder[newStatus] > statusOrder[currentStatus] + 1) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    // Não permitir voltar para status anteriores
    if (statusOrder[newStatus] < statusOrder[currentStatus]) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
  }
}

/**
 * Classe para Gestão de Políticas e Governança
 */
export class PolicyGovernanceManager {
  constructor(config = {}) {
    this.config = {
      storageMethod: config.storageMethod || 'memory', // 'memory', 'database'
      approvalWorkflowEnabled: config.approvalWorkflowEnabled !== undefined ? config.approvalWorkflowEnabled : true,
      ...config
    };

    // Armazenamento de políticas
    this.policies = new Map();
    
    // Armazenamento de versões de políticas
    this.policyVersions = new Map();
    
    // Armazenamento de aprovações de políticas
    this.policyApprovals = new Map();
  }

  /**
   * Registra uma nova política
   * @param {Object} policyData Dados da política
   * @returns {Promise<Object>} Política registrada
   */
  async registerPolicy(policyData) {
    const policyId = policyData.id || uuidv4();
    
    const policy = {
      id: policyId,
      name: policyData.name,
      description: policyData.description || '',
      type: policyData.type, // 'credit', 'risk', 'compliance', 'security', 'operational', etc.
      category: policyData.category,
      owner: policyData.owner,
      team: policyData.team || [],
      tags: policyData.tags || [],
      status: 'draft', // 'draft', 'in_review', 'approved', 'active', 'inactive', 'archived'
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      metadata: policyData.metadata || {}
    };
    
    // Validar política
    this._validatePolicy(policy);
    
    // Armazenar política
    this.policies.set(policyId, policy);
    
    // Criar primeira versão da política
    if (policyData.content) {
      await this.createPolicyVersion(policyId, {
        versionNumber: '0.1.0',
        description: 'Initial draft version',
        content: policyData.content
      });
    }
    
    return cloneDeep(policy);
  }

  /**
   * Atualiza uma política existente
   * @param {string} policyId ID da política
   * @param {Object} policyData Novos dados da política
   * @returns {Promise<Object>} Política atualizada
   */
  async updatePolicy(policyId, policyData) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    const currentPolicy = this.policies.get(policyId);
    
    // Campos que não podem ser atualizados diretamente
    const protectedFields = ['id', 'createdAt', 'status'];
    
    const updatedPolicy = {
      ...currentPolicy,
      ...Object.fromEntries(
        Object.entries(policyData).filter(([key]) => !protectedFields.includes(key))
      ),
      updatedAt: new Date().toISOString()
    };
    
    // Validar política
    this._validatePolicy(updatedPolicy);
    
    // Armazenar política atualizada
    this.policies.set(policyId, updatedPolicy);
    
    return cloneDeep(updatedPolicy);
  }

  /**
   * Atualiza o status de uma política
   * @param {string} policyId ID da política
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @returns {Promise<Object>} Política atualizada
   */
  async updatePolicyStatus(policyId, status, metadata = {}) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    const policy = this.policies.get(policyId);
    
    // Validar transição de status
    this._validateStatusTransition(policy.status, status);
    
    // Atualizar status
    policy.status = status;
    policy.updatedAt = new Date().toISOString();
    
    // Adicionar metadados específicos do status
    if (status === 'in_review') {
      policy.reviewStartedAt = new Date().toISOString();
      policy.reviewers = metadata.reviewers || [];
    } else if (status === 'approved') {
      policy.approvedAt = new Date().toISOString();
      policy.approvedBy = metadata.approvedBy;
      policy.approvalNotes = metadata.approvalNotes;
    } else if (status === 'active') {
      policy.activatedAt = new Date().toISOString();
      policy.activatedBy = metadata.activatedBy;
      policy.effectiveDate = metadata.effectiveDate || policy.activatedAt;
    } else if (status === 'inactive') {
      policy.deactivatedAt = new Date().toISOString();
      policy.deactivatedBy = metadata.deactivatedBy;
      policy.deactivationReason = metadata.deactivationReason;
    } else if (status === 'archived') {
      policy.archivedAt = new Date().toISOString();
      policy.archivedBy = metadata.archivedBy;
      policy.archivalReason = metadata.archivalReason;
    }
    
    // Atualizar metadados
    policy.metadata = {
      ...policy.metadata,
      ...metadata
    };
    
    // Armazenar política atualizada
    this.policies.set(policyId, policy);
    
    return cloneDeep(policy);
  }

  /**
   * Cria uma nova versão de uma política
   * @param {string} policyId ID da política
   * @param {Object} versionData Dados da versão
   * @returns {Promise<Object>} Versão da política
   */
  async createPolicyVersion(policyId, versionData) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    const policy = this.policies.get(policyId);
    
    // Gerar ID da versão
    const versionId = uuidv4();
    
    // Criar versão
    const version = {
      id: versionId,
      policyId,
      versionNumber: versionData.versionNumber,
      description: versionData.description || '',
      content: versionData.content || {},
      status: 'draft', // 'draft', 'in_review', 'approved', 'active', 'inactive'
      createdAt: new Date().toISOString(),
      createdBy: versionData.createdBy || policy.owner,
      metadata: versionData.metadata || {}
    };
    
    // Validar versão
    this._validatePolicyVersion(version);
    
    // Armazenar versão
    if (!this.policyVersions.has(policyId)) {
      this.policyVersions.set(policyId, new Map());
    }
    
    this.policyVersions.get(policyId).set(versionId, version);
    
    // Atualizar política com referência à nova versão
    policy.latestVersionId = versionId;
    policy.latestVersionNumber = versionData.versionNumber;
    policy.updatedAt = new Date().toISOString();
    
    // Armazenar política atualizada
    this.policies.set(policyId, policy);
    
    return cloneDeep(version);
  }

  /**
   * Atualiza o status de uma versão de política
   * @param {string} policyId ID da política
   * @param {string} versionId ID da versão
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @returns {Promise<Object>} Versão atualizada
   */
  async updatePolicyVersionStatus(policyId, versionId, status, metadata = {}) {
    if (!this.policyVersions.has(policyId) || !this.policyVersions.get(policyId).has(versionId)) {
      throw new Error(`Versão de política não encontrada: ${policyId}/${versionId}`);
    }
    
    const version = this.policyVersions.get(policyId).get(versionId);
    
    // Validar transição de status
    this._validateVersionStatusTransition(version.status, status);
    
    // Atualizar status
    version.status = status;
    version.updatedAt = new Date().toISOString();
    
    // Adicionar metadados específicos do status
    if (status === 'in_review') {
      version.reviewStartedAt = new Date().toISOString();
      version.reviewers = metadata.reviewers || [];
    } else if (status === 'approved') {
      version.approvedAt = new Date().toISOString();
      version.approvedBy = metadata.approvedBy;
      version.approvalNotes = metadata.approvalNotes;
    } else if (status === 'active') {
      version.activatedAt = new Date().toISOString();
      version.activatedBy = metadata.activatedBy;
      version.effectiveDate = metadata.effectiveDate || version.activatedAt;
    } else if (status === 'inactive') {
      version.deactivatedAt = new Date().toISOString();
      version.deactivatedBy = metadata.deactivatedBy;
      version.deactivationReason = metadata.deactivationReason;
    }
    
    // Atualizar metadados
    version.metadata = {
      ...version.metadata,
      ...metadata
    };
    
    // Armazenar versão atualizada
    this.policyVersions.get(policyId).set(versionId, version);
    
    // Se a versão foi ativada, atualizar a política
    if (status === 'active') {
      const policy = this.policies.get(policyId);
      
      policy.activeVersionId = versionId;
      policy.activeVersionNumber = version.versionNumber;
      
      // Atualizar status da política para 'active' se ainda não estiver
      if (policy.status !== 'active') {
        await this.updatePolicyStatus(policyId, 'active', {
          activatedBy: metadata.activatedBy,
          effectiveDate: metadata.effectiveDate
        });
      }
      
      // Armazenar política atualizada
      this.policies.set(policyId, policy);
    }
    
    return cloneDeep(version);
  }

  /**
   * Registra uma aprovação para uma política ou versão
   * @param {string} policyId ID da política
   * @param {string} versionId ID da versão (opcional)
   * @param {Object} approvalData Dados da aprovação
   * @returns {Promise<Object>} Aprovação registrada
   */
  async registerApproval(policyId, versionId, approvalData) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    if (versionId && (!this.policyVersions.has(policyId) || !this.policyVersions.get(policyId).has(versionId))) {
      throw new Error(`Versão de política não encontrada: ${policyId}/${versionId}`);
    }
    
    // Gerar ID da aprovação
    const approvalId = uuidv4();
    
    // Criar aprovação
    const approval = {
      id: approvalId,
      policyId,
      versionId,
      approver: approvalData.approver,
      role: approvalData.role,
      decision: approvalData.decision, // 'approved', 'rejected', 'needs_changes'
      comments: approvalData.comments || '',
      timestamp: new Date().toISOString(),
      metadata: approvalData.metadata || {}
    };
    
    // Validar aprovação
    this._validateApproval(approval);
    
    // Armazenar aprovação
    if (!this.policyApprovals.has(policyId)) {
      this.policyApprovals.set(policyId, new Map());
    }
    
    this.policyApprovals.get(policyId).set(approvalId, approval);
    
    // Atualizar status da política ou versão se todas as aprovações necessárias foram obtidas
    if (this.config.approvalWorkflowEnabled && approval.decision === 'approved') {
      await this._checkAndUpdateApprovalStatus(policyId, versionId);
    }
    
    return cloneDeep(approval);
  }

  /**
   * Verifica e atualiza o status de aprovação de uma política ou versão
   * @param {string} policyId ID da política
   * @param {string} versionId ID da versão (opcional)
   * @private
   */
  async _checkAndUpdateApprovalStatus(policyId, versionId) {
    // Obter todas as aprovações para a política/versão
    const approvals = Array.from(this.policyApprovals.get(policyId).values())
      .filter(approval => approval.versionId === versionId);
    
    // Verificar se há rejeições
    const hasRejections = approvals.some(approval => approval.decision === 'rejected');
    
    if (hasRejections) {
      // Se houver rejeições, não atualizar o status
      return;
    }
    
    // Verificar se há aprovações suficientes
    const requiredApprovals = 2; // Número mínimo de aprovações necessárias (configurável)
    const approvedCount = approvals.filter(approval => approval.decision === 'approved').length;
    
    if (approvedCount >= requiredApprovals) {
      // Atualizar status para 'approved'
      if (versionId) {
        await this.updatePolicyVersionStatus(policyId, versionId, 'approved', {
          approvedBy: 'approval_workflow',
          approvalNotes: `Aprovado automaticamente após ${approvedCount} aprovações.`
        });
      } else {
        await this.updatePolicyStatus(policyId, 'approved', {
          approvedBy: 'approval_workflow',
          approvalNotes: `Aprovado automaticamente após ${approvedCount} aprovações.`
        });
      }
    }
  }

  /**
   * Obtém uma política pelo ID
   * @param {string} policyId ID da política
   * @returns {Promise<Object>} Política
   */
  async getPolicy(policyId) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    return cloneDeep(this.policies.get(policyId));
  }

  /**
   * Lista todas as políticas
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de políticas
   */
  async listPolicies(filters = {}) {
    let policies = Array.from(this.policies.values());
    
    // Aplicar filtros
    if (filters.status) {
      policies = policies.filter(policy => policy.status === filters.status);
    }
    
    if (filters.type) {
      policies = policies.filter(policy => policy.type === filters.type);
    }
    
    if (filters.category) {
      policies = policies.filter(policy => policy.category === filters.category);
    }
    
    if (filters.owner) {
      policies = policies.filter(policy => policy.owner === filters.owner);
    }
    
    if (filters.team) {
      policies = policies.filter(policy => policy.team.includes(filters.team));
    }
    
    if (filters.tag) {
      policies = policies.filter(policy => policy.tags.includes(filters.tag));
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      policies = policies.filter(policy => new Date(policy.createdAt) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      policies = policies.filter(policy => new Date(policy.createdAt) <= endDate);
    }
    
    // Ordenar por data de criação (mais recente primeiro)
    policies.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Limitar resultados
    if (filters.limit) {
      policies = policies.slice(0, filters.limit);
    }
    
    return cloneDeep(policies);
  }

  /**
   * Obtém uma versão de política
   * @param {string} policyId ID da política
   * @param {string} versionId ID da versão
   * @returns {Promise<Object>} Versão da política
   */
  async getPolicyVersion(policyId, versionId) {
    if (!this.policyVersions.has(policyId) || !this.policyVersions.get(policyId).has(versionId)) {
      throw new Error(`Versão de política não encontrada: ${policyId}/${versionId}`);
    }
    
    return cloneDeep(this.policyVersions.get(policyId).get(versionId));
  }

  /**
   * Lista todas as versões de uma política
   * @param {string} policyId ID da política
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de versões
   */
  async listPolicyVersions(policyId, filters = {}) {
    if (!this.policyVersions.has(policyId)) {
      return [];
    }
    
    let versions = Array.from(this.policyVersions.get(policyId).values());
    
    // Aplicar filtros
    if (filters.status) {
      versions = versions.filter(version => version.status === filters.status);
    }
    
    // Ordenar por número de versão (decrescente)
    versions.sort((a, b) => {
      const [aMajor, aMinor, aPatch] = a.versionNumber.split('.').map(Number);
      const [bMajor, bMinor, bPatch] = b.versionNumber.split('.').map(Number);
      
      if (aMajor !== bMajor) return bMajor - aMajor;
      if (aMinor !== bMinor) return bMinor - aMinor;
      return bPatch - aPatch;
    });
    
    // Limitar resultados
    if (filters.limit) {
      versions = versions.slice(0, filters.limit);
    }
    
    return cloneDeep(versions);
  }

  /**
   * Lista aprovações de uma política ou versão
   * @param {string} policyId ID da política
   * @param {string} versionId ID da versão (opcional)
   * @returns {Promise<Array>} Lista de aprovações
   */
  async listApprovals(policyId, versionId = null) {
    if (!this.policyApprovals.has(policyId)) {
      return [];
    }
    
    let approvals = Array.from(this.policyApprovals.get(policyId).values());
    
    // Filtrar por versão se especificada
    if (versionId !== null) {
      approvals = approvals.filter(approval => approval.versionId === versionId);
    }
    
    // Ordenar por timestamp (mais recente primeiro)
    approvals.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    return cloneDeep(approvals);
  }

  /**
   * Valida uma política
   * @param {Object} policy Política a ser validada
   * @private
   */
  _validatePolicy(policy) {
    if (!policy.name) {
      throw new Error('Nome da política é obrigatório');
    }
    
    if (!policy.type) {
      throw new Error('Tipo da política é obrigatório');
    }
    
    if (!policy.owner) {
      throw new Error('Proprietário da política é obrigatório');
    }
  }

  /**
   * Valida uma versão de política
   * @param {Object} version Versão a ser validada
   * @private
   */
  _validatePolicyVersion(version) {
    if (!version.versionNumber) {
      throw new Error('Número de versão é obrigatório');
    }
    
    // Validar formato do número de versão (semver)
    const semverRegex = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/;
    if (!semverRegex.test(version.versionNumber)) {
      throw new Error(`Número de versão inválido: ${version.versionNumber}. Use o formato semver (x.y.z)`);
    }
    
    if (!version.content) {
      throw new Error('Conteúdo da versão é obrigatório');
    }
  }

  /**
   * Valida uma aprovação
   * @param {Object} approval Aprovação a ser validada
   * @private
   */
  _validateApproval(approval) {
    if (!approval.approver) {
      throw new Error('Aprovador é obrigatório');
    }
    
    if (!approval.role) {
      throw new Error('Papel do aprovador é obrigatório');
    }
    
    if (!approval.decision) {
      throw new Error('Decisão é obrigatória');
    }
    
    const validDecisions = ['approved', 'rejected', 'needs_changes'];
    if (!validDecisions.includes(approval.decision)) {
      throw new Error(`Decisão inválida: ${approval.decision}`);
    }
  }

  /**
   * Valida uma transição de status de política
   * @param {string} currentStatus Status atual
   * @param {string} newStatus Novo status
   * @private
   */
  _validateStatusTransition(currentStatus, newStatus) {
    const validStatuses = ['draft', 'in_review', 'approved', 'active', 'inactive', 'archived'];
    
    if (!validStatuses.includes(newStatus)) {
      throw new Error(`Status inválido: ${newStatus}`);
    }
    
    // Regras de transição de status
    if (currentStatus === 'archived') {
      throw new Error('Não é possível alterar o status de uma política arquivada');
    }
    
    // Regras específicas de transição
    if (currentStatus === 'draft' && !['in_review', 'archived'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'in_review' && !['draft', 'approved', 'archived'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'approved' && !['active', 'inactive', 'archived'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'active' && !['inactive', 'archived'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'inactive' && !['active', 'archived'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
  }

  /**
   * Valida uma transição de status de versão de política
   * @param {string} currentStatus Status atual
   * @param {string} newStatus Novo status
   * @private
   */
  _validateVersionStatusTransition(currentStatus, newStatus) {
    const validStatuses = ['draft', 'in_review', 'approved', 'active', 'inactive'];
    
    if (!validStatuses.includes(newStatus)) {
      throw new Error(`Status inválido: ${newStatus}`);
    }
    
    // Regras de transição de status
    if (currentStatus === 'inactive') {
      throw new Error('Não é possível alterar o status de uma versão inativa');
    }
    
    // Regras específicas de transição (similares às da política)
    if (currentStatus === 'draft' && !['in_review'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'in_review' && !['draft', 'approved'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'approved' && !['active', 'inactive'].includes(newStatus)) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'active' && newStatus !== 'inactive') {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
  }
}

/**
 * Classe para Trilha de Auditoria Imutável
 */
export class ImmutableAuditTrail {
  constructor(config = {}) {
    this.config = {
      storageMethod: config.storageMethod || 'memory', // 'memory', 'database', 'blockchain'
      hashAlgorithm: config.hashAlgorithm || 'SHA-256',
      maxLogSize: config.maxLogSize || 10000,
      ...config
    };

    // Armazenamento de eventos de auditoria
    this.auditEvents = [];
    
    // Hash do último evento (para encadeamento)
    this.lastEventHash = null;
  }

  /**
   * Registra um evento de auditoria
   * @param {Object} eventData Dados do evento
   * @returns {Promise<Object>} Evento registrado
   */
  async recordEvent(eventData) {
    // Gerar ID do evento
    const eventId = uuidv4();
    
    // Criar evento
    const event = {
      id: eventId,
      timestamp: new Date().toISOString(),
      eventType: eventData.eventType,
      actor: eventData.actor,
      action: eventData.action,
      entityType: eventData.entityType,
      entityId: eventData.entityId,
      details: eventData.details || {},
      metadata: eventData.metadata || {}
    };
    
    // Adicionar hash do evento anterior (para encadeamento)
    event.previousEventHash = this.lastEventHash;
    
    // Calcular hash do evento atual
    event.hash = this._calculateEventHash(event);
    
    // Atualizar hash do último evento
    this.lastEventHash = event.hash;
    
    // Armazenar evento
    if (this.config.storageMethod === 'memory') {
      if (this.auditEvents.length >= this.config.maxLogSize) {
        this.auditEvents.shift(); // Remover o mais antigo
      }
      this.auditEvents.push(event);
    } else if (this.config.storageMethod === 'database') {
      // TODO: Implementar armazenamento em banco de dados
      console.log(`[Audit Event DB] ${JSON.stringify(event)}`);
    } else if (this.config.storageMethod === 'blockchain') {
      // TODO: Implementar armazenamento em blockchain
      console.log(`[Audit Event Blockchain] ${JSON.stringify(event)}`);
    }
    
    return cloneDeep(event);
  }

  /**
   * Calcula o hash de um evento
   * @param {Object} event Evento a ser hasheado
   * @returns {string} Hash do evento
   * @private
   */
  _calculateEventHash(event) {
    // Criar cópia do evento sem o campo hash
    const eventForHashing = { ...event };
    delete eventForHashing.hash;
    
    // Converter para string
    const eventString = JSON.stringify(eventForHashing);
    
    // Calcular hash
    // Simulação - em produção, usaria uma biblioteca de criptografia
    return `hash_${eventString.length}_${Date.now()}`;
  }

  /**
   * Verifica a integridade da trilha de auditoria
   * @returns {Promise<Object>} Resultado da verificação
   */
  async verifyIntegrity() {
    if (this.auditEvents.length === 0) {
      return {
        valid: true,
        message: 'Trilha de auditoria vazia'
      };
    }
    
    let valid = true;
    const invalidEvents = [];
    
    // Verificar encadeamento de hashes
    let previousHash = null;
    
    for (let i = 0; i < this.auditEvents.length; i++) {
      const event = this.auditEvents[i];
      
      // Verificar hash do evento anterior
      if (event.previousEventHash !== previousHash) {
        valid = false;
        invalidEvents.push({
          eventId: event.id,
          position: i,
          error: 'Hash do evento anterior inválido'
        });
      }
      
      // Verificar hash do evento atual
      const calculatedHash = this._calculateEventHash(event);
      if (event.hash !== calculatedHash) {
        valid = false;
        invalidEvents.push({
          eventId: event.id,
          position: i,
          error: 'Hash do evento atual inválido'
        });
      }
      
      // Atualizar hash anterior
      previousHash = event.hash;
    }
    
    return {
      valid,
      eventsCount: this.auditEvents.length,
      invalidEvents: invalidEvents.length > 0 ? invalidEvents : null,
      message: valid ? 'Trilha de auditoria íntegra' : 'Trilha de auditoria comprometida'
    };
  }

  /**
   * Busca eventos de auditoria
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de eventos
   */
  async searchEvents(filters = {}) {
    let events = [...this.auditEvents];
    
    // Aplicar filtros
    if (filters.eventType) {
      events = events.filter(event => event.eventType === filters.eventType);
    }
    
    if (filters.actor) {
      events = events.filter(event => event.actor === filters.actor);
    }
    
    if (filters.action) {
      events = events.filter(event => event.action === filters.action);
    }
    
    if (filters.entityType) {
      events = events.filter(event => event.entityType === filters.entityType);
    }
    
    if (filters.entityId) {
      events = events.filter(event => event.entityId === filters.entityId);
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      events = events.filter(event => new Date(event.timestamp) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      events = events.filter(event => new Date(event.timestamp) <= endDate);
    }
    
    // Ordenar por timestamp (mais recente primeiro)
    events.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    // Limitar resultados
    if (filters.limit) {
      events = events.slice(0, filters.limit);
    }
    
    return cloneDeep(events);
  }

  /**
   * Exporta a trilha de auditoria
   * @param {Object} options Opções de exportação
   * @returns {Promise<Object>} Trilha de auditoria exportada
   */
  async exportAuditTrail(options = {}) {
    // Filtrar eventos
    let events = await this.searchEvents(options.filters || {});
    
    // Formatar eventos
    if (options.format === 'summary') {
      events = events.map(event => ({
        id: event.id,
        timestamp: event.timestamp,
        eventType: event.eventType,
        actor: event.actor,
        action: event.action,
        entityType: event.entityType,
        entityId: event.entityId
      }));
    }
    
    return {
      exportedAt: new Date().toISOString(),
      eventsCount: events.length,
      format: options.format || 'full',
      events
    };
  }
}

/**
 * Serviço Integrado de GRC, MRM e Auditoria
 */
export class GrcMrmService {
  constructor(config = {}) {
    this.modelLifecycleManager = new ModelLifecycleManager(config.modelLifecycle);
    this.policyGovernanceManager = new PolicyGovernanceManager(config.policyGovernance);
    this.immutableAuditTrail = new ImmutableAuditTrail(config.auditTrail);
  }

  /**
   * Registra um modelo com auditoria
   * @param {Object} modelData Dados do modelo
   * @param {Object} auditMetadata Metadados para auditoria
   * @returns {Promise<Object>} Modelo registrado
   */
  async registerModelWithAudit(modelData, auditMetadata = {}) {
    // Registrar modelo
    const model = await this.modelLifecycleManager.registerModel(modelData);
    
    // Registrar evento de auditoria
    await this.immutableAuditTrail.recordEvent({
      eventType: 'model_registration',
      actor: auditMetadata.actor || modelData.owner,
      action: 'create',
      entityType: 'model',
      entityId: model.id,
      details: {
        modelName: model.name,
        modelType: model.type,
        algorithm: model.algorithm
      }
    });
    
    return model;
  }

  /**
   * Registra uma política com auditoria
   * @param {Object} policyData Dados da política
   * @param {Object} auditMetadata Metadados para auditoria
   * @returns {Promise<Object>} Política registrada
   */
  async registerPolicyWithAudit(policyData, auditMetadata = {}) {
    // Registrar política
    const policy = await this.policyGovernanceManager.registerPolicy(policyData);
    
    // Registrar evento de auditoria
    await this.immutableAuditTrail.recordEvent({
      eventType: 'policy_registration',
      actor: auditMetadata.actor || policyData.owner,
      action: 'create',
      entityType: 'policy',
      entityId: policy.id,
      details: {
        policyName: policy.name,
        policyType: policy.type,
        policyCategory: policy.category
      }
    });
    
    return policy;
  }

  /**
   * Atualiza o status de um modelo com auditoria
   * @param {string} modelId ID do modelo
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @param {Object} auditMetadata Metadados para auditoria
   * @returns {Promise<Object>} Modelo atualizado
   */
  async updateModelStatusWithAudit(modelId, status, metadata = {}, auditMetadata = {}) {
    // Obter modelo atual para comparação
    const currentModel = await this.modelLifecycleManager.getModel(modelId);
    
    // Atualizar status
    const updatedModel = await this.modelLifecycleManager.updateModelStatus(modelId, status, metadata);
    
    // Registrar evento de auditoria
    await this.immutableAuditTrail.recordEvent({
      eventType: 'model_status_change',
      actor: auditMetadata.actor || metadata.updatedBy || 'system',
      action: 'update',
      entityType: 'model',
      entityId: modelId,
      details: {
        modelName: updatedModel.name,
        previousStatus: currentModel.status,
        newStatus: status,
        statusChangeReason: metadata.reason
      }
    });
    
    return updatedModel;
  }

  /**
   * Atualiza o status de uma política com auditoria
   * @param {string} policyId ID da política
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @param {Object} auditMetadata Metadados para auditoria
   * @returns {Promise<Object>} Política atualizada
   */
  async updatePolicyStatusWithAudit(policyId, status, metadata = {}, auditMetadata = {}) {
    // Obter política atual para comparação
    const currentPolicy = await this.policyGovernanceManager.getPolicy(policyId);
    
    // Atualizar status
    const updatedPolicy = await this.policyGovernanceManager.updatePolicyStatus(policyId, status, metadata);
    
    // Registrar evento de auditoria
    await this.immutableAuditTrail.recordEvent({
      eventType: 'policy_status_change',
      actor: auditMetadata.actor || metadata.updatedBy || 'system',
      action: 'update',
      entityType: 'policy',
      entityId: policyId,
      details: {
        policyName: updatedPolicy.name,
        previousStatus: currentPolicy.status,
        newStatus: status,
        statusChangeReason: metadata.reason
      }
    });
    
    return updatedPolicy;
  }

  /**
   * Registra métricas de modelo com auditoria
   * @param {string} modelId ID do modelo
   * @param {string} versionId ID da versão
   * @param {Object} metricsData Dados das métricas
   * @param {Object} auditMetadata Metadados para auditoria
   * @returns {Promise<Object>} Métricas registradas
   */
  async registerModelMetricsWithAudit(modelId, versionId, metricsData, auditMetadata = {}) {
    // Registrar métricas
    const metrics = await this.modelLifecycleManager.registerModelMetrics(modelId, versionId, metricsData);
    
    // Registrar evento de auditoria
    await this.immutableAuditTrail.recordEvent({
      eventType: 'model_metrics_registration',
      actor: auditMetadata.actor || metricsData.createdBy || 'system',
      action: 'create',
      entityType: 'model_metrics',
      entityId: metrics.id,
      details: {
        modelId,
        versionId,
        environment: metrics.environment,
        metricsKeys: Object.keys(metrics.metrics)
      }
    });
    
    return metrics;
  }

  /**
   * Cria um alerta de modelo com auditoria
   * @param {string} modelId ID do modelo
   * @param {Object} alertData Dados do alerta
   * @param {Object} auditMetadata Metadados para auditoria
   * @returns {Promise<Object>} Alerta criado
   */
  async createModelAlertWithAudit(modelId, alertData, auditMetadata = {}) {
    // Criar alerta
    const alert = await this.modelLifecycleManager.createModelAlert(modelId, alertData);
    
    // Registrar evento de auditoria
    await this.immutableAuditTrail.recordEvent({
      eventType: 'model_alert_creation',
      actor: auditMetadata.actor || alertData.createdBy || 'system',
      action: 'create',
      entityType: 'model_alert',
      entityId: alert.id,
      details: {
        modelId,
        versionId: alert.versionId,
        alertType: alert.type,
        alertSeverity: alert.severity,
        alertTitle: alert.title
      }
    });
    
    return alert;
  }

  /**
   * Registra uma aprovação de política com auditoria
   * @param {string} policyId ID da política
   * @param {string} versionId ID da versão (opcional)
   * @param {Object} approvalData Dados da aprovação
   * @param {Object} auditMetadata Metadados para auditoria
   * @returns {Promise<Object>} Aprovação registrada
   */
  async registerApprovalWithAudit(policyId, versionId, approvalData, auditMetadata = {}) {
    // Registrar aprovação
    const approval = await this.policyGovernanceManager.registerApproval(policyId, versionId, approvalData);
    
    // Registrar evento de auditoria
    await this.immutableAuditTrail.recordEvent({
      eventType: 'policy_approval',
      actor: auditMetadata.actor || approvalData.approver,
      action: 'approve',
      entityType: versionId ? 'policy_version' : 'policy',
      entityId: versionId || policyId,
      details: {
        policyId,
        versionId,
        approver: approval.approver,
        role: approval.role,
        decision: approval.decision,
        comments: approval.comments
      }
    });
    
    return approval;
  }

  /**
   * Gera um relatório de governança
   * @param {Object} options Opções do relatório
   * @returns {Promise<Object>} Relatório de governança
   */
  async generateGovernanceReport(options = {}) {
    const report = {
      generatedAt: new Date().toISOString(),
      period: {
        startDate: options.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
        endDate: options.endDate || new Date().toISOString()
      },
      summary: {},
      details: {}
    };
    
    // Filtros de período
    const periodFilters = {
      startDate: report.period.startDate,
      endDate: report.period.endDate
    };
    
    // Obter modelos
    const models = await this.modelLifecycleManager.listModels(periodFilters);
    
    // Obter políticas
    const policies = await this.policyGovernanceManager.listPolicies(periodFilters);
    
    // Obter eventos de auditoria
    const auditEvents = await this.immutableAuditTrail.searchEvents(periodFilters);
    
    // Calcular estatísticas
    report.summary = {
      models: {
        total: models.length,
        byStatus: this._countByProperty(models, 'status'),
        byType: this._countByProperty(models, 'type')
      },
      policies: {
        total: policies.length,
        byStatus: this._countByProperty(policies, 'status'),
        byType: this._countByProperty(policies, 'type')
      },
      auditEvents: {
        total: auditEvents.length,
        byType: this._countByProperty(auditEvents, 'eventType'),
        byActor: this._countByProperty(auditEvents, 'actor')
      }
    };
    
    // Adicionar detalhes se solicitado
    if (options.includeDetails) {
      report.details = {
        models: models.map(model => ({
          id: model.id,
          name: model.name,
          type: model.type,
          status: model.status,
          owner: model.owner,
          createdAt: model.createdAt,
          updatedAt: model.updatedAt
        })),
        policies: policies.map(policy => ({
          id: policy.id,
          name: policy.name,
          type: policy.type,
          category: policy.category,
          status: policy.status,
          owner: policy.owner,
          createdAt: policy.createdAt,
          updatedAt: policy.updatedAt
        })),
        recentAuditEvents: auditEvents.slice(0, 100).map(event => ({
          id: event.id,
          timestamp: event.timestamp,
          eventType: event.eventType,
          actor: event.actor,
          action: event.action,
          entityType: event.entityType,
          entityId: event.entityId
        }))
      };
    }
    
    return report;
  }

  /**
   * Conta ocorrências de uma propriedade em um array de objetos
   * @param {Array} array Array de objetos
   * @param {string} property Propriedade a ser contada
   * @returns {Object} Contagem por valor da propriedade
   * @private
   */
  _countByProperty(array, property) {
    return array.reduce((counts, item) => {
      const value = item[property];
      counts[value] = (counts[value] || 0) + 1;
      return counts;
    }, {});
  }
}

export default {
  ModelLifecycleManager,
  PolicyGovernanceManager,
  ImmutableAuditTrail,
  GrcMrmService
};
