/**
 * Serviço de Conformidade LGPD e Segurança
 * Implementa funcionalidades para garantir conformidade com a Lei Geral de Proteção de Dados
 * e reforçar a segurança em todos os fluxos do sistema.
 */

import { v4 as uuidv4 } from 'uuid';
import { cloneDeep, get, set } from 'lodash';
import CryptoJS from 'crypto-js';

/**
 * Classe para Gestão de Consentimento LGPD
 */
export class ConsentManager {
  constructor(config = {}) {
    this.config = {
      storageMethod: config.storageMethod || 'memory', // 'memory', 'database'
      consentExpirationDays: config.consentExpirationDays || 365, // 1 ano
      requireExplicitConsent: config.requireExplicitConsent !== undefined ? config.requireExplicitConsent : true,
      ...config
    };

    // Armazenamento de consentimentos
    this.consents = new Map();
  }

  /**
   * Registra um novo consentimento
   * @param {Object} consentData Dados do consentimento
   * @returns {Promise<Object>} Consentimento registrado
   */
  async registerConsent(consentData) {
    const consentId = consentData.id || uuidv4();
    
    // Calcular data de expiração
    const expirationDate = new Date();
    expirationDate.setDate(expirationDate.getDate() + this.config.consentExpirationDays);
    
    const consent = {
      id: consentId,
      userId: consentData.userId,
      userDocument: consentData.userDocument,
      userEmail: consentData.userEmail,
      purposes: consentData.purposes || [],
      dataCategories: consentData.dataCategories || [],
      thirdParties: consentData.thirdParties || [],
      createdAt: new Date().toISOString(),
      expiresAt: expirationDate.toISOString(),
      status: 'active',
      ipAddress: consentData.ipAddress,
      userAgent: consentData.userAgent,
      metadata: consentData.metadata || {}
    };
    
    // Validar consentimento
    this._validateConsent(consent);
    
    // Armazenar consentimento
    this.consents.set(consentId, consent);
    
    return cloneDeep(consent);
  }

  /**
   * Atualiza um consentimento existente
   * @param {string} consentId ID do consentimento
   * @param {Object} consentData Novos dados do consentimento
   * @returns {Promise<Object>} Consentimento atualizado
   */
  async updateConsent(consentId, consentData) {
    if (!this.consents.has(consentId)) {
      throw new Error(`Consentimento não encontrado: ${consentId}`);
    }
    
    const currentConsent = this.consents.get(consentId);
    
    // Verificar se o consentimento está ativo
    if (currentConsent.status !== 'active') {
      throw new Error(`Consentimento não está ativo: ${consentId}`);
    }
    
    const updatedConsent = {
      ...currentConsent,
      purposes: consentData.purposes || currentConsent.purposes,
      dataCategories: consentData.dataCategories || currentConsent.dataCategories,
      thirdParties: consentData.thirdParties || currentConsent.thirdParties,
      updatedAt: new Date().toISOString(),
      ipAddress: consentData.ipAddress || currentConsent.ipAddress,
      userAgent: consentData.userAgent || currentConsent.userAgent,
      metadata: {
        ...currentConsent.metadata,
        ...(consentData.metadata || {})
      }
    };
    
    // Validar consentimento
    this._validateConsent(updatedConsent);
    
    // Armazenar consentimento atualizado
    this.consents.set(consentId, updatedConsent);
    
    return cloneDeep(updatedConsent);
  }

  /**
   * Revoga um consentimento
   * @param {string} consentId ID do consentimento
   * @param {Object} metadata Metadados da revogação
   * @returns {Promise<Object>} Consentimento revogado
   */
  async revokeConsent(consentId, metadata = {}) {
    if (!this.consents.has(consentId)) {
      throw new Error(`Consentimento não encontrado: ${consentId}`);
    }
    
    const consent = this.consents.get(consentId);
    
    // Atualizar status do consentimento
    consent.status = 'revoked';
    consent.revokedAt = new Date().toISOString();
    consent.revocationReason = metadata.reason;
    consent.metadata = {
      ...consent.metadata,
      revocation: metadata
    };
    
    // Armazenar consentimento atualizado
    this.consents.set(consentId, consent);
    
    return cloneDeep(consent);
  }

  /**
   * Verifica se um consentimento está válido
   * @param {string} consentId ID do consentimento
   * @param {Array} purposes Finalidades a verificar
   * @param {Array} dataCategories Categorias de dados a verificar
   * @param {Array} thirdParties Terceiros a verificar
   * @returns {Promise<boolean>} Se o consentimento está válido
   */
  async verifyConsent(consentId, purposes = [], dataCategories = [], thirdParties = []) {
    if (!this.consents.has(consentId)) {
      return false;
    }
    
    const consent = this.consents.get(consentId);
    
    // Verificar se o consentimento está ativo
    if (consent.status !== 'active') {
      return false;
    }
    
    // Verificar se o consentimento não expirou
    if (new Date(consent.expiresAt) < new Date()) {
      return false;
    }
    
    // Verificar finalidades
    if (purposes.length > 0) {
      const hasAllPurposes = purposes.every(purpose => 
        consent.purposes.includes(purpose)
      );
      
      if (!hasAllPurposes) {
        return false;
      }
    }
    
    // Verificar categorias de dados
    if (dataCategories.length > 0) {
      const hasAllDataCategories = dataCategories.every(category => 
        consent.dataCategories.includes(category)
      );
      
      if (!hasAllDataCategories) {
        return false;
      }
    }
    
    // Verificar terceiros
    if (thirdParties.length > 0) {
      const hasAllThirdParties = thirdParties.every(party => 
        consent.thirdParties.includes(party)
      );
      
      if (!hasAllThirdParties) {
        return false;
      }
    }
    
    return true;
  }

  /**
   * Obtém um consentimento pelo ID
   * @param {string} consentId ID do consentimento
   * @returns {Promise<Object>} Consentimento
   */
  async getConsent(consentId) {
    if (!this.consents.has(consentId)) {
      throw new Error(`Consentimento não encontrado: ${consentId}`);
    }
    
    return cloneDeep(this.consents.get(consentId));
  }

  /**
   * Lista consentimentos de um usuário
   * @param {string} userId ID do usuário
   * @returns {Promise<Array>} Lista de consentimentos
   */
  async getUserConsents(userId) {
    const userConsents = Array.from(this.consents.values())
      .filter(consent => consent.userId === userId);
    
    return cloneDeep(userConsents);
  }

  /**
   * Valida um consentimento
   * @param {Object} consent Consentimento a ser validado
   * @private
   */
  _validateConsent(consent) {
    if (!consent.userId) {
      throw new Error('ID do usuário é obrigatório');
    }
    
    if (this.config.requireExplicitConsent) {
      if (!consent.purposes || consent.purposes.length === 0) {
        throw new Error('Finalidades do consentimento são obrigatórias');
      }
      
      if (!consent.dataCategories || consent.dataCategories.length === 0) {
        throw new Error('Categorias de dados do consentimento são obrigatórias');
      }
    }
  }
}

/**
 * Classe para Criptografia e Segurança de Dados
 */
export class DataSecurity {
  constructor(config = {}) {
    this.config = {
      encryptionKey: config.encryptionKey || 'default-encryption-key', // Deve ser substituído em produção
      hashAlgorithm: config.hashAlgorithm || 'SHA-256',
      ...config
    };
  }

  /**
   * Criptografa dados sensíveis
   * @param {any} data Dados a serem criptografados
   * @returns {string} Dados criptografados
   */
  encrypt(data) {
    const dataStr = typeof data === 'string' ? data : JSON.stringify(data);
    return CryptoJS.AES.encrypt(dataStr, this.config.encryptionKey).toString();
  }

  /**
   * Descriptografa dados
   * @param {string} encryptedData Dados criptografados
   * @param {boolean} parseJson Se deve fazer parse do JSON após descriptografar
   * @returns {any} Dados descriptografados
   */
  decrypt(encryptedData, parseJson = false) {
    const bytes = CryptoJS.AES.decrypt(encryptedData, this.config.encryptionKey);
    const decryptedStr = bytes.toString(CryptoJS.enc.Utf8);
    
    if (parseJson) {
      try {
        return JSON.parse(decryptedStr);
      } catch (error) {
        return decryptedStr;
      }
    }
    
    return decryptedStr;
  }

  /**
   * Gera um hash de dados
   * @param {string} data Dados para gerar hash
   * @returns {string} Hash gerado
   */
  hash(data) {
    return CryptoJS[this.config.hashAlgorithm](data).toString();
  }

  /**
   * Anonimiza dados pessoais
   * @param {Object} data Dados a serem anonimizados
   * @param {Array} fieldsToAnonymize Campos a serem anonimizados
   * @returns {Object} Dados anonimizados
   */
  anonymizeData(data, fieldsToAnonymize) {
    const anonymizedData = cloneDeep(data);
    
    for (const field of fieldsToAnonymize) {
      const value = get(anonymizedData, field);
      
      if (value !== undefined) {
        if (typeof value === 'string') {
          // Anonimizar string
          set(anonymizedData, field, this._anonymizeString(value));
        } else if (typeof value === 'number') {
          // Anonimizar número
          set(anonymizedData, field, 0);
        } else if (Array.isArray(value)) {
          // Anonimizar array
          set(anonymizedData, field, []);
        } else if (typeof value === 'object' && value !== null) {
          // Anonimizar objeto
          set(anonymizedData, field, {});
        }
      }
    }
    
    return anonymizedData;
  }

  /**
   * Anonimiza uma string
   * @param {string} str String a ser anonimizada
   * @returns {string} String anonimizada
   * @private
   */
  _anonymizeString(str) {
    if (!str) return '';
    
    // Verificar se é um CPF/CNPJ
    if (/^\d{11}$/.test(str.replace(/\D/g, ''))) {
      return '***.***.***-**';
    }
    
    if (/^\d{14}$/.test(str.replace(/\D/g, ''))) {
      return '**.***.***/****-**';
    }
    
    // Verificar se é um email
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str)) {
      const [username, domain] = str.split('@');
      return `${username.charAt(0)}*****@${domain}`;
    }
    
    // Verificar se é um telefone
    if (/^\d{10,11}$/.test(str.replace(/\D/g, ''))) {
      return '(**) *****-****';
    }
    
    // Outros tipos de string
    if (str.length <= 5) {
      return '*'.repeat(str.length);
    }
    
    return `${str.charAt(0)}${'*'.repeat(str.length - 2)}${str.charAt(str.length - 1)}`;
  }

  /**
   * Pseudonimiza dados pessoais
   * @param {Object} data Dados a serem pseudonimizados
   * @param {Array} fieldsToPseudonimize Campos a serem pseudonimizados
   * @param {string} salt Sal para pseudonimização
   * @returns {Object} Dados pseudonimizados e mapeamento
   */
  pseudonymizeData(data, fieldsToPseudonimize, salt = '') {
    const pseudonymizedData = cloneDeep(data);
    const mapping = {};
    
    for (const field of fieldsToPseudonimize) {
      const value = get(pseudonymizedData, field);
      
      if (value !== undefined && value !== null) {
        // Gerar pseudônimo
        const pseudonym = this._generatePseudonym(value, salt);
        
        // Armazenar mapeamento
        mapping[field] = {
          original: value,
          pseudonym
        };
        
        // Substituir valor
        set(pseudonymizedData, field, pseudonym);
      }
    }
    
    return {
      data: pseudonymizedData,
      mapping
    };
  }

  /**
   * Gera um pseudônimo para um valor
   * @param {any} value Valor a ser pseudonimizado
   * @param {string} salt Sal para pseudonimização
   * @returns {string} Pseudônimo gerado
   * @private
   */
  _generatePseudonym(value, salt) {
    const valueStr = typeof value === 'string' ? value : JSON.stringify(value);
    const hash = this.hash(`${valueStr}${salt}`);
    return `pseudo_${hash.substring(0, 8)}`;
  }
}

/**
 * Classe para Gestão de Direitos do Titular
 */
export class DataSubjectRightsManager {
  constructor(config = {}) {
    this.config = {
      storageMethod: config.storageMethod || 'memory', // 'memory', 'database'
      requestExpirationDays: config.requestExpirationDays || 30,
      ...config
    };

    // Armazenamento de solicitações
    this.requests = new Map();
  }

  /**
   * Registra uma nova solicitação de direito do titular
   * @param {Object} requestData Dados da solicitação
   * @returns {Promise<Object>} Solicitação registrada
   */
  async registerRequest(requestData) {
    const requestId = requestData.id || uuidv4();
    
    // Calcular data de expiração
    const expirationDate = new Date();
    expirationDate.setDate(expirationDate.getDate() + this.config.requestExpirationDays);
    
    const request = {
      id: requestId,
      userId: requestData.userId,
      userDocument: requestData.userDocument,
      userEmail: requestData.userEmail,
      requestType: requestData.requestType, // 'access', 'rectification', 'deletion', 'portability', 'revocation', 'information'
      details: requestData.details || {},
      status: 'pending', // 'pending', 'in_progress', 'completed', 'rejected'
      createdAt: new Date().toISOString(),
      expiresAt: expirationDate.toISOString(),
      ipAddress: requestData.ipAddress,
      userAgent: requestData.userAgent,
      metadata: requestData.metadata || {}
    };
    
    // Validar solicitação
    this._validateRequest(request);
    
    // Armazenar solicitação
    this.requests.set(requestId, request);
    
    return cloneDeep(request);
  }

  /**
   * Atualiza o status de uma solicitação
   * @param {string} requestId ID da solicitação
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @returns {Promise<Object>} Solicitação atualizada
   */
  async updateRequestStatus(requestId, status, metadata = {}) {
    if (!this.requests.has(requestId)) {
      throw new Error(`Solicitação não encontrada: ${requestId}`);
    }
    
    const request = this.requests.get(requestId);
    
    // Validar transição de status
    this._validateStatusTransition(request.status, status);
    
    // Atualizar status
    request.status = status;
    request.updatedAt = new Date().toISOString();
    
    // Adicionar metadados específicos do status
    if (status === 'completed') {
      request.completedAt = new Date().toISOString();
      request.completionDetails = metadata.completionDetails;
    } else if (status === 'rejected') {
      request.rejectedAt = new Date().toISOString();
      request.rejectionReason = metadata.rejectionReason;
    }
    
    // Atualizar metadados
    request.metadata = {
      ...request.metadata,
      ...metadata
    };
    
    // Armazenar solicitação atualizada
    this.requests.set(requestId, request);
    
    return cloneDeep(request);
  }

  /**
   * Obtém uma solicitação pelo ID
   * @param {string} requestId ID da solicitação
   * @returns {Promise<Object>} Solicitação
   */
  async getRequest(requestId) {
    if (!this.requests.has(requestId)) {
      throw new Error(`Solicitação não encontrada: ${requestId}`);
    }
    
    return cloneDeep(this.requests.get(requestId));
  }

  /**
   * Lista solicitações de um usuário
   * @param {string} userId ID do usuário
   * @returns {Promise<Array>} Lista de solicitações
   */
  async getUserRequests(userId) {
    const userRequests = Array.from(this.requests.values())
      .filter(request => request.userId === userId);
    
    return cloneDeep(userRequests);
  }

  /**
   * Lista todas as solicitações
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de solicitações
   */
  async listRequests(filters = {}) {
    let requests = Array.from(this.requests.values());
    
    // Aplicar filtros
    if (filters.userId) {
      requests = requests.filter(request => request.userId === filters.userId);
    }
    
    if (filters.status) {
      requests = requests.filter(request => request.status === filters.status);
    }
    
    if (filters.requestType) {
      requests = requests.filter(request => request.requestType === filters.requestType);
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      requests = requests.filter(request => new Date(request.createdAt) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      requests = requests.filter(request => new Date(request.createdAt) <= endDate);
    }
    
    // Ordenar por data de criação (mais recente primeiro)
    requests.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Limitar resultados
    if (filters.limit) {
      requests = requests.slice(0, filters.limit);
    }
    
    return cloneDeep(requests);
  }

  /**
   * Valida uma solicitação
   * @param {Object} request Solicitação a ser validada
   * @private
   */
  _validateRequest(request) {
    if (!request.userId) {
      throw new Error('ID do usuário é obrigatório');
    }
    
    if (!request.requestType) {
      throw new Error('Tipo de solicitação é obrigatório');
    }
    
    const validRequestTypes = ['access', 'rectification', 'deletion', 'portability', 'revocation', 'information'];
    if (!validRequestTypes.includes(request.requestType)) {
      throw new Error(`Tipo de solicitação inválido: ${request.requestType}`);
    }
  }

  /**
   * Valida uma transição de status
   * @param {string} currentStatus Status atual
   * @param {string} newStatus Novo status
   * @private
   */
  _validateStatusTransition(currentStatus, newStatus) {
    const validStatuses = ['pending', 'in_progress', 'completed', 'rejected'];
    
    if (!validStatuses.includes(newStatus)) {
      throw new Error(`Status inválido: ${newStatus}`);
    }
    
    // Regras de transição de status
    if (currentStatus === 'completed' || currentStatus === 'rejected') {
      throw new Error(`Não é possível alterar o status de uma solicitação ${currentStatus}`);
    }
    
    if (currentStatus === 'pending' && newStatus !== 'in_progress' && newStatus !== 'rejected') {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    if (currentStatus === 'in_progress' && newStatus === 'pending') {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
  }
}

/**
 * Classe para Gestão de Incidentes de Segurança
 */
export class SecurityIncidentManager {
  constructor(config = {}) {
    this.config = {
      storageMethod: config.storageMethod || 'memory', // 'memory', 'database'
      notificationEmails: config.notificationEmails || [],
      ...config
    };

    // Armazenamento de incidentes
    this.incidents = new Map();
  }

  /**
   * Registra um novo incidente de segurança
   * @param {Object} incidentData Dados do incidente
   * @returns {Promise<Object>} Incidente registrado
   */
  async registerIncident(incidentData) {
    const incidentId = incidentData.id || uuidv4();
    
    const incident = {
      id: incidentId,
      title: incidentData.title,
      description: incidentData.description,
      severity: incidentData.severity || 'medium', // 'low', 'medium', 'high', 'critical'
      category: incidentData.category, // 'data_breach', 'unauthorized_access', 'malware', 'phishing', 'other'
      affectedUsers: incidentData.affectedUsers || [],
      affectedData: incidentData.affectedData || [],
      detectedAt: incidentData.detectedAt || new Date().toISOString(),
      reportedBy: incidentData.reportedBy,
      status: 'open', // 'open', 'investigating', 'contained', 'resolved', 'closed'
      createdAt: new Date().toISOString(),
      metadata: incidentData.metadata || {}
    };
    
    // Validar incidente
    this._validateIncident(incident);
    
    // Armazenar incidente
    this.incidents.set(incidentId, incident);
    
    // Notificar sobre o incidente (simulado)
    this._notifyIncident(incident);
    
    return cloneDeep(incident);
  }

  /**
   * Atualiza o status de um incidente
   * @param {string} incidentId ID do incidente
   * @param {string} status Novo status
   * @param {Object} metadata Metadados adicionais
   * @returns {Promise<Object>} Incidente atualizado
   */
  async updateIncidentStatus(incidentId, status, metadata = {}) {
    if (!this.incidents.has(incidentId)) {
      throw new Error(`Incidente não encontrado: ${incidentId}`);
    }
    
    const incident = this.incidents.get(incidentId);
    
    // Validar transição de status
    this._validateStatusTransition(incident.status, status);
    
    // Atualizar status
    incident.status = status;
    incident.updatedAt = new Date().toISOString();
    
    // Adicionar metadados específicos do status
    if (status === 'contained') {
      incident.containedAt = new Date().toISOString();
      incident.containmentActions = metadata.containmentActions;
    } else if (status === 'resolved') {
      incident.resolvedAt = new Date().toISOString();
      incident.resolutionDetails = metadata.resolutionDetails;
    } else if (status === 'closed') {
      incident.closedAt = new Date().toISOString();
      incident.rootCauseAnalysis = metadata.rootCauseAnalysis;
      incident.preventiveMeasures = metadata.preventiveMeasures;
    }
    
    // Atualizar metadados
    incident.metadata = {
      ...incident.metadata,
      ...metadata
    };
    
    // Armazenar incidente atualizado
    this.incidents.set(incidentId, incident);
    
    return cloneDeep(incident);
  }

  /**
   * Adiciona uma ação a um incidente
   * @param {string} incidentId ID do incidente
   * @param {Object} actionData Dados da ação
   * @returns {Promise<Object>} Incidente atualizado
   */
  async addIncidentAction(incidentId, actionData) {
    if (!this.incidents.has(incidentId)) {
      throw new Error(`Incidente não encontrado: ${incidentId}`);
    }
    
    const incident = this.incidents.get(incidentId);
    
    // Criar ação
    const action = {
      id: uuidv4(),
      description: actionData.description,
      type: actionData.type, // 'investigation', 'containment', 'remediation', 'notification', 'other'
      performedBy: actionData.performedBy,
      performedAt: new Date().toISOString(),
      details: actionData.details || {}
    };
    
    // Adicionar ação ao incidente
    if (!incident.actions) {
      incident.actions = [];
    }
    
    incident.actions.push(action);
    incident.updatedAt = new Date().toISOString();
    
    // Armazenar incidente atualizado
    this.incidents.set(incidentId, incident);
    
    return cloneDeep(incident);
  }

  /**
   * Obtém um incidente pelo ID
   * @param {string} incidentId ID do incidente
   * @returns {Promise<Object>} Incidente
   */
  async getIncident(incidentId) {
    if (!this.incidents.has(incidentId)) {
      throw new Error(`Incidente não encontrado: ${incidentId}`);
    }
    
    return cloneDeep(this.incidents.get(incidentId));
  }

  /**
   * Lista todos os incidentes
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Array>} Lista de incidentes
   */
  async listIncidents(filters = {}) {
    let incidents = Array.from(this.incidents.values());
    
    // Aplicar filtros
    if (filters.status) {
      incidents = incidents.filter(incident => incident.status === filters.status);
    }
    
    if (filters.severity) {
      incidents = incidents.filter(incident => incident.severity === filters.severity);
    }
    
    if (filters.category) {
      incidents = incidents.filter(incident => incident.category === filters.category);
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      incidents = incidents.filter(incident => new Date(incident.createdAt) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      incidents = incidents.filter(incident => new Date(incident.createdAt) <= endDate);
    }
    
    // Ordenar por severidade e data de criação
    incidents.sort((a, b) => {
      const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
      if (severityOrder[a.severity] !== severityOrder[b.severity]) {
        return severityOrder[a.severity] - severityOrder[b.severity];
      }
      return new Date(b.createdAt) - new Date(a.createdAt);
    });
    
    // Limitar resultados
    if (filters.limit) {
      incidents = incidents.slice(0, filters.limit);
    }
    
    return cloneDeep(incidents);
  }

  /**
   * Valida um incidente
   * @param {Object} incident Incidente a ser validado
   * @private
   */
  _validateIncident(incident) {
    if (!incident.title) {
      throw new Error('Título do incidente é obrigatório');
    }
    
    if (!incident.description) {
      throw new Error('Descrição do incidente é obrigatória');
    }
    
    if (!incident.category) {
      throw new Error('Categoria do incidente é obrigatória');
    }
    
    const validCategories = ['data_breach', 'unauthorized_access', 'malware', 'phishing', 'other'];
    if (!validCategories.includes(incident.category)) {
      throw new Error(`Categoria de incidente inválida: ${incident.category}`);
    }
    
    const validSeverities = ['low', 'medium', 'high', 'critical'];
    if (!validSeverities.includes(incident.severity)) {
      throw new Error(`Severidade de incidente inválida: ${incident.severity}`);
    }
  }

  /**
   * Valida uma transição de status
   * @param {string} currentStatus Status atual
   * @param {string} newStatus Novo status
   * @private
   */
  _validateStatusTransition(currentStatus, newStatus) {
    const validStatuses = ['open', 'investigating', 'contained', 'resolved', 'closed'];
    
    if (!validStatuses.includes(newStatus)) {
      throw new Error(`Status inválido: ${newStatus}`);
    }
    
    // Regras de transição de status
    if (currentStatus === 'closed') {
      throw new Error('Não é possível alterar o status de um incidente fechado');
    }
    
    const statusOrder = {
      open: 0,
      investigating: 1,
      contained: 2,
      resolved: 3,
      closed: 4
    };
    
    // Não permitir pular etapas (exceto para 'open' que pode ir para qualquer status)
    if (currentStatus !== 'open' && statusOrder[newStatus] > statusOrder[currentStatus] + 1) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
    
    // Não permitir voltar para status anteriores (exceto 'investigating' que pode voltar para 'open')
    if (currentStatus !== 'investigating' && statusOrder[newStatus] < statusOrder[currentStatus]) {
      throw new Error(`Transição de status inválida: ${currentStatus} -> ${newStatus}`);
    }
  }

  /**
   * Notifica sobre um incidente (simulado)
   * @param {Object} incident Incidente a ser notificado
   * @private
   */
  _notifyIncident(incident) {
    // Simulação de notificação
    console.log(`[Incident Notification] New security incident: ${incident.title} (${incident.severity})`);
    
    // Em um ambiente real, aqui seria enviado um email ou outra notificação
    if (this.config.notificationEmails.length > 0) {
      console.log(`[Incident Notification] Emails would be sent to: ${this.config.notificationEmails.join(', ')}`);
    }
  }
}

/**
 * Serviço Integrado de LGPD e Segurança
 */
export class LgpdSecurityService {
  constructor(config = {}) {
    this.consentManager = new ConsentManager(config.consent);
    this.dataSecurity = new DataSecurity(config.security);
    this.dataSubjectRightsManager = new DataSubjectRightsManager(config.rights);
    this.securityIncidentManager = new SecurityIncidentManager(config.incidents);
  }

  /**
   * Verifica se o processamento de dados é permitido
   * @param {Object} processingContext Contexto do processamento
   * @returns {Promise<Object>} Resultado da verificação
   */
  async verifyDataProcessing(processingContext) {
    const {
      userId,
      consentId,
      purposes,
      dataCategories,
      thirdParties,
      legalBasis
    } = processingContext;
    
    // Resultado padrão
    const result = {
      allowed: false,
      reason: '',
      legalBasisUsed: null,
      consentVerified: false
    };
    
    // Verificar base legal
    if (legalBasis && legalBasis !== 'consent') {
      // Processamento baseado em outra base legal (contrato, interesse legítimo, etc.)
      result.allowed = true;
      result.legalBasisUsed = legalBasis;
      result.reason = `Processamento permitido com base em ${legalBasis}`;
      return result;
    }
    
    // Processamento baseado em consentimento
    if (!consentId) {
      result.reason = 'Consentimento não fornecido';
      return result;
    }
    
    try {
      // Verificar consentimento
      const consentValid = await this.consentManager.verifyConsent(
        consentId,
        purposes,
        dataCategories,
        thirdParties
      );
      
      result.consentVerified = true;
      
      if (consentValid) {
        result.allowed = true;
        result.legalBasisUsed = 'consent';
        result.reason = 'Consentimento válido';
      } else {
        result.reason = 'Consentimento inválido ou insuficiente';
      }
    } catch (error) {
      result.reason = `Erro ao verificar consentimento: ${error.message}`;
    }
    
    return result;
  }

  /**
   * Processa dados com proteção LGPD
   * @param {Object} data Dados a serem processados
   * @param {Object} processingContext Contexto do processamento
   * @returns {Promise<Object>} Resultado do processamento
   */
  async processDataWithProtection(data, processingContext) {
    // Verificar se o processamento é permitido
    const verificationResult = await this.verifyDataProcessing(processingContext);
    
    if (!verificationResult.allowed) {
      throw new Error(`Processamento não permitido: ${verificationResult.reason}`);
    }
    
    // Clonar dados para não modificar o original
    let processedData = cloneDeep(data);
    
    // Aplicar proteções conforme o contexto
    if (processingContext.requiresEncryption) {
      // Criptografar campos sensíveis
      for (const field of processingContext.fieldsToEncrypt || []) {
        const value = get(processedData, field);
        
        if (value !== undefined) {
          const encryptedValue = this.dataSecurity.encrypt(value);
          set(processedData, field, encryptedValue);
        }
      }
    }
    
    if (processingContext.requiresAnonymization) {
      // Anonimizar campos
      processedData = this.dataSecurity.anonymizeData(
        processedData,
        processingContext.fieldsToAnonymize || []
      );
    }
    
    if (processingContext.requiresPseudonymization) {
      // Pseudonimizar campos
      const { data: pseudonymizedData, mapping } = this.dataSecurity.pseudonymizeData(
        processedData,
        processingContext.fieldsToPseudonimize || [],
        processingContext.pseudonymizationSalt
      );
      
      processedData = pseudonymizedData;
      
      // Armazenar mapeamento de pseudônimos (em um sistema real, seria armazenado de forma segura)
      if (processingContext.storePseudonymMapping) {
        // Simulação de armazenamento
        console.log('[Pseudonym Mapping]', mapping);
      }
    }
    
    // Registrar o processamento (em um sistema real, seria registrado em log de auditoria)
    if (processingContext.auditLog) {
      console.log('[Data Processing Audit]', {
        userId: processingContext.userId,
        purposes: processingContext.purposes,
        legalBasis: verificationResult.legalBasisUsed,
        timestamp: new Date().toISOString()
      });
    }
    
    return {
      data: processedData,
      processingInfo: {
        timestamp: new Date().toISOString(),
        legalBasis: verificationResult.legalBasisUsed,
        protectionsApplied: {
          encryption: processingContext.requiresEncryption,
          anonymization: processingContext.requiresAnonymization,
          pseudonymization: processingContext.requiresPseudonymization
        }
      }
    };
  }

  /**
   * Registra um incidente de segurança relacionado a dados pessoais
   * @param {Object} incidentData Dados do incidente
   * @returns {Promise<Object>} Incidente registrado e plano de resposta
   */
  async handleDataBreachIncident(incidentData) {
    // Registrar incidente
    const incident = await this.securityIncidentManager.registerIncident({
      ...incidentData,
      category: 'data_breach'
    });
    
    // Criar plano de resposta
    const responseActions = [
      {
        type: 'investigation',
        description: 'Investigar escopo e impacto do vazamento',
        priority: 'high',
        deadline: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 horas
      },
      {
        type: 'containment',
        description: 'Conter o vazamento e prevenir exposição adicional',
        priority: 'critical',
        deadline: new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString() // 12 horas
      },
      {
        type: 'notification',
        description: 'Notificar autoridade nacional (ANPD)',
        priority: 'high',
        deadline: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString() // 48 horas
      },
      {
        type: 'notification',
        description: 'Notificar titulares afetados',
        priority: 'high',
        deadline: new Date(Date.now() + 72 * 60 * 60 * 1000).toISOString() // 72 horas
      },
      {
        type: 'remediation',
        description: 'Implementar medidas corretivas',
        priority: 'medium',
        deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 7 dias
      }
    ];
    
    // Adicionar ações ao incidente
    for (const action of responseActions) {
      await this.securityIncidentManager.addIncidentAction(incident.id, {
        description: action.description,
        type: action.type,
        performedBy: 'system',
        details: {
          priority: action.priority,
          deadline: action.deadline,
          status: 'pending'
        }
      });
    }
    
    // Atualizar status do incidente
    await this.securityIncidentManager.updateIncidentStatus(incident.id, 'investigating', {
      investigationStarted: new Date().toISOString(),
      investigationTeam: ['dpo', 'security_officer', 'it_manager']
    });
    
    return {
      incident: await this.securityIncidentManager.getIncident(incident.id),
      responseActions
    };
  }
}

export default {
  ConsentManager,
  DataSecurity,
  DataSubjectRightsManager,
  SecurityIncidentManager,
  LgpdSecurityService
};
