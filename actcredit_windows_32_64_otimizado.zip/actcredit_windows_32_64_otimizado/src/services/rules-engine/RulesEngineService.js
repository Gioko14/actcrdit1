/**
 * Motor de Regras Configurável (Low-Code/No-Code)
 * Implementa um sistema flexível para definição, execução e gerenciamento de regras de negócio
 */

import { Engine } from 'json-rules-engine';
import { v4 as uuidv4 } from 'uuid';
import { cloneDeep, isEqual, get, set } from 'lodash';

/**
 * Classe principal do Motor de Regras
 */
export class RulesEngine {
  constructor(config = {}) {
    this.config = {
      enableCache: config.enableCache !== undefined ? config.enableCache : true,
      cacheTTL: config.cacheTTL || 3600000, // 1 hora em milissegundos
      maxRulesPerPolicy: config.maxRulesPerPolicy || 100,
      maxConditionsPerRule: config.maxConditionsPerRule || 20,
      ...config
    };

    // Armazenamento de políticas
    this.policies = new Map();
    
    // Cache de resultados
    this.resultsCache = new Map();
    
    // Registro de execuções para auditoria
    this.executionLog = [];
    
    // Operadores personalizados
    this.customOperators = new Map();
    
    // Funções personalizadas
    this.customFunctions = new Map();
    
    // Registrar operadores padrão
    this._registerDefaultOperators();
    
    // Registrar funções padrão
    this._registerDefaultFunctions();
  }

  /**
   * Registra operadores padrão
   * @private
   */
  _registerDefaultOperators() {
    // Operadores numéricos
    this.registerOperator('equals', (factValue, jsonValue) => factValue === jsonValue);
    this.registerOperator('notEquals', (factValue, jsonValue) => factValue !== jsonValue);
    this.registerOperator('greaterThan', (factValue, jsonValue) => factValue > jsonValue);
    this.registerOperator('greaterThanOrEquals', (factValue, jsonValue) => factValue >= jsonValue);
    this.registerOperator('lessThan', (factValue, jsonValue) => factValue < jsonValue);
    this.registerOperator('lessThanOrEquals', (factValue, jsonValue) => factValue <= jsonValue);
    this.registerOperator('between', (factValue, jsonValue) => {
      return factValue >= jsonValue[0] && factValue <= jsonValue[1];
    });
    
    // Operadores de texto
    this.registerOperator('contains', (factValue, jsonValue) => {
      if (typeof factValue !== 'string') return false;
      return factValue.includes(jsonValue);
    });
    this.registerOperator('notContains', (factValue, jsonValue) => {
      if (typeof factValue !== 'string') return false;
      return !factValue.includes(jsonValue);
    });
    this.registerOperator('startsWith', (factValue, jsonValue) => {
      if (typeof factValue !== 'string') return false;
      return factValue.startsWith(jsonValue);
    });
    this.registerOperator('endsWith', (factValue, jsonValue) => {
      if (typeof factValue !== 'string') return false;
      return factValue.endsWith(jsonValue);
    });
    this.registerOperator('matches', (factValue, jsonValue) => {
      if (typeof factValue !== 'string') return false;
      return new RegExp(jsonValue).test(factValue);
    });
    
    // Operadores de array
    this.registerOperator('in', (factValue, jsonValue) => {
      if (!Array.isArray(jsonValue)) return false;
      return jsonValue.includes(factValue);
    });
    this.registerOperator('notIn', (factValue, jsonValue) => {
      if (!Array.isArray(jsonValue)) return false;
      return !jsonValue.includes(factValue);
    });
    this.registerOperator('containsAny', (factValue, jsonValue) => {
      if (!Array.isArray(factValue) || !Array.isArray(jsonValue)) return false;
      return jsonValue.some(value => factValue.includes(value));
    });
    this.registerOperator('containsAll', (factValue, jsonValue) => {
      if (!Array.isArray(factValue) || !Array.isArray(jsonValue)) return false;
      return jsonValue.every(value => factValue.includes(value));
    });
    
    // Operadores de data
    this.registerOperator('before', (factValue, jsonValue) => {
      const factDate = new Date(factValue);
      const jsonDate = new Date(jsonValue);
      return factDate < jsonDate;
    });
    this.registerOperator('after', (factValue, jsonValue) => {
      const factDate = new Date(factValue);
      const jsonDate = new Date(jsonValue);
      return factDate > jsonDate;
    });
    this.registerOperator('onOrBefore', (factValue, jsonValue) => {
      const factDate = new Date(factValue);
      const jsonDate = new Date(jsonValue);
      return factDate <= jsonDate;
    });
    this.registerOperator('onOrAfter', (factValue, jsonValue) => {
      const factDate = new Date(factValue);
      const jsonDate = new Date(jsonValue);
      return factDate >= jsonDate;
    });
    this.registerOperator('dateBetween', (factValue, jsonValue) => {
      const factDate = new Date(factValue);
      const startDate = new Date(jsonValue[0]);
      const endDate = new Date(jsonValue[1]);
      return factDate >= startDate && factDate <= endDate;
    });
    
    // Operadores lógicos
    this.registerOperator('isNull', (factValue) => factValue === null || factValue === undefined);
    this.registerOperator('isNotNull', (factValue) => factValue !== null && factValue !== undefined);
    this.registerOperator('isEmpty', (factValue) => {
      if (factValue === null || factValue === undefined) return true;
      if (typeof factValue === 'string') return factValue.trim() === '';
      if (Array.isArray(factValue)) return factValue.length === 0;
      if (typeof factValue === 'object') return Object.keys(factValue).length === 0;
      return false;
    });
    this.registerOperator('isNotEmpty', (factValue) => {
      if (factValue === null || factValue === undefined) return false;
      if (typeof factValue === 'string') return factValue.trim() !== '';
      if (Array.isArray(factValue)) return factValue.length > 0;
      if (typeof factValue === 'object') return Object.keys(factValue).length > 0;
      return true;
    });
  }

  /**
   * Registra funções padrão
   * @private
   */
  _registerDefaultFunctions() {
    // Funções matemáticas
    this.registerFunction('sum', (values) => {
      if (!Array.isArray(values)) return 0;
      return values.reduce((sum, value) => sum + (Number(value) || 0), 0);
    });
    this.registerFunction('average', (values) => {
      if (!Array.isArray(values) || values.length === 0) return 0;
      const sum = values.reduce((sum, value) => sum + (Number(value) || 0), 0);
      return sum / values.length;
    });
    this.registerFunction('min', (values) => {
      if (!Array.isArray(values) || values.length === 0) return null;
      return Math.min(...values.map(value => Number(value) || 0));
    });
    this.registerFunction('max', (values) => {
      if (!Array.isArray(values) || values.length === 0) return null;
      return Math.max(...values.map(value => Number(value) || 0));
    });
    
    // Funções de texto
    this.registerFunction('concat', (values, separator = '') => {
      if (!Array.isArray(values)) return '';
      return values.join(separator);
    });
    this.registerFunction('uppercase', (value) => {
      if (typeof value !== 'string') return value;
      return value.toUpperCase();
    });
    this.registerFunction('lowercase', (value) => {
      if (typeof value !== 'string') return value;
      return value.toLowerCase();
    });
    this.registerFunction('substring', (value, start, end) => {
      if (typeof value !== 'string') return '';
      return value.substring(start, end);
    });
    
    // Funções de data
    this.registerFunction('now', () => new Date().toISOString());
    this.registerFunction('today', () => {
      const date = new Date();
      return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    });
    this.registerFunction('addDays', (date, days) => {
      const result = new Date(date);
      result.setDate(result.getDate() + days);
      return result.toISOString();
    });
    this.registerFunction('dateDiff', (date1, date2, unit = 'days') => {
      const d1 = new Date(date1);
      const d2 = new Date(date2);
      const diffMs = Math.abs(d2 - d1);
      
      switch (unit.toLowerCase()) {
        case 'seconds':
          return Math.floor(diffMs / 1000);
        case 'minutes':
          return Math.floor(diffMs / (1000 * 60));
        case 'hours':
          return Math.floor(diffMs / (1000 * 60 * 60));
        case 'days':
          return Math.floor(diffMs / (1000 * 60 * 60 * 24));
        case 'months':
          return (
            (d2.getFullYear() - d1.getFullYear()) * 12 +
            (d2.getMonth() - d1.getMonth())
          );
        case 'years':
          return d2.getFullYear() - d1.getFullYear();
        default:
          return diffMs;
      }
    });
    
    // Funções de array
    this.registerFunction('count', (array) => {
      if (!Array.isArray(array)) return 0;
      return array.length;
    });
    this.registerFunction('first', (array) => {
      if (!Array.isArray(array) || array.length === 0) return null;
      return array[0];
    });
    this.registerFunction('last', (array) => {
      if (!Array.isArray(array) || array.length === 0) return null;
      return array[array.length - 1];
    });
    this.registerFunction('filter', (array, property, operator, value) => {
      if (!Array.isArray(array)) return [];
      
      const operatorFn = this.customOperators.get(operator);
      if (!operatorFn) return array;
      
      return array.filter(item => {
        const propValue = property ? get(item, property) : item;
        return operatorFn(propValue, value);
      });
    });
  }

  /**
   * Registra um operador personalizado
   * @param {string} name Nome do operador
   * @param {Function} operatorFn Função do operador
   */
  registerOperator(name, operatorFn) {
    if (typeof operatorFn !== 'function') {
      throw new Error(`Operador deve ser uma função: ${name}`);
    }
    
    this.customOperators.set(name, operatorFn);
  }

  /**
   * Registra uma função personalizada
   * @param {string} name Nome da função
   * @param {Function} fn Função personalizada
   */
  registerFunction(name, fn) {
    if (typeof fn !== 'function') {
      throw new Error(`Função deve ser uma função: ${name}`);
    }
    
    this.customFunctions.set(name, fn);
  }

  /**
   * Cria uma nova política de regras
   * @param {Object} policyData Dados da política
   * @returns {string} ID da política criada
   */
  createPolicy(policyData) {
    const policyId = policyData.id || uuidv4();
    
    const policy = {
      id: policyId,
      name: policyData.name || `Policy ${policyId}`,
      description: policyData.description || '',
      version: policyData.version || 1,
      rules: policyData.rules || [],
      active: policyData.active !== undefined ? policyData.active : true,
      priority: policyData.priority || 0,
      createdAt: policyData.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      metadata: policyData.metadata || {}
    };
    
    // Validar política
    this._validatePolicy(policy);
    
    // Armazenar política
    this.policies.set(policyId, policy);
    
    return policyId;
  }

  /**
   * Atualiza uma política existente
   * @param {string} policyId ID da política
   * @param {Object} policyData Novos dados da política
   * @returns {boolean} Sucesso da operação
   */
  updatePolicy(policyId, policyData) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    const currentPolicy = this.policies.get(policyId);
    
    const updatedPolicy = {
      ...currentPolicy,
      ...policyData,
      id: policyId, // Garantir que o ID não seja alterado
      version: (currentPolicy.version || 0) + 1,
      updatedAt: new Date().toISOString()
    };
    
    // Validar política
    this._validatePolicy(updatedPolicy);
    
    // Armazenar política atualizada
    this.policies.set(policyId, updatedPolicy);
    
    // Limpar cache relacionado a esta política
    this._clearPolicyCache(policyId);
    
    return true;
  }

  /**
   * Obtém uma política pelo ID
   * @param {string} policyId ID da política
   * @returns {Object} Política
   */
  getPolicy(policyId) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    return cloneDeep(this.policies.get(policyId));
  }

  /**
   * Lista todas as políticas
   * @param {Object} filters Filtros opcionais
   * @returns {Array} Lista de políticas
   */
  listPolicies(filters = {}) {
    let policies = Array.from(this.policies.values());
    
    // Aplicar filtros
    if (filters.active !== undefined) {
      policies = policies.filter(policy => policy.active === filters.active);
    }
    
    if (filters.name) {
      const nameFilter = filters.name.toLowerCase();
      policies = policies.filter(policy => 
        policy.name.toLowerCase().includes(nameFilter)
      );
    }
    
    // Ordenar por prioridade (decrescente) e depois por nome
    policies.sort((a, b) => {
      if (a.priority !== b.priority) {
        return b.priority - a.priority;
      }
      return a.name.localeCompare(b.name);
    });
    
    return cloneDeep(policies);
  }

  /**
   * Exclui uma política
   * @param {string} policyId ID da política
   * @returns {boolean} Sucesso da operação
   */
  deletePolicy(policyId) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    // Remover política
    this.policies.delete(policyId);
    
    // Limpar cache relacionado a esta política
    this._clearPolicyCache(policyId);
    
    return true;
  }

  /**
   * Ativa ou desativa uma política
   * @param {string} policyId ID da política
   * @param {boolean} active Estado de ativação
   * @returns {boolean} Sucesso da operação
   */
  setPolicyActive(policyId, active) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    const policy = this.policies.get(policyId);
    
    // Atualizar estado de ativação
    policy.active = active;
    policy.updatedAt = new Date().toISOString();
    
    // Armazenar política atualizada
    this.policies.set(policyId, policy);
    
    // Limpar cache relacionado a esta política
    this._clearPolicyCache(policyId);
    
    return true;
  }

  /**
   * Adiciona uma regra a uma política
   * @param {string} policyId ID da política
   * @param {Object} ruleData Dados da regra
   * @returns {string} ID da regra adicionada
   */
  addRule(policyId, ruleData) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    const policy = this.policies.get(policyId);
    
    // Verificar limite de regras
    if (policy.rules.length >= this.config.maxRulesPerPolicy) {
      throw new Error(`Limite de regras excedido: ${this.config.maxRulesPerPolicy}`);
    }
    
    const ruleId = ruleData.id || uuidv4();
    
    const rule = {
      id: ruleId,
      name: ruleData.name || `Rule ${ruleId}`,
      description: ruleData.description || '',
      conditions: ruleData.conditions || [],
      actions: ruleData.actions || [],
      priority: ruleData.priority || 0,
      active: ruleData.active !== undefined ? ruleData.active : true,
      createdAt: new Date().toISOString(),
      metadata: ruleData.metadata || {}
    };
    
    // Validar regra
    this._validateRule(rule);
    
    // Adicionar regra à política
    policy.rules.push(rule);
    policy.updatedAt = new Date().toISOString();
    policy.version = (policy.version || 0) + 1;
    
    // Armazenar política atualizada
    this.policies.set(policyId, policy);
    
    // Limpar cache relacionado a esta política
    this._clearPolicyCache(policyId);
    
    return ruleId;
  }

  /**
   * Atualiza uma regra existente
   * @param {string} policyId ID da política
   * @param {string} ruleId ID da regra
   * @param {Object} ruleData Novos dados da regra
   * @returns {boolean} Sucesso da operação
   */
  updateRule(policyId, ruleId, ruleData) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    const policy = this.policies.get(policyId);
    
    // Encontrar índice da regra
    const ruleIndex = policy.rules.findIndex(rule => rule.id === ruleId);
    
    if (ruleIndex === -1) {
      throw new Error(`Regra não encontrada: ${ruleId}`);
    }
    
    const currentRule = policy.rules[ruleIndex];
    
    const updatedRule = {
      ...currentRule,
      ...ruleData,
      id: ruleId, // Garantir que o ID não seja alterado
      updatedAt: new Date().toISOString()
    };
    
    // Validar regra
    this._validateRule(updatedRule);
    
    // Atualizar regra na política
    policy.rules[ruleIndex] = updatedRule;
    policy.updatedAt = new Date().toISOString();
    policy.version = (policy.version || 0) + 1;
    
    // Armazenar política atualizada
    this.policies.set(policyId, policy);
    
    // Limpar cache relacionado a esta política
    this._clearPolicyCache(policyId);
    
    return true;
  }

  /**
   * Remove uma regra de uma política
   * @param {string} policyId ID da política
   * @param {string} ruleId ID da regra
   * @returns {boolean} Sucesso da operação
   */
  removeRule(policyId, ruleId) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    const policy = this.policies.get(policyId);
    
    // Encontrar índice da regra
    const ruleIndex = policy.rules.findIndex(rule => rule.id === ruleId);
    
    if (ruleIndex === -1) {
      throw new Error(`Regra não encontrada: ${ruleId}`);
    }
    
    // Remover regra da política
    policy.rules.splice(ruleIndex, 1);
    policy.updatedAt = new Date().toISOString();
    policy.version = (policy.version || 0) + 1;
    
    // Armazenar política atualizada
    this.policies.set(policyId, policy);
    
    // Limpar cache relacionado a esta política
    this._clearPolicyCache(policyId);
    
    return true;
  }

  /**
   * Executa uma política com dados de entrada
   * @param {string} policyId ID da política
   * @param {Object} facts Dados de entrada
   * @param {Object} options Opções de execução
   * @returns {Promise<Object>} Resultado da execução
   */
  async executePolicy(policyId, facts, options = {}) {
    if (!this.policies.has(policyId)) {
      throw new Error(`Política não encontrada: ${policyId}`);
    }
    
    const policy = this.policies.get(policyId);
    
    // Verificar se a política está ativa
    if (!policy.active && !options.ignoreActive) {
      throw new Error(`Política inativa: ${policyId}`);
    }
    
    // Verificar cache
    if (this.config.enableCache && !options.skipCache) {
      const cacheKey = this._generateCacheKey(policyId, facts);
      const cachedResult = this._getCachedResult(cacheKey);
      
      if (cachedResult) {
        return cachedResult;
      }
    }
    
    // Criar engine de regras
    const engine = new Engine();
    
    // Adicionar regras ativas à engine
    const activeRules = policy.rules
      .filter(rule => rule.active || options.ignoreActive)
      .sort((a, b) => b.priority - a.priority);
    
    for (const rule of activeRules) {
      const ruleDefinition = this._convertRuleToEngineFormat(rule);
      engine.addRule(ruleDefinition);
    }
    
    // Preparar resultado
    const result = {
      policyId,
      policyName: policy.name,
      policyVersion: policy.version,
      executionId: uuidv4(),
      timestamp: new Date().toISOString(),
      facts: cloneDeep(facts),
      results: [],
      actions: [],
      success: true
    };
    
    try {
      // Executar engine
      const { results, events } = await engine.run(facts);
      
      // Processar resultados
      result.results = results;
      
      // Processar ações
      for (const event of events) {
        const actions = event.params.actions || [];
        
        for (const action of actions) {
          // Executar ação
          const actionResult = await this._executeAction(action, facts);
          
          // Adicionar resultado da ação
          result.actions.push({
            ...action,
            result: actionResult
          });
        }
      }
    } catch (error) {
      result.success = false;
      result.error = {
        message: error.message,
        stack: error.stack
      };
    }
    
    // Registrar execução
    this._logExecution(result);
    
    // Armazenar em cache
    if (this.config.enableCache && !options.skipCache) {
      const cacheKey = this._generateCacheKey(policyId, facts);
      this._cacheResult(cacheKey, result);
    }
    
    return result;
  }

  /**
   * Executa todas as políticas ativas com dados de entrada
   * @param {Object} facts Dados de entrada
   * @param {Object} options Opções de execução
   * @returns {Promise<Object>} Resultado da execução
   */
  async executeAllPolicies(facts, options = {}) {
    // Obter políticas ativas
    const policies = this.listPolicies({ active: true });
    
    // Ordenar por prioridade
    policies.sort((a, b) => b.priority - a.priority);
    
    // Preparar resultado
    const result = {
      executionId: uuidv4(),
      timestamp: new Date().toISOString(),
      facts: cloneDeep(facts),
      policyResults: [],
      success: true
    };
    
    // Executar cada política
    for (const policy of policies) {
      try {
        const policyResult = await this.executePolicy(policy.id, facts, options);
        result.policyResults.push(policyResult);
      } catch (error) {
        result.policyResults.push({
          policyId: policy.id,
          policyName: policy.name,
          success: false,
          error: {
            message: error.message,
            stack: error.stack
          }
        });
        
        // Se a opção failFast estiver ativada, interromper execução
        if (options.failFast) {
          result.success = false;
          break;
        }
      }
    }
    
    // Verificar sucesso geral
    result.success = result.policyResults.every(policyResult => policyResult.success);
    
    // Agregar ações
    result.actions = result.policyResults.flatMap(policyResult => policyResult.actions || []);
    
    return result;
  }

  /**
   * Obtém o histórico de execuções
   * @param {Object} filters Filtros opcionais
   * @returns {Array} Histórico de execuções
   */
  getExecutionHistory(filters = {}) {
    let history = [...this.executionLog];
    
    // Aplicar filtros
    if (filters.policyId) {
      history = history.filter(entry => entry.policyId === filters.policyId);
    }
    
    if (filters.success !== undefined) {
      history = history.filter(entry => entry.success === filters.success);
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate);
      history = history.filter(entry => new Date(entry.timestamp) >= startDate);
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate);
      history = history.filter(entry => new Date(entry.timestamp) <= endDate);
    }
    
    // Ordenar por timestamp (mais recente primeiro)
    history.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    // Limitar resultados
    if (filters.limit) {
      history = history.slice(0, filters.limit);
    }
    
    return cloneDeep(history);
  }

  /**
   * Limpa o histórico de execuções
   */
  clearExecutionHistory() {
    this.executionLog = [];
  }

  /**
   * Limpa o cache de resultados
   */
  clearCache() {
    this.resultsCache.clear();
  }

  /**
   * Exporta todas as políticas
   * @returns {Object} Políticas exportadas
   */
  exportPolicies() {
    return {
      version: '1.0',
      timestamp: new Date().toISOString(),
      policies: Array.from(this.policies.values())
    };
  }

  /**
   * Importa políticas
   * @param {Object} data Dados de importação
   * @param {boolean} overwrite Se deve sobrescrever políticas existentes
   * @returns {Object} Resultado da importação
   */
  importPolicies(data, overwrite = false) {
    if (!data || !data.policies || !Array.isArray(data.policies)) {
      throw new Error('Formato de importação inválido');
    }
    
    const result = {
      success: true,
      imported: 0,
      skipped: 0,
      errors: []
    };
    
    for (const policy of data.policies) {
      try {
        // Verificar se a política já existe
        const exists = this.policies.has(policy.id);
        
        if (exists && !overwrite) {
          result.skipped++;
          continue;
        }
        
        // Validar política
        this._validatePolicy(policy);
        
        // Armazenar política
        this.policies.set(policy.id, cloneDeep(policy));
        
        result.imported++;
      } catch (error) {
        result.errors.push({
          policyId: policy.id,
          message: error.message
        });
      }
    }
    
    result.success = result.errors.length === 0;
    
    return result;
  }

  /**
   * Valida uma política
   * @param {Object} policy Política a ser validada
   * @private
   */
  _validatePolicy(policy) {
    if (!policy.id) {
      throw new Error('ID da política é obrigatório');
    }
    
    if (!policy.name) {
      throw new Error('Nome da política é obrigatório');
    }
    
    if (policy.rules.length > this.config.maxRulesPerPolicy) {
      throw new Error(`Limite de regras excedido: ${this.config.maxRulesPerPolicy}`);
    }
    
    // Validar cada regra
    for (const rule of policy.rules) {
      this._validateRule(rule);
    }
  }

  /**
   * Valida uma regra
   * @param {Object} rule Regra a ser validada
   * @private
   */
  _validateRule(rule) {
    if (!rule.id) {
      throw new Error('ID da regra é obrigatório');
    }
    
    if (!rule.name) {
      throw new Error('Nome da regra é obrigatório');
    }
    
    if (!rule.conditions || !Array.isArray(rule.conditions)) {
      throw new Error('Condições da regra são obrigatórias');
    }
    
    if (rule.conditions.length === 0) {
      throw new Error('Regra deve ter pelo menos uma condição');
    }
    
    if (rule.conditions.length > this.config.maxConditionsPerRule) {
      throw new Error(`Limite de condições excedido: ${this.config.maxConditionsPerRule}`);
    }
    
    if (!rule.actions || !Array.isArray(rule.actions)) {
      throw new Error('Ações da regra são obrigatórias');
    }
    
    if (rule.actions.length === 0) {
      throw new Error('Regra deve ter pelo menos uma ação');
    }
    
    // Validar cada condição
    for (const condition of rule.conditions) {
      this._validateCondition(condition);
    }
    
    // Validar cada ação
    for (const action of rule.actions) {
      this._validateAction(action);
    }
  }

  /**
   * Valida uma condição
   * @param {Object} condition Condição a ser validada
   * @private
   */
  _validateCondition(condition) {
    if (!condition.fact) {
      throw new Error('Fact da condição é obrigatório');
    }
    
    if (!condition.operator) {
      throw new Error('Operador da condição é obrigatório');
    }
    
    // Verificar se o operador existe
    if (!this.customOperators.has(condition.operator)) {
      throw new Error(`Operador não registrado: ${condition.operator}`);
    }
    
    // Validar valor da condição
    if (condition.value === undefined && !condition.valueFunction) {
      throw new Error('Valor ou função de valor da condição é obrigatório');
    }
    
    // Validar função de valor
    if (condition.valueFunction) {
      if (!condition.valueFunction.name) {
        throw new Error('Nome da função de valor é obrigatório');
      }
      
      if (!this.customFunctions.has(condition.valueFunction.name)) {
        throw new Error(`Função não registrada: ${condition.valueFunction.name}`);
      }
    }
  }

  /**
   * Valida uma ação
   * @param {Object} action Ação a ser validada
   * @private
   */
  _validateAction(action) {
    if (!action.type) {
      throw new Error('Tipo da ação é obrigatório');
    }
    
    // Validar parâmetros da ação
    if (action.type === 'function' && !action.function) {
      throw new Error('Função da ação é obrigatória para ações do tipo function');
    }
    
    if (action.type === 'function' && !this.customFunctions.has(action.function)) {
      throw new Error(`Função não registrada: ${action.function}`);
    }
  }

  /**
   * Converte uma regra para o formato da engine
   * @param {Object} rule Regra a ser convertida
   * @returns {Object} Regra no formato da engine
   * @private
   */
  _convertRuleToEngineFormat(rule) {
    // Converter condições para o formato da engine
    const conditions = {
      all: rule.conditions.map(condition => {
        const engineCondition = {
          fact: condition.fact,
          operator: condition.operator,
          value: condition.value
        };
        
        // Se houver uma função de valor, substituir o valor pelo resultado da função
        if (condition.valueFunction) {
          const fn = this.customFunctions.get(condition.valueFunction.name);
          
          if (fn) {
            engineCondition.value = fn(...(condition.valueFunction.args || []));
          }
        }
        
        return engineCondition;
      })
    };
    
    // Criar regra no formato da engine
    return {
      conditions,
      event: {
        type: rule.id,
        params: {
          rule: {
            id: rule.id,
            name: rule.name
          },
          actions: rule.actions
        }
      }
    };
  }

  /**
   * Executa uma ação
   * @param {Object} action Ação a ser executada
   * @param {Object} facts Dados de entrada
   * @returns {Promise<any>} Resultado da ação
   * @private
   */
  async _executeAction(action, facts) {
    switch (action.type) {
      case 'function':
        return this._executeFunctionAction(action, facts);
      
      case 'setFact':
        return this._executeSetFactAction(action, facts);
      
      case 'notification':
        return this._executeNotificationAction(action, facts);
      
      default:
        throw new Error(`Tipo de ação não suportado: ${action.type}`);
    }
  }

  /**
   * Executa uma ação de função
   * @param {Object} action Ação a ser executada
   * @param {Object} facts Dados de entrada
   * @returns {Promise<any>} Resultado da ação
   * @private
   */
  async _executeFunctionAction(action, facts) {
    const fn = this.customFunctions.get(action.function);
    
    if (!fn) {
      throw new Error(`Função não registrada: ${action.function}`);
    }
    
    // Preparar argumentos
    const args = (action.args || []).map(arg => {
      // Se o argumento for uma referência a um fact, obter o valor do fact
      if (arg && arg.factRef) {
        return get(facts, arg.factRef);
      }
      
      return arg;
    });
    
    // Executar função
    return fn(...args);
  }

  /**
   * Executa uma ação de definição de fact
   * @param {Object} action Ação a ser executada
   * @param {Object} facts Dados de entrada
   * @returns {Promise<any>} Resultado da ação
   * @private
   */
  async _executeSetFactAction(action, facts) {
    if (!action.fact) {
      throw new Error('Fact da ação é obrigatório');
    }
    
    if (action.value === undefined && !action.valueFunction) {
      throw new Error('Valor ou função de valor da ação é obrigatório');
    }
    
    let value = action.value;
    
    // Se houver uma função de valor, obter o valor da função
    if (action.valueFunction) {
      const fn = this.customFunctions.get(action.valueFunction.name);
      
      if (!fn) {
        throw new Error(`Função não registrada: ${action.valueFunction.name}`);
      }
      
      // Preparar argumentos
      const args = (action.valueFunction.args || []).map(arg => {
        // Se o argumento for uma referência a um fact, obter o valor do fact
        if (arg && arg.factRef) {
          return get(facts, arg.factRef);
        }
        
        return arg;
      });
      
      // Executar função
      value = fn(...args);
    }
    
    // Definir valor no fact
    set(facts, action.fact, value);
    
    return value;
  }

  /**
   * Executa uma ação de notificação
   * @param {Object} action Ação a ser executada
   * @param {Object} facts Dados de entrada
   * @returns {Promise<any>} Resultado da ação
   * @private
   */
  async _executeNotificationAction(action, facts) {
    if (!action.message) {
      throw new Error('Mensagem da ação é obrigatória');
    }
    
    // Processar mensagem (substituir variáveis)
    const message = action.message.replace(/\${([^}]+)}/g, (match, factPath) => {
      return get(facts, factPath, match);
    });
    
    // Em um ambiente real, aqui seria enviada a notificação
    // Para este exemplo, apenas retornamos a mensagem processada
    return {
      type: action.notificationType || 'info',
      message,
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Gera uma chave de cache
   * @param {string} policyId ID da política
   * @param {Object} facts Dados de entrada
   * @returns {string} Chave de cache
   * @private
   */
  _generateCacheKey(policyId, facts) {
    // Criar hash dos facts
    const factsString = JSON.stringify(facts);
    const factsHash = this._hashString(factsString);
    
    return `${policyId}:${factsHash}`;
  }

  /**
   * Gera um hash de uma string
   * @param {string} str String a ser hasheada
   * @returns {string} Hash da string
   * @private
   */
  _hashString(str) {
    let hash = 0;
    
    if (str.length === 0) {
      return hash.toString(16);
    }
    
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Converter para inteiro de 32 bits
    }
    
    return hash.toString(16);
  }

  /**
   * Obtém um resultado do cache
   * @param {string} cacheKey Chave de cache
   * @returns {Object|null} Resultado do cache ou null se não encontrado
   * @private
   */
  _getCachedResult(cacheKey) {
    if (!this.resultsCache.has(cacheKey)) {
      return null;
    }
    
    const cachedEntry = this.resultsCache.get(cacheKey);
    
    // Verificar se o cache expirou
    if (Date.now() > cachedEntry.expiresAt) {
      this.resultsCache.delete(cacheKey);
      return null;
    }
    
    return cloneDeep(cachedEntry.result);
  }

  /**
   * Armazena um resultado no cache
   * @param {string} cacheKey Chave de cache
   * @param {Object} result Resultado a ser armazenado
   * @private
   */
  _cacheResult(cacheKey, result) {
    this.resultsCache.set(cacheKey, {
      result: cloneDeep(result),
      expiresAt: Date.now() + this.config.cacheTTL
    });
  }

  /**
   * Limpa o cache relacionado a uma política
   * @param {string} policyId ID da política
   * @private
   */
  _clearPolicyCache(policyId) {
    // Remover todas as entradas de cache que começam com o ID da política
    for (const key of this.resultsCache.keys()) {
      if (key.startsWith(`${policyId}:`)) {
        this.resultsCache.delete(key);
      }
    }
  }

  /**
   * Registra uma execução no histórico
   * @param {Object} result Resultado da execução
   * @private
   */
  _logExecution(result) {
    // Limitar tamanho do histórico
    if (this.executionLog.length >= 1000) {
      this.executionLog.shift();
    }
    
    this.executionLog.push(cloneDeep(result));
  }
}

/**
 * Componente React para editor visual de regras
 */
export class RulesEditor {
  constructor(config = {}) {
    this.config = {
      ...config
    };
    
    this.rulesEngine = new RulesEngine(config);
  }
  
  // Métodos para integração com o editor visual serão implementados aqui
}

export default {
  RulesEngine,
  RulesEditor
};
