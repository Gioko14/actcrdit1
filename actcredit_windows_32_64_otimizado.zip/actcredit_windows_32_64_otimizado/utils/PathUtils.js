/**
 * Utilitário para manipulação de caminhos multiplataforma
 * Compatível com Windows 32/64 bits e sistemas Unix-like
 */

const path = require('path');
const fs = require('fs');
const os = require('os');

/**
 * Determina o diretório base da aplicação independente do ponto de execução
 * @returns {string} Caminho absoluto para o diretório raiz da aplicação
 */
function getAppRoot() {
    return path.resolve(__dirname, '..');
}

/**
 * Normaliza um caminho para o formato do sistema operacional atual
 * @param {string} filePath - Caminho a ser normalizado
 * @returns {string} Caminho normalizado
 */
function normalizePath(filePath) {
    return path.normalize(filePath);
}

/**
 * Verifica se um caminho existe e é acessível
 * @param {string} filePath - Caminho a ser verificado
 * @returns {boolean} Verdadeiro se o caminho existe e é acessível
 */
function pathExists(filePath) {
    try {
        fs.accessSync(filePath);
        return true;
    } catch (err) {
        return false;
    }
}

/**
 * Cria um diretório recursivamente se não existir
 * @param {string} dirPath - Caminho do diretório a ser criado
 * @returns {boolean} Verdadeiro se o diretório foi criado ou já existia
 */
function ensureDirectoryExists(dirPath) {
    try {
        if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
        }
        return true;
    } catch (err) {
        console.error(`Erro ao criar diretório ${dirPath}:`, err);
        return false;
    }
}

/**
 * Detecta a arquitetura do sistema (32 ou 64 bits)
 * @returns {string} '32' ou '64' indicando a arquitetura
 */
function detectArchitecture() {
    const arch = os.arch();
    if (arch === 'x64' || arch === 'arm64') {
        return '64';
    } else {
        return '32';
    }
}

/**
 * Verifica se o sistema é Windows
 * @returns {boolean} Verdadeiro se o sistema for Windows
 */
function isWindows() {
    return os.platform() === 'win32';
}

module.exports = {
    getAppRoot,
    normalizePath,
    pathExists,
    ensureDirectoryExists,
    detectArchitecture,
    isWindows
};
