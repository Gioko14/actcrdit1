/**
 * Script de inicialização multiplataforma para ActCredit
 * Garante compatibilidade entre Windows 32/64 bits e sistemas Unix-like
 */

const express = require('express');
const path = require('path');
const fs = require('fs');
const PathUtils = require('./utils/PathUtils');

// Configuração do servidor
const app = express();
const PORT = process.env.NODE_PORT || 3000;

// Verificar e criar diretórios necessários
const ensureDirectoryExists = (dirPath) => {
  if (!fs.existsSync(dirPath)) {
    try {
      fs.mkdirSync(dirPath, { recursive: true });
      console.log(`Diretório criado: ${dirPath}`);
    } catch (err) {
      console.error(`Erro ao criar diretório ${dirPath}:`, err);
    }
  }
};

// Criar diretórios essenciais
ensureDirectoryExists(path.join(__dirname, 'logs'));
ensureDirectoryExists(path.join(__dirname, 'data'));
ensureDirectoryExists(path.join(__dirname, 'temp'));
ensureDirectoryExists(path.join(__dirname, 'uploads'));

// Verificar se o diretório dist existe
const distPath = path.join(__dirname, 'dist');
if (!fs.existsSync(distPath)) {
  console.warn(`Aviso: Diretório de distribuição não encontrado em ${distPath}`);
  console.log('Criando diretório dist com página básica...');
  
  ensureDirectoryExists(distPath);
  
  // Criar um arquivo index.html básico
  const indexHtml = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ActCredit - Sistema de Análise de Crédito</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
        }
        .status {
            padding: 15px;
            background-color: #e7f4ff;
            border-left: 4px solid #2980b9;
            margin-bottom: 20px;
        }
        .info {
            margin-top: 30px;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>ActCredit - Sistema de Análise de Crédito</h1>
        
        <div class="status">
            <h2>Status do Sistema</h2>
            <p>O servidor backend está em execução.</p>
            <p>Arquitetura do sistema: ${PathUtils.detectArchitecture()} bits</p>
        </div>
        
        <div class="info">
            <h2>Informações</h2>
            <p>Esta é uma página temporária. O sistema ActCredit está funcionando corretamente no backend.</p>
            <p>Para processar documentos, utilize a API REST disponível ou aguarde o carregamento completo da interface.</p>
        </div>
    </div>
</body>
</html>`;

  fs.writeFileSync(path.join(distPath, 'index.html'), indexHtml);
  console.log('Página básica criada com sucesso.');
}

// Servir arquivos estáticos da pasta dist
app.use(express.static(distPath));

// Middleware para logging de requisições
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] ${req.method} ${req.url}`;
  
  console.log(logMessage);
  
  // Também salvar em arquivo de log
  const logDir = path.join(__dirname, 'logs');
  const logFile = path.join(logDir, 'server.log');
  
  try {
    fs.appendFileSync(logFile, logMessage + '\n');
  } catch (err) {
    console.error('Erro ao escrever no arquivo de log:', err);
  }
  
  next();
});

// API básica para verificação de status
app.get('/api/status', (req, res) => {
  res.json({
    status: 'online',
    version: '1.0.0',
    architecture: PathUtils.detectArchitecture() + ' bits',
    timestamp: new Date().toISOString()
  });
});

// Middleware para tratamento de erros
app.use((err, req, res, next) => {
  const timestamp = new Date().toISOString();
  console.error(`[${timestamp}] Erro:`, err);
  
  // Também salvar em arquivo de log
  const logDir = path.join(__dirname, 'logs');
  const logFile = path.join(logDir, 'errors.log');
  
  try {
    fs.appendFileSync(logFile, `[${timestamp}] ${err.stack || err}\n`);
  } catch (logErr) {
    console.error('Erro ao escrever no arquivo de log de erros:', logErr);
  }
  
  res.status(500).send('Erro interno do servidor');
});

// Redirecionar todas as requisições para o index.html (necessário para SPA)
app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

// Iniciar o servidor
app.listen(PORT, '0.0.0.0', () => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] Servidor ActCredit rodando na porta ${PORT}`);
  console.log(`Sistema operacional: ${process.platform}`);
  console.log(`Arquitetura: ${PathUtils.detectArchitecture()} bits`);
  console.log(`Diretório de distribuição: ${distPath}`);
  console.log(`Acesse: http://localhost:${PORT}`);
  
  // Também salvar em arquivo de log
  const logDir = path.join(__dirname, 'logs');
  const logFile = path.join(logDir, 'server.log');
  
  try {
    fs.appendFileSync(logFile, `[${timestamp}] Servidor iniciado na porta ${PORT}\n`);
  } catch (err) {
    console.error('Erro ao escrever no arquivo de log:', err);
  }
});

// Tratamento de sinais para encerramento gracioso
process.on('SIGTERM', () => {
  console.log('Recebido sinal SIGTERM, encerrando servidor...');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Recebido sinal SIGINT, encerrando servidor...');
  process.exit(0);
});

// Tratamento de exceções não capturadas
process.on('uncaughtException', (err) => {
  const timestamp = new Date().toISOString();
  console.error(`[${timestamp}] Exceção não capturada:`, err);
  
  // Também salvar em arquivo de log
  const logDir = path.join(__dirname, 'logs');
  const logFile = path.join(logDir, 'errors.log');
  
  try {
    fs.appendFileSync(logFile, `[${timestamp}] Exceção não capturada: ${err.stack || err}\n`);
  } catch (logErr) {
    console.error('Erro ao escrever no arquivo de log de erros:', logErr);
  }
  
  // Não encerramos o processo para permitir que o servidor continue funcionando
  // process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  const timestamp = new Date().toISOString();
  console.error(`[${timestamp}] Rejeição não tratada em:`, promise, 'razão:', reason);
  
  // Também salvar em arquivo de log
  const logDir = path.join(__dirname, 'logs');
  const logFile = path.join(logDir, 'errors.log');
  
  try {
    fs.appendFileSync(logFile, `[${timestamp}] Rejeição não tratada: ${reason}\n`);
  } catch (logErr) {
    console.error('Erro ao escrever no arquivo de log de erros:', logErr);
  }
  
  // Não encerramos o processo para permitir que o servidor continue funcionando
});
