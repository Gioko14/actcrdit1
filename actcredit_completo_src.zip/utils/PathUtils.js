/**
 * Utilitário para manipulação de caminhos compatível com Windows e Linux
 * 
 * Este módulo fornece funções para garantir que os caminhos de arquivos
 * sejam tratados corretamente em diferentes sistemas operacionais.
 */

const path = require('path');
const fs = require('fs');
const os = require('os');

/**
 * Verifica se o sistema operacional é Windows
 * @returns {boolean} True se o sistema for Windows, false caso contrário
 */
function isWindows() {
  return os.platform() === 'win32';
}

/**
 * Normaliza um caminho para o sistema operacional atual
 * @param {string} filePath - Caminho a ser normalizado
 * @returns {string} Caminho normalizado
 */
function normalizePath(filePath) {
  return path.normalize(filePath);
}

/**
 * Junta segmentos de caminho de forma compatível com o sistema operacional
 * @param {...string} paths - Segmentos de caminho para juntar
 * @returns {string} Caminho completo
 */
function joinPaths(...paths) {
  return path.join(...paths);
}

/**
 * Resolve um caminho relativo para absoluto
 * @param {string} relativePath - Caminho relativo
 * @returns {string} Caminho absoluto
 */
function resolvePath(relativePath) {
  return path.resolve(relativePath);
}

/**
 * Verifica se um caminho existe
 * @param {string} filePath - Caminho a ser verificado
 * @returns {boolean} True se o caminho existir, false caso contrário
 */
function pathExists(filePath) {
  try {
    fs.accessSync(filePath);
    return true;
  } catch (err) {
    return false;
  }
}

/**
 * Cria um diretório recursivamente se não existir
 * @param {string} dirPath - Caminho do diretório
 */
function ensureDirectoryExists(dirPath) {
  if (!pathExists(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

/**
 * Obtém o diretório base da aplicação
 * @returns {string} Caminho do diretório base
 */
function getAppRootDir() {
  return path.resolve(__dirname, '..');
}

/**
 * Obtém o diretório temporário do sistema
 * @returns {string} Caminho do diretório temporário
 */
function getTempDir() {
  return os.tmpdir();
}

module.exports = {
  isWindows,
  normalizePath,
  joinPaths,
  resolvePath,
  pathExists,
  ensureDirectoryExists,
  getAppRootDir,
  getTempDir
};
