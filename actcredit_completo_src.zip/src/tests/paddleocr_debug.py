import sys
import json
import os
from paddleocr import PaddleOCR

# Script simplificado para testar o PaddleOCR com debug detalhado
try:
    # Caminho da imagem de teste
    image_path = sys.argv[1] if len(sys.argv) > 1 else '/home/ubuntu/actcredit/actcredit/src/tests/test_ocr/test_text.png'
    
    # Verificar se o arquivo existe
    if not os.path.exists(image_path):
        print(json.dumps({"success": False, "error": f"Arquivo não encontrado: {image_path}"}))
        sys.exit(1)
    
    print("DEBUG: Iniciando PaddleOCR...")
    
    # Inicializar PaddleOCR com configurações básicas
    ocr = PaddleOCR(lang='por')
    
    print(f"DEBUG: PaddleOCR inicializado. Processando imagem: {image_path}")
    
    # Realizar OCR na imagem
    result = ocr.predict(image_path)
    
    print(f"DEBUG: Resultado bruto: {result}")
    
    # Extrair texto com verificação de estrutura
    extracted_text = ""
    if result:
        print(f"DEBUG: Tipo do resultado: {type(result)}")
        print(f"DEBUG: Comprimento do resultado: {len(result)}")
        
        for idx in range(len(result)):
            res = result[idx]
            print(f"DEBUG: Tipo do resultado[{idx}]: {type(res)}")
            print(f"DEBUG: Conteúdo do resultado[{idx}]: {res}")
            
            if isinstance(res, list):
                for line_idx, line in enumerate(res):
                    print(f"DEBUG: Linha {line_idx}: {line}")
                    if isinstance(line, list) and len(line) > 1:
                        if isinstance(line[1], tuple) and len(line[1]) > 0:
                            extracted_text += line[1][0] + "\n"
                            print(f"DEBUG: Texto extraído: {line[1][0]}")
    
    # Imprimir resultado como JSON
    output = {
        "success": True,
        "text": extracted_text,
        "result_length": len(result) if result else 0
    }
    print(json.dumps(output))
    sys.exit(0)
except Exception as e:
    import traceback
    # Imprimir erro como JSON com stack trace
    error_output = {
        "success": False,
        "error": str(e),
        "traceback": traceback.format_exc()
    }
    print(json.dumps(error_output))
    sys.exit(1)
