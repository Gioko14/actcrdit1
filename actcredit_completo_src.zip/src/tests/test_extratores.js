/**
 * Script de teste para validar o funcionamento dos extratores OCR
 * Testa tanto o Tesseract quanto o PaddleOCR (deep learning)
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const tesseractService = require('../services/ocr/TesseractService');
const paddleOCRService = require('../services/ocr/PaddleOCRService');

// Diretório para testes
const testDir = path.join(__dirname, 'test_ocr');
if (!fs.existsSync(testDir)) {
  fs.mkdirSync(testDir, { recursive: true });
}

// Criar uma imagem de teste com texto
const createTestImage = () => {
  const imagePath = path.join(testDir, 'test_text.png');
  
  // Verificar se a imagem já existe
  if (fs.existsSync(imagePath)) {
    console.log(`Imagem de teste já existe em: ${imagePath}`);
    return imagePath;
  }
  
  try {
    // Usar o comando convert do ImageMagick para criar uma imagem com texto
    execSync(`convert -size 800x600 -background white -fill black -font Arial -pointsize 24 -gravity center label:"Teste de OCR com Extratores\nActCredit Plataforma\nTeste de Reconhecimento 123456789\nPaddleOCR e Tesseract" "${imagePath}"`);
    console.log(`Imagem de teste criada em: ${imagePath}`);
    return imagePath;
  } catch (error) {
    console.error('Erro ao criar imagem de teste:', error);
    
    // Alternativa: criar um arquivo de texto simples para testar
    const textPath = path.join(testDir, 'test_text.txt');
    fs.writeFileSync(textPath, 'Teste de OCR com Extratores\nActCredit Plataforma\nTeste de Reconhecimento 123456789\nPaddleOCR e Tesseract');
    console.log(`Arquivo de texto criado como alternativa em: ${textPath}`);
    return textPath;
  }
};

// Função para testar o Tesseract OCR
const testTesseractOCR = async (imagePath) => {
  try {
    console.log('\n=== Testando Tesseract OCR ===');
    
    // Verificar instalação do Tesseract
    const isInstalled = await tesseractService.checkTesseractInstallation();
    console.log(`Tesseract instalado e funcionando: ${isInstalled}`);
    
    if (!isInstalled) {
      console.error('Tesseract não está instalado ou não está funcionando corretamente.');
      return { success: false, error: 'Tesseract não instalado' };
    }
    
    // Executar OCR na imagem de teste
    console.log('Executando OCR com Tesseract na imagem de teste...');
    const startTime = Date.now();
    const extractedText = await tesseractService.extractTextFromImage(imagePath);
    const endTime = Date.now();
    
    console.log('\n--- Texto Extraído com Tesseract ---');
    console.log(extractedText);
    console.log('----------------------');
    console.log(`Tempo de processamento: ${(endTime - startTime) / 1000} segundos`);
    
    // Testar extração de dados estruturados
    const patterns = {
      plataforma: 'ActCredit\\s+(\\w+)',
      numeros: '(\\d+)'
    };
    
    const structuredData = tesseractService.extractStructuredData(extractedText, patterns);
    console.log('Dados estruturados extraídos:');
    console.log(structuredData);
    
    return {
      success: true,
      extractedText,
      structuredData,
      processingTime: endTime - startTime
    };
  } catch (error) {
    console.error('Erro durante o teste do Tesseract OCR:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

// Função para testar o PaddleOCR
const testPaddleOCR = async (imagePath) => {
  try {
    console.log('\n=== Testando PaddleOCR (Deep Learning) ===');
    
    // Verificar instalação do PaddleOCR
    const isInstalled = await paddleOCRService.checkPaddleOCRInstallation();
    console.log(`PaddleOCR instalado e funcionando: ${isInstalled}`);
    
    if (!isInstalled) {
      console.log('Tentando instalar dependências do PaddleOCR...');
      const installSuccess = await paddleOCRService.installDependencies();
      
      if (!installSuccess) {
        console.error('Falha ao instalar PaddleOCR.');
        return { success: false, error: 'PaddleOCR não instalado' };
      }
    }
    
    // Executar OCR na imagem de teste
    console.log('Executando OCR com PaddleOCR na imagem de teste...');
    const startTime = Date.now();
    const extractedText = await paddleOCRService.extractTextFromImage(imagePath);
    const endTime = Date.now();
    
    console.log('\n--- Texto Extraído com PaddleOCR ---');
    console.log(extractedText);
    console.log('----------------------');
    console.log(`Tempo de processamento: ${(endTime - startTime) / 1000} segundos`);
    
    // Testar extração de dados estruturados
    const patterns = {
      plataforma: 'ActCredit\\s+(\\w+)',
      numeros: '(\\d+)'
    };
    
    const structuredData = paddleOCRService.extractStructuredData(extractedText, patterns);
    console.log('Dados estruturados extraídos:');
    console.log(structuredData);
    
    return {
      success: true,
      extractedText,
      structuredData,
      processingTime: endTime - startTime
    };
  } catch (error) {
    console.error('Erro durante o teste do PaddleOCR:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

// Função principal de teste
const runTests = async () => {
  try {
    console.log('Iniciando testes dos extratores OCR...');
    
    // Criar ou usar imagem de teste
    const testImagePath = createTestImage();
    
    // Testar Tesseract OCR
    const tesseractResult = await testTesseractOCR(testImagePath);
    
    // Testar PaddleOCR
    const paddleOCRResult = await testPaddleOCR(testImagePath);
    
    // Comparar resultados
    console.log('\n=== Comparação de Resultados ===');
    console.log(`Tesseract OCR: ${tesseractResult.success ? 'Sucesso' : 'Falha'}`);
    console.log(`PaddleOCR: ${paddleOCRResult.success ? 'Sucesso' : 'Falha'}`);
    
    if (tesseractResult.success && paddleOCRResult.success) {
      console.log(`\nTempo de processamento Tesseract: ${tesseractResult.processingTime / 1000} segundos`);
      console.log(`Tempo de processamento PaddleOCR: ${paddleOCRResult.processingTime / 1000} segundos`);
      
      // Calcular qual é mais rápido
      const fasterEngine = tesseractResult.processingTime < paddleOCRResult.processingTime ? 'Tesseract' : 'PaddleOCR';
      const speedDiff = Math.abs(tesseractResult.processingTime - paddleOCRResult.processingTime) / 1000;
      console.log(`${fasterEngine} foi mais rápido por ${speedDiff.toFixed(2)} segundos`);
    }
    
    // Salvar resultados em um arquivo
    const results = {
      tesseract: tesseractResult,
      paddleOCR: paddleOCRResult,
      timestamp: new Date().toISOString(),
      comparison: {
        tesseractSuccess: tesseractResult.success,
        paddleOCRSuccess: paddleOCRResult.success,
        tesseractTime: tesseractResult.processingTime,
        paddleOCRTime: paddleOCRResult.processingTime
      }
    };
    
    fs.writeFileSync(
      path.join(testDir, 'extratores_test_result.json'), 
      JSON.stringify(results, null, 2)
    );
    
    console.log(`\nResultado dos testes salvo em: ${path.join(testDir, 'extratores_test_result.json')}`);
    console.log('\nTestes dos extratores OCR concluídos!');
    
    return results;
  } catch (error) {
    console.error('Erro ao executar testes dos extratores:', error);
    return { success: false, error: error.message };
  }
};

// Executar os testes
runTests()
  .then(results => {
    if (results.tesseract.success && results.paddleOCR.success) {
      console.log('\nAmbos os extratores estão funcionando corretamente!');
    } else {
      console.error('\nAlguns extratores apresentaram problemas. Verifique os resultados detalhados.');
    }
  })
  .catch(error => {
    console.error('Erro fatal durante os testes:', error);
  });
