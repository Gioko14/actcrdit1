// Arquivo de teste para o TesseractService
const fs = require('fs');
const path = require('path');
const tesseractService = require('../services/ocr/TesseractService');

// Diretório para testes
const testDir = path.join(__dirname, 'test_ocr');
if (!fs.existsSync(testDir)) {
  fs.mkdirSync(testDir, { recursive: true });
}

// Criar uma imagem de teste com texto
const createTestImage = () => {
  const imagePath = path.join(testDir, 'test_text.png');
  
  // Verificar se a imagem já existe
  if (fs.existsSync(imagePath)) {
    console.log(`Imagem de teste já existe em: ${imagePath}`);
    return imagePath;
  }
  
  // Criar uma imagem simples com texto usando o módulo child_process
  // para executar um comando que gera uma imagem com texto
  const { execSync } = require('child_process');
  
  try {
    // Usar o comando convert do ImageMagick para criar uma imagem com texto
    execSync(`convert -size 500x300 -background white -fill black -font Arial -pointsize 24 -gravity center label:"Teste de OCR com Tesseract\nActCredit Plataforma\n123456789" "${imagePath}"`);
    console.log(`Imagem de teste criada em: ${imagePath}`);
    return imagePath;
  } catch (error) {
    console.error('Erro ao criar imagem de teste:', error);
    
    // Alternativa: criar um arquivo de texto simples para testar
    const textPath = path.join(testDir, 'test_text.txt');
    fs.writeFileSync(textPath, 'Teste de OCR com Tesseract\nActCredit Plataforma\n123456789');
    console.log(`Arquivo de texto criado como alternativa em: ${textPath}`);
    return textPath;
  }
};

// Função principal de teste
const runTest = async () => {
  try {
    console.log('Iniciando teste do TesseractService...');
    
    // Verificar instalação do Tesseract
    const isInstalled = await tesseractService.checkTesseractInstallation();
    console.log(`Tesseract instalado e funcionando: ${isInstalled}`);
    
    if (!isInstalled) {
      console.error('Tesseract não está instalado ou não está funcionando corretamente.');
      return;
    }
    
    // Criar ou usar imagem de teste
    const testImagePath = createTestImage();
    
    // Executar OCR na imagem de teste
    console.log('Executando OCR na imagem de teste...');
    const extractedText = await tesseractService.extractTextFromImage(testImagePath);
    
    console.log('\n--- Texto Extraído ---');
    console.log(extractedText);
    console.log('----------------------\n');
    
    // Testar extração de dados estruturados
    const patterns = {
      plataforma: 'ActCredit\\s+(\\w+)',
      numeros: '(\\d+)'
    };
    
    const structuredData = tesseractService.extractStructuredData(extractedText, patterns);
    console.log('Dados estruturados extraídos:');
    console.log(structuredData);
    
    console.log('\nTeste do TesseractService concluído com sucesso!');
    return {
      success: true,
      extractedText,
      structuredData
    };
  } catch (error) {
    console.error('Erro durante o teste do TesseractService:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

// Executar o teste
runTest()
  .then(result => {
    // Salvar resultado em um arquivo
    fs.writeFileSync(
      path.join(testDir, 'test_result.json'), 
      JSON.stringify(result, null, 2)
    );
    console.log(`Resultado do teste salvo em: ${path.join(testDir, 'test_result.json')}`);
  })
  .catch(error => {
    console.error('Erro ao executar teste:', error);
  });
