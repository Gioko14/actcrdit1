#!/bin/bash

# Instalador automatizado para ML e pilares avançados do ActCredit Premium
# Este script configura o ambiente necessário para todos os componentes avançados

set -e  # Interrompe a execução em caso de erro

# Cores para output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para exibir mensagens de progresso
log() {
  echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

# Função para exibir mensagens de sucesso
success() {
  echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

# Função para exibir avisos
warning() {
  echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

# Função para exibir erros
error() {
  echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

# Função para verificar se um comando existe
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# Diretório base
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$BASE_DIR/../../.." && pwd)"

# Verificar se está sendo executado como root
if [ "$EUID" -ne 0 ]; then
  warning "Este script não está sendo executado como root. Algumas operações podem falhar."
  warning "Considere executar com sudo se encontrar problemas de permissão."
  read -p "Deseja continuar? (s/n) " -n 1 -r
  echo
  if [[ ! $REPLY =~ ^[Ss]$ ]]; then
    error "Instalação cancelada pelo usuário."
    exit 1
  fi
fi

# Criar diretório de logs
mkdir -p "$BASE_DIR/logs"
LOG_FILE="$BASE_DIR/logs/install_$(date +'%Y%m%d_%H%M%S').log"

# Redirecionar stdout e stderr para o arquivo de log e para o console
exec > >(tee -a "$LOG_FILE") 2>&1

log "Iniciando instalação do ActCredit Premium ML e pilares avançados..."
log "Log completo será salvo em: $LOG_FILE"

# Verificar requisitos do sistema
log "Verificando requisitos do sistema..."

# Verificar Python
if command_exists python3; then
  PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
  success "Python $PYTHON_VERSION encontrado."
else
  error "Python 3 não encontrado. Por favor, instale o Python 3.8 ou superior."
  exit 1
fi

# Verificar pip
if command_exists pip3; then
  PIP_VERSION=$(pip3 --version | awk '{print $2}')
  success "pip $PIP_VERSION encontrado."
else
  error "pip não encontrado. Por favor, instale o pip para Python 3."
  exit 1
fi

# Verificar Node.js
if command_exists node; then
  NODE_VERSION=$(node --version)
  success "Node.js $NODE_VERSION encontrado."
else
  error "Node.js não encontrado. Por favor, instale o Node.js 14 ou superior."
  exit 1
fi

# Verificar npm
if command_exists npm; then
  NPM_VERSION=$(npm --version)
  success "npm $NPM_VERSION encontrado."
else
  error "npm não encontrado. Por favor, instale o npm."
  exit 1
fi

# Verificar Docker (opcional)
if command_exists docker; then
  DOCKER_VERSION=$(docker --version | cut -d' ' -f3 | tr -d ',')
  success "Docker $DOCKER_VERSION encontrado."
else
  warning "Docker não encontrado. Alguns componentes podem requerer Docker para isolamento e portabilidade."
  warning "Recomendamos instalar o Docker para uma experiência completa."
fi

# Criar ambiente virtual Python
log "Criando ambiente virtual Python..."
cd "$BASE_DIR"

if [ -d "venv" ]; then
  warning "Ambiente virtual já existe. Deseja recriá-lo?"
  read -p "Isso removerá todas as bibliotecas instaladas. Continuar? (s/n) " -n 1 -r
  echo
  if [[ $REPLY =~ ^[Ss]$ ]]; then
    log "Removendo ambiente virtual existente..."
    rm -rf venv
    python3 -m venv venv
    success "Ambiente virtual recriado com sucesso."
  else
    log "Mantendo ambiente virtual existente."
  fi
else
  python3 -m venv venv
  success "Ambiente virtual criado com sucesso."
fi

# Ativar ambiente virtual
log "Ativando ambiente virtual..."
source venv/bin/activate
success "Ambiente virtual ativado."

# Atualizar pip
log "Atualizando pip..."
pip install --upgrade pip
success "pip atualizado com sucesso."

# Instalar dependências Python
log "Instalando dependências Python para ML e pilares avançados..."
pip install -r requirements.txt
success "Dependências Python instaladas com sucesso."

# Instalar dependências específicas para MLOps
log "Instalando dependências para MLOps..."
pip install mlflow dvc great-expectations
success "Dependências MLOps instaladas com sucesso."

# Instalar dependências para XAI
log "Instalando dependências para Explicabilidade (XAI)..."
pip install shap lime alibi interpret
success "Dependências XAI instaladas com sucesso."

# Instalar dependências para Open Finance
log "Instalando dependências para Open Finance..."
pip install requests-oauthlib cryptography pyjwt
success "Dependências Open Finance instaladas com sucesso."

# Instalar dependências Node.js para o motor de regras
log "Instalando dependências Node.js para o motor de regras configurável..."
cd "$PROJECT_ROOT"
npm install --save json-rules-engine react-flow-renderer
success "Dependências Node.js instaladas com sucesso."

# Configurar diretórios de dados
log "Configurando diretórios de dados..."
mkdir -p "$BASE_DIR/data/raw"
mkdir -p "$BASE_DIR/data/processed"
mkdir -p "$BASE_DIR/data/external"
mkdir -p "$BASE_DIR/data/interim"
mkdir -p "$BASE_DIR/models/trained"
mkdir -p "$BASE_DIR/models/deployed"
mkdir -p "$BASE_DIR/models/archive"
success "Diretórios de dados configurados com sucesso."

# Configurar MLflow
log "Configurando MLflow..."
mkdir -p "$BASE_DIR/mlflow"
cat > "$BASE_DIR/mlflow/mlflow.cfg" << EOF
artifact_root: $BASE_DIR/mlflow/artifacts
tracking_uri: sqlite:///$BASE_DIR/mlflow/mlflow.db
registry_uri: sqlite:///$BASE_DIR/mlflow/mlflow.db
EOF
success "MLflow configurado com sucesso."

# Configurar DVC
log "Configurando DVC..."
cd "$BASE_DIR"
if [ -d ".dvc" ]; then
  log "DVC já inicializado."
else
  dvc init
  success "DVC inicializado com sucesso."
fi

# Configurar Great Expectations
log "Configurando Great Expectations..."
cd "$BASE_DIR"
if [ -d "great_expectations" ]; then
  log "Great Expectations já inicializado."
else
  great_expectations init
  success "Great Expectations inicializado com sucesso."
fi

# Configurar ambiente para testes
log "Configurando ambiente para testes..."
mkdir -p "$BASE_DIR/tests/unit"
mkdir -p "$BASE_DIR/tests/integration"
mkdir -p "$BASE_DIR/tests/system"
cat > "$BASE_DIR/tests/conftest.py" << EOF
import pytest
import os
import sys

# Adicionar diretório raiz ao path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

@pytest.fixture(scope="session")
def test_data_path():
    return os.path.join(os.path.dirname(__file__), 'data')
EOF
success "Ambiente de testes configurado com sucesso."

# Configurar ambiente para documentação
log "Configurando ambiente para documentação..."
mkdir -p "$BASE_DIR/docs/api"
mkdir -p "$BASE_DIR/docs/user"
mkdir -p "$BASE_DIR/docs/developer"
cat > "$BASE_DIR/docs/index.md" << EOF
# ActCredit Premium - Documentação

## Visão Geral

O ActCredit Premium é um motor de crédito avançado com recursos de machine learning,
explicabilidade, integração com Open Finance, motor de regras configurável e muito mais.

## Seções

- [API](api/index.md): Documentação da API
- [Usuário](user/index.md): Guia do usuário
- [Desenvolvedor](developer/index.md): Guia do desenvolvedor
EOF
success "Ambiente de documentação configurado com sucesso."

# Configurar ambiente para APIs
log "Configurando ambiente para APIs bidirecionais..."
mkdir -p "$PROJECT_ROOT/src/services/api"
cat > "$PROJECT_ROOT/src/services/api/config.js" << EOF
/**
 * Configuração das APIs bidirecionais
 */
export const API_CONFIG = {
  baseUrl: process.env.API_BASE_URL || '/api',
  version: 'v1',
  timeout: 30000,
  retryAttempts: 3,
  retryDelay: 1000,
  webhookUrl: process.env.WEBHOOK_URL || '/api/webhooks',
};
EOF
success "Ambiente para APIs configurado com sucesso."

# Configurar ambiente para segurança
log "Configurando ambiente para segurança avançada..."
mkdir -p "$PROJECT_ROOT/src/lib/security"
cat > "$PROJECT_ROOT/src/lib/security/rbac.js" << EOF
/**
 * Sistema de controle de acesso baseado em função (RBAC)
 */
export const ROLES = {
  ADMIN: 'admin',
  MANAGER: 'manager',
  ANALYST: 'analyst',
  VIEWER: 'viewer',
};

export const PERMISSIONS = {
  CREATE_USER: 'create_user',
  EDIT_USER: 'edit_user',
  DELETE_USER: 'delete_user',
  VIEW_USER: 'view_user',
  CREATE_POLICY: 'create_policy',
  EDIT_POLICY: 'edit_policy',
  DELETE_POLICY: 'delete_policy',
  VIEW_POLICY: 'view_policy',
  APPROVE_CREDIT: 'approve_credit',
  REJECT_CREDIT: 'reject_credit',
  VIEW_CREDIT: 'view_credit',
  EXPORT_DATA: 'export_data',
  IMPORT_DATA: 'import_data',
  VIEW_REPORTS: 'view_reports',
  CREATE_REPORTS: 'create_reports',
  EDIT_REPORTS: 'edit_reports',
  DELETE_REPORTS: 'delete_reports',
  CONFIGURE_SYSTEM: 'configure_system',
};

export const ROLE_PERMISSIONS = {
  [ROLES.ADMIN]: Object.values(PERMISSIONS),
  [ROLES.MANAGER]: [
    PERMISSIONS.VIEW_USER,
    PERMISSIONS.CREATE_POLICY,
    PERMISSIONS.EDIT_POLICY,
    PERMISSIONS.VIEW_POLICY,
    PERMISSIONS.APPROVE_CREDIT,
    PERMISSIONS.REJECT_CREDIT,
    PERMISSIONS.VIEW_CREDIT,
    PERMISSIONS.EXPORT_DATA,
    PERMISSIONS.VIEW_REPORTS,
    PERMISSIONS.CREATE_REPORTS,
    PERMISSIONS.EDIT_REPORTS,
  ],
  [ROLES.ANALYST]: [
    PERMISSIONS.VIEW_POLICY,
    PERMISSIONS.VIEW_CREDIT,
    PERMISSIONS.EXPORT_DATA,
    PERMISSIONS.VIEW_REPORTS,
    PERMISSIONS.CREATE_REPORTS,
  ],
  [ROLES.VIEWER]: [
    PERMISSIONS.VIEW_POLICY,
    PERMISSIONS.VIEW_CREDIT,
    PERMISSIONS.VIEW_REPORTS,
  ],
};
EOF
success "Ambiente para segurança configurado com sucesso."

# Verificar instalação
log "Verificando instalação..."
cd "$BASE_DIR"
source venv/bin/activate
python -c "import numpy, pandas, sklearn, tensorflow, xgboost, shap, lime, mlflow, greatexpectations; print('Verificação de importação bem-sucedida!')"
if [ $? -eq 0 ]; then
  success "Verificação de importação bem-sucedida!"
else
  error "Verificação de importação falhou. Verifique o log para mais detalhes."
  exit 1
fi

# Criar arquivo de configuração
log "Criando arquivo de configuração..."
cat > "$BASE_DIR/config/config.yaml" << EOF
# Configuração do ActCredit Premium ML e pilares avançados

# Ambiente
environment: development  # development, staging, production

# Caminhos
paths:
  data: data
  models: models
  logs: logs
  mlflow: mlflow
  great_expectations: great_expectations

# Machine Learning
ml:
  random_state: 42
  test_size: 0.2
  cv_folds: 5
  scoring: roc_auc
  hyperparameter_tuning:
    n_trials: 100
    timeout: 3600
    n_jobs: -1

# MLOps
mlops:
  model_registry: mlflow
  experiment_tracking: mlflow
  data_versioning: dvc
  data_validation: great_expectations
  monitoring:
    drift_detection: true
    performance_tracking: true
    retraining_trigger:
      performance_threshold: 0.05
      drift_threshold: 0.1

# XAI
xai:
  global_explanations:
    - shap
    - permutation_importance
  local_explanations:
    - lime
    - shap
  counterfactuals: true

# Open Finance
open_finance:
  api_version: v1
  timeout: 30
  retry_attempts: 3
  scopes:
    - accounts
    - credit-cards-accounts
    - loans
    - financings
    - invoice-financings
    - unarranged-accounts-overdraft
    - resources

# Motor de Regras
rules_engine:
  version: v1
  cache_enabled: true
  cache_ttl: 3600
  max_rules_per_policy: 100
  max_conditions_per_rule: 20

# GRC
grc:
  audit_trail:
    enabled: true
    retention_days: 365
  model_risk_management:
    enabled: true
    validation_frequency_days: 90
  champion_challenger:
    enabled: true
    traffic_allocation:
      champion: 0.9
      challenger: 0.1

# Segurança
security:
  rbac:
    enabled: true
  encryption:
    algorithm: AES-256-GCM
  dlp:
    enabled: true
    sensitive_fields:
      - cpf
      - cnpj
      - credit_card
      - bank_account
EOF
success "Arquivo de configuração criado com sucesso."

# Criar script de inicialização
log "Criando script de inicialização..."
cat > "$BASE_DIR/start.sh" << EOF
#!/bin/bash

# Script de inicialização do ActCredit Premium ML e pilares avançados

# Ativar ambiente virtual
source venv/bin/activate

# Iniciar MLflow
mlflow ui --backend-store-uri sqlite:///$BASE_DIR/mlflow/mlflow.db --default-artifact-root $BASE_DIR/mlflow/artifacts --host 0.0.0.0 --port 5000 &

# Iniciar API
cd $PROJECT_ROOT
npm run start:api
EOF
chmod +x "$BASE_DIR/start.sh"
success "Script de inicialização criado com sucesso."

# Finalizar instalação
success "Instalação concluída com sucesso!"
log "Para iniciar o ActCredit Premium ML e pilares avançados, execute:"
log "  cd $BASE_DIR && ./start.sh"
log "Para acessar o MLflow, abra http://localhost:5000 no navegador."
log "Para mais informações, consulte a documentação em $BASE_DIR/docs/index.md"

# Desativar ambiente virtual
deactivate
