/**
 * MLScoringService.js
 * Serviço responsável por integrar com a API de scoring de ML
 * e fornecer explicabilidade para os resultados do modelo.
 */

import axios from 'axios';

class MLScoringService {
  constructor() {
    this.apiBaseUrl = '/api';
  }

  /**
   * Obtém o score de crédito e explicabilidade para os dados fornecidos
   * @param {Object} dadosAnalise - Dados para análise de crédito
   * @returns {Promise<Object>} Score, probabilidade de default e fatores explicativos
   */
  async obterScore(dadosAnalise) {
    try {
      const response = await axios.post(`${this.apiBaseUrl}/ml-scoring`, dadosAnalise);
      
      // Se a API não retornar os fatores explicativos, gera fatores simulados
      if (!response.data.fatoresPositivos || !response.data.fatoresNegativos) {
        return this.enriquecerComExplicabilidade(response.data, dadosAnalise);
      }
      
      return response.data;
    } catch (error) {
      console.error('Erro ao obter score de ML:', error);
      
      // Em caso de erro, retorna dados simulados para não interromper o fluxo
      return this.gerarScoreSimulado(dadosAnalise);
    }
  }

  /**
   * Enriquece o resultado do score com fatores explicativos
   * @param {Object} resultado - Resultado original da API
   * @param {Object} dadosAnalise - Dados originais da análise
   * @returns {Object} Resultado enriquecido com explicabilidade
   */
  enriquecerComExplicabilidade(resultado, dadosAnalise) {
    const score = resultado.score || 0;
    const probabilidadeDefault = resultado.probabilidadeDefault || score > 0 ? (100 - score) / 100 : 0.5;
    
    // Gera fatores explicativos com base nos dados da análise
    const fatoresPositivos = this.gerarFatoresPositivos(dadosAnalise, score);
    const fatoresNegativos = this.gerarFatoresNegativos(dadosAnalise, score);
    
    return {
      ...resultado,
      score,
      probabilidadeDefault,
      fatoresPositivos,
      fatoresNegativos
    };
  }

  /**
   * Gera fatores positivos com base nos dados da análise
   * @param {Object} dadosAnalise - Dados da análise
   * @param {Number} score - Score obtido
   * @returns {Array} Lista de fatores positivos
   */
  gerarFatoresPositivos(dadosAnalise, score) {
    const fatores = [];
    
    // Faturamento
    if (dadosAnalise.faturamentoAnual && dadosAnalise.faturamentoAnual > 1000000) {
      fatores.push('Faturamento anual elevado (R$ ' + dadosAnalise.faturamentoAnual.toLocaleString('pt-BR') + ')');
    }
    
    // Tempo de atividade
    if (dadosAnalise.tempoAtividade && dadosAnalise.tempoAtividade > 5) {
      fatores.push('Tempo de atividade significativo (' + dadosAnalise.tempoAtividade + ' anos)');
    }
    
    // Endividamento
    if (dadosAnalise.percentualEndividamento && dadosAnalise.percentualEndividamento < 30) {
      fatores.push('Baixo percentual de endividamento (' + dadosAnalise.percentualEndividamento + '%)');
    }
    
    // Setor
    if (dadosAnalise.setor && ['Tecnologia', 'Saúde', 'Energia'].includes(dadosAnalise.setor)) {
      fatores.push('Atuação em setor de baixo risco (' + dadosAnalise.setor + ')');
    }
    
    // Região
    if (dadosAnalise.regiao && ['Sudeste', 'Sul'].includes(dadosAnalise.regiao)) {
      fatores.push('Localização em região economicamente estável (' + dadosAnalise.regiao + ')');
    }
    
    // Adiciona fatores genéricos se necessário
    if (fatores.length < 3) {
      if (score >= 80) {
        fatores.push('Histórico de crédito positivo');
        fatores.push('Bom relacionamento com instituições financeiras');
      }
      if (score >= 70 && !fatores.includes('Histórico de crédito positivo')) {
        fatores.push('Histórico de crédito satisfatório');
      }
      if (score >= 60 && fatores.length < 3) {
        fatores.push('Pontualidade nos pagamentos anteriores');
      }
    }
    
    return fatores;
  }

  /**
   * Gera fatores negativos com base nos dados da análise
   * @param {Object} dadosAnalise - Dados da análise
   * @param {Number} score - Score obtido
   * @returns {Array} Lista de fatores negativos
   */
  gerarFatoresNegativos(dadosAnalise, score) {
    const fatores = [];
    
    // Faturamento
    if (dadosAnalise.faturamentoAnual && dadosAnalise.faturamentoAnual < 500000) {
      fatores.push('Faturamento anual abaixo do ideal (R$ ' + dadosAnalise.faturamentoAnual.toLocaleString('pt-BR') + ')');
    }
    
    // Tempo de atividade
    if (dadosAnalise.tempoAtividade && dadosAnalise.tempoAtividade < 2) {
      fatores.push('Tempo de atividade reduzido (' + dadosAnalise.tempoAtividade + ' anos)');
    }
    
    // Endividamento
    if (dadosAnalise.percentualEndividamento && dadosAnalise.percentualEndividamento > 50) {
      fatores.push('Alto percentual de endividamento (' + dadosAnalise.percentualEndividamento + '%)');
    }
    
    // Setor
    if (dadosAnalise.setor && ['Entretenimento', 'Turismo', 'Varejo'].includes(dadosAnalise.setor)) {
      fatores.push('Atuação em setor de maior volatilidade (' + dadosAnalise.setor + ')');
    }
    
    // Região
    if (dadosAnalise.regiao && ['Norte', 'Nordeste'].includes(dadosAnalise.regiao)) {
      fatores.push('Localização em região com maior instabilidade econômica (' + dadosAnalise.regiao + ')');
    }
    
    // Adiciona fatores genéricos se necessário
    if (fatores.length < 2) {
      if (score < 40) {
        fatores.push('Histórico de crédito negativo');
        fatores.push('Inadimplência recente registrada');
      }
      if (score < 60 && !fatores.includes('Histórico de crédito negativo')) {
        fatores.push('Histórico de crédito com restrições');
      }
      if (score < 70 && fatores.length < 2) {
        fatores.push('Atrasos pontuais em pagamentos anteriores');
      }
    }
    
    return fatores;
  }

  /**
   * Gera um score simulado para casos de falha na API
   * @param {Object} dadosAnalise - Dados da análise
   * @returns {Object} Score simulado com explicabilidade
   */
  gerarScoreSimulado(dadosAnalise) {
    // Calcula um score baseado nos dados disponíveis
    let score = 65; // Score base médio
    
    // Ajusta com base no faturamento
    if (dadosAnalise.faturamentoAnual) {
      if (dadosAnalise.faturamentoAnual > 5000000) score += 15;
      else if (dadosAnalise.faturamentoAnual > 1000000) score += 10;
      else if (dadosAnalise.faturamentoAnual < 500000) score -= 10;
    }
    
    // Ajusta com base no tempo de atividade
    if (dadosAnalise.tempoAtividade) {
      if (dadosAnalise.tempoAtividade > 10) score += 15;
      else if (dadosAnalise.tempoAtividade > 5) score += 10;
      else if (dadosAnalise.tempoAtividade < 2) score -= 15;
    }
    
    // Ajusta com base no endividamento
    if (dadosAnalise.percentualEndividamento) {
      if (dadosAnalise.percentualEndividamento < 20) score += 15;
      else if (dadosAnalise.percentualEndividamento < 40) score += 5;
      else if (dadosAnalise.percentualEndividamento > 60) score -= 15;
    }
    
    // Limita o score entre 0 e 100
    score = Math.max(0, Math.min(100, score));
    
    // Calcula probabilidade de default
    const probabilidadeDefault = (100 - score) / 100;
    
    // Gera fatores explicativos
    const fatoresPositivos = this.gerarFatoresPositivos(dadosAnalise, score);
    const fatoresNegativos = this.gerarFatoresNegativos(dadosAnalise, score);
    
    return {
      score,
      probabilidadeDefault,
      fatoresPositivos,
      fatoresNegativos,
      simulado: true
    };
  }
}

export default new MLScoringService();
