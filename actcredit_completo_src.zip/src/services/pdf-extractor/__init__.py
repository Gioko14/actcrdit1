"""
Pacote de extração de PDF com deep learning para ActCredit
"""

from .pdf_extractor import (
    PDFExtractor,
    extract_text_from_pdf,
    extract_structured_data,
    process_pdf_with_paddle,
    process_pdf_with_tesseract,
    extract_cnpj_from_text,
    extract_financial_data
)

__version__ = '2.0.0'
