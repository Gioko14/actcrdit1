"""
Interface de linha de comando para o extrator de PDF
Permite extrair texto, dados estruturados e tabelas de documentos PDF
"""

import os
import sys
import json
import argparse
import logging
from pathlib import Path
from typing import Dict, Any

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('pdf_extractor_cli')

# Importar o extrator de PDF
from pdf_extractor import PDFExtractor

def parse_args():
    """Analisa os argumentos da linha de comando"""
    parser = argparse.ArgumentParser(description='Extrator de PDF com Deep Learning')
    
    # Argumentos obrigatórios
    parser.add_argument('pdf_path', help='Caminho para o arquivo PDF')
    
    # Argumentos opcionais
    parser.add_argument('--output', '-o', help='Caminho para o arquivo de saída (JSON)')
    parser.add_argument('--text-output', '-t', help='Caminho para o arquivo de saída de texto')
    parser.add_argument('--mode', '-m', choices=['full', 'text', 'structure', 'tables', 'layout'],
                        default='full', help='Modo de extração')
    parser.add_argument('--gpu', '-g', action='store_true', help='Usar GPU para aceleração')
    parser.add_argument('--lang', '-l', default='pt', help='Idioma para OCR')
    parser.add_argument('--verbose', '-v', action='store_true', help='Modo verboso')
    parser.add_argument('--no-preprocess', action='store_true', help='Desativar pré-processamento de imagem')
    
    return parser.parse_args()

def process_pdf(args) -> Dict[str, Any]:
    """Processa o PDF de acordo com os argumentos fornecidos"""
    # Verificar se o arquivo existe
    if not os.path.exists(args.pdf_path):
        logger.error(f"Arquivo não encontrado: {args.pdf_path}")
        sys.exit(1)
    
    # Configurar nível de log
    if args.verbose:
        logging.getLogger('pdf_extractor').setLevel(logging.DEBUG)
    
    # Inicializar extrator
    extractor = PDFExtractor(use_gpu=args.gpu, lang=args.lang)
    
    # Processar PDF de acordo com o modo selecionado
    if args.mode == 'full':
        logger.info(f"Processando PDF completo: {args.pdf_path}")
        result = extractor.process_pdf(args.pdf_path)
    
    elif args.mode == 'text':
        logger.info(f"Extraindo texto do PDF: {args.pdf_path}")
        result = extractor.extract_text_from_pdf(args.pdf_path, use_ocr=not args.no_preprocess)
    
    elif args.mode == 'structure':
        logger.info(f"Extraindo dados estruturados do PDF: {args.pdf_path}")
        # Extrair texto primeiro
        text_result = extractor.extract_text_from_pdf(args.pdf_path, use_ocr=not args.no_preprocess)
        # Extrair dados estruturados do texto
        structured_data = extractor.extract_structured_data(text_result.get("text", ""))
        result = {
            "text": text_result.get("text", ""),
            "structured_data": structured_data
        }
    
    elif args.mode == 'tables':
        logger.info(f"Extraindo tabelas do PDF: {args.pdf_path}")
        # Tentar extrair com PaddleOCR Structure primeiro
        tables = extractor.extract_tables_with_paddle(args.pdf_path)
        
        # Se não encontrar tabelas ou PaddleOCR não estiver disponível, tentar Camelot
        if not tables:
            tables = extractor.extract_tables_with_camelot(args.pdf_path)
        
        result = {"tables": tables}
    
    elif args.mode == 'layout':
        logger.info(f"Analisando layout do PDF: {args.pdf_path}")
        # Converter PDF para imagens
        from pdf2image import convert_from_path
        images = convert_from_path(args.pdf_path)
        
        layout_results = []
        for i, image in enumerate(images):
            # Converter para formato numpy/OpenCV
            import numpy as np
            img_np = np.array(image)
            
            # Analisar layout
            layout_data = extractor.analyze_layout(img_np)
            layout_results.append({
                "page_num": i + 1,
                "layout_data": layout_data
            })
        
        result = {"layout_results": layout_results}
    
    else:
        logger.error(f"Modo desconhecido: {args.mode}")
        sys.exit(1)
    
    return result

def save_results(result: Dict[str, Any], args):
    """Salva os resultados em arquivos"""
    # Salvar resultado em JSON
    if args.output:
        output_path = args.output
    else:
        output_path = f"output_{args.mode}.json"
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    logger.info(f"Resultados salvos em: {output_path}")
    
    # Salvar texto em arquivo separado se solicitado
    if args.text_output and "text" in result:
        with open(args.text_output, 'w', encoding='utf-8') as f:
            f.write(result["text"])
        
        logger.info(f"Texto extraído salvo em: {args.text_output}")

def main():
    """Função principal"""
    # Analisar argumentos
    args = parse_args()
    
    try:
        # Processar PDF
        result = process_pdf(args)
        
        # Salvar resultados
        save_results(result, args)
        
        # Exibir resumo dos resultados
        if args.mode == 'full' or args.mode == 'text':
            text_length = len(result.get("text", ""))
            logger.info(f"Texto extraído: {text_length} caracteres")
        
        if args.mode == 'full' or args.mode == 'structure':
            structured_data = result.get("structured_data", {})
            cnpjs = structured_data.get("cnpjs", [])
            cpfs = structured_data.get("cpfs", [])
            logger.info(f"CNPJs encontrados: {len(cnpjs)}")
            logger.info(f"CPFs encontrados: {len(cpfs)}")
        
        if args.mode == 'full' or args.mode == 'tables':
            tables = result.get("tables", [])
            logger.info(f"Tabelas encontradas: {len(tables)}")
        
        if args.mode == 'layout':
            layout_results = result.get("layout_results", [])
            total_elements = sum(page.get("layout_data", {}).get("num_elements", 0) for page in layout_results)
            logger.info(f"Elementos de layout encontrados: {total_elements} em {len(layout_results)} páginas")
        
        logger.info("Processamento concluído com sucesso")
    
    except Exception as e:
        logger.error(f"Erro ao processar PDF: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
