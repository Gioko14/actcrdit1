"""
Testes automatizados para o extrator de PDF melhorado
"""
import os
import sys
import unittest
import logging
import tempfile
from PIL import Image, ImageDraw, ImageFont
import numpy as np

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("pdf_extractor_tests.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("pdf_extractor_tests")

# Diretório atual
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
# Diretório para arquivos temporários de teste
TEST_DIR = os.path.join(CURRENT_DIR, "test_files")
os.makedirs(TEST_DIR, exist_ok=True)

# Importar o módulo a ser testado
from pdf_extractor import PDFExtractor, extract_text_from_pdf, extract_structured_data

class PDFExtractorTests(unittest.TestCase):
    def setUp(self):
        """Configuração para cada teste"""
        logger.info("Iniciando testes do extrator de PDF melhorado")
        
        # Criar uma imagem de teste com texto
        self.test_image_path = os.path.join(TEST_DIR, "test_image.png")
        self.create_test_image(self.test_image_path)
        
        # Criar um PDF de teste simples
        self.test_pdf_path = os.path.join(TEST_DIR, "test_document.pdf")
        self.create_test_pdf(self.test_pdf_path)
        
        # Inicializar o extrator
        self.extractor = PDFExtractor()
    
    def create_test_image(self, path):
        """Cria uma imagem de teste com texto"""
        # Criar uma imagem em branco
        img = Image.new('RGB', (800, 600), color=(255, 255, 255))
        d = ImageDraw.Draw(img)
        
        # Adicionar texto
        d.text((50, 50), "ActCredit - Teste de OCR", fill=(0, 0, 0))
        d.text((50, 100), "CNPJ: 12.345.678/0001-90", fill=(0, 0, 0))
        d.text((50, 150), "Valor: R$ 1.234,56", fill=(0, 0, 0))
        d.text((50, 200), "Data: 26/05/2025", fill=(0, 0, 0))
        
        # Adicionar uma tabela simples
        d.rectangle([(50, 250), (750, 400)], outline=(0, 0, 0))
        d.line([(50, 300), (750, 300)], fill=(0, 0, 0))
        d.line([(250, 250), (250, 400)], fill=(0, 0, 0))
        d.line([(450, 250), (450, 400)], fill=(0, 0, 0))
        d.line([(600, 250), (600, 400)], fill=(0, 0, 0))
        
        # Adicionar cabeçalho da tabela
        d.text((100, 260), "Produto", fill=(0, 0, 0))
        d.text((300, 260), "Quantidade", fill=(0, 0, 0))
        d.text((500, 260), "Valor", fill=(0, 0, 0))
        d.text((650, 260), "Total", fill=(0, 0, 0))
        
        # Adicionar dados da tabela
        d.text((100, 320), "Item 1", fill=(0, 0, 0))
        d.text((300, 320), "2", fill=(0, 0, 0))
        d.text((500, 320), "R$ 100,00", fill=(0, 0, 0))
        d.text((650, 320), "R$ 200,00", fill=(0, 0, 0))
        
        d.text((100, 360), "Item 2", fill=(0, 0, 0))
        d.text((300, 360), "3", fill=(0, 0, 0))
        d.text((500, 360), "R$ 150,00", fill=(0, 0, 0))
        d.text((650, 360), "R$ 450,00", fill=(0, 0, 0))
        
        # Salvar a imagem
        img.save(path)
        logger.info(f"Imagem de teste criada em {path}")
    
    def create_test_pdf(self, path):
        """Cria um PDF de teste a partir da imagem"""
        try:
            import img2pdf
            # Converter a imagem para PDF
            with open(path, "wb") as f:
                f.write(img2pdf.convert(self.test_image_path))
            logger.info(f"PDF de teste criado em {path}")
        except ImportError:
            # Se img2pdf não estiver disponível, usar a imagem diretamente
            import shutil
            shutil.copy(self.test_image_path, path.replace(".pdf", ".png"))
            logger.warning("img2pdf não disponível, usando imagem PNG para testes")
    
    def test_pdf_to_images(self):
        """Testa a conversão de PDF para imagens"""
        # Se o PDF não foi criado, usar a imagem diretamente
        test_path = self.test_pdf_path if os.path.exists(self.test_pdf_path) else self.test_image_path
        
        # Testar a conversão
        if test_path.endswith(".pdf"):
            images = self.extractor.pdf_to_images(test_path)
            self.assertIsNotNone(images)
            self.assertGreater(len(images), 0)
        else:
            logger.info("Pulando teste de conversão PDF para imagens, usando imagem diretamente")
    
    def test_extract_text_with_tesseract(self):
        """Testa a extração de texto com Tesseract OCR"""
        # Carregar a imagem de teste
        image = np.array(Image.open(self.test_image_path))
        
        # Extrair texto com Tesseract
        text = self.extractor.extract_text_with_tesseract(image)
        
        # Verificar se o texto foi extraído
        self.assertIsNotNone(text)
        self.assertIn("ActCredit", text)
    
    def test_extract_text_with_paddleocr(self):
        """Testa a extração de texto com PaddleOCR"""
        # Verificar se PaddleOCR está disponível
        if not self.extractor.paddle_available:
            logger.warning("PaddleOCR não disponível, pulando teste")
            return
        
        # Carregar a imagem de teste
        image = np.array(Image.open(self.test_image_path))
        
        # Extrair texto com PaddleOCR
        text = self.extractor.extract_text_with_paddleocr(image)
        
        # Verificar se o texto foi extraído
        self.assertIsNotNone(text)
    
    def test_analyze_layout(self):
        """Testa a análise de layout com LayoutParser"""
        # Verificar se LayoutParser está disponível
        if not self.extractor.layout_available:
            logger.warning("LayoutParser não disponível, pulando teste")
            return
        
        # Carregar a imagem de teste
        image = np.array(Image.open(self.test_image_path))
        
        # Analisar layout
        layout = self.extractor.analyze_layout(image)
        
        # Verificar se o layout foi analisado
        self.assertIsNotNone(layout)
    
    def test_extract_tables(self):
        """Testa a extração de tabelas"""
        # Se o PDF não foi criado, usar a imagem diretamente
        test_path = self.test_pdf_path if os.path.exists(self.test_pdf_path) else self.test_image_path
        
        # Extrair tabelas
        if test_path.endswith(".pdf"):
            tables = self.extractor.extract_tables(test_path)
            # Verificar se as tabelas foram extraídas
            self.assertIsNotNone(tables)
        else:
            logger.info("Pulando teste de extração de tabelas, usando imagem diretamente")
    
    def test_full_extraction_pipeline(self):
        """Testa o pipeline completo de extração"""
        # Se o PDF não foi criado, usar a imagem diretamente
        test_path = self.test_pdf_path if os.path.exists(self.test_pdf_path) else self.test_image_path
        
        # Extrair texto e dados estruturados
        if test_path.endswith(".pdf"):
            result = extract_text_from_pdf(test_path)
            self.assertIsNotNone(result)
            
            structured_data = extract_structured_data(test_path)
            self.assertIsNotNone(structured_data)
        else:
            logger.info("Pulando teste de pipeline completo, usando imagem diretamente")
            # Testar extração diretamente da imagem
            image = np.array(Image.open(self.test_image_path))
            text = self.extractor.extract_text_with_tesseract(image)
            self.assertIsNotNone(text)
    
    def tearDown(self):
        """Limpeza após cada teste"""
        # Remover arquivos temporários
        if os.path.exists(self.test_image_path):
            os.remove(self.test_image_path)
        if os.path.exists(self.test_pdf_path):
            os.remove(self.test_pdf_path)

if __name__ == "__main__":
    unittest.main()
