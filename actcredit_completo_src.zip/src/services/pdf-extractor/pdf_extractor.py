"""
Módulo otimizado do extrator de PDF com foco em eficiência de memória
Implementa funções para extração de texto, dados estruturados e análise de documentos
"""

import os
import re
import json
import time
import logging
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Union

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("pdf_extractor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("pdf_extractor")

# Importar bibliotecas de OCR e processamento de imagem
try:
    import pytesseract
    from pdf2image import convert_from_path
    import cv2
    import fitz  # PyMuPDF
    import pdfplumber
    logger.info("Bibliotecas básicas importadas com sucesso")
except ImportError as e:
    logger.error(f"Falha ao importar bibliotecas necessárias: {str(e)}")
    raise

# Verificar disponibilidade do PaddleOCR (importação adiada para economizar memória)
paddle_available = False
try:
    # Apenas verificar se está disponível, sem importar ainda
    import importlib.util
    if importlib.util.find_spec("paddleocr") is not None:
        paddle_available = True
        logger.info("PaddleOCR disponível (será carregado sob demanda)")
    else:
        logger.warning("PaddleOCR não está disponível, usando apenas Tesseract")
except ImportError:
    logger.warning("PaddleOCR não está disponível, usando apenas Tesseract")

# Carregar modelo spaCy para português (se disponível)
try:
    import spacy
    nlp = spacy.load("pt_core_news_sm")
    spacy_available = True
    logger.info("Modelo spaCy para português carregado com sucesso")
except:
    spacy_available = False
    logger.warning("Modelo spaCy para português não disponível, análise de texto será limitada")

class PDFExtractor:
    """
    Classe principal para extração de dados de PDF com otimização de memória
    """
    
    def __init__(self, use_gpu: bool = False, lang: str = 'pt'):
        """
        Inicializa o extrator de PDF
        
        Args:
            use_gpu: Se True, usa GPU para aceleração (se disponível)
            lang: Idioma para OCR (padrão: português)
        """
        self.use_gpu = use_gpu
        self.lang = lang
        self.models = {}
        self._paddle_ocr = None
    
    @property
    def paddle_ocr(self):
        """Carrega PaddleOCR sob demanda para economizar memória"""
        if self._paddle_ocr is None and paddle_available:
            try:
                from paddleocr import PaddleOCR
                # Usar versão mais leve do modelo para economizar memória
                self._paddle_ocr = PaddleOCR(use_angle_cls=False, lang="pt", use_gpu=self.use_gpu)
                logger.info("PaddleOCR inicializado com sucesso")
            except Exception as e:
                logger.error(f"Erro ao inicializar PaddleOCR: {str(e)}")
                self._paddle_ocr = None
        return self._paddle_ocr
    
    def preprocess_image(self, image: np.ndarray, method: str = 'default') -> np.ndarray:
        """
        Pré-processa a imagem para melhorar a qualidade do OCR
        
        Args:
            image: Imagem em formato numpy array
            method: Método de pré-processamento ('default', 'adaptive', 'denoise', 'enhance')
            
        Returns:
            Imagem pré-processada
        """
        # Converter para escala de cinza se a imagem for colorida
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        else:
            gray = image.copy()
        
        if method == 'default':
            # Pré-processamento básico
            return gray
        
        elif method == 'adaptive':
            # Threshold adaptativo para melhorar contraste
            return cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
            )
        
        elif method == 'denoise':
            # Redução de ruído
            denoised = cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)
            # Threshold adaptativo
            return cv2.adaptiveThreshold(
                denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
            )
        
        elif method == 'enhance':
            # Redução de ruído
            denoised = cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)
            # Equalização de histograma para melhorar contraste
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
            enhanced = clahe.apply(denoised)
            # Threshold adaptativo
            return cv2.adaptiveThreshold(
                enhanced, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
            )
        
        else:
            logger.warning(f"Método de pré-processamento desconhecido: {method}, usando padrão")
            return gray
    
    def deskew_image(self, image: np.ndarray) -> np.ndarray:
        """
        Corrige a inclinação da imagem
        
        Args:
            image: Imagem em formato numpy array
            
        Returns:
            Imagem corrigida
        """
        try:
            # Converter para binário
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
            else:
                gray = image.copy()
            
            # Threshold para binarização
            _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
            
            # Encontrar todos os pontos não-zero
            coords = np.column_stack(np.where(binary > 0))
            
            # Encontrar o ângulo de inclinação
            if len(coords) > 0:
                angle = cv2.minAreaRect(coords)[-1]
                
                # Ajustar ângulo
                if angle < -45:
                    angle = -(90 + angle)
                else:
                    angle = -angle
                
                # Rotacionar a imagem para corrigir a inclinação
                (h, w) = image.shape[:2]
                center = (w // 2, h // 2)
                M = cv2.getRotationMatrix2D(center, angle, 1.0)
                rotated = cv2.warpAffine(
                    image, M, (w, h), 
                    flags=cv2.INTER_CUBIC, 
                    borderMode=cv2.BORDER_REPLICATE
                )
                
                return rotated
        except Exception as e:
            logger.warning(f"Erro ao corrigir inclinação: {str(e)}")
        
        # Retornar imagem original em caso de erro
        return image
    
    def extract_text_with_tesseract(self, image: np.ndarray, preprocess: bool = True) -> str:
        """
        Extrai texto de uma imagem usando Tesseract OCR
        
        Args:
            image: Imagem em formato numpy array
            preprocess: Se True, aplica pré-processamento na imagem
            
        Returns:
            Texto extraído
        """
        try:
            # Pré-processar imagem se solicitado
            if preprocess:
                # Aplicar deskew
                image = self.deskew_image(image)
                
                # Aplicar pré-processamento avançado
                processed_image = self.preprocess_image(image, method='enhance')
            else:
                processed_image = image
            
            # Usar 'por' (português) em vez de 'pt' como código de idioma
            # Tesseract usa 'por' para português
            lang = 'por' if self.lang == 'pt' else self.lang
            
            # Extrair texto com Tesseract
            text = pytesseract.image_to_string(processed_image, lang=lang)
            
            return text
        except Exception as e:
            logger.error(f"Erro ao extrair texto com Tesseract: {str(e)}")
            return ""
    
    def extract_text_with_paddleocr(self, image: np.ndarray) -> Tuple[str, List[Dict]]:
        """
        Extrai texto de uma imagem usando PaddleOCR
        
        Args:
            image: Imagem em formato numpy array
            
        Returns:
            Tuple contendo o texto extraído e os dados detalhados (texto, confiança, coordenadas)
        """
        if not paddle_available or self.paddle_ocr is None:
            logger.warning("PaddleOCR não está disponível")
            return "", []
        
        try:
            # Aplicar deskew
            image = self.deskew_image(image)
            
            # Executar OCR na imagem
            result = self.paddle_ocr.ocr(image, cls=True)
            
            if not result or not result[0]:
                return "", []
            
            # Extrair texto e dados detalhados
            text_lines = []
            detailed_data = []
            
            for line in result[0]:
                if len(line) >= 2:
                    text = line[1][0]  # Texto reconhecido
                    confidence = line[1][1]  # Confiança
                    box = line[0]  # Coordenadas da caixa
                    
                    text_lines.append(text)
                    detailed_data.append({
                        "text": text,
                        "confidence": float(confidence),
                        "box": box
                    })
            
            # Juntar linhas de texto
            full_text = "\n".join(text_lines)
            
            return full_text, detailed_data
        except Exception as e:
            logger.error(f"Erro ao extrair texto com PaddleOCR: {str(e)}")
            return "", []
    
    def extract_pdf_pages(self, pdf_path: str) -> List[np.ndarray]:
        """
        Converte páginas de PDF para imagens
        
        Args:
            pdf_path: Caminho para o arquivo PDF
            
        Returns:
            Lista de imagens (numpy arrays)
        """
        try:
            # Converter PDF para imagens
            images = convert_from_path(pdf_path)
            
            # Converter PIL Images para numpy arrays
            np_images = [np.array(img) for img in images]
            
            return np_images
        except Exception as e:
            logger.error(f"Erro ao converter PDF para imagens: {str(e)}")
            return []
    
    def extract_pdf_metadata(self, pdf_path: str) -> Dict[str, Any]:
        """
        Extrai metadados de um PDF
        
        Args:
            pdf_path: Caminho para o arquivo PDF
            
        Returns:
            Dicionário com metadados
        """
        try:
            # Abrir PDF com PyMuPDF
            doc = fitz.open(pdf_path)
            
            # Extrair metadados
            metadata = {
                "title": doc.metadata.get("title", ""),
                "author": doc.metadata.get("author", ""),
                "subject": doc.metadata.get("subject", ""),
                "keywords": doc.metadata.get("keywords", ""),
                "creator": doc.metadata.get("creator", ""),
                "producer": doc.metadata.get("producer", ""),
                "creation_date": doc.metadata.get("creationDate", ""),
                "modification_date": doc.metadata.get("modDate", ""),
                "page_count": len(doc),
                "file_size": os.path.getsize(pdf_path),
                "is_encrypted": doc.is_encrypted,
                "permissions": doc.permissions
            }
            
            # Fechar documento
            doc.close()
            
            return metadata
        except Exception as e:
            logger.error(f"Erro ao extrair metadados do PDF: {str(e)}")
            return {"error": str(e)}
    
    def extract_text_from_pdf(self, pdf_path: str, use_ocr: bool = False, ocr_engine: str = 'auto') -> Dict[str, Any]:
        """
        Extrai texto de um PDF, com ou sem OCR
        
        Args:
            pdf_path: Caminho para o arquivo PDF
            use_ocr: Se True, usa OCR para extrair texto
            ocr_engine: Motor de OCR a ser usado ('auto', 'tesseract', 'paddleocr')
            
        Returns:
            Dicionário com texto extraído por página
        """
        try:
            # Extrair metadados
            metadata = self.extract_pdf_metadata(pdf_path)
            
            # Inicializar resultado
            result = {
                "metadata": metadata,
                "pages": []
            }
            
            if use_ocr:
                # Extrair páginas como imagens
                images = self.extract_pdf_pages(pdf_path)
                
                # Processar cada página com OCR
                for i, image in enumerate(images):
                    page_result = {"page_num": i + 1, "text": "", "confidence": 0.0}
                    
                    if (ocr_engine == 'auto' or ocr_engine == 'paddleocr') and paddle_available:
                        text, details = self.extract_text_with_paddleocr(image)
                        if text:
                            # Calcular confiança média
                            if details:
                                confidence = sum(item["confidence"] for item in details) / len(details)
                            else:
                                confidence = 0.0
                            
                            page_result["text"] = text
                            page_result["confidence"] = confidence
                            page_result["engine"] = "paddleocr"
                            page_result["details"] = details
                            
                            # Se PaddleOCR funcionou bem, continuar para a próxima página
                            result["pages"].append(page_result)
                            continue
                    
                    # Fallback para Tesseract
                    text = self.extract_text_with_tesseract(image)
                    page_result["text"] = text
                    page_result["confidence"] = 0.7  # Valor fixo, Tesseract não fornece confiança por padrão
                    page_result["engine"] = "tesseract"
                    
                    result["pages"].append(page_result)
            else:
                # Extrair texto diretamente do PDF sem OCR
                doc = fitz.open(pdf_path)
                
                for i in range(len(doc)):
                    page = doc.load_page(i)
                    text = page.get_text()
                    
                    result["pages"].append({
                        "page_num": i + 1,
                        "text": text,
                        "engine": "pdfminer"
                    })
                
                doc.close()
            
            return result
        except Exception as e:
            logger.error(f"Erro ao extrair texto do PDF: {str(e)}")
            return {"error": str(e)}

def extract_company_data(text_result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extrai dados de empresa do texto extraído
    
    Args:
        text_result: Resultado da extração de texto
        
    Returns:
        Dicionário com dados da empresa
    """
    # Inicializar resultado
    company_data = {
        "name": "",
        "cnpj": "",
        "address": "",
        "contact": "",
        "financial_info": {},
        "confidence": 0.0
    }
    
    # Juntar texto de todas as páginas
    all_text = ""
    for page in text_result.get("pages", []):
        all_text += page.get("text", "") + "\n"
    
    # Extrair CNPJ
    cnpj_pattern = r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}'
    cnpj_matches = re.findall(cnpj_pattern, all_text)
    if cnpj_matches:
        company_data["cnpj"] = cnpj_matches[0]
    
    # Extrair nome da empresa (assumindo que está próximo ao CNPJ)
    if company_data["cnpj"]:
        # Pegar linhas antes do CNPJ
        lines = all_text.split('\n')
        cnpj_line_index = -1
        
        for i, line in enumerate(lines):
            if company_data["cnpj"] in line:
                cnpj_line_index = i
                break
        
        if cnpj_line_index > 0:
            # Procurar nome da empresa nas linhas anteriores
            for i in range(cnpj_line_index - 1, max(0, cnpj_line_index - 5), -1):
                line = lines[i].strip()
                if line and len(line) > 5 and not re.search(r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}', line):
                    company_data["name"] = line
                    break
    
    # Extrair endereço (linhas após o CNPJ)
    if company_data["cnpj"]:
        lines = all_text.split('\n')
        cnpj_line_index = -1
        
        for i, line in enumerate(lines):
            if company_data["cnpj"] in line:
                cnpj_line_index = i
                break
        
        if cnpj_line_index >= 0 and cnpj_line_index < len(lines) - 1:
            # Procurar endereço nas linhas seguintes
            address_lines = []
            for i in range(cnpj_line_index + 1, min(len(lines), cnpj_line_index + 5)):
                line = lines[i].strip()
                if line and len(line) > 5 and re.search(r'\b(Rua|Avenida|Av\.|R\.|Alameda|Al\.|Praça|Rodovia|Rod\.)\b', line, re.IGNORECASE):
                    address_lines.append(line)
            
            if address_lines:
                company_data["address"] = " ".join(address_lines)
    
    # Extrair informações financeiras
    financial_info = {}
    
    # Procurar valores monetários
    money_pattern = r'R\$\s*[\d\.,]+|\d+[\.,]\d{3}[\.,]\d{2}'
    money_matches = re.findall(money_pattern, all_text)
    
    if money_matches:
        financial_info["monetary_values"] = money_matches
    
    # Procurar datas
    date_pattern = r'\d{2}/\d{2}/\d{4}|\d{2}\.\d{2}\.\d{4}|\d{2}-\d{2}-\d{4}'
    date_matches = re.findall(date_pattern, all_text)
    
    if date_matches:
        financial_info["dates"] = date_matches
    
    company_data["financial_info"] = financial_info
    
    # Calcular confiança com base na quantidade de dados extraídos
    confidence = 0.0
    if company_data["name"]:
        confidence += 0.2
    if company_data["cnpj"]:
        confidence += 0.3
    if company_data["address"]:
        confidence += 0.2
    if financial_info:
        confidence += 0.3
    
    company_data["confidence"] = confidence
    
    return company_data

# Função principal para extrair dados de PDF
def extract_pdf_data(pdf_path: str, use_ocr: bool = True, ocr_engine: str = 'auto') -> Dict[str, Any]:
    """
    Função principal para extrair dados de um PDF
    
    Args:
        pdf_path: Caminho para o arquivo PDF
        use_ocr: Se True, usa OCR para extrair texto
        ocr_engine: Motor de OCR a ser usado ('auto', 'tesseract', 'paddleocr')
        
    Returns:
        Dicionário com dados extraídos
    """
    try:
        # Inicializar extrator
        extractor = PDFExtractor()
        
        # Extrair texto
        text_result = extractor.extract_text_from_pdf(pdf_path, use_ocr, ocr_engine)
        
        # Extrair metadados
        metadata = extractor.extract_pdf_metadata(pdf_path)
        
        # Analisar conteúdo para empresas
        company_data = extract_company_data(text_result)
        
        # Resultado final
        result = {
            "metadata": metadata,
            "text_extraction": text_result,
            "company_data": company_data,
            "extraction_timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        
        return result
    except Exception as e:
        logger.error(f"Erro ao extrair dados do PDF: {str(e)}")
        return {"error": str(e)}
