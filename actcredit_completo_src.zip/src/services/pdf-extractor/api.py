"""
API FastAPI para o extrator de PDF com PaddleOCR e outras bibliotecas de deep learning
Fornece endpoints para upload, processamento e extração de dados de documentos PDF
"""

import os
import sys
import json
import time
import uuid
import logging
import tempfile
from pathlib import Path
from typing import List, Dict, Any, Optional, Union

import uvicorn
from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks, Form, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("pdf_extractor_api.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("pdf_extractor_api")

# Importar o módulo de extração de PDF
from pdf_extractor import (
    PDFExtractor,
    extract_text_from_pdf,
    extract_structured_data,
    process_pdf_with_paddle,
    process_pdf_with_tesseract,
    extract_cnpj_from_text,
    extract_financial_data
)

# Criar diretório para armazenar PDFs temporários
UPLOAD_DIR = Path("./uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

# Criar aplicação FastAPI
app = FastAPI(
    title="ActCredit Premium - Extrator de PDF Avançado",
    description="API para extração de dados de documentos PDF com deep learning para análise de crédito",
    version="2.0.0"
)

# Configurar CORS para permitir acesso do frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Em produção, restringir para origens específicas
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Modelos de dados
class ExtractionRequest(BaseModel):
    file_id: str
    extraction_type: str = "full"  # "full", "cnpj_only", "financial_only", "tables_only", "layout_only"
    use_deep_learning: bool = True
    use_gpu: bool = False

class ExtractionResponse(BaseModel):
    task_id: str
    status: str
    message: str

class ExtractionResult(BaseModel):
    task_id: str
    status: str
    data: Dict[str, Any]
    processing_time: float

class ModelInfo(BaseModel):
    name: str
    version: str
    available: bool
    description: str

# Armazenamento em memória para status das tarefas (em produção, usar Redis ou banco de dados)
tasks_status = {}
extraction_results = {}

# Inicializar extrator global para reutilização
try:
    global_extractor = PDFExtractor(use_gpu=False)
    logger.info("Extrator global inicializado com sucesso")
except Exception as e:
    logger.error(f"Erro ao inicializar extrator global: {str(e)}")
    global_extractor = None

@app.get("/")
async def root():
    """Endpoint raiz para verificar se a API está funcionando"""
    return {
        "message": "ActCredit Premium PDF Extractor API v2.0",
        "status": "online",
        "deep_learning_available": global_extractor is not None
    }

@app.get("/models")
async def get_models_info():
    """Retorna informações sobre os modelos disponíveis"""
    models_info = []
    
    # Verificar PaddleOCR
    try:
        from paddleocr import PaddleOCR, __version__ as paddle_version
        models_info.append(
            ModelInfo(
                name="PaddleOCR",
                version=paddle_version,
                available=True,
                description="OCR de alta precisão com suporte a múltiplos idiomas e análise de layout"
            )
        )
    except ImportError:
        models_info.append(
            ModelInfo(
                name="PaddleOCR",
                version="N/A",
                available=False,
                description="OCR de alta precisão com suporte a múltiplos idiomas e análise de layout"
            )
        )
    
    # Verificar LayoutParser
    try:
        import layoutparser as lp
        models_info.append(
            ModelInfo(
                name="LayoutParser",
                version=lp.__version__,
                available=True,
                description="Análise de layout de documentos com deep learning"
            )
        )
    except (ImportError, AttributeError):
        models_info.append(
            ModelInfo(
                name="LayoutParser",
                version="N/A",
                available=False,
                description="Análise de layout de documentos com deep learning"
            )
        )
    
    # Verificar TrOCR
    try:
        from transformers import TrOCRProcessor, __version__ as transformers_version
        models_info.append(
            ModelInfo(
                name="TrOCR",
                version=transformers_version,
                available=True,
                description="OCR baseado em transformers para reconhecimento de texto de alta precisão"
            )
        )
    except ImportError:
        models_info.append(
            ModelInfo(
                name="TrOCR",
                version="N/A",
                available=False,
                description="OCR baseado em transformers para reconhecimento de texto de alta precisão"
            )
        )
    
    # Verificar Camelot
    try:
        import camelot
        models_info.append(
            ModelInfo(
                name="Camelot",
                version=camelot.__version__,
                available=True,
                description="Extração de tabelas de PDFs"
            )
        )
    except (ImportError, AttributeError):
        models_info.append(
            ModelInfo(
                name="Camelot",
                version="N/A",
                available=False,
                description="Extração de tabelas de PDFs"
            )
        )
    
    # Verificar Tesseract
    try:
        import pytesseract
        tesseract_version = pytesseract.get_tesseract_version()
        models_info.append(
            ModelInfo(
                name="Tesseract OCR",
                version=str(tesseract_version),
                available=True,
                description="OCR tradicional para extração de texto"
            )
        )
    except:
        models_info.append(
            ModelInfo(
                name="Tesseract OCR",
                version="N/A",
                available=False,
                description="OCR tradicional para extração de texto"
            )
        )
    
    return {"models": models_info}

@app.post("/upload/", response_model=dict)
async def upload_pdf(file: UploadFile = File(...)):
    """
    Endpoint para upload de arquivo PDF
    Retorna um ID único para o arquivo que pode ser usado para processamento posterior
    """
    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Apenas arquivos PDF são aceitos")
    
    try:
        # Gerar ID único para o arquivo
        file_id = str(uuid.uuid4())
        file_path = UPLOAD_DIR / f"{file_id}.pdf"
        
        # Salvar arquivo
        with open(file_path, "wb") as buffer:
            buffer.write(await file.read())
        
        logger.info(f"Arquivo PDF recebido e salvo: {file_id}")
        return {
            "file_id": file_id,
            "filename": file.filename,
            "status": "uploaded",
            "message": "Arquivo recebido com sucesso"
        }
    except Exception as e:
        logger.error(f"Erro ao processar upload: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao processar upload: {str(e)}")

@app.post("/extract/", response_model=ExtractionResponse)
async def extract_data(request: ExtractionRequest, background_tasks: BackgroundTasks):
    """
    Inicia o processo de extração de dados do PDF em segundo plano
    Retorna um ID de tarefa que pode ser usado para verificar o status e obter resultados
    """
    file_path = UPLOAD_DIR / f"{request.file_id}.pdf"
    
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Arquivo não encontrado")
    
    # Gerar ID único para a tarefa
    task_id = str(uuid.uuid4())
    
    # Registrar tarefa como "em processamento"
    tasks_status[task_id] = "processing"
    
    # Adicionar tarefa em segundo plano
    background_tasks.add_task(
        process_extraction_task,
        task_id=task_id,
        file_path=str(file_path),
        extraction_type=request.extraction_type,
        use_deep_learning=request.use_deep_learning,
        use_gpu=request.use_gpu
    )
    
    logger.info(f"Tarefa de extração iniciada: {task_id} para arquivo {request.file_id}")
    return ExtractionResponse(
        task_id=task_id,
        status="processing",
        message="Processamento iniciado"
    )

@app.get("/status/{task_id}")
async def get_task_status(task_id: str):
    """Verifica o status de uma tarefa de extração"""
    if task_id not in tasks_status:
        raise HTTPException(status_code=404, detail="Tarefa não encontrada")
    
    status = tasks_status[task_id]
    return {
        "task_id": task_id,
        "status": status,
        "message": "Tarefa concluída" if status == "completed" else "Tarefa em processamento"
    }

@app.get("/result/{task_id}")
async def get_extraction_result(task_id: str):
    """Obtém o resultado de uma tarefa de extração concluída"""
    if task_id not in tasks_status:
        raise HTTPException(status_code=404, detail="Tarefa não encontrada")
    
    if tasks_status[task_id] != "completed":
        return {
            "task_id": task_id,
            "status": tasks_status[task_id],
            "message": "Tarefa ainda em processamento"
        }
    
    if task_id not in extraction_results:
        raise HTTPException(status_code=500, detail="Resultado não encontrado para tarefa concluída")
    
    return extraction_results[task_id]

@app.delete("/file/{file_id}")
async def delete_file(file_id: str):
    """Remove um arquivo PDF do servidor"""
    file_path = UPLOAD_DIR / f"{file_id}.pdf"
    
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Arquivo não encontrado")
    
    try:
        os.remove(file_path)
        return {"status": "success", "message": "Arquivo removido com sucesso"}
    except Exception as e:
        logger.error(f"Erro ao remover arquivo: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao remover arquivo: {str(e)}")

# Função para processamento em segundo plano
async def process_extraction_task(
    task_id: str, 
    file_path: str, 
    extraction_type: str,
    use_deep_learning: bool = True,
    use_gpu: bool = False
):
    """Processa a extração de dados do PDF em segundo plano"""
    try:
        start_time = time.time()
        logger.info(f"Iniciando processamento da tarefa {task_id} para arquivo {file_path}")
        
        # Inicializar extrator ou usar o global
        if global_extractor is None or use_gpu:
            extractor = PDFExtractor(use_gpu=use_gpu)
        else:
            extractor = global_extractor
        
        # Processar dados de acordo com o tipo de extração solicitado
        result = {}
        
        if extraction_type == "cnpj_only":
            # Extrair apenas CNPJ
            text_result = extractor.extract_text_from_pdf(file_path, use_ocr=use_deep_learning)
            cnpj = extract_cnpj_from_text(text_result.get("text", ""))
            result = {"cnpj": cnpj}
        
        elif extraction_type == "financial_only":
            # Extrair apenas dados financeiros
            text_result = extractor.extract_text_from_pdf(file_path, use_ocr=use_deep_learning)
            financial_data = extract_financial_data(text_result.get("text", ""))
            result = {"financial_data": financial_data}
        
        elif extraction_type == "tables_only":
            # Extrair apenas tabelas
            if use_deep_learning:
                # Tentar extrair com PaddleOCR Structure
                tables = extractor.extract_tables_with_paddle(file_path)
                
                # Se não encontrar tabelas ou PaddleOCR não estiver disponível, tentar Camelot
                if not tables:
                    tables = extractor.extract_tables_with_camelot(file_path)
            else:
                # Usar apenas Camelot
                tables = extractor.extract_tables_with_camelot(file_path)
            
            result = {"tables": tables}
        
        elif extraction_type == "layout_only":
            # Extrair apenas layout
            # Converter PDF para imagens
            from pdf2image import convert_from_path
            images = convert_from_path(file_path)
            
            layout_results = []
            for i, image in enumerate(images):
                # Converter para formato numpy/OpenCV
                import numpy as np
                img_np = np.array(image)
                
                # Analisar layout
                layout_data = extractor.analyze_layout(img_np)
                layout_results.append({
                    "page_num": i + 1,
                    "layout_data": layout_data
                })
            
            result = {"layout_results": layout_results}
        
        else:
            # Extração completa
            result = extractor.process_pdf(
                file_path, 
                extract_tables=True, 
                analyze_layout=True
            )
        
        # Calcular tempo de processamento
        processing_time = time.time() - start_time
        
        # Armazenar resultado
        extraction_results[task_id] = {
            "task_id": task_id,
            "status": "completed",
            "data": result,
            "processing_time": processing_time
        }
        
        # Atualizar status da tarefa
        tasks_status[task_id] = "completed"
        
        logger.info(f"Processamento concluído para tarefa {task_id} em {processing_time:.2f} segundos")
    
    except Exception as e:
        logger.error(f"Erro ao processar tarefa {task_id}: {str(e)}")
        tasks_status[task_id] = "error"
        extraction_results[task_id] = {
            "task_id": task_id,
            "status": "error",
            "data": {"error": str(e)},
            "processing_time": time.time() - start_time
        }

# Iniciar servidor se executado diretamente
if __name__ == "__main__":
    uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=True)
