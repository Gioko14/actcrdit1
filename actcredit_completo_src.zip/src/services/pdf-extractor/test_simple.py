"""
Versão simplificada dos testes automatizados para o extrator de PDF
Foco em isolar o segmentation fault
"""
import os
import sys
import unittest
import logging
from PIL import Image, ImageDraw

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("pdf_extractor_tests_simple.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("pdf_extractor_tests_simple")

# Diretório atual
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
# Diretório para arquivos temporários de teste
TEST_DIR = os.path.join(CURRENT_DIR, "test_files")
os.makedirs(TEST_DIR, exist_ok=True)

# Criar uma imagem de teste com texto
test_image_path = os.path.join(TEST_DIR, "test_image_simple.png")
img = Image.new('RGB', (800, 600), color=(255, 255, 255))
d = ImageDraw.Draw(img)
d.text((50, 50), "ActCredit - Teste de OCR", fill=(0, 0, 0))
img.save(test_image_path)
logger.info(f"Imagem de teste criada em {test_image_path}")

# Importar apenas o necessário para o teste básico
try:
    import pytesseract
    logger.info("Pytesseract importado com sucesso")
except ImportError as e:
    logger.error(f"Erro ao importar pytesseract: {str(e)}")

# Teste básico com Tesseract
try:
    text = pytesseract.image_to_string(Image.open(test_image_path), lang='por')
    logger.info(f"Texto extraído com Tesseract: {text}")
except Exception as e:
    logger.error(f"Erro ao extrair texto com Tesseract: {str(e)}")

# Tentar importar PaddleOCR de forma isolada
try:
    from paddleocr import PaddleOCR
    logger.info("PaddleOCR importado com sucesso")
    
    # Tentar inicializar PaddleOCR com configuração mínima
    try:
        paddle_ocr = PaddleOCR(lang='por', show_log=False)
        logger.info("PaddleOCR inicializado com sucesso")
    except Exception as e:
        logger.error(f"Erro ao inicializar PaddleOCR: {str(e)}")
except ImportError as e:
    logger.error(f"Erro ao importar PaddleOCR: {str(e)}")

# Tentar importar LayoutParser de forma isolada
try:
    import layoutparser as lp
    logger.info(f"LayoutParser importado com sucesso, versão: {lp.__version__}")
    logger.info(f"Modelos disponíveis: {dir(lp)}")
    
    # Verificar se PaddleDetectionLayoutModel está disponível
    if hasattr(lp, 'PaddleDetectionLayoutModel'):
        logger.info("PaddleDetectionLayoutModel está disponível")
    else:
        logger.warning("PaddleDetectionLayoutModel não está disponível")
except ImportError as e:
    logger.error(f"Erro ao importar LayoutParser: {str(e)}")

logger.info("Testes básicos concluídos com sucesso")
