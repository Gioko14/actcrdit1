"""
Utilitários para o extrator de PDF
Funções auxiliares para processamento de imagens, análise de texto e manipulação de dados
"""

import os
import re
import cv2
import numpy as np
import logging
from typing import List, Dict, Any, Optional, Tuple, Union
from pathlib import Path

# Configurar logging
logger = logging.getLogger("pdf_extractor.utils")

def enhance_image(image: np.ndarray, method: str = 'adaptive') -> np.ndarray:
    """
    Melhora a qualidade da imagem para OCR
    
    Args:
        image: Imagem em formato numpy array
        method: Método de melhoria ('adaptive', 'otsu', 'canny', 'sharpen')
        
    Returns:
        Imagem melhorada
    """
    # Converter para escala de cinza se a imagem for colorida
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    else:
        gray = image.copy()
    
    if method == 'adaptive':
        # Threshold adaptativo
        return cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
        )
    
    elif method == 'otsu':
        # Threshold de Otsu
        _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        return binary
    
    elif method == 'canny':
        # Detecção de bordas com Canny
        edges = cv2.Canny(gray, 100, 200)
        return edges
    
    elif method == 'sharpen':
        # Aplicar filtro de nitidez
        kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
        sharpened = cv2.filter2D(gray, -1, kernel)
        return sharpened
    
    else:
        logger.warning(f"Método de melhoria desconhecido: {method}, usando imagem original")
        return gray

def remove_noise(image: np.ndarray, method: str = 'gaussian') -> np.ndarray:
    """
    Remove ruído da imagem
    
    Args:
        image: Imagem em formato numpy array
        method: Método de remoção de ruído ('gaussian', 'median', 'bilateral', 'nlmeans')
        
    Returns:
        Imagem sem ruído
    """
    # Converter para escala de cinza se a imagem for colorida
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    else:
        gray = image.copy()
    
    if method == 'gaussian':
        # Filtro gaussiano
        return cv2.GaussianBlur(gray, (5, 5), 0)
    
    elif method == 'median':
        # Filtro de mediana
        return cv2.medianBlur(gray, 5)
    
    elif method == 'bilateral':
        # Filtro bilateral
        return cv2.bilateralFilter(gray, 9, 75, 75)
    
    elif method == 'nlmeans':
        # Non-local means denoising
        return cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)
    
    else:
        logger.warning(f"Método de remoção de ruído desconhecido: {method}, usando imagem original")
        return gray

def correct_skew(image: np.ndarray, delta: float = 1.0, limit: float = 5.0) -> np.ndarray:
    """
    Corrige a inclinação da imagem
    
    Args:
        image: Imagem em formato numpy array
        delta: Incremento do ângulo em graus
        limit: Limite máximo de ângulo em graus
        
    Returns:
        Imagem corrigida
    """
    try:
        # Converter para escala de cinza se a imagem for colorida
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        else:
            gray = image.copy()
        
        # Threshold para binarização
        _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        
        # Encontrar todos os pontos não-zero
        coords = np.column_stack(np.where(binary > 0))
        
        # Encontrar o ângulo de inclinação
        if len(coords) > 0:
            angle = cv2.minAreaRect(coords)[-1]
            
            # Ajustar ângulo
            if angle < -45:
                angle = -(90 + angle)
            else:
                angle = -angle
            
            # Limitar ângulo
            if abs(angle) > limit:
                angle = 0
            
            # Rotacionar a imagem para corrigir a inclinação
            (h, w) = image.shape[:2]
            center = (w // 2, h // 2)
            M = cv2.getRotationMatrix2D(center, angle, 1.0)
            rotated = cv2.warpAffine(
                image, M, (w, h), 
                flags=cv2.INTER_CUBIC, 
                borderMode=cv2.BORDER_REPLICATE
            )
            
            return rotated
    except Exception as e:
        logger.warning(f"Erro ao corrigir inclinação: {str(e)}")
    
    # Retornar imagem original em caso de erro
    return image

def detect_table_areas(image: np.ndarray) -> List[Tuple[int, int, int, int]]:
    """
    Detecta áreas que podem conter tabelas na imagem
    
    Args:
        image: Imagem em formato numpy array
        
    Returns:
        Lista de coordenadas (x, y, w, h) das áreas de tabela
    """
    try:
        # Converter para escala de cinza se a imagem for colorida
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        else:
            gray = image.copy()
        
        # Threshold para binarização
        _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        
        # Aplicar operações morfológicas para destacar linhas horizontais e verticais
        # Kernel horizontal
        kernel_h = np.ones((1, 40), np.uint8)
        # Kernel vertical
        kernel_v = np.ones((40, 1), np.uint8)
        
        # Detectar linhas horizontais
        horizontal = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel_h)
        # Detectar linhas verticais
        vertical = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel_v)
        
        # Combinar linhas horizontais e verticais
        table_mask = cv2.bitwise_or(horizontal, vertical)
        
        # Dilatar para conectar componentes próximos
        kernel = np.ones((5, 5), np.uint8)
        table_mask = cv2.dilate(table_mask, kernel, iterations=3)
        
        # Encontrar contornos
        contours, _ = cv2.findContours(table_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Filtrar contornos por área
        min_area = 5000  # Área mínima para considerar como tabela
        table_areas = []
        
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            area = w * h
            
            if area > min_area:
                table_areas.append((x, y, w, h))
        
        return table_areas
    
    except Exception as e:
        logger.warning(f"Erro ao detectar áreas de tabela: {str(e)}")
        return []

def extract_text_from_region(image: np.ndarray, region: Tuple[int, int, int, int], ocr_engine: str = 'tesseract') -> str:
    """
    Extrai texto de uma região específica da imagem
    
    Args:
        image: Imagem em formato numpy array
        region: Coordenadas (x, y, w, h) da região
        ocr_engine: Motor OCR a ser usado ('tesseract' ou 'paddleocr')
        
    Returns:
        Texto extraído da região
    """
    try:
        # Extrair região da imagem
        x, y, w, h = region
        roi = image[y:y+h, x:x+w]
        
        # Pré-processar região
        if len(roi.shape) == 3:
            gray = cv2.cvtColor(roi, cv2.COLOR_RGB2GRAY)
        else:
            gray = roi.copy()
        
        # Aplicar threshold adaptativo
        binary = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
        )
        
        if ocr_engine == 'tesseract':
            # Extrair texto com Tesseract
            import pytesseract
            text = pytesseract.image_to_string(binary, lang='por')
            return text
        
        elif ocr_engine == 'paddleocr':
            # Extrair texto com PaddleOCR
            try:
                from paddleocr import PaddleOCR
                ocr = PaddleOCR(use_angle_cls=True, lang='pt', show_log=False)
                result = ocr.ocr(binary, cls=True)
                
                if result and result[0]:
                    text_lines = []
                    for line in result[0]:
                        text_lines.append(line[1][0])  # Texto reconhecido
                    
                    return "\n".join(text_lines)
                else:
                    return ""
            except:
                logger.warning("PaddleOCR não disponível, usando Tesseract")
                import pytesseract
                text = pytesseract.image_to_string(binary, lang='por')
                return text
        
        else:
            logger.warning(f"Motor OCR desconhecido: {ocr_engine}, usando Tesseract")
            import pytesseract
            text = pytesseract.image_to_string(binary, lang='por')
            return text
    
    except Exception as e:
        logger.warning(f"Erro ao extrair texto da região: {str(e)}")
        return ""

def normalize_text(text: str) -> str:
    """
    Normaliza o texto extraído, removendo caracteres indesejados e corrigindo problemas comuns
    
    Args:
        text: Texto a ser normalizado
        
    Returns:
        Texto normalizado
    """
    if not text:
        return ""
    
    # Remover caracteres de controle, exceto quebras de linha
    text = re.sub(r'[\x00-\x09\x0b\x0c\x0e-\x1f\x7f]', '', text)
    
    # Substituir múltiplas quebras de linha por uma única
    text = re.sub(r'\n{3,}', '\n\n', text)
    
    # Remover espaços em branco no início e fim de cada linha
    lines = text.split('\n')
    lines = [line.strip() for line in lines]
    text = '\n'.join(lines)
    
    # Remover linhas que contêm apenas caracteres especiais ou muito curtas
    lines = text.split('\n')
    filtered_lines = []
    for line in lines:
        # Remover linhas que contêm apenas caracteres especiais
        if re.match(r'^[^\w]*$', line) and len(line) < 3:
            continue
        # Manter linhas não vazias
        if line.strip():
            filtered_lines.append(line)
    
    text = '\n'.join(filtered_lines)
    
    return text

def extract_entities_regex(text: str) -> Dict[str, List[str]]:
    """
    Extrai entidades do texto usando expressões regulares
    
    Args:
        text: Texto a ser analisado
        
    Returns:
        Dicionário com entidades extraídas
    """
    entities = {}
    
    # Extrair CNPJ
    cnpj_pattern = r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}'
    entities["cnpj"] = re.findall(cnpj_pattern, text)
    
    # Extrair CPF
    cpf_pattern = r'\d{3}\.\d{3}\.\d{3}-\d{2}'
    entities["cpf"] = re.findall(cpf_pattern, text)
    
    # Extrair valores monetários
    money_pattern = r'R\$\s*[\d\.,]+'
    entities["valor"] = re.findall(money_pattern, text)
    
    # Extrair datas
    date_pattern = r'\d{2}/\d{2}/\d{4}'
    entities["data"] = re.findall(date_pattern, text)
    
    # Extrair telefones
    phone_pattern = r'\(\d{2}\)\s*\d{4,5}-\d{4}'
    entities["telefone"] = re.findall(phone_pattern, text)
    
    # Extrair emails
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    entities["email"] = re.findall(email_pattern, text)
    
    # Extrair CEP
    cep_pattern = r'\d{5}-\d{3}'
    entities["cep"] = re.findall(cep_pattern, text)
    
    # Extrair inscrição estadual
    ie_pattern = r'(?:INSCRIÇÃO ESTADUAL|INSCR\.?\s*EST\.?|I\.E\.?)[\s:]*(\d[\d\.]+)'
    ie_matches = re.findall(ie_pattern, text.upper())
    entities["inscricao_estadual"] = ie_matches
    
    return entities

def clean_temp_files(directory: Union[str, Path], max_age_hours: int = 24):
    """
    Remove arquivos temporários antigos
    
    Args:
        directory: Diretório contendo arquivos temporários
        max_age_hours: Idade máxima dos arquivos em horas
    """
    try:
        import time
        from datetime import datetime, timedelta
        
        directory = Path(directory)
        if not directory.exists():
            return
        
        # Calcular timestamp limite
        max_age_seconds = max_age_hours * 3600
        current_time = time.time()
        
        # Listar arquivos no diretório
        for file_path in directory.glob('*'):
            if file_path.is_file():
                # Verificar idade do arquivo
                file_age = current_time - file_path.stat().st_mtime
                if file_age > max_age_seconds:
                    # Remover arquivo
                    file_path.unlink()
                    logger.info(f"Arquivo temporário removido: {file_path}")
    
    except Exception as e:
        logger.error(f"Erro ao limpar arquivos temporários: {str(e)}")

def get_document_metadata(pdf_path: str) -> Dict[str, Any]:
    """
    Extrai metadados do documento PDF
    
    Args:
        pdf_path: Caminho para o arquivo PDF
        
    Returns:
        Dicionário com metadados do documento
    """
    try:
        import fitz  # PyMuPDF
        
        metadata = {}
        
        with fitz.open(pdf_path) as doc:
            # Metadados básicos
            metadata["num_pages"] = len(doc)
            metadata["file_size"] = os.path.getsize(pdf_path)
            
            # Metadados do documento
            doc_info = doc.metadata
            if doc_info:
                metadata["title"] = doc_info.get("title", "")
                metadata["author"] = doc_info.get("author", "")
                metadata["subject"] = doc_info.get("subject", "")
                metadata["keywords"] = doc_info.get("keywords", "")
                metadata["creator"] = doc_info.get("creator", "")
                metadata["producer"] = doc_info.get("producer", "")
                metadata["creation_date"] = doc_info.get("creationDate", "")
                metadata["modification_date"] = doc_info.get("modDate", "")
            
            # Informações sobre as páginas
            page_info = []
            for i, page in enumerate(doc):
                page_info.append({
                    "page_num": i + 1,
                    "width": page.rect.width,
                    "height": page.rect.height,
                    "rotation": page.rotation
                })
            
            metadata["pages_info"] = page_info
        
        return metadata
    
    except Exception as e:
        logger.error(f"Erro ao extrair metadados do documento: {str(e)}")
        return {"error": str(e)}
