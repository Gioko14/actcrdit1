/**
 * BiAnalyticsService.js
 * Serviço responsável por fornecer dados analíticos e métricas
 * para o dashboard e relatórios do ActCredit.
 */

import axios from 'axios';

class BiAnalyticsService {
  constructor() {
    this.apiBaseUrl = '/api';
    // Usar localStorage para persistência real entre sessões
    this.initLocalStorage();
  }

  /**
   * Inicializa o armazenamento local com dados padrão se necessário
   */
  initLocalStorage() {
    if (!localStorage.getItem('actcredit_analises')) {
      const dadosPadrao = [
        {
          id: 1,
          cliente: 'Tech Solutions Ltda',
          nomeCliente: 'Tech Solutions Ltda',
          cnpjCliente: '12.345.678/0001-99',
          data: '15/05/2025',
          dataAnalise: '2025-05-15T10:30:00',
          tipo: 'Majoração',
          tipoAnalise: 'Majoração',
          modalidadeCredito: 'Capital de Giro',
          score: 92,
          status: 'Aprovado',
          decisao: 'Aprovado',
          justificativa: 'Excelente histórico de crédito e score elevado',
          setorCliente: 'Tecnologia',
          regiaoCliente: 'Sudeste',
          tempoAtividade: 5,
          valorSolicitado: 500000,
          faturamentoAnual: 5800000,
          percentualEndividamento: 25,
          prazoDesejado: 36,
          serasaScore: 850,
          serasaPendencias: [],
          serasaConsultado: true,
          resultadosPoliticas: [
            {
              politica: 'Score Mínimo',
              criterio: 'Score >= 60',
              dadoVerificado: 'Score: 92',
              resultado: 'Cumprida',
              detalhes: 'Score 92 é maior que o mínimo exigido (60)'
            },
            {
              politica: 'Score Mínimo Serasa',
              criterio: 'Score Serasa >= 400',
              dadoVerificado: 'Score: 850',
              resultado: 'Cumprida',
              detalhes: 'Score Serasa OK.'
            }
          ],
          fatoresPositivos: [
            'Faturamento anual elevado (R$ 5.800.000,00)',
            'Tempo de atividade significativo (5 anos)',
            'Atuação em setor de baixo risco (Tecnologia)'
          ],
          fatoresNegativos: [
            'Percentual de endividamento moderado (25%)'
          ],
          probabilidadeDefault: 0.08,
          condicoes: {
            limiteAprovado: 500000,
            taxaAprovada: 1.2,
            prazoAprovado: 36,
            garantiasExigidas: ['Aval dos Sócios']
          }
        },
        {
          id: 2,
          cliente: 'Mercado Central S.A.',
          nomeCliente: 'Mercado Central S.A.',
          cnpjCliente: '23.456.789/0001-88',
          data: '14/05/2025',
          dataAnalise: '2025-05-14T14:45:00',
          tipo: 'Nova Análise',
          tipoAnalise: 'Prospecção',
          modalidadeCredito: 'Investimento',
          score: 78,
          status: 'Aprovado',
          decisao: 'Aprovado',
          justificativa: 'Bom histórico e score adequado',
          setorCliente: 'Varejo',
          regiaoCliente: 'Sudeste',
          tempoAtividade: 8,
          valorSolicitado: 750000,
          faturamentoAnual: 12500000,
          percentualEndividamento: 30,
          prazoDesejado: 48,
          serasaScore: 720,
          serasaPendencias: [],
          serasaConsultado: true,
          resultadosPoliticas: [
            {
              politica: 'Score Mínimo',
              criterio: 'Score >= 60',
              dadoVerificado: 'Score: 78',
              resultado: 'Cumprida',
              detalhes: 'Score 78 é maior que o mínimo exigido (60)'
            },
            {
              politica: 'Score Mínimo Serasa',
              criterio: 'Score Serasa >= 400',
              dadoVerificado: 'Score: 720',
              resultado: 'Cumprida',
              detalhes: 'Score Serasa OK.'
            }
          ],
          fatoresPositivos: [
            'Faturamento anual elevado (R$ 12.500.000,00)',
            'Tempo de atividade significativo (8 anos)'
          ],
          fatoresNegativos: [
            'Percentual de endividamento moderado (30%)'
          ],
          probabilidadeDefault: 0.22,
          condicoes: {
            limiteAprovado: 700000,
            taxaAprovada: 1.4,
            prazoAprovado: 48,
            garantiasExigidas: ['Aval dos Sócios', 'Recebíveis']
          }
        },
        {
          id: 3,
          cliente: 'Indústria Nacional S.A.',
          nomeCliente: 'Indústria Nacional S.A.',
          cnpjCliente: '34.567.890/0001-77',
          data: '12/05/2025',
          dataAnalise: '2025-05-12T09:15:00',
          tipo: 'Renovação',
          tipoAnalise: 'Renovação',
          modalidadeCredito: 'Capital de Giro',
          score: 85,
          status: 'Aprovado',
          decisao: 'Aprovado',
          justificativa: 'Excelente histórico e score elevado',
          setorCliente: 'Indústria',
          regiaoCliente: 'Sul',
          tempoAtividade: 12,
          valorSolicitado: 1200000,
          faturamentoAnual: 18000000,
          percentualEndividamento: 20,
          prazoDesejado: 36,
          serasaScore: 800,
          serasaPendencias: [],
          serasaConsultado: true,
          resultadosPoliticas: [
            {
              politica: 'Score Mínimo',
              criterio: 'Score >= 60',
              dadoVerificado: 'Score: 85',
              resultado: 'Cumprida',
              detalhes: 'Score 85 é maior que o mínimo exigido (60)'
            },
            {
              politica: 'Score Mínimo Serasa',
              criterio: 'Score Serasa >= 400',
              dadoVerificado: 'Score: 800',
              resultado: 'Cumprida',
              detalhes: 'Score Serasa OK.'
            }
          ],
          fatoresPositivos: [
            'Faturamento anual elevado (R$ 18.000.000,00)',
            'Tempo de atividade significativo (12 anos)',
            'Baixo percentual de endividamento (20%)'
          ],
          fatoresNegativos: [],
          probabilidadeDefault: 0.15,
          condicoes: {
            limiteAprovado: 1200000,
            taxaAprovada: 1.1,
            prazoAprovado: 36,
            garantiasExigidas: ['Aval dos Sócios']
          }
        },
        {
          id: 4,
          cliente: 'Agro Forte Ltda',
          nomeCliente: 'Agro Forte Ltda',
          cnpjCliente: '45.678.901/0001-66',
          data: '10/05/2025',
          dataAnalise: '2025-05-10T16:20:00',
          tipo: 'Nova Análise',
          tipoAnalise: 'Prospecção',
          modalidadeCredito: 'Investimento',
          score: 45,
          status: 'Reprovado',
          decisao: 'Reprovado',
          justificativa: 'Score abaixo do mínimo exigido',
          setorCliente: 'Agronegócio',
          regiaoCliente: 'Centro-Oeste',
          tempoAtividade: 3,
          valorSolicitado: 800000,
          faturamentoAnual: 3500000,
          percentualEndividamento: 45,
          prazoDesejado: 60,
          serasaScore: 380,
          serasaPendencias: ['Pendência Financeira XPTO', 'Protesto Cartório Y'],
          serasaConsultado: true,
          resultadosPoliticas: [
            {
              politica: 'Score Mínimo',
              criterio: 'Score >= 60',
              dadoVerificado: 'Score: 45',
              resultado: 'Não Cumprida',
              detalhes: 'Score 45 é menor que o mínimo exigido (60)'
            },
            {
              politica: 'Score Mínimo Serasa',
              criterio: 'Score Serasa >= 400',
              dadoVerificado: 'Score: 380',
              resultado: 'Não Cumprida',
              detalhes: 'Score Serasa abaixo do mínimo.'
            },
            {
              politica: 'Pendências Serasa',
              criterio: 'Não possuir pendências financeiras ou protestos',
              dadoVerificado: '2 pendências encontradas',
              resultado: 'Não Cumprida',
              detalhes: 'Encontradas pendências: Pendência Financeira XPTO, Protesto Cartório Y'
            }
          ],
          fatoresPositivos: [
            'Setor em crescimento'
          ],
          fatoresNegativos: [
            'Score abaixo do mínimo (45)',
            'Pendências no Serasa',
            'Alto percentual de endividamento (45%)',
            'Tempo de atividade baixo (3 anos)'
          ],
          probabilidadeDefault: 0.55,
          condicoes: null
        },
        {
          id: 5,
          cliente: 'Saúde Integral S.A.',
          nomeCliente: 'Saúde Integral S.A.',
          cnpjCliente: '56.789.012/0001-55',
          data: '08/05/2025',
          dataAnalise: '2025-05-08T11:10:00',
          tipo: 'Majoração',
          tipoAnalise: 'Majoração',
          modalidadeCredito: 'Capital de Giro',
          score: 67,
          status: 'Análise Manual',
          decisao: 'Análise Manual',
          justificativa: 'Score na faixa limite, requer análise manual',
          setorCliente: 'Saúde',
          regiaoCliente: 'Sudeste',
          tempoAtividade: 4,
          valorSolicitado: 600000,
          faturamentoAnual: 4200000,
          percentualEndividamento: 35,
          prazoDesejado: 48,
          serasaScore: 650,
          serasaPendencias: [],
          serasaConsultado: true,
          resultadosPoliticas: [
            {
              politica: 'Score Mínimo',
              criterio: 'Score >= 60',
              dadoVerificado: 'Score: 67',
              resultado: 'Cumprida',
              detalhes: 'Score 67 é maior que o mínimo exigido (60)'
            },
            {
              politica: 'Score Mínimo Serasa',
              criterio: 'Score Serasa >= 400',
              dadoVerificado: 'Score: 650',
              resultado: 'Cumprida',
              detalhes: 'Score Serasa OK.'
            },
            {
              politica: 'Limite de Endividamento',
              criterio: 'Endividamento <= 30%',
              dadoVerificado: 'Endividamento: 35%',
              resultado: 'Não Cumprida',
              detalhes: 'Endividamento 35% é maior que o limite de 30%'
            }
          ],
          fatoresPositivos: [
            'Score acima do mínimo (67)',
            'Sem pendências no Serasa'
          ],
          fatoresNegativos: [
            'Percentual de endividamento elevado (35%)',
            'Tempo de atividade moderado (4 anos)'
          ],
          probabilidadeDefault: 0.33,
          condicoes: null
        }
      ];
      
      localStorage.setItem('actcredit_analises', JSON.stringify(dadosPadrao));
    }
    
    // Inicializar políticas se não existirem
    if (!localStorage.getItem('actcredit_politicas')) {
      const politicasPadrao = [
        {
          id: 1,
          nome: 'Score Mínimo',
          descricao: 'Score deve ser maior ou igual a 60',
          criterio: 'score >= 60',
          ativa: true,
          parametros: {
            scoreMinimo: 60
          }
        },
        {
          id: 2,
          nome: 'Score Mínimo Serasa',
          descricao: 'Score Serasa deve ser maior ou igual a 400',
          criterio: 'serasaScore >= 400',
          ativa: true,
          parametros: {
            scoreMinimo: 400
          }
        },
        {
          id: 3,
          nome: 'Pendências Serasa',
          descricao: 'Não possuir pendências financeiras ou protestos',
          criterio: 'serasaPendencias.length === 0',
          ativa: true,
          parametros: {}
        },
        {
          id: 4,
          nome: 'Limite de Endividamento',
          descricao: 'Endividamento deve ser menor ou igual a 30%',
          criterio: 'percentualEndividamento <= 30',
          ativa: true,
          parametros: {
            limiteEndividamento: 30
          }
        },
        {
          id: 5,
          nome: 'Tempo Mínimo de Atividade',
          descricao: 'Empresa deve ter pelo menos 2 anos de atividade',
          criterio: 'tempoAtividade >= 2',
          ativa: true,
          parametros: {
            tempoMinimo: 2
          }
        }
      ];
      
      localStorage.setItem('actcredit_politicas', JSON.stringify(politicasPadrao));
    }
  }

  /**
   * Adiciona uma nova análise ao armazenamento local
   * @param {Object} analise - Objeto com dados da análise
   * @returns {Promise<Object>} Análise adicionada com ID
   */
  async adicionarAnalise(analise) {
    try {
      // Obter análises existentes
      const analises = JSON.parse(localStorage.getItem('actcredit_analises') || '[]');
      
      // Gerar ID único
      const novoId = analises.length > 0 ? Math.max(...analises.map(a => a.id)) + 1 : 1;
      
      // Aplicar políticas ativas
      const politicasAtivas = this.getPoliticasAtivas();
      const resultadosPoliticas = this.aplicarPoliticas(analise, politicasAtivas);
      
      // Criar nova análise com dados completos
      const novaAnalise = {
        id: novoId,
        ...analise,
        data: new Date().toLocaleDateString('pt-BR'),
        resultadosPoliticas: resultadosPoliticas,
        // Garantir que campos essenciais existam
        cliente: analise.nomeCliente || analise.cliente || "Cliente não identificado",
        nomeCliente: analise.nomeCliente || analise.cliente || "Cliente não identificado",
        cnpjCliente: analise.cnpjCliente || "00.000.000/0000-00",
        dataAnalise: analise.dataAnalise || new Date().toISOString()
      };
      
      // Adicionar ao início da lista (mais recente primeiro)
      analises.unshift(novaAnalise);
      
      // Salvar no localStorage
      localStorage.setItem('actcredit_analises', JSON.stringify(analises));
      
      return novaAnalise;
    } catch (error) {
      console.error('Erro ao adicionar análise:', error);
      throw error;
    }
  }

  /**
   * Obtém políticas ativas
   * @returns {Array} Lista de políticas ativas
   */
  getPoliticasAtivas() {
    try {
      const politicas = JSON.parse(localStorage.getItem('actcredit_politicas') || '[]');
      return politicas.filter(p => p.ativa);
    } catch (error) {
      console.error('Erro ao obter políticas ativas:', error);
      return [];
    }
  }

  /**
   * Aplica políticas a uma análise
   * @param {Object} analise - Análise a ser avaliada
   * @param {Array} politicas - Lista de políticas a aplicar
   * @returns {Array} Resultados da aplicação das políticas
   */
  aplicarPoliticas(analise, politicas) {
    try {
      return politicas.map(politica => {
        let resultado = 'Não Aplicável';
        let detalhes = 'Não foi possível avaliar esta política';
        let dadoVerificado = 'N/A';
        
        // Aplicar política com base no critério
        switch (politica.nome) {
          case 'Score Mínimo':
            dadoVerificado = `Score: ${analise.score}`;
            if (analise.score >= politica.parametros.scoreMinimo) {
              resultado = 'Cumprida';
              detalhes = `Score ${analise.score} é maior ou igual ao mínimo exigido (${politica.parametros.scoreMinimo})`;
            } else {
              resultado = 'Não Cumprida';
              detalhes = `Score ${analise.score} é menor que o mínimo exigido (${politica.parametros.scoreMinimo})`;
            }
            break;
            
          case 'Score Mínimo Serasa':
            dadoVerificado = `Score: ${analise.serasaScore || 'N/A'}`;
            if (analise.serasaScore && analise.serasaScore >= politica.parametros.scoreMinimo) {
              resultado = 'Cumprida';
              detalhes = 'Score Serasa OK.';
            } else {
              resultado = 'Não Cumprida';
              detalhes = 'Score Serasa abaixo do mínimo.';
            }
            break;
            
          case 'Pendências Serasa':
            const pendencias = analise.serasaPendencias || [];
            dadoVerificado = `${pendencias.length} pendências encontradas`;
            if (pendencias.length === 0) {
              resultado = 'Cumprida';
              detalhes = 'Sem pendências no Serasa.';
            } else {
              resultado = 'Não Cumprida';
              detalhes = `Encontradas pendências: ${pendencias.join(', ')}`;
            }
            break;
            
          case 'Limite de Endividamento':
            dadoVerificado = `Endividamento: ${analise.percentualEndividamento || 0}%`;
            if ((analise.percentualEndividamento || 0) <= politica.parametros.limiteEndividamento) {
              resultado = 'Cumprida';
              detalhes = `Endividamento ${analise.percentualEndividamento || 0}% é menor ou igual ao limite de ${politica.parametros.limiteEndividamento}%`;
            } else {
              resultado = 'Não Cumprida';
              detalhes = `Endividamento ${analise.percentualEndividamento || 0}% é maior que o limite de ${politica.parametros.limiteEndividamento}%`;
            }
            break;
            
          case 'Tempo Mínimo de Atividade':
            dadoVerificado = `Tempo de Atividade: ${analise.tempoAtividade || 0} anos`;
            if ((analise.tempoAtividade || 0) >= politica.parametros.tempoMinimo) {
              resultado = 'Cumprida';
              detalhes = `Tempo de atividade (${analise.tempoAtividade || 0} anos) é maior ou igual ao mínimo exigido (${politica.parametros.tempoMinimo} anos)`;
            } else {
              resultado = 'Não Cumprida';
              detalhes = `Tempo de atividade (${analise.tempoAtividade || 0} anos) é menor que o mínimo exigido (${politica.parametros.tempoMinimo} anos)`;
            }
            break;
        }
        
        return {
          politica: politica.nome,
          criterio: politica.descricao,
          dadoVerificado,
          resultado,
          detalhes
        };
      });
    } catch (error) {
      console.error('Erro ao aplicar políticas:', error);
      return [];
    }
  }

  /**
   * Obtém métricas gerais de análise de crédito
   * @returns {Promise<Object>} Métricas de análise
   */
  async getMetricasAnalise() {
    try {
      // Obter análises do localStorage
      const analises = JSON.parse(localStorage.getItem('actcredit_analises') || '[]');
      
      // Calcular métricas com base nas análises armazenadas
      const totalAnalises = analises.length;
      const aprovadas = analises.filter(a => a.status === 'Aprovado' || a.status === 'Aprovado com Condições' || 
                                            a.decisao === 'Aprovado' || a.decisao === 'Aprovado com Condições').length;
      const taxaAprovacao = totalAnalises > 0 ? Math.round((aprovadas / totalAnalises) * 100) : 0;
      const somaScores = analises.reduce((acc, a) => acc + (a.score || 0), 0);
      const scoreMedio = totalAnalises > 0 ? Math.round(somaScores / totalAnalises) : 0;
      
      return {
        totalAnalises,
        taxaAprovacao,
        scoreMedio,
        tempoMedioAnalise: 2.4
      };
    } catch (error) {
      console.error('Erro ao obter métricas de análise:', error);
      return {
        totalAnalises: 0,
        taxaAprovacao: 0,
        scoreMedio: 0,
        tempoMedioAnalise: 0
      };
    }
  }

  /**
   * Obtém lista de análises de crédito
   * @param {String} tipo - Tipo de análises a serem obtidas (recentes, pendentes, manual)
   * @returns {Promise<Array>} Lista de análises
   */
  async getAnalises(tipo = 'recentes') {
    try {
      // Obter análises do localStorage
      const analises = JSON.parse(localStorage.getItem('actcredit_analises') || '[]');
      
      // Filtrar conforme o tipo solicitado
      if (tipo === 'pendentes') {
        return analises.filter(a => a.status === 'Análise Manual' || a.decisao === 'Análise Manual');
      } else if (tipo === 'manual') {
        return analises.filter(a => a.status === 'Análise Manual' || a.decisao === 'Análise Manual');
      }
      
      return analises;
    } catch (error) {
      console.error('Erro ao obter análises:', error);
      return [];
    }
  }

  /**
   * Obtém métricas de dashboard
   * @returns {Promise<Object>} Métricas do dashboard
   */
  async getMetricasDashboard() {
    try {
      // Obter análises do localStorage
      const analises = JSON.parse(localStorage.getItem('actcredit_analises') || '[]');
      
      // Calcular métricas com base nas análises armazenadas
      const totalAnalises = analises.length;
      const aprovadas = analises.filter(a => a.status === 'Aprovado' || a.status === 'Aprovado com Condições' || 
                                            a.decisao === 'Aprovado' || a.decisao === 'Aprovado com Condições').length;
      const reprovadas = analises.filter(a => a.status === 'Reprovado' || a.decisao === 'Reprovado').length;
      const emAnalise = analises.filter(a => a.status === 'Análise Manual' || a.decisao === 'Análise Manual').length;
      
      // Calcular volume de crédito aprovado
      const volumeCredito = analises
        .filter(a => a.status === 'Aprovado' || a.status === 'Aprovado com Condições' || 
                    a.decisao === 'Aprovado' || a.decisao === 'Aprovado com Condições')
        .reduce((acc, a) => acc + (a.valorSolicitado || 0), 0);
      
      // Dados simulados para demonstração
      return {
        totalClientes: 87,
        clientesAtivos: 78,
        novosMes: 12,
        limiteTotal: 4200000,
        
        analisesRealizadas: totalAnalises,
        analisesAprovadas: aprovadas,
        analisesReprovadas: reprovadas,
        analisesEmAnalise: emAnalise,
        
        volumeCredito,
        volumeCreditoMesAnterior: volumeCredito * 0.85, // Simulado: 85% do atual
        taxaInadimplencia: 2.3,
        taxaInadimplenciaMesAnterior: 2.8
      };
    } catch (error) {
      console.error('Erro ao obter métricas do dashboard:', error);
      return {
        totalClientes: 0,
        clientesAtivos: 0,
        novosMes: 0,
        limiteTotal: 0,
        
        analisesRealizadas: 0,
        analisesAprovadas: 0,
        analisesReprovadas: 0,
        analisesEmAnalise: 0,
        
        volumeCredito: 0,
        volumeCreditoMesAnterior: 0,
        taxaInadimplencia: 0,
        taxaInadimplenciaMesAnterior: 0
      };
    }
  }

  /**
   * Obtém dados para gráficos do dashboard
   * @returns {Promise<Object>} Dados para gráficos
   */
  async getDadosGraficos() {
    try {
      // Dados simulados para demonstração
      return {
        analisePorMes: {
          labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
          datasets: [
            {
              label: 'Aprovadas',
              data: [18, 22, 20, 25, 27, 32],
              backgroundColor: '#22c55e'
            },
            {
              label: 'Reprovadas',
              data: [8, 7, 9, 6, 5, 5],
              backgroundColor: '#ef4444'
            },
            {
              label: 'Em Análise',
              data: [4, 3, 5, 4, 6, 5],
              backgroundColor: '#eab308'
            }
          ]
        },
        
        scoreMedioPorSetor: {
          labels: ['Tecnologia', 'Varejo', 'Indústria', 'Agronegócio', 'Saúde', 'Serviços'],
          datasets: [
            {
              label: 'Score Médio',
              data: [82, 74, 78, 68, 76, 72],
              backgroundColor: '#3b82f6'
            }
          ]
        },
        
        volumeCreditoPorMes: {
          labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
          datasets: [
            {
              label: 'Volume de Crédito (R$ mil)',
              data: [2800, 3100, 2900, 3300, 3500, 3750],
              borderColor: '#22c55e',
              backgroundColor: 'rgba(34, 197, 94, 0.1)',
              fill: true
            }
          ]
        }
      };
    } catch (error) {
      console.error('Erro ao obter dados para gráficos:', error);
      return {
        analisePorMes: { labels: [], datasets: [] },
        scoreMedioPorSetor: { labels: [], datasets: [] },
        volumeCreditoPorMes: { labels: [], datasets: [] }
      };
    }
  }

  /**
   * Obtém lista de políticas de crédito
   * @returns {Promise<Array>} Lista de políticas
   */
  async getPoliticas() {
    try {
      return JSON.parse(localStorage.getItem('actcredit_politicas') || '[]');
    } catch (error) {
      console.error('Erro ao obter políticas:', error);
      return [];
    }
  }

  /**
   * Atualiza uma política de crédito
   * @param {Number} id - ID da política
   * @param {Object} dadosAtualizados - Novos dados da política
   * @returns {Promise<Object>} Política atualizada
   */
  async atualizarPolitica(id, dadosAtualizados) {
    try {
      const politicas = JSON.parse(localStorage.getItem('actcredit_politicas') || '[]');
      const index = politicas.findIndex(p => p.id === id);
      
      if (index === -1) {
        throw new Error(`Política com ID ${id} não encontrada`);
      }
      
      politicas[index] = {
        ...politicas[index],
        ...dadosAtualizados
      };
      
      localStorage.setItem('actcredit_politicas', JSON.stringify(politicas));
      return politicas[index];
    } catch (error) {
      console.error(`Erro ao atualizar política ${id}:`, error);
      throw error;
    }
  }

  /**
   * Adiciona uma nova política de crédito
   * @param {Object} politica - Dados da nova política
   * @returns {Promise<Object>} Política adicionada
   */
  async adicionarPolitica(politica) {
    try {
      const politicas = JSON.parse(localStorage.getItem('actcredit_politicas') || '[]');
      const novoId = politicas.length > 0 ? Math.max(...politicas.map(p => p.id)) + 1 : 1;
      
      const novaPolitica = {
        id: novoId,
        ...politica,
        ativa: politica.ativa !== undefined ? politica.ativa : true
      };
      
      politicas.push(novaPolitica);
      localStorage.setItem('actcredit_politicas', JSON.stringify(politicas));
      
      return novaPolitica;
    } catch (error) {
      console.error('Erro ao adicionar política:', error);
      throw error;
    }
  }

  /**
   * Obtém lista de clientes
   * @returns {Promise<Array>} Lista de clientes
   */
  async getClientes() {
    try {
      // Dados simulados para demonstração
      return [
        {
          id: 1,
          nome: 'Tech Solutions Ltda',
          segmento: 'Tecnologia',
          localizacao: 'São Paulo, SP',
          contato: 'João Silva',
          status: 'Ativo'
        },
        {
          id: 2,
          nome: 'Mercado Central S.A.',
          segmento: 'Varejo',
          localizacao: 'Belo Horizonte, MG',
          contato: 'Maria Oliveira',
          status: 'Ativo'
        },
        {
          id: 3,
          nome: 'Indústria Nacional S.A.',
          segmento: 'Indústria',
          localizacao: 'Curitiba, PR',
          contato: 'Pedro Santos',
          status: 'Ativo'
        },
        {
          id: 4,
          nome: 'Agro Forte Ltda',
          segmento: 'Agronegócio',
          localizacao: 'Goiânia, GO',
          contato: 'Ana Costa',
          status: 'Inativo'
        },
        {
          id: 5,
          nome: 'Saúde Integral S.A.',
          segmento: 'Saúde',
          localizacao: 'Rio de Janeiro, RJ',
          contato: 'Carlos Mendes',
          status: 'Ativo'
        },
        {
          id: 6,
          nome: 'Serviços Gerais Ltda',
          segmento: 'Serviços',
          localizacao: 'Brasília, DF',
          contato: 'Fernanda Lima',
          status: 'Ativo'
        }
      ];
    } catch (error) {
      console.error('Erro ao obter clientes:', error);
      return [];
    }
  }

  /**
   * Obtém detalhes de um cliente específico
   * @param {Number} id - ID do cliente
   * @returns {Promise<Object>} Detalhes do cliente
   */
  async getDetalheCliente(id) {
    try {
      // Dados simulados para demonstração
      const clientes = {
        1: {
          id: 1,
          nome: 'Tech Solutions Ltda',
          segmento: 'Tecnologia',
          localizacao: 'São Paulo, SP',
          telefone: '(11) 98765-4321',
          email: 'contato@techsolutions.com.br',
          contatoPrincipal: 'João Silva',
          cargo: 'Diretor Financeiro',
          dataCadastro: '10/01/2023',
          faturamentoAnual: 5800000,
          limiteCredito: 750000,
          observacoes: 'Cliente com excelente histórico de pagamentos e crescimento consistente nos últimos 3 anos. Possui certificações ISO 9001 e ISO 27001, o que demonstra comprometimento com qualidade e segurança.'
        },
        2: {
          id: 2,
          nome: 'Mercado Central S.A.',
          segmento: 'Varejo',
          localizacao: 'Belo Horizonte, MG',
          telefone: '(31) 98765-4321',
          email: 'contato@mercadocentral.com.br',
          contatoPrincipal: 'Maria Oliveira',
          cargo: 'Gerente Financeiro',
          dataCadastro: '15/03/2023',
          faturamentoAnual: 12500000,
          limiteCredito: 1500000,
          observacoes: 'Rede de supermercados em expansão, com planos de abrir mais 3 unidades nos próximos 12 meses. Histórico de crédito excelente e boa liquidez.'
        }
      };
      
      return clientes[id] || null;
    } catch (error) {
      console.error(`Erro ao obter detalhes do cliente ${id}:`, error);
      return null;
    }
  }

  /**
   * Limpa todos os dados de teste (apenas para desenvolvimento)
   */
  limparDados() {
    localStorage.removeItem('actcredit_analises');
    localStorage.removeItem('actcredit_politicas');
    this.initLocalStorage();
  }
}

export default new BiAnalyticsService();
