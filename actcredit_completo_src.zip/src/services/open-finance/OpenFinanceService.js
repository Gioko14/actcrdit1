/**
 * Serviço de Open Finance e Integração Bancária
 * Implementação com SQLite para substituir simulações por dados reais
 */

import { v4 as uuidv4 } from 'uuid';
import ApiClient from '../../utils/ApiClient';
import logger from '../../utils/Logger';

/**
 * Classe para gerenciamento de integração com Open Finance
 * Integrada com SQLite para dados reais
 */
export class OpenFinanceService {
  constructor(config = {}) {
    this.config = {
      apiBaseUrl: config.apiBaseUrl || '/api',
      cacheEnabled: config.cacheEnabled !== undefined ? config.cacheEnabled : true,
      cacheTTL: config.cacheTTL || 300000, // 5 minutos em ms
      ...config
    };

    // Cliente API para comunicação com o backend SQLite
    this.apiClient = new ApiClient(this.config.apiBaseUrl);
    
    // Cache de resultados
    this.cache = new Map();
  }

  /**
   * Obtém dados bancários de um cliente via Open Finance
   * @param {string} clientId ID do cliente
   * @param {string} consentId ID do consentimento (opcional)
   * @returns {Promise<Object>} Dados bancários do cliente
   */
  async getClientBankingData(clientId, consentId = null) {
    try {
      logger.info(`[OpenFinanceService] Obtendo dados bancários do cliente ${clientId}`);
      
      // Verificar cache
      const cacheKey = `banking_${clientId}_${consentId || 'default'}`;
      if (this.config.cacheEnabled) {
        const cachedResult = this.cache.get(cacheKey);
        if (cachedResult && cachedResult.expiresAt > Date.now()) {
          logger.info('[OpenFinanceService] Retornando dados bancários do cache');
          return cachedResult.result;
        }
      }
      
      // Construir parâmetros de consulta
      const queryParams = new URLSearchParams();
      if (consentId) {
        queryParams.append('consentId', consentId);
      }
      
      // Obter dados da API
      const url = `/open-finance/banking/${clientId}?${queryParams.toString()}`;
      const response = await this.apiClient.get(url);
      
      // Processar resultado
      const result = response.data;
      
      // Armazenar no cache
      if (this.config.cacheEnabled) {
        this.cache.set(cacheKey, {
          result,
          expiresAt: Date.now() + this.config.cacheTTL
        });
      }
      
      logger.info('[OpenFinanceService] Dados bancários obtidos com sucesso');
      return result;
    } catch (error) {
      logger.error('[OpenFinanceService] Erro ao obter dados bancários:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao obter dados bancários'
      };
    }
  }

  /**
   * Obtém histórico de transações de um cliente via Open Finance
   * @param {string} clientId ID do cliente
   * @param {Object} filters Filtros para consulta
   * @param {string} consentId ID do consentimento (opcional)
   * @returns {Promise<Object>} Histórico de transações
   */
  async getClientTransactionHistory(clientId, filters = {}, consentId = null) {
    try {
      logger.info(`[OpenFinanceService] Obtendo histórico de transações do cliente ${clientId}`);
      
      // Construir parâmetros de consulta
      const queryParams = new URLSearchParams();
      
      if (consentId) {
        queryParams.append('consentId', consentId);
      }
      
      if (filters.startDate) {
        queryParams.append('startDate', filters.startDate);
      }
      
      if (filters.endDate) {
        queryParams.append('endDate', filters.endDate);
      }
      
      if (filters.type) {
        queryParams.append('type', filters.type);
      }
      
      if (filters.minAmount) {
        queryParams.append('minAmount', filters.minAmount);
      }
      
      if (filters.maxAmount) {
        queryParams.append('maxAmount', filters.maxAmount);
      }
      
      // Obter histórico da API
      const url = `/open-finance/transactions/${clientId}?${queryParams.toString()}`;
      const response = await this.apiClient.get(url);
      
      logger.info('[OpenFinanceService] Histórico de transações obtido com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[OpenFinanceService] Erro ao obter histórico de transações:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao obter histórico de transações'
      };
    }
  }

  /**
   * Cria um novo consentimento para acesso a dados via Open Finance
   * @param {string} clientId ID do cliente
   * @param {Object} consentData Dados do consentimento
   * @returns {Promise<Object>} Resultado da criação do consentimento
   */
  async createConsent(clientId, consentData) {
    try {
      logger.info(`[OpenFinanceService] Criando consentimento para cliente ${clientId}`);
      
      // Validar dados de entrada
      if (!consentData || !consentData.permissions || consentData.permissions.length === 0) {
        throw new Error('Dados de consentimento inválidos ou incompletos');
      }
      
      // Preparar payload
      const payload = {
        clientId,
        ...consentData,
        createdAt: new Date().toISOString()
      };
      
      // Enviar dados para API
      const response = await this.apiClient.post('/open-finance/consents', payload);
      
      logger.info('[OpenFinanceService] Consentimento criado com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[OpenFinanceService] Erro ao criar consentimento:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao criar consentimento'
      };
    }
  }

  /**
   * Obtém status de um consentimento
   * @param {string} consentId ID do consentimento
   * @returns {Promise<Object>} Status do consentimento
   */
  async getConsentStatus(consentId) {
    try {
      logger.info(`[OpenFinanceService] Verificando status do consentimento ${consentId}`);
      
      // Obter status da API
      const response = await this.apiClient.get(`/open-finance/consents/${consentId}/status`);
      
      logger.info('[OpenFinanceService] Status do consentimento obtido com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[OpenFinanceService] Erro ao verificar status do consentimento:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao verificar status do consentimento'
      };
    }
  }

  /**
   * Revoga um consentimento existente
   * @param {string} consentId ID do consentimento
   * @returns {Promise<Object>} Resultado da revogação
   */
  async revokeConsent(consentId) {
    try {
      logger.info(`[OpenFinanceService] Revogando consentimento ${consentId}`);
      
      // Enviar solicitação para API
      const response = await this.apiClient.delete(`/open-finance/consents/${consentId}`);
      
      logger.info('[OpenFinanceService] Consentimento revogado com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[OpenFinanceService] Erro ao revogar consentimento:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao revogar consentimento'
      };
    }
  }
}

// Exportar instância singleton para uso em toda a aplicação
const openFinanceService = new OpenFinanceService();
export default openFinanceService;
