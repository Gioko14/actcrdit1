/**
 * Serviço de Integração com Protheus ERP
 * Implementação com SQLite para substituir simulações por dados reais
 */

import { v4 as uuidv4 } from 'uuid';
import ApiClient from '../../utils/ApiClient';
import logger from '../../utils/Logger';

/**
 * Classe para gerenciamento de integração com Protheus ERP
 * Integrada com SQLite para dados reais
 */
export class ProtheusIntegrationService {
  constructor(config = {}) {
    this.config = {
      apiBaseUrl: config.apiBaseUrl || '/api',
      cacheEnabled: config.cacheEnabled !== undefined ? config.cacheEnabled : true,
      cacheTTL: config.cacheTTL || 300000, // 5 minutos em ms
      ...config
    };

    // Cliente API para comunicação com o backend SQLite
    this.apiClient = new ApiClient(this.config.apiBaseUrl);
    
    // Cache de resultados
    this.cache = new Map();
  }

  /**
   * Obtém dados financeiros de um cliente do Protheus
   * @param {string} clientId ID do cliente
   * @returns {Promise<Object>} Dados financeiros do cliente
   */
  async getClientFinancialData(clientId) {
    try {
      logger.info(`[ProtheusIntegrationService] Obtendo dados financeiros do cliente ${clientId}`);
      
      // Verificar cache
      const cacheKey = `financial_${clientId}`;
      if (this.config.cacheEnabled) {
        const cachedResult = this.cache.get(cacheKey);
        if (cachedResult && cachedResult.expiresAt > Date.now()) {
          logger.info('[ProtheusIntegrationService] Retornando dados financeiros do cache');
          return cachedResult.result;
        }
      }
      
      // Obter dados da API
      const response = await this.apiClient.get(`/protheus/financial/${clientId}`);
      
      // Processar resultado
      const result = response.data;
      
      // Armazenar no cache
      if (this.config.cacheEnabled) {
        this.cache.set(cacheKey, {
          result,
          expiresAt: Date.now() + this.config.cacheTTL
        });
      }
      
      logger.info('[ProtheusIntegrationService] Dados financeiros obtidos com sucesso');
      return result;
    } catch (error) {
      logger.error('[ProtheusIntegrationService] Erro ao obter dados financeiros:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao obter dados financeiros'
      };
    }
  }

  /**
   * Obtém histórico de pedidos de um cliente do Protheus
   * @param {string} clientId ID do cliente
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Object>} Histórico de pedidos
   */
  async getClientOrderHistory(clientId, filters = {}) {
    try {
      logger.info(`[ProtheusIntegrationService] Obtendo histórico de pedidos do cliente ${clientId}`);
      
      // Construir parâmetros de consulta
      const queryParams = new URLSearchParams();
      
      if (filters.startDate) {
        queryParams.append('startDate', filters.startDate);
      }
      
      if (filters.endDate) {
        queryParams.append('endDate', filters.endDate);
      }
      
      if (filters.status) {
        queryParams.append('status', filters.status);
      }
      
      // Obter histórico da API
      const url = `/protheus/orders/${clientId}?${queryParams.toString()}`;
      const response = await this.apiClient.get(url);
      
      logger.info('[ProtheusIntegrationService] Histórico de pedidos obtido com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[ProtheusIntegrationService] Erro ao obter histórico de pedidos:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao obter histórico de pedidos'
      };
    }
  }

  /**
   * Obtém dados cadastrais de um cliente do Protheus
   * @param {string} clientId ID do cliente
   * @returns {Promise<Object>} Dados cadastrais do cliente
   */
  async getClientRegistrationData(clientId) {
    try {
      logger.info(`[ProtheusIntegrationService] Obtendo dados cadastrais do cliente ${clientId}`);
      
      // Verificar cache
      const cacheKey = `registration_${clientId}`;
      if (this.config.cacheEnabled) {
        const cachedResult = this.cache.get(cacheKey);
        if (cachedResult && cachedResult.expiresAt > Date.now()) {
          logger.info('[ProtheusIntegrationService] Retornando dados cadastrais do cache');
          return cachedResult.result;
        }
      }
      
      // Obter dados da API
      const response = await this.apiClient.get(`/protheus/registration/${clientId}`);
      
      // Processar resultado
      const result = response.data;
      
      // Armazenar no cache
      if (this.config.cacheEnabled) {
        this.cache.set(cacheKey, {
          result,
          expiresAt: Date.now() + this.config.cacheTTL
        });
      }
      
      logger.info('[ProtheusIntegrationService] Dados cadastrais obtidos com sucesso');
      return result;
    } catch (error) {
      logger.error('[ProtheusIntegrationService] Erro ao obter dados cadastrais:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao obter dados cadastrais'
      };
    }
  }

  /**
   * Sincroniza dados de análise de crédito com o Protheus
   * @param {Object} analysisData Dados da análise de crédito
   * @returns {Promise<Object>} Resultado da sincronização
   */
  async syncCreditAnalysis(analysisData) {
    try {
      logger.info('[ProtheusIntegrationService] Sincronizando análise de crédito com Protheus');
      
      // Validar dados de entrada
      if (!analysisData || !analysisData.analysisId) {
        throw new Error('Dados de análise inválidos ou incompletos');
      }
      
      // Enviar dados para API de sincronização
      const response = await this.apiClient.post('/protheus/sync/credit-analysis', analysisData);
      
      logger.info('[ProtheusIntegrationService] Análise de crédito sincronizada com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[ProtheusIntegrationService] Erro ao sincronizar análise de crédito:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao sincronizar análise de crédito'
      };
    }
  }

  /**
   * Verifica status de conexão com o Protheus
   * @returns {Promise<Object>} Status da conexão
   */
  async checkConnectionStatus() {
    try {
      logger.info('[ProtheusIntegrationService] Verificando status de conexão com Protheus');
      
      // Verificar status da API
      const response = await this.apiClient.get('/protheus/status');
      
      logger.info('[ProtheusIntegrationService] Status de conexão verificado com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[ProtheusIntegrationService] Erro ao verificar status de conexão:', error);
      return {
        success: false,
        connected: false,
        error: error.response?.data?.error || error.message || 'Erro ao verificar status de conexão'
      };
    }
  }
}

// Exportar instância singleton para uso em toda a aplicação
const protheusIntegrationService = new ProtheusIntegrationService();
export default protheusIntegrationService;
