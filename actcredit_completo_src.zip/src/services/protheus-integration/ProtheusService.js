/**
 * Serviço de integração com Protheus ERP
 * Implementação gratuita usando APIs REST
 */

import axios from 'axios';
import { message } from 'antd';

// URL base da API Protheus (deve ser configurada no .env)
const PROTHEUS_API_URL = process.env.REACT_APP_PROTHEUS_API_URL || 'http://localhost:8080/api/protheus';

// Token de autenticação (em produção, usar mecanismo seguro de autenticação)
const getAuthToken = () => {
  return localStorage.getItem('protheus_token') || '';
};

// Configuração do axios para requisições ao Protheus
const protheusApi = axios.create({
  baseURL: PROTHEUS_API_URL,
  timeout: 30000, // 30 segundos
  headers: {
    'Content-Type': 'application/json',
  }
});

// Interceptor para adicionar token de autenticação
protheusApi.interceptors.request.use(
  config => {
    const token = getAuthToken();
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

// Serviço de integração com Protheus
const ProtheusService = {
  /**
   * Consulta dados de cliente por CNPJ no Protheus
   * @param {string} cnpj - CNPJ do cliente
   * @returns {Promise} Promessa com dados do cliente
   */
  consultarCliente: async (cnpj) => {
    try {
      // Remover caracteres especiais do CNPJ
      const cleanCNPJ = cnpj.replace(/[^\d]/g, '');
      
      // Simulação de consulta ao Protheus (em produção, usar API real)
      // Como solicitado, usando apenas recursos gratuitos
      const response = await axios.get(`https://brasilapi.com.br/api/cnpj/v1/${cleanCNPJ}`);
      
      // Adicionar campos simulados que viriam do Protheus
      const clienteData = {
        ...response.data,
        codigo_cliente: `C${Math.floor(Math.random() * 100000)}`,
        limite_credito: Math.floor(Math.random() * 1000000) / 100,
        saldo_atual: Math.floor(Math.random() * 500000) / 100,
        classificacao_risco: ['A', 'B', 'C', 'D', 'E'][Math.floor(Math.random() * 5)],
        dias_atraso_medio: Math.floor(Math.random() * 30),
        valor_em_aberto: Math.floor(Math.random() * 200000) / 100,
        historico_pagamentos: [
          { data: '2025-01-15', valor: 12500.00, status: 'Pago' },
          { data: '2025-02-15', valor: 12500.00, status: 'Pago' },
          { data: '2025-03-15', valor: 12500.00, status: 'Pago' },
          { data: '2025-04-15', valor: 12500.00, status: 'Pendente' },
        ],
        ultima_compra: '2025-03-28',
        fonte_dados: 'Protheus (simulado)'
      };
      
      return clienteData;
    } catch (error) {
      console.error('Erro ao consultar cliente no Protheus:', error);
      throw error;
    }
  },
  
  /**
   * Consulta histórico de pedidos do cliente no Protheus
   * @param {string} codigoCliente - Código do cliente no Protheus
   * @returns {Promise} Promessa com histórico de pedidos
   */
  consultarHistoricoPedidos: async (codigoCliente) => {
    try {
      // Simulação de consulta ao histórico de pedidos (em produção, usar API real)
      const pedidos = [];
      
      // Gerar pedidos simulados
      const numPedidos = Math.floor(Math.random() * 10) + 5;
      const hoje = new Date();
      
      for (let i = 0; i < numPedidos; i++) {
        const dataPedido = new Date(hoje);
        dataPedido.setDate(hoje.getDate() - (i * 30));
        
        pedidos.push({
          numero_pedido: `PED${Math.floor(Math.random() * 1000000)}`,
          data_pedido: dataPedido.toISOString().split('T')[0],
          valor_total: Math.floor(Math.random() * 100000) / 100,
          status: ['Faturado', 'Em separação', 'Entregue', 'Cancelado'][Math.floor(Math.random() * 4)],
          forma_pagamento: ['Boleto', 'Cartão', 'Transferência', 'Crediário'][Math.floor(Math.random() * 4)],
          prazo_pagamento: [30, 60, 90][Math.floor(Math.random() * 3)],
          itens: Math.floor(Math.random() * 10) + 1
        });
      }
      
      return {
        codigo_cliente: codigoCliente,
        total_pedidos: pedidos.length,
        valor_total: pedidos.reduce((sum, pedido) => sum + pedido.valor_total, 0),
        pedidos: pedidos
      };
    } catch (error) {
      console.error('Erro ao consultar histórico de pedidos:', error);
      throw error;
    }
  },
  
  /**
   * Consulta títulos em aberto do cliente no Protheus
   * @param {string} codigoCliente - Código do cliente no Protheus
   * @returns {Promise} Promessa com títulos em aberto
   */
  consultarTitulosAberto: async (codigoCliente) => {
    try {
      // Simulação de consulta a títulos em aberto (em produção, usar API real)
      const titulos = [];
      
      // Gerar títulos simulados
      const numTitulos = Math.floor(Math.random() * 5) + 1;
      const hoje = new Date();
      
      for (let i = 0; i < numTitulos; i++) {
        const dataVencimento = new Date(hoje);
        dataVencimento.setDate(hoje.getDate() + (i * 15) + 15);
        
        titulos.push({
          numero_titulo: `TIT${Math.floor(Math.random() * 1000000)}`,
          data_emissao: new Date(hoje.getTime() - (i * 15 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0],
          data_vencimento: dataVencimento.toISOString().split('T')[0],
          valor: Math.floor(Math.random() * 50000) / 100,
          saldo: Math.floor(Math.random() * 50000) / 100,
          status: ['Em aberto', 'Parcialmente pago', 'Vencido'][Math.floor(Math.random() * 3)],
          dias_atraso: Math.max(0, Math.floor((hoje - dataVencimento) / (24 * 60 * 60 * 1000)))
        });
      }
      
      return {
        codigo_cliente: codigoCliente,
        total_titulos: titulos.length,
        valor_total: titulos.reduce((sum, titulo) => sum + titulo.valor, 0),
        saldo_total: titulos.reduce((sum, titulo) => sum + titulo.saldo, 0),
        titulos: titulos
      };
    } catch (error) {
      console.error('Erro ao consultar títulos em aberto:', error);
      throw error;
    }
  },
  
  /**
   * Realiza análise de crédito completa via Protheus
   * @param {string} cnpj - CNPJ do cliente
   * @param {string} tipoAnalise - Tipo de análise (Majoração, Reativação, Prospecção, Revisão)
   * @returns {Promise} Promessa com resultado da análise
   */
  realizarAnaliseCredito: async (cnpj, tipoAnalise) => {
    try {
      // Consultar dados do cliente
      const cliente = await ProtheusService.consultarCliente(cnpj);
      
      // Consultar histórico de pedidos
      const historicoPedidos = await ProtheusService.consultarHistoricoPedidos(cliente.codigo_cliente);
      
      // Consultar títulos em aberto
      const titulosAberto = await ProtheusService.consultarTitulosAberto(cliente.codigo_cliente);
      
      // Calcular score de crédito (simulação)
      const scoreCredito = Math.floor(Math.random() * 1000);
      
      // Determinar limite recomendado com base no score
      let limiteRecomendado = 0;
      let classificacaoRisco = '';
      
      if (scoreCredito >= 800) {
        limiteRecomendado = cliente.limite_credito * 1.5;
        classificacaoRisco = 'A';
      } else if (scoreCredito >= 600) {
        limiteRecomendado = cliente.limite_credito * 1.2;
        classificacaoRisco = 'B';
      } else if (scoreCredito >= 400) {
        limiteRecomendado = cliente.limite_credito;
        classificacaoRisco = 'C';
      } else if (scoreCredito >= 200) {
        limiteRecomendado = cliente.limite_credito * 0.8;
        classificacaoRisco = 'D';
      } else {
        limiteRecomendado = cliente.limite_credito * 0.5;
        classificacaoRisco = 'E';
      }
      
      // Resultado da análise
      const resultado = {
        cnpj: cnpj,
        tipo_analise: tipoAnalise,
        data_analise: new Date().toISOString(),
        cliente: cliente,
        historico_pedidos: historicoPedidos,
        titulos_aberto: titulosAberto,
        score_credito: scoreCredito,
        limite_atual: cliente.limite_credito,
        limite_recomendado: limiteRecomendado,
        classificacao_risco: classificacaoRisco,
        recomendacao: scoreCredito >= 400 ? 'Aprovado' : 'Reprovado',
        observacoes: `Análise de crédito ${tipoAnalise} realizada via integração Protheus.`,
        fonte_dados: 'Protheus (simulado)'
      };
      
      return resultado;
    } catch (error) {
      console.error('Erro ao realizar análise de crédito:', error);
      throw error;
    }
  },
  
  /**
   * Realiza análise de crédito em lote via Protheus
   * @param {Array} cnpjs - Lista de CNPJs para análise
   * @param {string} tipoAnalise - Tipo de análise (Majoração, Reativação, Prospecção, Revisão)
   * @returns {Promise} Promessa com resultados das análises
   */
  realizarAnaliseCreditoLote: async (cnpjs, tipoAnalise) => {
    try {
      const resultados = [];
      
      // Processar cada CNPJ sequencialmente
      for (const cnpj of cnpjs) {
        try {
          const resultado = await ProtheusService.realizarAnaliseCredito(cnpj, tipoAnalise);
          resultados.push({
            cnpj: cnpj,
            status: 'success',
            resultado: resultado
          });
        } catch (error) {
          resultados.push({
            cnpj: cnpj,
            status: 'error',
            erro: error.message
          });
        }
      }
      
      return {
        total: cnpjs.length,
        sucesso: resultados.filter(r => r.status === 'success').length,
        erro: resultados.filter(r => r.status === 'error').length,
        resultados: resultados
      };
    } catch (error) {
      console.error('Erro ao realizar análise de crédito em lote:', error);
      throw error;
    }
  }
};

export default ProtheusService;
