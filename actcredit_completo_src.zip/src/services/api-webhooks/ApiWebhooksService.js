/**
 * Serviço de API Webhooks
 * Implementação com SQLite para substituir simulações por dados reais
 */

import { v4 as uuidv4 } from 'uuid';
import ApiClient from '../../utils/ApiClient';
import logger from '../../utils/Logger';

/**
 * Classe para gerenciamento de webhooks para integrações externas
 * Integrada com SQLite para dados reais
 */
export class ApiWebhooksService {
  constructor(config = {}) {
    this.config = {
      apiBaseUrl: config.apiBaseUrl || '/api',
      cacheEnabled: config.cacheEnabled !== undefined ? config.cacheEnabled : true,
      cacheTTL: config.cacheTTL || 300000, // 5 minutos em ms
      ...config
    };

    // Cliente API para comunicação com o backend SQLite
    this.apiClient = new ApiClient(this.config.apiBaseUrl);
    
    // Cache de resultados
    this.cache = new Map();
  }

  /**
   * Registra um novo webhook
   * @param {Object} webhookData Dados do webhook
   * @returns {Promise<Object>} Resultado do registro
   */
  async registerWebhook(webhookData) {
    try {
      logger.info('[ApiWebhooksService] Registrando novo webhook');
      
      // Validar dados de entrada
      if (!webhookData || !webhookData.url || !webhookData.events || webhookData.events.length === 0) {
        throw new Error('Dados do webhook inválidos ou incompletos');
      }
      
      // Preparar payload
      const payload = {
        ...webhookData,
        webhookId: webhookData.webhookId || uuidv4(),
        createdAt: new Date().toISOString(),
        status: 'active'
      };
      
      // Enviar dados para API
      const response = await this.apiClient.post('/webhooks', payload);
      
      logger.info('[ApiWebhooksService] Webhook registrado com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[ApiWebhooksService] Erro ao registrar webhook:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao registrar webhook'
      };
    }
  }

  /**
   * Obtém todos os webhooks registrados
   * @returns {Promise<Object>} Lista de webhooks
   */
  async getWebhooks() {
    try {
      logger.info('[ApiWebhooksService] Obtendo lista de webhooks');
      
      // Verificar cache
      const cacheKey = 'webhooks_list';
      if (this.config.cacheEnabled) {
        const cachedResult = this.cache.get(cacheKey);
        if (cachedResult && cachedResult.expiresAt > Date.now()) {
          logger.info('[ApiWebhooksService] Retornando lista de webhooks do cache');
          return cachedResult.result;
        }
      }
      
      // Obter webhooks da API
      const response = await this.apiClient.get('/webhooks');
      
      // Processar resultado
      const result = response.data;
      
      // Armazenar no cache
      if (this.config.cacheEnabled) {
        this.cache.set(cacheKey, {
          result,
          expiresAt: Date.now() + this.config.cacheTTL
        });
      }
      
      logger.info('[ApiWebhooksService] Lista de webhooks obtida com sucesso');
      return result;
    } catch (error) {
      logger.error('[ApiWebhooksService] Erro ao obter lista de webhooks:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao obter lista de webhooks'
      };
    }
  }

  /**
   * Atualiza um webhook existente
   * @param {string} webhookId ID do webhook
   * @param {Object} webhookData Novos dados do webhook
   * @returns {Promise<Object>} Resultado da atualização
   */
  async updateWebhook(webhookId, webhookData) {
    try {
      logger.info(`[ApiWebhooksService] Atualizando webhook ${webhookId}`);
      
      // Validar dados de entrada
      if (!webhookData) {
        throw new Error('Dados do webhook não fornecidos');
      }
      
      // Enviar dados para API
      const response = await this.apiClient.put(`/webhooks/${webhookId}`, webhookData);
      
      // Limpar cache
      if (this.config.cacheEnabled) {
        this.cache.delete('webhooks_list');
      }
      
      logger.info('[ApiWebhooksService] Webhook atualizado com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[ApiWebhooksService] Erro ao atualizar webhook:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao atualizar webhook'
      };
    }
  }

  /**
   * Remove um webhook
   * @param {string} webhookId ID do webhook
   * @returns {Promise<Object>} Resultado da remoção
   */
  async deleteWebhook(webhookId) {
    try {
      logger.info(`[ApiWebhooksService] Removendo webhook ${webhookId}`);
      
      // Enviar solicitação para API
      const response = await this.apiClient.delete(`/webhooks/${webhookId}`);
      
      // Limpar cache
      if (this.config.cacheEnabled) {
        this.cache.delete('webhooks_list');
      }
      
      logger.info('[ApiWebhooksService] Webhook removido com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[ApiWebhooksService] Erro ao remover webhook:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao remover webhook'
      };
    }
  }

  /**
   * Obtém histórico de entregas de um webhook
   * @param {string} webhookId ID do webhook
   * @param {Object} filters Filtros para consulta
   * @returns {Promise<Object>} Histórico de entregas
   */
  async getWebhookDeliveryHistory(webhookId, filters = {}) {
    try {
      logger.info(`[ApiWebhooksService] Obtendo histórico de entregas para webhook ${webhookId}`);
      
      // Construir parâmetros de consulta
      const queryParams = new URLSearchParams();
      
      if (filters.startDate) {
        queryParams.append('startDate', filters.startDate);
      }
      
      if (filters.endDate) {
        queryParams.append('endDate', filters.endDate);
      }
      
      if (filters.status) {
        queryParams.append('status', filters.status);
      }
      
      // Obter histórico da API
      const url = `/webhooks/${webhookId}/history?${queryParams.toString()}`;
      const response = await this.apiClient.get(url);
      
      logger.info('[ApiWebhooksService] Histórico de entregas obtido com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[ApiWebhooksService] Erro ao obter histórico de entregas:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao obter histórico de entregas'
      };
    }
  }

  /**
   * Testa um webhook enviando um evento de teste
   * @param {string} webhookId ID do webhook
   * @returns {Promise<Object>} Resultado do teste
   */
  async testWebhook(webhookId) {
    try {
      logger.info(`[ApiWebhooksService] Testando webhook ${webhookId}`);
      
      // Enviar solicitação para API
      const response = await this.apiClient.post(`/webhooks/${webhookId}/test`);
      
      logger.info('[ApiWebhooksService] Teste de webhook enviado com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[ApiWebhooksService] Erro ao testar webhook:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao testar webhook'
      };
    }
  }
}

// Exportar instância singleton para uso em toda a aplicação
const apiWebhooksService = new ApiWebhooksService();
export default apiWebhooksService;
