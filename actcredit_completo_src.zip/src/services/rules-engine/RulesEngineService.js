/**
 * RulesEngineService.js - Versão Aprimorada
 * Serviço responsável por aplicar as políticas de crédito e regras de negócio
 * nas análises de crédito, integrando com o modelo de ML e retornando decisões
 * detalhadas com justificativas.
 * 
 * Melhorias implementadas:
 * - Integração explícita e configurável de políticas de crédito
 * - Explicabilidade do modelo (XAI)
 * - Detalhamento da decisão e condições
 * - Rastreabilidade e auditoria aprimoradas
 */

import axios from 'axios';
import MLScoringService from '../ml-scoring/MLScoringService';

class RulesEngineService {
  constructor() {
    this.apiBaseUrl = '/api';
    this.politicasCache = null;
    this.politicasCacheExpiry = null;
  }

  /**
   * Obtém todas as políticas de crédito ativas do banco de dados
   * @returns {Promise<Array>} Lista de políticas ativas
   */
  async getPoliticasAtivas() {
    // Verifica se o cache é válido (15 minutos)
    const agora = new Date();
    if (this.politicasCache && this.politicasCacheExpiry && this.politicasCacheExpiry > agora) {
      return this.politicasCache;
    }

    try {
      const response = await axios.get(`${this.apiBaseUrl}/politicas-credito?status=Ativo`);
      
      // Atualiza o cache
      this.politicasCache = response.data;
      this.politicasCacheExpiry = new Date(agora.getTime() + 15 * 60 * 1000); // 15 minutos
      
      return response.data;
    } catch (error) {
      console.error('Erro ao obter políticas de crédito:', error);
      throw new Error('Falha ao carregar políticas de crédito');
    }
  }

  /**
   * Aplica uma política específica aos dados da análise
   * @param {Object} politica - Política a ser aplicada
   * @param {Object} dadosAnalise - Dados da análise de crédito
   * @param {Number} score - Score de ML obtido
   * @returns {Object} Resultado da aplicação da política
   */
  aplicarPolitica(politica, dadosAnalise, score) {
    // Estrutura de retorno
    const resultado = {
      politica: politica.nome,
      criterio: politica.criterio,
      dadoVerificado: null,
      resultado: 'Não Aplicável',
      detalhes: '',
      impactoScore: 0, // Nova propriedade para explicabilidade
      impactoDecisao: 'Baixo' // Nova propriedade para explicabilidade
    };

    try {
      // Aplicação das políticas baseadas no tipo
      switch (politica.tipo) {
        case 'SCORE_MINIMO':
          resultado.dadoVerificado = `Score: ${score}`;
          if (score >= politica.valorMinimo) {
            resultado.resultado = 'Cumprida';
            resultado.detalhes = `Score ${score} é maior ou igual ao mínimo exigido (${politica.valorMinimo})`;
            resultado.impactoScore = 0; // Não afeta o score
            resultado.impactoDecisao = 'Baixo';
          } else {
            resultado.resultado = 'Não Cumprida';
            resultado.detalhes = `Score ${score} é menor que o mínimo exigido (${politica.valorMinimo})`;
            resultado.impactoScore = -10; // Reduz o score em 10 pontos
            resultado.impactoDecisao = politica.essencial ? 'Alto' : 'Médio';
          }
          break;

        case 'FATURAMENTO_MINIMO':
          const faturamento = dadosAnalise.faturamentoAnual || 0;
          resultado.dadoVerificado = `Faturamento: R$ ${faturamento.toLocaleString('pt-BR')}`;
          
          if (faturamento >= politica.valorMinimo) {
            resultado.resultado = 'Cumprida';
            resultado.detalhes = `Faturamento R$ ${faturamento.toLocaleString('pt-BR')} é maior ou igual ao mínimo exigido (R$ ${politica.valorMinimo.toLocaleString('pt-BR')})`;
            resultado.impactoScore = 0;
            resultado.impactoDecisao = 'Baixo';
          } else {
            resultado.resultado = 'Não Cumprida';
            resultado.detalhes = `Faturamento R$ ${faturamento.toLocaleString('pt-BR')} é menor que o mínimo exigido (R$ ${politica.valorMinimo.toLocaleString('pt-BR')})`;
            
            // Calcula o impacto com base na diferença percentual
            const diferencaPercentual = (politica.valorMinimo - faturamento) / politica.valorMinimo;
            if (diferencaPercentual > 0.5) {
              resultado.impactoScore = -15;
              resultado.impactoDecisao = 'Alto';
            } else if (diferencaPercentual > 0.2) {
              resultado.impactoScore = -10;
              resultado.impactoDecisao = 'Médio';
            } else {
              resultado.impactoScore = -5;
              resultado.impactoDecisao = 'Baixo';
            }
          }
          break;

        case 'SETOR_RESTRITO':
          const setorCliente = dadosAnalise.setor || '';
          resultado.dadoVerificado = `Setor: ${setorCliente}`;
          
          const setoresRestritos = politica.setoresRestritos || [];
          if (setoresRestritos.includes(setorCliente)) {
            resultado.resultado = 'Não Cumprida';
            resultado.detalhes = `Setor ${setorCliente} está na lista de setores restritos`;
            resultado.impactoScore = -20;
            resultado.impactoDecisao = 'Alto';
          } else {
            resultado.resultado = 'Cumprida';
            resultado.detalhes = `Setor ${setorCliente} não está na lista de setores restritos`;
            resultado.impactoScore = 0;
            resultado.impactoDecisao = 'Baixo';
          }
          break;

        case 'TEMPO_ATIVIDADE':
          const tempoAtividade = dadosAnalise.tempoAtividade || 0;
          resultado.dadoVerificado = `Tempo de Atividade: ${tempoAtividade} anos`;
          
          if (tempoAtividade >= politica.valorMinimo) {
            resultado.resultado = 'Cumprida';
            resultado.detalhes = `Tempo de atividade (${tempoAtividade} anos) é maior ou igual ao mínimo exigido (${politica.valorMinimo} anos)`;
            resultado.impactoScore = 0;
            resultado.impactoDecisao = 'Baixo';
          } else {
            resultado.resultado = 'Não Cumprida';
            resultado.detalhes = `Tempo de atividade (${tempoAtividade} anos) é menor que o mínimo exigido (${politica.valorMinimo} anos)`;
            
            // Impacto maior para empresas muito novas
            if (tempoAtividade < 1) {
              resultado.impactoScore = -15;
              resultado.impactoDecisao = 'Alto';
            } else {
              resultado.impactoScore = -10;
              resultado.impactoDecisao = 'Médio';
            }
          }
          break;

        case 'LIMITE_ENDIVIDAMENTO':
          const endividamento = dadosAnalise.percentualEndividamento || 0;
          resultado.dadoVerificado = `Endividamento: ${endividamento}%`;
          
          if (endividamento <= politica.valorMaximo) {
            resultado.resultado = 'Cumprida';
            resultado.detalhes = `Endividamento (${endividamento}%) é menor ou igual ao máximo permitido (${politica.valorMaximo}%)`;
            resultado.impactoScore = 0;
            resultado.impactoDecisao = 'Baixo';
          } else {
            resultado.resultado = 'Não Cumprida';
            resultado.detalhes = `Endividamento (${endividamento}%) é maior que o máximo permitido (${politica.valorMaximo}%)`;
            
            // Impacto baseado no quanto excede o limite
            const excesso = endividamento - politica.valorMaximo;
            if (excesso > 20) {
              resultado.impactoScore = -20;
              resultado.impactoDecisao = 'Alto';
            } else if (excesso > 10) {
              resultado.impactoScore = -15;
              resultado.impactoDecisao = 'Médio';
            } else {
              resultado.impactoScore = -10;
              resultado.impactoDecisao = 'Baixo';
            }
          }
          break;

        default:
          resultado.detalhes = 'Tipo de política não implementado';
      }
    } catch (error) {
      console.error(`Erro ao aplicar política ${politica.nome}:`, error);
      resultado.resultado = 'Erro';
      resultado.detalhes = `Erro ao processar: ${error.message}`;
    }

    return resultado;
  }

  /**
   * Determina o limite de crédito com base no score e nas políticas
   * @param {Number} score - Score de ML obtido
   * @param {Object} dadosAnalise - Dados da análise de crédito
   * @param {Array} resultadosPoliticas - Resultados da aplicação das políticas
   * @returns {Object} Limite e condições aprovadas
   */
  determinarLimiteECondicoes(score, dadosAnalise, resultadosPoliticas) {
    const valorSolicitado = dadosAnalise.valorSolicitado || 0;
    const faturamentoAnual = dadosAnalise.faturamentoAnual || 0;
    
    // Cálculo base do limite como percentual do faturamento
    let percentualFaturamento = 0;
    if (score >= 90) percentualFaturamento = 0.30; // 30% do faturamento
    else if (score >= 80) percentualFaturamento = 0.25; // 25% do faturamento
    else if (score >= 70) percentualFaturamento = 0.20; // 20% do faturamento
    else if (score >= 60) percentualFaturamento = 0.15; // 15% do faturamento
    else percentualFaturamento = 0.10; // 10% do faturamento
    
    let limiteCalculado = faturamentoAnual * percentualFaturamento;
    
    // Ajuste do limite com base nas políticas não cumpridas
    const politicasNaoCumpridas = resultadosPoliticas.filter(p => p.resultado === 'Não Cumprida');
    
    // Redução do limite para cada política não cumprida
    if (politicasNaoCumpridas.length > 0) {
      const fatorReducao = Math.max(0.5, 1 - (politicasNaoCumpridas.length * 0.1));
      limiteCalculado *= fatorReducao;
    }
    
    // Determinar taxa de juros com base no score
    let taxaJuros = 0;
    if (score >= 90) taxaJuros = 0.8; // 0.8% a.m.
    else if (score >= 80) taxaJuros = 1.0; // 1.0% a.m.
    else if (score >= 70) taxaJuros = 1.2; // 1.2% a.m.
    else if (score >= 60) taxaJuros = 1.5; // 1.5% a.m.
    else taxaJuros = 1.8; // 1.8% a.m.
    
    // Ajuste da taxa com base nas políticas não cumpridas
    if (politicasNaoCumpridas.length > 0) {
      taxaJuros += politicasNaoCumpridas.length * 0.2; // +0.2% por política não cumprida
    }
    
    // Determinar prazo máximo com base no score
    let prazoMaximo = 0;
    if (score >= 80) prazoMaximo = 60; // 60 meses
    else if (score >= 70) prazoMaximo = 48; // 48 meses
    else if (score >= 60) prazoMaximo = 36; // 36 meses
    else prazoMaximo = 24; // 24 meses
    
    // Determinar necessidade de garantias
    let garantiasExigidas = [];
    if (score < 70 || politicasNaoCumpridas.length > 0) {
      garantiasExigidas.push('Aval dos Sócios');
    }
    
    if (score < 60 || politicasNaoCumpridas.length > 1) {
      garantiasExigidas.push('Garantia Real (Imóvel ou Equipamentos)');
    }
    
    // Detalhamento do cálculo para explicabilidade
    const detalhamentoCalculo = {
      baseadoEm: {
        score: score,
        faturamentoAnual: faturamentoAnual,
        percentualUtilizado: percentualFaturamento * 100
      },
      ajustes: {
        politicasNaoCumpridas: politicasNaoCumpridas.length,
        fatorReducao: politicasNaoCumpridas.length > 0 ? Math.max(0.5, 1 - (politicasNaoCumpridas.length * 0.1)) : 1
      },
      limiteSolicitado: valorSolicitado,
      limiteCalculadoInicial: faturamentoAnual * percentualFaturamento,
      limiteCalculadoFinal: limiteCalculado
    };
    
    return {
      limiteAprovado: Math.min(limiteCalculado, valorSolicitado),
      taxaAprovada: taxaJuros,
      prazoAprovado: prazoMaximo,
      garantiasExigidas: garantiasExigidas,
      detalhamentoCalculo: detalhamentoCalculo // Novo campo para explicabilidade
    };
  }

  /**
   * Gera uma justificativa detalhada para a decisão
   * @param {String} decisao - Decisão final
   * @param {Number} score - Score de ML obtido
   * @param {Array} resultadosPoliticas - Resultados da aplicação das políticas
   * @param {Object} condicoes - Condições aprovadas (se aplicável)
   * @returns {String} Justificativa detalhada
   */
  gerarJustificativa(decisao, score, resultadosPoliticas, condicoes) {
    let justificativa = '';
    
    const politicasCumpridas = resultadosPoliticas.filter(p => p.resultado === 'Cumprida').length;
    const politicasNaoCumpridas = resultadosPoliticas.filter(p => p.resultado === 'Não Cumprida');
    
    // Políticas de alto impacto não cumpridas
    const politicasAltoImpacto = politicasNaoCumpridas.filter(p => p.impactoDecisao === 'Alto');
    
    switch (decisao) {
      case 'Aprovado':
        justificativa = `Aprovado devido a score satisfatório (${score}) e cumprimento de todas as políticas essenciais (${politicasCumpridas}/${resultadosPoliticas.length}).`;
        
        // Adiciona detalhes sobre o score
        if (score >= 90) {
          justificativa += ` O score de ${score} indica um risco muito baixo.`;
        } else if (score >= 80) {
          justificativa += ` O score de ${score} indica um risco baixo.`;
        } else {
          justificativa += ` O score de ${score} indica um risco moderado, mas aceitável.`;
        }
        break;
        
      case 'Aprovado com Condições':
        justificativa = `Aprovado com condições devido a score satisfatório (${score}), porém com ${politicasNaoCumpridas.length} política(s) não cumprida(s): `;
        justificativa += politicasNaoCumpridas.map(p => p.politica).join(', ') + '. ';
        
        if (condicoes) {
          justificativa += `\n\nLimite aprovado: R$ ${condicoes.limiteAprovado.toLocaleString('pt-BR')}, `;
          justificativa += `Taxa: ${condicoes.taxaAprovada.toFixed(2)}% a.m., `;
          justificativa += `Prazo: até ${condicoes.prazoAprovado} meses. `;
          
          if (condicoes.garantiasExigidas && condicoes.garantiasExigidas.length > 0) {
            justificativa += `\nGarantias exigidas: ${condicoes.garantiasExigidas.join(', ')}.`;
          }
          
          // Explicação do cálculo do limite
          if (condicoes.detalhamentoCalculo) {
            const calc = condicoes.detalhamentoCalculo;
            justificativa += `\n\nDetalhamento do cálculo do limite:`;
            justificativa += `\n- Faturamento anual: R$ ${calc.baseadoEm.faturamentoAnual.toLocaleString('pt-BR')}`;
            justificativa += `\n- Percentual utilizado: ${calc.baseadoEm.percentualUtilizado.toFixed(1)}%`;
            justificativa += `\n- Limite inicial calculado: R$ ${calc.limiteCalculadoInicial.toLocaleString('pt-BR')}`;
            
            if (calc.ajustes.politicasNaoCumpridas > 0) {
              justificativa += `\n- Redução por políticas não cumpridas: ${((1 - calc.ajustes.fatorReducao) * 100).toFixed(1)}%`;
              justificativa += `\n- Limite final calculado: R$ ${calc.limiteCalculadoFinal.toLocaleString('pt-BR')}`;
            }
            
            if (calc.limiteSolicitado < calc.limiteCalculadoFinal) {
              justificativa += `\n- Limite aprovado igual ao solicitado: R$ ${calc.limiteSolicitado.toLocaleString('pt-BR')}`;
            }
          }
        }
        break;
        
      case 'Análise Manual':
        justificativa = `Encaminhado para análise manual devido a score intermediário (${score}) `;
        
        if (politicasNaoCumpridas.length > 0) {
          justificativa += `e ${politicasNaoCumpridas.length} política(s) não cumprida(s): `;
          justificativa += politicasNaoCumpridas.map(p => `${p.politica} (Impacto: ${p.impactoDecisao})`).join(', ') + '.';
          
          if (politicasAltoImpacto.length > 0) {
            justificativa += `\n\nPolíticas de alto impacto não cumpridas:`;
            politicasAltoImpacto.forEach(p => {
              justificativa += `\n- ${p.politica}: ${p.detalhes}`;
            });
          }
        } else {
          justificativa += 'apesar do cumprimento de todas as políticas.';
        }
        
        justificativa += `\n\nRecomendação: Revisar manualmente os seguintes aspectos:`;
        justificativa += `\n- Histórico de relacionamento com o cliente`;
        justificativa += `\n- Perspectivas do setor de atuação`;
        justificativa += `\n- Garantias adicionais disponíveis`;
        break;
        
      case 'Reprovado':
        justificativa = `Reprovado devido a score insatisfatório (${score}) `;
        
        if (politicasNaoCumpridas.length > 0) {
          justificativa += `e ${politicasNaoCumpridas.length} política(s) não cumprida(s): `;
          justificativa += politicasNaoCumpridas.map(p => p.politica).join(', ') + '.';
          
          if (politicasAltoImpacto.length > 0) {
            justificativa += `\n\nPolíticas de alto impacto não cumpridas:`;
            politicasAltoImpacto.forEach(p => {
              justificativa += `\n- ${p.politica}: ${p.detalhes}`;
            });
          }
          
          justificativa += `\n\nRecomendações para nova solicitação:`;
          politicasNaoCumpridas.forEach(p => {
            justificativa += `\n- ${p.politica}: Atender ao critério "${p.criterio}"`;
          });
        } else {
          justificativa += 'apesar do cumprimento de todas as políticas.';
          justificativa += `\n\nO score de ${score} indica um risco elevado. Recomenda-se aguardar 3 meses para nova solicitação.`;
        }
        break;
        
      default:
        justificativa = 'Não foi possível determinar uma justificativa.';
    }
    
    return justificativa;
  }

  /**
   * Processa uma análise de crédito completa
   * @param {Object} dadosAnalise - Dados da análise de crédito
   * @returns {Promise<Object>} Resultado completo da análise
   */
  async processarAnalise(dadosAnalise) {
    try {
      // 1. Obter score do modelo de ML com explicabilidade
      const mlService = MLScoringService;
      const scoreResponse = await mlService.obterScore(dadosAnalise);
      const { score, probabilidadeDefault, fatoresPositivos, fatoresNegativos } = scoreResponse;
      
      // 2. Obter políticas ativas
      const politicasAtivas = await this.getPoliticasAtivas();
      
      // 3. Aplicar cada política aos dados da análise
      const resultadosPoliticas = politicasAtivas.map(politica => 
        this.aplicarPolitica(politica, dadosAnalise, score)
      );
      
      // 4. Determinar decisão com base no score e nas políticas
      let decisao = '';
      let condicoes = null;
      
      const politicasEssenciaisNaoCumpridas = resultadosPoliticas
        .filter(p => p.resultado === 'Não Cumprida' && p.politica.essencial === true);
      
      const politicasNaoCumpridas = resultadosPoliticas
        .filter(p => p.resultado === 'Não Cumprida');
      
      // Lógica de decisão
      if (politicasEssenciaisNaoCumpridas.length > 0 || score < 40) {
        // Reprovação automática se políticas essenciais não forem cumpridas ou score muito baixo
        decisao = 'Reprovado';
      } else if (score >= 80 && politicasNaoCumpridas.length === 0) {
        // Aprovação automática para score alto e todas políticas cumpridas
        decisao = 'Aprovado';
        condicoes = this.determinarLimiteECondicoes(score, dadosAnalise, resultadosPoliticas);
      } else if (score >= 60 && politicasNaoCumpridas.length <= 2) {
        // Aprovação com condições para score médio-alto com poucas políticas não cumpridas
        decisao = 'Aprovado com Condições';
        condicoes = this.determinarLimiteECondicoes(score, dadosAnalise, resultadosPoliticas);
      } else if (score >= 40) {
        // Análise manual para casos intermediários
        decisao = 'Análise Manual';
      } else {
        // Reprovação para score baixo
        decisao = 'Reprovado';
      }
      
      // 5. Gerar justificativa
      const justificativa = this.gerarJustificativa(decisao, score, resultadosPoliticas, condicoes);
      
      // 6. Montar resultado completo com dados para auditoria
      const resultado = {
        // Dados básicos
        score,
        probabilidadeDefault,
        fatoresPositivos,
        fatoresNegativos,
        resultadosPoliticas,
        decisao,
        justificativa,
        condicoes,
        
        // Dados para auditoria e rastreabilidade
        dataAnalise: new Date().toISOString(),
        dadosUtilizados: {
          cliente: {
            nome: dadosAnalise.nome,
            cnpj: dadosAnalise.cnpj,
            setor: dadosAnalise.setor,
            regiao: dadosAnalise.regiao,
            tempoAtividade: dadosAnalise.tempoAtividade
          },
          financeiros: {
            faturamentoAnual: dadosAnalise.faturamentoAnual,
            percentualEndividamento: dadosAnalise.percentualEndividamento,
            valorSolicitado: dadosAnalise.valorSolicitado
          }
        },
        
        // Metadados do processo
        metadados: {
          versaoEngine: '2.0',
          politicasAplicadas: politicasAtivas.length,
          politicasCumpridas: resultadosPoliticas.filter(p => p.resultado === 'Cumprida').length,
          politicasNaoCumpridas: politicasNaoCumpridas.length,
          tempoProcessamento: new Date().getTime() - new Date(dadosAnalise.dataInicio || new Date()).getTime(),
          origemAnalise: dadosAnalise.tipoAnalise || 'Manual'
        }
      };
      
      // 7. Salvar histórico da análise (em um cenário real, seria feito via API)
      try {
        await axios.post(`${this.apiBaseUrl}/historico-analise`, resultado);
      } catch (error) {
        console.warn('Erro ao salvar histórico da análise:', error);
        // Não interrompe o fluxo em caso de erro no salvamento do histórico
      }
      
      return resultado;
    } catch (error) {
      console.error('Erro ao processar análise de crédito:', error);
      throw new Error('Falha ao processar análise de crédito');
    }
  }
}

export default new RulesEngineService();
