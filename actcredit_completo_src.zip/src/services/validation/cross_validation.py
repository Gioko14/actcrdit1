import os
import sys
import json
import logging
import requests
import re
import time
from typing import Dict, List, Any, Optional, Tuple, Union
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("validation.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("cross_validation")

class CrossValidationSystem:
    """
    Sistema de validação cruzada de dados financeiros
    Verifica dados extraídos contra fontes externas confiáveis
    """
    
    def __init__(self, cache_dir: Optional[str] = None):
        """
        Inicializa o sistema de validação cruzada
        
        Args:
            cache_dir: Diretório para cache de resultados (opcional)
        """
        # Configurar cache
        if cache_dir:
            self.cache_dir = Path(cache_dir)
        else:
            self.cache_dir = Path(os.path.dirname(os.path.abspath(__file__))) / "cache"
        
        # Criar diretório de cache se não existir
        os.makedirs(self.cache_dir, exist_ok=True)
        
        # Inicializar APIs e fontes de dados
        self.apis = {
            "cnpj": self._validate_cnpj,
            "empresa": self._validate_company_name,
            "endereco": self._validate_address,
            "valores": self._validate_monetary_values,
            "datas": self._validate_dates
        }
        
        logger.info(f"Sistema de validação cruzada inicializado. Cache: {self.cache_dir}")
    
    def validate_data(self, extracted_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Valida dados extraídos contra fontes externas
        
        Args:
            extracted_data: Dados extraídos do documento
            
        Returns:
            Dicionário com resultados da validação
        """
        try:
            # Inicializar resultado
            validation_result = {
                "validated": {},
                "confidence": {},
                "overall_confidence": 0.0,
                "validation_timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            
            # Extrair entidades consolidadas
            if "consolidated" in extracted_data and "entities" in extracted_data["consolidated"]:
                entities = extracted_data["consolidated"]["entities"]
            else:
                entities = extracted_data.get("entities", {})
            
            # Validar cada tipo de entidade
            for entity_type, validator_func in self.apis.items():
                if entity_type in entities:
                    entity_data = entities[entity_type]
                    validation, confidence = validator_func(entity_data)
                    validation_result["validated"][entity_type] = validation
                    validation_result["confidence"][entity_type] = confidence
            
            # Calcular confiança geral
            if validation_result["confidence"]:
                validation_result["overall_confidence"] = sum(validation_result["confidence"].values()) / len(validation_result["confidence"])
            
            return validation_result
        except Exception as e:
            logger.error(f"Erro ao validar dados: {str(e)}")
            return {"error": str(e)}
    
    def _validate_cnpj(self, cnpj_list: List[str]) -> Tuple[List[Dict[str, Any]], float]:
        """
        Valida CNPJs usando APIs públicas
        
        Args:
            cnpj_list: Lista de CNPJs extraídos
            
        Returns:
            Tuple com lista de CNPJs validados e confiança média
        """
        validated_cnpjs = []
        confidence_sum = 0.0
        
        for cnpj in cnpj_list:
            # Limpar formatação
            clean_cnpj = re.sub(r'[^\d]', '', cnpj)
            
            # Verificar se CNPJ está no cache
            cache_file = self.cache_dir / f"cnpj_{clean_cnpj}.json"
            if cache_file.exists():
                try:
                    with open(cache_file, 'r', encoding='utf-8') as f:
                        cached_data = json.load(f)
                        validated_cnpjs.append(cached_data)
                        confidence_sum += cached_data.get("validation_confidence", 0.8)
                        continue
                except Exception as e:
                    logger.warning(f"Erro ao ler cache para CNPJ {cnpj}: {str(e)}")
            
            # Validar CNPJ
            validation_result = self._validate_cnpj_format(clean_cnpj)
            
            # Tentar obter dados da API pública (se disponível)
            try:
                # API gratuita da ReceitaWS (versão limitada)
                # Nota: Em produção, seria necessário uma API com maior quota
                api_url = f"https://www.receitaws.com.br/v1/cnpj/{clean_cnpj}"
                headers = {"User-Agent": "Mozilla/5.0"}
                
                response = requests.get(api_url, headers=headers, timeout=5)
                
                if response.status_code == 200:
                    api_data = response.json()
                    
                    # Verificar se API retornou erro
                    if "erro" in api_data and api_data["erro"]:
                        validation_result["api_validation"] = False
                        validation_result["api_message"] = api_data.get("message", "CNPJ não encontrado")
                        validation_result["validation_confidence"] = 0.7  # Confiança baseada apenas na validação de formato
                    else:
                        # CNPJ encontrado na API
                        validation_result["api_validation"] = True
                        validation_result["company_name"] = api_data.get("nome", "")
                        validation_result["trading_name"] = api_data.get("fantasia", "")
                        validation_result["status"] = api_data.get("situacao", "")
                        validation_result["address"] = {
                            "street": api_data.get("logradouro", ""),
                            "number": api_data.get("numero", ""),
                            "complement": api_data.get("complemento", ""),
                            "zip": api_data.get("cep", ""),
                            "neighborhood": api_data.get("bairro", ""),
                            "city": api_data.get("municipio", ""),
                            "state": api_data.get("uf", "")
                        }
                        validation_result["validation_confidence"] = 0.98  # Alta confiança com validação de API
                else:
                    # API indisponível ou limite excedido
                    validation_result["api_validation"] = None
                    validation_result["api_message"] = f"API indisponível: {response.status_code}"
                    validation_result["validation_confidence"] = 0.7  # Confiança baseada apenas na validação de formato
            
            except Exception as e:
                logger.warning(f"Erro ao consultar API para CNPJ {cnpj}: {str(e)}")
                validation_result["api_validation"] = None
                validation_result["api_message"] = f"Erro na consulta: {str(e)}"
                validation_result["validation_confidence"] = 0.7  # Confiança baseada apenas na validação de formato
            
            # Salvar no cache
            try:
                with open(cache_file, 'w', encoding='utf-8') as f:
                    json.dump(validation_result, f, ensure_ascii=False, indent=2)
            except Exception as e:
                logger.warning(f"Erro ao salvar cache para CNPJ {cnpj}: {str(e)}")
            
            validated_cnpjs.append(validation_result)
            confidence_sum += validation_result.get("validation_confidence", 0.0)
        
        # Calcular confiança média
        avg_confidence = confidence_sum / len(cnpj_list) if cnpj_list else 0.0
        
        return validated_cnpjs, avg_confidence
    
    def _validate_cnpj_format(self, cnpj: str) -> Dict[str, Any]:
        """
        Valida o formato e dígitos verificadores de um CNPJ
        
        Args:
            cnpj: CNPJ a ser validado (apenas dígitos)
            
        Returns:
            Dicionário com resultado da validação
        """
        result = {
            "cnpj": cnpj,
            "format_validation": False,
            "checksum_validation": False,
            "validation_confidence": 0.0
        }
        
        # Verificar formato
        if not cnpj or not cnpj.isdigit() or len(cnpj) != 14:
            return result
        
        # CNPJ com todos os dígitos iguais é inválido
        if len(set(cnpj)) == 1:
            return result
        
        result["format_validation"] = True
        
        # Validar primeiro dígito verificador
        sum_of_products = 0
        weight = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        
        for i in range(12):
            sum_of_products += int(cnpj[i]) * weight[i]
        
        remainder = sum_of_products % 11
        check_digit_1 = 0 if remainder < 2 else 11 - remainder
        
        if int(cnpj[12]) != check_digit_1:
            return result
        
        # Validar segundo dígito verificador
        sum_of_products = 0
        weight = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        
        for i in range(13):
            sum_of_products += int(cnpj[i]) * weight[i]
        
        remainder = sum_of_products % 11
        check_digit_2 = 0 if remainder < 2 else 11 - remainder
        
        if int(cnpj[13]) != check_digit_2:
            return result
        
        # CNPJ válido
        result["checksum_validation"] = True
        result["validation_confidence"] = 0.7  # Confiança baseada apenas na validação de formato
        
        return result
    
    def _validate_company_name(self, company_name: str) -> Tuple[Dict[str, Any], float]:
        """
        Valida nome de empresa usando fontes externas
        
        Args:
            company_name: Nome da empresa extraído
            
        Returns:
            Tuple com dados validados e confiança
        """
        if not company_name:
            return {}, 0.0
        
        # Inicializar resultado
        validation_result = {
            "company_name": company_name,
            "normalized_name": self._normalize_company_name(company_name),
            "validation_methods": []
        }
        
        # Validação por regras de negócio
        business_rules_validation = self._validate_company_name_rules(company_name)
        validation_result["validation_methods"].append({
            "method": "business_rules",
            "result": business_rules_validation
        })
        
        # Validação por base de dados local (simulada)
        local_db_validation = self._validate_company_name_local_db(company_name)
        validation_result["validation_methods"].append({
            "method": "local_database",
            "result": local_db_validation
        })
        
        # Calcular confiança com base nos métodos de validação
        confidence_sum = 0.0
        for method in validation_result["validation_methods"]:
            confidence_sum += method["result"].get("confidence", 0.0)
        
        avg_confidence = confidence_sum / len(validation_result["validation_methods"])
        
        return validation_result, avg_confidence
    
    def _normalize_company_name(self, name: str) -> str:
        """
        Normaliza nome de empresa para comparação
        
        Args:
            name: Nome da empresa
            
        Returns:
            Nome normalizado
        """
        # Converter para minúsculas
        normalized = name.lower()
        
        # Remover acentos
        import unicodedata
        normalized = unicodedata.normalize('NFKD', normalized).encode('ASCII', 'ignore').decode('ASCII')
        
        # Remover termos comuns de razão social
        terms_to_remove = [
            "ltda", "limitada", "s/a", "s.a.", "sa", "mei", "eireli", 
            "epp", "me", "microempresa", "empresa individual", 
            "sociedade anonima", "companhia", "cia"
        ]
        
        for term in terms_to_remove:
            normalized = re.sub(r'\b' + term + r'\b', '', normalized)
        
        # Remover pontuação e caracteres especiais
        normalized = re.sub(r'[^\w\s]', '', normalized)
        
        # Remover espaços extras
        normalized = re.sub(r'\s+', ' ', normalized).strip()
        
        return normalized
    
    def _validate_company_name_rules(self, name: str) -> Dict[str, Any]:
        """
        Valida nome de empresa usando regras de negócio
        
        Args:
            name: Nome da empresa
            
        Returns:
            Resultado da validação
        """
        result = {
            "is_valid": False,
            "confidence": 0.0,
            "reasons": []
        }
        
        # Verificar comprimento mínimo
        if len(name) < 3:
            result["reasons"].append("Nome muito curto")
            return result
        
        # Verificar se contém apenas números
        if name.isdigit():
            result["reasons"].append("Nome contém apenas números")
            return result
        
        # Verificar padrões suspeitos
        suspicious_patterns = [
            r'^[a-z]$',  # Apenas uma letra
            r'^test',    # Começa com "test"
            r'^exemplo', # Começa com "exemplo"
            r'^[0-9]+$'  # Apenas números
        ]
        
        for pattern in suspicious_patterns:
            if re.search(pattern, name.lower()):
                result["reasons"].append(f"Padrão suspeito encontrado: {pattern}")
                return result
        
        # Nome parece válido
        result["is_valid"] = True
        
        # Calcular confiança com base em heurísticas
        confidence = 0.7  # Base
        
        # Nomes mais longos tendem a ser mais confiáveis
        if len(name) > 10:
            confidence += 0.1
        
        # Nomes com termos comuns de empresas são mais confiáveis
        business_terms = ["ltda", "limitada", "s/a", "s.a.", "sa", "eireli", "companhia", "cia"]
        for term in business_terms:
            if term.lower() in name.lower():
                confidence += 0.1
                break
        
        result["confidence"] = min(confidence, 0.95)  # Limitar a 0.95
        
        return result
    
    def _validate_company_name_local_db(self, name: str) -> Dict[str, Any]:
        """
        Simula validação de nome de empresa em base de dados local
        
        Args:
            name: Nome da empresa
            
        Returns:
            Resultado da validação
        """
        # Normalizar nome para comparação
        normalized_name = self._normalize_company_name(name)
        
        # Simular base de dados local
        # Em produção, isso seria uma consulta a um banco de dados real
        local_db = {
            "censi": {
                "full_name": "Censi Indústria de Materiais Metálicos Ltda",
                "trading_name": "Censi Metalúrgica",
                "cnpj": "02.308.456/0001-49",
                "confidence": 0.95
            },
            "petrobras": {
                "full_name": "Petróleo Brasileiro S.A.",
                "trading_name": "Petrobras",
                "cnpj": "33.000.167/0001-01",
                "confidence": 0.98
            },
            "vale": {
                "full_name": "Vale S.A.",
                "trading_name": "Vale",
                "cnpj": "33.592.510/0001-54",
                "confidence": 0.98
            }
        }
        
        result = {
            "found_in_db": False,
            "confidence": 0.0,
            "match_details": {}
        }
        
        # Verificar correspondências exatas ou parciais
        best_match = None
        best_score = 0.0
        
        for key, company_data in local_db.items():
            # Normalizar nomes da base
            db_full_normalized = self._normalize_company_name(company_data["full_name"])
            db_trading_normalized = self._normalize_company_name(company_data["trading_name"])
            
            # Calcular similaridade
            from difflib import SequenceMatcher
            
            full_name_score = SequenceMatcher(None, normalized_name, db_full_normalized).ratio()
            trading_name_score = SequenceMatcher(None, normalized_name, db_trading_normalized).ratio()
            
            # Usar o melhor score
            score = max(full_name_score, trading_name_score)
            
            if score > best_score:
                best_score = score
                best_match = company_data
        
        # Definir limiar de correspondência
        if best_score >= 0.8:
            result["found_in_db"] = True
            result["confidence"] = best_score * best_match["confidence"]
            result["match_details"] = best_match
        elif best_score >= 0.6:
            # Correspondência parcial
            result["found_in_db"] = "partial"
            result["confidence"] = best_score * 0.7  # Reduzir confiança para correspondências parciais
            result["match_details"] = best_match
        else:
            result["confidence"] = 0.5  # Confiança base para nomes não encontrados
        
        return result
    
    def _validate_address(self, address: str) -> Tuple[Dict[str, Any], float]:
        """
        Valida endereço usando serviços de geolocalização
        
        Args:
            address: Endereço extraído
            
        Returns:
            Tuple com dados validados e confiança
        """
        if not address:
            return {}, 0.0
        
        # Inicializar resultado
        validation_result = {
            "address": address,
            "normalized_address": self._normalize_address(address),
            "validation_methods": []
        }
        
        # Validação por regras de negócio
        business_rules_validation = self._validate_address_rules(address)
        validation_result["validation_methods"].append({
            "method": "business_rules",
            "result": business_rules_validation
        })
        
        # Validação por CEP (se disponível)
        cep_validation = self._validate_address_cep(address)
        if cep_validation:
            validation_result["validation_methods"].append({
                "method": "cep_validation",
                "result": cep_validation
            })
        
        # Calcular confiança com base nos métodos de validação
        confidence_sum = 0.0
        for method in validation_result["validation_methods"]:
            confidence_sum += method["result"].get("confidence", 0.0)
        
        avg_confidence = confidence_sum / len(validation_result["validation_methods"])
        
        return validation_result, avg_confidence
    
    def _normalize_address(self, address: str) -> str:
        """
        Normaliza endereço para comparação
        
        Args:
            address: Endereço
            
        Returns:
            Endereço normalizado
        """
        # Converter para minúsculas
        normalized = address.lower()
        
        # Remover acentos
        import unicodedata
        normalized = unicodedata.normalize('NFKD', normalized).encode('ASCII', 'ignore').decode('ASCII')
        
        # Padronizar abreviações comuns
        replacements = {
            "r.": "rua",
            "av.": "avenida",
            "av": "avenida",
            "al.": "alameda",
            "al": "alameda",
            "pc.": "praca",
            "pc": "praca",
            "rod.": "rodovia",
            "rod": "rodovia",
            "n.": "numero",
            "no.": "numero",
            "no": "numero",
            "apto.": "apartamento",
            "apto": "apartamento",
            "cj.": "conjunto",
            "cj": "conjunto",
            "andar.": "andar",
            "and.": "andar",
            "and": "andar"
        }
        
        for old, new in replacements.items():
            normalized = re.sub(r'\b' + old + r'\b', new, normalized)
        
        # Remover pontuação e caracteres especiais
        normalized = re.sub(r'[^\w\s]', '', normalized)
        
        # Remover espaços extras
        normalized = re.sub(r'\s+', ' ', normalized).strip()
        
        return normalized
    
    def _validate_address_rules(self, address: str) -> Dict[str, Any]:
        """
        Valida endereço usando regras de negócio
        
        Args:
            address: Endereço
            
        Returns:
            Resultado da validação
        """
        result = {
            "is_valid": False,
            "confidence": 0.0,
            "reasons": []
        }
        
        # Verificar comprimento mínimo
        if len(address) < 5:
            result["reasons"].append("Endereço muito curto")
            return result
        
        # Verificar se contém apenas números
        if address.isdigit():
            result["reasons"].append("Endereço contém apenas números")
            return result
        
        # Verificar presença de elementos de endereço
        address_elements = [
            r'\b(rua|r\.|avenida|av\.|alameda|al\.|praça|pc\.|rodovia|rod\.)\b',  # Logradouro
            r'\b\d+\b',  # Número
            r'\b(sala|conjunto|cj|apto|apartamento|andar|and)\b',  # Complemento
            r'\b\d{5}[-\s]?\d{3}\b'  # CEP
        ]
        
        elements_found = 0
        for pattern in address_elements:
            if re.search(pattern, address, re.IGNORECASE):
                elements_found += 1
        
        # Endereço deve conter pelo menos 2 elementos
        if elements_found < 2:
            result["reasons"].append(f"Poucos elementos de endereço encontrados: {elements_found}")
            return result
        
        # Endereço parece válido
        result["is_valid"] = True
        
        # Calcular confiança com base em heurísticas
        confidence = 0.6  # Base
        
        # Mais elementos encontrados = maior confiança
        confidence += 0.1 * elements_found
        
        result["confidence"] = min(confidence, 0.95)  # Limitar a 0.95
        
        return result
    
    def _validate_address_cep(self, address: str) -> Optional[Dict[str, Any]]:
        """
        Valida endereço usando serviço de CEP
        
        Args:
            address: Endereço
            
        Returns:
            Resultado da validação ou None se CEP não encontrado
        """
        # Extrair CEP do endereço
        cep_match = re.search(r'\b(\d{5})[-\s]?(\d{3})\b', address)
        if not cep_match:
            return None
        
        cep = cep_match.group(1) + cep_match.group(2)
        
        # Verificar se CEP está no cache
        cache_file = self.cache_dir / f"cep_{cep}.json"
        if cache_file.exists():
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Erro ao ler cache para CEP {cep}: {str(e)}")
        
        # Inicializar resultado
        result = {
            "cep": cep,
            "is_valid": False,
            "confidence": 0.0,
            "details": {}
        }
        
        try:
            # Consultar API gratuita de CEP
            api_url = f"https://viacep.com.br/ws/{cep}/json/"
            response = requests.get(api_url, timeout=5)
            
            if response.status_code == 200:
                api_data = response.json()
                
                # Verificar se API retornou erro
                if "erro" in api_data and api_data["erro"]:
                    result["is_valid"] = False
                    result["confidence"] = 0.3
                else:
                    # CEP encontrado na API
                    result["is_valid"] = True
                    result["details"] = {
                        "street": api_data.get("logradouro", ""),
                        "neighborhood": api_data.get("bairro", ""),
                        "city": api_data.get("localidade", ""),
                        "state": api_data.get("uf", "")
                    }
                    
                    # Verificar correspondência com endereço original
                    normalized_address = self._normalize_address(address)
                    elements_found = 0
                    
                    for key, value in result["details"].items():
                        if value and value.lower() in normalized_address:
                            elements_found += 1
                    
                    # Calcular confiança com base na correspondência
                    if elements_found >= 2:
                        result["confidence"] = 0.9  # Alta confiança
                    elif elements_found == 1:
                        result["confidence"] = 0.7  # Média confiança
                    else:
                        result["confidence"] = 0.5  # Baixa confiança
            else:
                # API indisponível
                result["is_valid"] = False
                result["confidence"] = 0.3
        
        except Exception as e:
            logger.warning(f"Erro ao consultar API para CEP {cep}: {str(e)}")
            result["is_valid"] = False
            result["confidence"] = 0.3
        
        # Salvar no cache
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.warning(f"Erro ao salvar cache para CEP {cep}: {str(e)}")
        
        return result
    
    def _validate_monetary_values(self, values: List[str]) -> Tuple[List[Dict[str, Any]], float]:
        """
        Valida valores monetários
        
        Args:
            values: Lista de valores monetários extraídos
            
        Returns:
            Tuple com lista de valores validados e confiança média
        """
        validated_values = []
        confidence_sum = 0.0
        
        for value in values:
            # Inicializar resultado
            validation_result = {
                "original_value": value,
                "normalized_value": None,
                "is_valid": False,
                "confidence": 0.0
            }
            
            # Normalizar valor
            normalized = self._normalize_monetary_value(value)
            validation_result["normalized_value"] = normalized
            
            if normalized is not None:
                validation_result["is_valid"] = True
                validation_result["confidence"] = 0.9  # Alta confiança para valores bem formatados
            else:
                validation_result["confidence"] = 0.3  # Baixa confiança para valores mal formatados
            
            validated_values.append(validation_result)
            confidence_sum += validation_result["confidence"]
        
        # Calcular confiança média
        avg_confidence = confidence_sum / len(values) if values else 0.0
        
        return validated_values, avg_confidence
    
    def _normalize_monetary_value(self, value: str) -> Optional[float]:
        """
        Normaliza valor monetário para formato numérico
        
        Args:
            value: Valor monetário como string
            
        Returns:
            Valor como float ou None se inválido
        """
        try:
            # Remover prefixo de moeda
            clean_value = re.sub(r'^R\$\s*', '', value)
            
            # Remover pontos de milhar
            clean_value = clean_value.replace('.', '')
            
            # Substituir vírgula por ponto decimal
            clean_value = clean_value.replace(',', '.')
            
            # Converter para float
            return float(clean_value)
        except:
            return None
    
    def _validate_dates(self, dates: List[str]) -> Tuple[List[Dict[str, Any]], float]:
        """
        Valida datas
        
        Args:
            dates: Lista de datas extraídas
            
        Returns:
            Tuple com lista de datas validadas e confiança média
        """
        validated_dates = []
        confidence_sum = 0.0
        
        for date in dates:
            # Inicializar resultado
            validation_result = {
                "original_date": date,
                "normalized_date": None,
                "is_valid": False,
                "confidence": 0.0
            }
            
            # Normalizar data
            normalized = self._normalize_date(date)
            validation_result["normalized_date"] = normalized
            
            if normalized:
                validation_result["is_valid"] = True
                
                # Verificar se data está no futuro
                import datetime
                today = datetime.date.today()
                
                if normalized > today:
                    # Datas futuras são menos confiáveis em documentos financeiros
                    validation_result["confidence"] = 0.7
                    validation_result["warning"] = "Data no futuro"
                else:
                    validation_result["confidence"] = 0.95  # Alta confiança para datas bem formatadas
            else:
                validation_result["confidence"] = 0.3  # Baixa confiança para datas mal formatadas
            
            validated_dates.append(validation_result)
            confidence_sum += validation_result["confidence"]
        
        # Calcular confiança média
        avg_confidence = confidence_sum / len(dates) if dates else 0.0
        
        return validated_dates, avg_confidence
    
    def _normalize_date(self, date: str) -> Optional[object]:
        """
        Normaliza data para formato padrão
        
        Args:
            date: Data como string
            
        Returns:
            Objeto date ou None se inválido
        """
        import datetime
        
        # Padrões de data comuns no Brasil
        patterns = [
            # DD/MM/YYYY
            (r'(\d{2})/(\d{2})/(\d{4})', lambda m: datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))),
            # DD.MM.YYYY
            (r'(\d{2})\.(\d{2})\.(\d{4})', lambda m: datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))),
            # DD-MM-YYYY
            (r'(\d{2})-(\d{2})-(\d{4})', lambda m: datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))),
            # YYYY-MM-DD
            (r'(\d{4})-(\d{2})-(\d{2})', lambda m: datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3))))
        ]
        
        for pattern, date_constructor in patterns:
            match = re.match(pattern, date)
            if match:
                try:
                    return date_constructor(match)
                except ValueError:
                    # Data inválida (ex: 31/02/2023)
                    continue
        
        return None

# Função principal para validação cruzada de dados
def validate_extracted_data(extracted_data: Dict[str, Any], cache_dir: Optional[str] = None) -> Dict[str, Any]:
    """
    Função principal para validação cruzada de dados extraídos
    
    Args:
        extracted_data: Dados extraídos do documento
        cache_dir: Diretório para cache de resultados (opcional)
        
    Returns:
        Dicionário com resultados da validação
    """
    try:
        # Inicializar sistema de validação
        validator = CrossValidationSystem(cache_dir=cache_dir)
        
        # Validar dados
        validation_result = validator.validate_data(extracted_data)
        
        return validation_result
    except Exception as e:
        logger.error(f"Erro ao validar dados: {str(e)}")
        return {"error": str(e)}

# Função para instalação de dependências em ambiente Windows
def install_dependencies_windows():
    """
    Instala dependências necessárias em ambiente Windows
    
    Returns:
        True se sucesso, False caso contrário
    """
    try:
        import subprocess
        import sys
        
        # Verificar se pip está disponível
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "--version"])
        except:
            logger.error("Pip não está disponível. Por favor, instale o pip primeiro.")
            return False
        
        # Instalar dependências
        dependencies = [
            "requests",
            "python-dateutil"
        ]
        
        for dep in dependencies:
            logger.info(f"Instalando {dep}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", dep])
        
        logger.info("Todas as dependências Python foram instaladas com sucesso!")
        return True
    except Exception as e:
        logger.error(f"Erro ao instalar dependências: {str(e)}")
        return False

if __name__ == "__main__":
    # Exemplo de uso
    if len(sys.argv) > 1:
        import json
        
        input_file = sys.argv[1]
        
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                extracted_data = json.load(f)
            
            validation_result = validate_extracted_data(extracted_data)
            
            print(json.dumps(validation_result, ensure_ascii=False, indent=2))
        except Exception as e:
            print(f"Erro: {str(e)}")
    else:
        print("Uso: python cross_validation.py caminho/para/dados_extraidos.json")
