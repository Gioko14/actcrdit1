import os
import sys
import logging
import torch
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Union

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("ia_extractor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("ia_extractor")

# Verificar disponibilidade de GPU
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
logger.info(f"Usando dispositivo: {device}")

# Diretório para modelos
MODELS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
os.makedirs(MODELS_DIR, exist_ok=True)

class IAExtractor:
    """
    Classe principal para extração de dados usando modelos de IA especializados
    Implementa arquitetura híbrida PaddleOCR + LayoutLMv3 + BERTimbau
    """
    
    def __init__(self, use_gpu: bool = False, lang: str = 'por'):
        """
        Inicializa o extrator de IA
        
        Args:
            use_gpu: Se True, usa GPU para aceleração (se disponível)
            lang: Idioma para OCR (padrão: português)
        """
        self.use_gpu = use_gpu and torch.cuda.is_available()
        self.lang = lang
        self.models = {}
        self._paddle_ocr = None
        self._layout_model = None
        self._nlp_model = None
        
        # Verificar dependências
        self._check_dependencies()
    
    def _check_dependencies(self):
        """Verifica se todas as dependências necessárias estão instaladas"""
        try:
            # Verificar PaddleOCR
            import importlib.util
            paddle_available = importlib.util.find_spec("paddleocr") is not None
            if paddle_available:
                logger.info("PaddleOCR disponível (será carregado sob demanda)")
            else:
                logger.warning("PaddleOCR não está disponível, será necessário instalar")
            
            # Verificar Transformers (para LayoutLMv3 e BERTimbau)
            transformers_available = importlib.util.find_spec("transformers") is not None
            if transformers_available:
                logger.info("Hugging Face Transformers disponível")
            else:
                logger.warning("Hugging Face Transformers não está disponível, será necessário instalar")
            
            # Verificar PyTorch
            torch_available = importlib.util.find_spec("torch") is not None
            if torch_available:
                logger.info(f"PyTorch disponível: {torch.__version__}")
            else:
                logger.warning("PyTorch não está disponível, será necessário instalar")
            
        except Exception as e:
            logger.error(f"Erro ao verificar dependências: {str(e)}")
    
    @property
    def paddle_ocr(self):
        """Carrega PaddleOCR sob demanda para economizar memória"""
        if self._paddle_ocr is None:
            try:
                from paddleocr import PaddleOCR
                # Usar versão mais precisa do modelo para português
                self._paddle_ocr = PaddleOCR(use_angle_cls=True, lang="pt", use_gpu=self.use_gpu)
                logger.info("PaddleOCR inicializado com sucesso")
            except Exception as e:
                logger.error(f"Erro ao inicializar PaddleOCR: {str(e)}")
                self._paddle_ocr = None
        return self._paddle_ocr
    
    @property
    def layout_model(self):
        """Carrega LayoutLMv3 sob demanda"""
        if self._layout_model is None:
            try:
                from transformers import LayoutLMv3ForSequenceClassification, LayoutLMv3Processor
                
                # Verificar se o modelo já está baixado
                model_path = os.path.join(MODELS_DIR, "layoutlmv3-base")
                if os.path.exists(model_path):
                    # Carregar modelo local
                    self._layout_model = {
                        "model": LayoutLMv3ForSequenceClassification.from_pretrained(model_path),
                        "processor": LayoutLMv3Processor.from_pretrained(model_path)
                    }
                else:
                    # Baixar e salvar modelo
                    logger.info("Baixando modelo LayoutLMv3 (isso pode levar alguns minutos)...")
                    model = LayoutLMv3ForSequenceClassification.from_pretrained("microsoft/layoutlmv3-base")
                    processor = LayoutLMv3Processor.from_pretrained("microsoft/layoutlmv3-base")
                    
                    # Salvar modelo localmente
                    model.save_pretrained(model_path)
                    processor.save_pretrained(model_path)
                    
                    self._layout_model = {
                        "model": model,
                        "processor": processor
                    }
                
                # Mover para GPU se disponível
                if self.use_gpu:
                    self._layout_model["model"] = self._layout_model["model"].to(device)
                
                logger.info("LayoutLMv3 inicializado com sucesso")
            except Exception as e:
                logger.error(f"Erro ao inicializar LayoutLMv3: {str(e)}")
                self._layout_model = None
        return self._layout_model
    
    @property
    def nlp_model(self):
        """Carrega BERTimbau sob demanda"""
        if self._nlp_model is None:
            try:
                from transformers import AutoModelForTokenClassification, AutoTokenizer
                
                # Verificar se o modelo já está baixado
                model_path = os.path.join(MODELS_DIR, "bertimbau-base")
                if os.path.exists(model_path):
                    # Carregar modelo local
                    self._nlp_model = {
                        "model": AutoModelForTokenClassification.from_pretrained(model_path),
                        "tokenizer": AutoTokenizer.from_pretrained(model_path)
                    }
                else:
                    # Baixar e salvar modelo
                    logger.info("Baixando modelo BERTimbau (isso pode levar alguns minutos)...")
                    model = AutoModelForTokenClassification.from_pretrained("neuralmind/bert-base-portuguese-cased")
                    tokenizer = AutoTokenizer.from_pretrained("neuralmind/bert-base-portuguese-cased")
                    
                    # Salvar modelo localmente
                    model.save_pretrained(model_path)
                    tokenizer.save_pretrained(model_path)
                    
                    self._nlp_model = {
                        "model": model,
                        "tokenizer": tokenizer
                    }
                
                # Mover para GPU se disponível
                if self.use_gpu:
                    self._nlp_model["model"] = self._nlp_model["model"].to(device)
                
                logger.info("BERTimbau inicializado com sucesso")
            except Exception as e:
                logger.error(f"Erro ao inicializar BERTimbau: {str(e)}")
                self._nlp_model = None
        return self._nlp_model
    
    def extract_text_with_paddleocr(self, image: np.ndarray) -> Tuple[str, List[Dict], float]:
        """
        Extrai texto de uma imagem usando PaddleOCR otimizado
        
        Args:
            image: Imagem em formato numpy array
            
        Returns:
            Tuple contendo o texto extraído, os dados detalhados e a confiança média
        """
        if self.paddle_ocr is None:
            logger.warning("PaddleOCR não está disponível")
            return "", [], 0.0
        
        try:
            # Executar OCR na imagem
            result = self.paddle_ocr.ocr(image, cls=True)
            
            if not result or not result[0]:
                return "", [], 0.0
            
            # Extrair texto e dados detalhados
            text_lines = []
            detailed_data = []
            confidence_sum = 0.0
            confidence_count = 0
            
            for line in result[0]:
                if len(line) >= 2:
                    text = line[1][0]  # Texto reconhecido
                    confidence = line[1][1]  # Confiança
                    box = line[0]  # Coordenadas da caixa
                    
                    text_lines.append(text)
                    detailed_data.append({
                        "text": text,
                        "confidence": float(confidence),
                        "box": box
                    })
                    
                    confidence_sum += float(confidence)
                    confidence_count += 1
            
            # Juntar linhas de texto
            full_text = "\n".join(text_lines)
            
            # Calcular confiança média
            avg_confidence = confidence_sum / confidence_count if confidence_count > 0 else 0.0
            
            return full_text, detailed_data, avg_confidence
        except Exception as e:
            logger.error(f"Erro ao extrair texto com PaddleOCR: {str(e)}")
            return "", [], 0.0
    
    def analyze_layout(self, image: np.ndarray, ocr_results: List[Dict]) -> Dict[str, Any]:
        """
        Analisa o layout do documento usando LayoutLMv3
        
        Args:
            image: Imagem em formato numpy array
            ocr_results: Resultados do OCR com coordenadas
            
        Returns:
            Dicionário com análise de layout (regiões, tipos de conteúdo)
        """
        if self.layout_model is None:
            logger.warning("LayoutLMv3 não está disponível")
            return {}
        
        try:
            # Preparar dados para o modelo
            words = [item["text"] for item in ocr_results]
            boxes = [item["box"] for item in ocr_results]
            
            # Normalizar caixas para o formato esperado pelo LayoutLMv3
            normalized_boxes = []
            for box in boxes:
                x_min, y_min = min(point[0] for point in box), min(point[1] for point in box)
                x_max, y_max = max(point[0] for point in box), max(point[1] for point in box)
                normalized_boxes.append([x_min, y_min, x_max, y_max])
            
            # Processar imagem e texto
            processor = self.layout_model["processor"]
            model = self.layout_model["model"]
            
            encoding = processor(
                image, 
                words,
                boxes=normalized_boxes,
                return_tensors="pt",
                truncation=True,
                padding="max_length"
            )
            
            # Mover para GPU se disponível
            if self.use_gpu:
                encoding = {k: v.to(device) for k, v in encoding.items()}
            
            # Executar inferência
            with torch.no_grad():
                outputs = model(**encoding)
            
            # Processar resultados
            # Nota: Aqui precisaríamos de um modelo fine-tuned para classificação de regiões
            # Por enquanto, retornamos uma análise básica
            
            # Identificar regiões por posição
            regions = self._identify_regions_by_position(ocr_results)
            
            return {
                "regions": regions,
                "document_type": self._identify_document_type(words),
                "confidence": float(torch.softmax(outputs.logits, dim=1).max().item())
            }
        except Exception as e:
            logger.error(f"Erro ao analisar layout: {str(e)}")
            return {}
    
    def _identify_regions_by_position(self, ocr_results: List[Dict]) -> Dict[str, List[Dict]]:
        """
        Identifica regiões do documento com base na posição dos textos
        
        Args:
            ocr_results: Resultados do OCR com coordenadas
            
        Returns:
            Dicionário com regiões identificadas
        """
        # Implementação simplificada - em produção usaríamos o modelo treinado
        regions = {
            "header": [],
            "body": [],
            "footer": [],
            "table": []
        }
        
        # Obter dimensões da imagem a partir das coordenadas
        all_points = [point for item in ocr_results for point in item["box"]]
        if not all_points:
            return regions
            
        max_y = max(point[1] for point in all_points)
        
        # Classificar por posição vertical
        for item in ocr_results:
            box = item["box"]
            y_center = sum(point[1] for point in box) / len(box)
            
            # Classificação simples por posição vertical
            if y_center < max_y * 0.2:
                regions["header"].append(item)
            elif y_center > max_y * 0.8:
                regions["footer"].append(item)
            else:
                regions["body"].append(item)
                
                # Detectar possíveis tabelas (textos alinhados horizontalmente)
                # Esta é uma heurística simples, o modelo treinado seria mais preciso
                if self._is_likely_table_row(item, ocr_results):
                    regions["table"].append(item)
        
        return regions
    
    def _is_likely_table_row(self, item: Dict, all_items: List[Dict]) -> bool:
        """
        Verifica se um item de texto provavelmente faz parte de uma tabela
        
        Args:
            item: Item de texto a verificar
            all_items: Todos os itens de texto
            
        Returns:
            True se provavelmente é parte de tabela
        """
        # Implementação simplificada - detecta alinhamentos horizontais
        box = item["box"]
        y_center = sum(point[1] for point in box) / len(box)
        
        # Contar itens alinhados horizontalmente
        aligned_items = 0
        for other in all_items:
            if other == item:
                continue
                
            other_box = other["box"]
            other_y_center = sum(point[1] for point in other_box) / len(other_box)
            
            # Se estão aproximadamente na mesma linha
            if abs(y_center - other_y_center) < 20:  # Tolerância de 20 pixels
                aligned_items += 1
        
        # Se há vários itens alinhados, provavelmente é uma tabela
        return aligned_items >= 3
    
    def _identify_document_type(self, words: List[str]) -> str:
        """
        Identifica o tipo de documento com base nas palavras-chave
        
        Args:
            words: Lista de palavras extraídas do documento
            
        Returns:
            Tipo de documento identificado
        """
        # Converter para minúsculas e juntar para busca
        text = " ".join(words).lower()
        
        # Palavras-chave para diferentes tipos de documentos
        keywords = {
            "nota_fiscal": ["nota fiscal", "nfe", "danfe", "cnpj", "icms", "cfop"],
            "extrato_bancario": ["extrato", "saldo", "banco", "agência", "conta", "débito", "crédito"],
            "balanco_patrimonial": ["balanço", "patrimonial", "ativo", "passivo", "patrimônio líquido"],
            "dre": ["demonstração", "resultado", "exercício", "receita", "despesa", "lucro"],
            "contrato": ["contrato", "partes", "cláusula", "vigência", "rescisão"]
        }
        
        # Contar ocorrências de palavras-chave
        scores = {doc_type: 0 for doc_type in keywords}
        for doc_type, key_list in keywords.items():
            for key in key_list:
                if key in text:
                    scores[doc_type] += 1
        
        # Retornar o tipo com maior pontuação
        if max(scores.values()) > 0:
            return max(scores.items(), key=lambda x: x[1])[0]
        else:
            return "desconhecido"
    
    def extract_entities_with_nlp(self, text: str) -> Dict[str, Any]:
        """
        Extrai entidades financeiras usando BERTimbau
        
        Args:
            text: Texto extraído do documento
            
        Returns:
            Dicionário com entidades extraídas
        """
        if self.nlp_model is None:
            logger.warning("BERTimbau não está disponível")
            return {}
        
        try:
            # Extrair entidades usando expressões regulares e NLP
            entities = {
                "cnpj": self._extract_cnpj(text),
                "valores": self._extract_monetary_values(text),
                "datas": self._extract_dates(text),
                "empresa": self._extract_company_name(text)
            }
            
            # Usar BERTimbau para melhorar a extração de entidades
            # Nota: Idealmente, usaríamos um modelo fine-tuned para NER financeiro
            # Esta é uma implementação simplificada
            
            tokenizer = self.nlp_model["tokenizer"]
            model = self.nlp_model["model"]
            
            # Dividir texto em chunks para processamento
            chunks = self._split_text_into_chunks(text, max_length=512)
            
            all_entities = []
            for chunk in chunks:
                inputs = tokenizer(chunk, return_tensors="pt", truncation=True, padding=True)
                
                # Mover para GPU se disponível
                if self.use_gpu:
                    inputs = {k: v.to(device) for k, v in inputs.items()}
                
                # Executar inferência
                with torch.no_grad():
                    outputs = model(**inputs)
                
                # Processar resultados
                # Nota: Aqui precisaríamos de um modelo fine-tuned para NER financeiro
                # Por enquanto, usamos apenas as entidades extraídas por regex
            
            return entities
        except Exception as e:
            logger.error(f"Erro ao extrair entidades: {str(e)}")
            return {}
    
    def _split_text_into_chunks(self, text: str, max_length: int = 512) -> List[str]:
        """
        Divide texto em chunks para processamento
        
        Args:
            text: Texto a dividir
            max_length: Tamanho máximo de cada chunk
            
        Returns:
            Lista de chunks de texto
        """
        words = text.split()
        chunks = []
        current_chunk = []
        current_length = 0
        
        for word in words:
            # +1 para o espaço
            word_length = len(word) + 1
            
            if current_length + word_length > max_length:
                chunks.append(" ".join(current_chunk))
                current_chunk = [word]
                current_length = word_length
            else:
                current_chunk.append(word)
                current_length += word_length
        
        if current_chunk:
            chunks.append(" ".join(current_chunk))
        
        return chunks
    
    def _extract_cnpj(self, text: str) -> List[str]:
        """Extrai CNPJs do texto"""
        import re
        pattern = r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}'
        return re.findall(pattern, text)
    
    def _extract_monetary_values(self, text: str) -> List[str]:
        """Extrai valores monetários do texto"""
        import re
        pattern = r'R\$\s*[\d\.,]+|\d+[\.,]\d{3}[\.,]\d{2}'
        return re.findall(pattern, text)
    
    def _extract_dates(self, text: str) -> List[str]:
        """Extrai datas do texto"""
        import re
        pattern = r'\d{2}/\d{2}/\d{4}|\d{2}\.\d{2}\.\d{4}|\d{2}-\d{2}-\d{4}'
        return re.findall(pattern, text)
    
    def _extract_company_name(self, text: str) -> str:
        """Extrai nome da empresa do texto"""
        # Implementação simplificada - busca nome próximo ao CNPJ
        import re
        
        # Procurar CNPJ
        cnpj_match = re.search(r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}', text)
        if not cnpj_match:
            return ""
        
        # Pegar contexto ao redor do CNPJ
        cnpj_pos = cnpj_match.start()
        start_pos = max(0, cnpj_pos - 200)
        end_pos = min(len(text), cnpj_pos + 200)
        context = text[start_pos:end_pos]
        
        # Dividir em linhas
        lines = context.split('\n')
        
        # Procurar linha com possível nome de empresa
        for i, line in enumerate(lines):
            if cnpj_match.group() in line:
                # Verificar linhas anteriores
                for j in range(i-1, max(0, i-5), -1):
                    candidate = lines[j].strip()
                    # Heurística simples: linha não vazia, sem números, com mais de 5 caracteres
                    if candidate and len(candidate) > 5 and not re.search(r'\d', candidate):
                        return candidate
        
        return ""
    
    def process_document_image(self, image: np.ndarray) -> Dict[str, Any]:
        """
        Processa imagem de documento usando pipeline completo
        
        Args:
            image: Imagem em formato numpy array
            
        Returns:
            Dicionário com resultados da análise
        """
        try:
            # Extrair texto com PaddleOCR
            text, ocr_details, ocr_confidence = self.extract_text_with_paddleocr(image)
            
            # Analisar layout
            layout_analysis = self.analyze_layout(image, ocr_details)
            
            # Extrair entidades
            entities = self.extract_entities_with_nlp(text)
            
            # Calcular confiança geral
            layout_confidence = layout_analysis.get("confidence", 0.0)
            overall_confidence = (ocr_confidence + layout_confidence) / 2
            
            # Resultado final
            result = {
                "text": text,
                "layout": layout_analysis,
                "entities": entities,
                "confidence": {
                    "ocr": ocr_confidence,
                    "layout": layout_confidence,
                    "overall": overall_confidence
                },
                "document_type": layout_analysis.get("document_type", "desconhecido")
            }
            
            return result
        except Exception as e:
            logger.error(f"Erro ao processar documento: {str(e)}")
            return {"error": str(e)}
    
    def process_pdf(self, pdf_path: str) -> Dict[str, Any]:
        """
        Processa arquivo PDF usando pipeline completo
        
        Args:
            pdf_path: Caminho para o arquivo PDF
            
        Returns:
            Dicionário com resultados da análise
        """
        try:
            # Converter PDF para imagens
            from pdf2image import convert_from_path
            images = convert_from_path(pdf_path)
            
            # Processar cada página
            results = []
            for i, image in enumerate(images):
                # Converter PIL Image para numpy array
                image_np = np.array(image)
                
                # Processar imagem
                page_result = self.process_document_image(image_np)
                page_result["page_num"] = i + 1
                
                results.append(page_result)
            
            # Consolidar resultados
            consolidated = self._consolidate_results(results)
            
            return {
                "pages": results,
                "consolidated": consolidated
            }
        except Exception as e:
            logger.error(f"Erro ao processar PDF: {str(e)}")
            return {"error": str(e)}
    
    def _consolidate_results(self, page_results: List[Dict]) -> Dict[str, Any]:
        """
        Consolida resultados de múltiplas páginas
        
        Args:
            page_results: Lista de resultados por página
            
        Returns:
            Dicionário com resultados consolidados
        """
        # Inicializar resultado consolidado
        consolidated = {
            "document_type": "",
            "entities": {
                "cnpj": [],
                "valores": [],
                "datas": [],
                "empresa": ""
            },
            "confidence": 0.0
        }
        
        # Consolidar tipo de documento (usar o mais frequente)
        doc_types = {}
        for page in page_results:
            doc_type = page.get("document_type", "desconhecido")
            doc_types[doc_type] = doc_types.get(doc_type, 0) + 1
        
        if doc_types:
            consolidated["document_type"] = max(doc_types.items(), key=lambda x: x[1])[0]
        
        # Consolidar entidades
        all_cnpjs = []
        all_valores = []
        all_datas = []
        company_names = []
        
        for page in page_results:
            entities = page.get("entities", {})
            
            all_cnpjs.extend(entities.get("cnpj", []))
            all_valores.extend(entities.get("valores", []))
            all_datas.extend(entities.get("datas", []))
            
            if entities.get("empresa"):
                company_names.append(entities.get("empresa"))
        
        # Remover duplicatas
        consolidated["entities"]["cnpj"] = list(set(all_cnpjs))
        consolidated["entities"]["valores"] = list(set(all_valores))
        consolidated["entities"]["datas"] = list(set(all_datas))
        
        # Usar o nome de empresa mais frequente
        if company_names:
            from collections import Counter
            most_common = Counter(company_names).most_common(1)
            if most_common:
                consolidated["entities"]["empresa"] = most_common[0][0]
        
        # Calcular confiança média
        confidences = [page.get("confidence", {}).get("overall", 0.0) for page in page_results]
        if confidences:
            consolidated["confidence"] = sum(confidences) / len(confidences)
        
        return consolidated

# Função principal para extração avançada de dados de PDF
def extract_pdf_data_advanced(pdf_path: str, use_gpu: bool = False) -> Dict[str, Any]:
    """
    Função principal para extrair dados de um PDF usando modelos avançados de IA
    
    Args:
        pdf_path: Caminho para o arquivo PDF
        use_gpu: Se True, usa GPU para aceleração (se disponível)
        
    Returns:
        Dicionário com dados extraídos
    """
    try:
        # Inicializar extrator
        extractor = IAExtractor(use_gpu=use_gpu)
        
        # Processar PDF
        result = extractor.process_pdf(pdf_path)
        
        # Adicionar metadados
        import time
        result["extraction_timestamp"] = time.strftime("%Y-%m-%d %H:%M:%S")
        
        return result
    except Exception as e:
        logger.error(f"Erro ao extrair dados do PDF: {str(e)}")
        return {"error": str(e)}

# Função para instalação de dependências em ambiente Windows
def install_dependencies_windows():
    """
    Instala dependências necessárias em ambiente Windows
    
    Returns:
        True se sucesso, False caso contrário
    """
    try:
        import subprocess
        import sys
        
        # Verificar se pip está disponível
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "--version"])
        except:
            logger.error("Pip não está disponível. Por favor, instale o pip primeiro.")
            return False
        
        # Instalar dependências
        dependencies = [
            "torch torchvision torchaudio",
            "transformers",
            "pdf2image",
            "paddlepaddle",
            "paddleocr",
            "numpy",
            "pillow",
            "opencv-python"
        ]
        
        for dep in dependencies:
            logger.info(f"Instalando {dep}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", dep])
        
        # Verificar instalação do Tesseract (necessário para fallback)
        try:
            import pytesseract
            pytesseract.get_tesseract_version()
            logger.info("Tesseract já está instalado")
        except:
            logger.warning("Tesseract não encontrado. Por favor, instale o Tesseract OCR manualmente.")
            logger.warning("Download: https://github.com/UB-Mannheim/tesseract/wiki")
        
        # Verificar instalação do Poppler (necessário para pdf2image)
        try:
            from pdf2image import convert_from_path
            logger.info("Poppler já está configurado")
        except:
            logger.warning("Poppler não encontrado. Por favor, instale o Poppler manualmente.")
            logger.warning("Download: https://github.com/oschwartz10612/poppler-windows/releases/")
        
        logger.info("Todas as dependências Python foram instaladas com sucesso!")
        return True
    except Exception as e:
        logger.error(f"Erro ao instalar dependências: {str(e)}")
        return False

if __name__ == "__main__":
    # Exemplo de uso
    if len(sys.argv) > 1:
        pdf_path = sys.argv[1]
        result = extract_pdf_data_advanced(pdf_path)
        print(result)
    else:
        print("Uso: python ia_extractor.py caminho/para/arquivo.pdf")
