/**
 * Serviço de LGPD (Lei Geral de Proteção de Dados) e Segurança
 * Implementação com SQLite para substituir simulações por dados reais
 */

import { v4 as uuidv4 } from 'uuid';
import ApiClient from '../../utils/ApiClient';
import logger from '../../utils/Logger';

/**
 * Classe para gerenciamento de conformidade com LGPD e segurança de dados
 * Integrada com SQLite para dados reais
 */
export class LgpdSecurityService {
  constructor(config = {}) {
    this.config = {
      apiBaseUrl: config.apiBaseUrl || '/api',
      cacheEnabled: config.cacheEnabled !== undefined ? config.cacheEnabled : true,
      cacheTTL: config.cacheTTL || 300000, // 5 minutos em ms
      ...config
    };

    // Cliente API para comunicação com o backend SQLite
    this.apiClient = new ApiClient(this.config.apiBaseUrl);
    
    // Cache de resultados
    this.cache = new Map();
  }

  /**
   * Registra consentimento de uso de dados de um cliente
   * @param {string} clientId ID do cliente
   * @param {Object} consentData Dados do consentimento
   * @returns {Promise<Object>} Resultado do registro de consentimento
   */
  async registerConsent(clientId, consentData) {
    try {
      logger.info(`[LgpdSecurityService] Registrando consentimento para cliente ${clientId}`);
      
      // Validar dados de entrada
      if (!consentData || !consentData.purposes || consentData.purposes.length === 0) {
        throw new Error('Dados de consentimento inválidos ou incompletos');
      }
      
      // Preparar payload
      const payload = {
        clientId,
        ...consentData,
        consentId: consentData.consentId || uuidv4(),
        createdAt: new Date().toISOString()
      };
      
      // Enviar dados para API
      const response = await this.apiClient.post('/lgpd/consents', payload);
      
      logger.info('[LgpdSecurityService] Consentimento registrado com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[LgpdSecurityService] Erro ao registrar consentimento:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao registrar consentimento'
      };
    }
  }

  /**
   * Verifica se existe consentimento válido para um cliente
   * @param {string} clientId ID do cliente
   * @param {string} purpose Finalidade do consentimento
   * @returns {Promise<Object>} Status do consentimento
   */
  async verifyConsent(clientId, purpose) {
    try {
      logger.info(`[LgpdSecurityService] Verificando consentimento para cliente ${clientId} e finalidade ${purpose}`);
      
      // Verificar cache
      const cacheKey = `consent_${clientId}_${purpose}`;
      if (this.config.cacheEnabled) {
        const cachedResult = this.cache.get(cacheKey);
        if (cachedResult && cachedResult.expiresAt > Date.now()) {
          logger.info('[LgpdSecurityService] Retornando status de consentimento do cache');
          return cachedResult.result;
        }
      }
      
      // Construir parâmetros de consulta
      const queryParams = new URLSearchParams();
      queryParams.append('purpose', purpose);
      
      // Obter status da API
      const url = `/lgpd/consents/${clientId}/verify?${queryParams.toString()}`;
      const response = await this.apiClient.get(url);
      
      // Processar resultado
      const result = response.data;
      
      // Armazenar no cache
      if (this.config.cacheEnabled) {
        this.cache.set(cacheKey, {
          result,
          expiresAt: Date.now() + this.config.cacheTTL
        });
      }
      
      logger.info('[LgpdSecurityService] Status de consentimento verificado com sucesso');
      return result;
    } catch (error) {
      logger.error('[LgpdSecurityService] Erro ao verificar consentimento:', error);
      return {
        success: false,
        hasConsent: false,
        error: error.response?.data?.error || error.message || 'Erro ao verificar consentimento'
      };
    }
  }

  /**
   * Revoga consentimento de uso de dados de um cliente
   * @param {string} clientId ID do cliente
   * @param {string} consentId ID do consentimento
   * @returns {Promise<Object>} Resultado da revogação
   */
  async revokeConsent(clientId, consentId) {
    try {
      logger.info(`[LgpdSecurityService] Revogando consentimento ${consentId} para cliente ${clientId}`);
      
      // Enviar solicitação para API
      const response = await this.apiClient.delete(`/lgpd/consents/${clientId}/${consentId}`);
      
      // Limpar cache relacionado
      if (this.config.cacheEnabled) {
        // Limpar todos os caches relacionados ao cliente
        const keysToDelete = [];
        this.cache.forEach((value, key) => {
          if (key.startsWith(`consent_${clientId}`)) {
            keysToDelete.push(key);
          }
        });
        
        keysToDelete.forEach(key => {
          this.cache.delete(key);
        });
      }
      
      logger.info('[LgpdSecurityService] Consentimento revogado com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[LgpdSecurityService] Erro ao revogar consentimento:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao revogar consentimento'
      };
    }
  }

  /**
   * Registra solicitação de acesso a dados pessoais
   * @param {string} clientId ID do cliente
   * @param {Object} requestData Dados da solicitação
   * @returns {Promise<Object>} Resultado do registro da solicitação
   */
  async registerDataAccessRequest(clientId, requestData) {
    try {
      logger.info(`[LgpdSecurityService] Registrando solicitação de acesso a dados para cliente ${clientId}`);
      
      // Preparar payload
      const payload = {
        clientId,
        ...requestData,
        requestId: requestData.requestId || uuidv4(),
        createdAt: new Date().toISOString(),
        status: 'pending'
      };
      
      // Enviar dados para API
      const response = await this.apiClient.post('/lgpd/access-requests', payload);
      
      logger.info('[LgpdSecurityService] Solicitação de acesso registrada com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[LgpdSecurityService] Erro ao registrar solicitação de acesso:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao registrar solicitação de acesso'
      };
    }
  }

  /**
   * Registra incidente de segurança
   * @param {Object} incidentData Dados do incidente
   * @returns {Promise<Object>} Resultado do registro do incidente
   */
  async registerSecurityIncident(incidentData) {
    try {
      logger.info('[LgpdSecurityService] Registrando incidente de segurança');
      
      // Validar dados de entrada
      if (!incidentData || !incidentData.description) {
        throw new Error('Dados do incidente inválidos ou incompletos');
      }
      
      // Preparar payload
      const payload = {
        ...incidentData,
        incidentId: incidentData.incidentId || uuidv4(),
        createdAt: new Date().toISOString(),
        status: 'reported'
      };
      
      // Enviar dados para API
      const response = await this.apiClient.post('/lgpd/security-incidents', payload);
      
      logger.info('[LgpdSecurityService] Incidente de segurança registrado com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[LgpdSecurityService] Erro ao registrar incidente de segurança:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao registrar incidente de segurança'
      };
    }
  }
}

// Exportar instância singleton para uso em toda a aplicação
const lgpdSecurityService = new LgpdSecurityService();
export default lgpdSecurityService;
