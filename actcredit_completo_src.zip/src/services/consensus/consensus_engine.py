import os
import sys
import json
import logging
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("consensus.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("consensus_engine")

class ConsensusEngine:
    """
    Motor de processamento multicamadas com votação por consenso
    Combina resultados de diferentes motores de extração para maior precisão
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Inicializa o motor de consenso
        
        Args:
            config_path: Caminho para arquivo de configuração (opcional)
        """
        # Carregar configuração
        self.config = self._load_config(config_path)
        
        # Inicializar motores
        self.engines = {}
        self._initialize_engines()
        
        # Inicializar estratégias de consenso
        self.consensus_strategies = {
            "text": self._text_consensus,
            "entities": self._entities_consensus,
            "layout": self._layout_consensus,
            "classification": self._classification_consensus
        }
        
        logger.info("Motor de consenso inicializado")
    
    def _load_config(self, config_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Carrega configuração do motor de consenso
        
        Args:
            config_path: Caminho para arquivo de configuração
            
        Returns:
            Dicionário com configuração
        """
        # Configuração padrão
        default_config = {
            "engines": {
                "paddleocr": {
                    "enabled": True,
                    "weight": 0.4,
                    "threshold": 0.6
                },
                "tesseract": {
                    "enabled": True,
                    "weight": 0.3,
                    "threshold": 0.5
                },
                "layoutlm": {
                    "enabled": True,
                    "weight": 0.5,
                    "threshold": 0.7
                },
                "bertimbau": {
                    "enabled": True,
                    "weight": 0.4,
                    "threshold": 0.6
                },
                "validation": {
                    "enabled": True,
                    "weight": 0.6,
                    "threshold": 0.7
                }
            },
            "consensus": {
                "min_engines": 2,
                "confidence_threshold": 0.8,
                "fallback_strategy": "highest_confidence"
            }
        }
        
        # Se caminho de configuração não foi fornecido, usar configuração padrão
        if not config_path:
            return default_config
        
        # Tentar carregar configuração do arquivo
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                user_config = json.load(f)
            
            # Mesclar configuração do usuário com padrão
            for section, values in user_config.items():
                if section in default_config:
                    if isinstance(values, dict) and isinstance(default_config[section], dict):
                        # Mesclar subseções
                        for key, value in values.items():
                            default_config[section][key] = value
                    else:
                        # Substituir seção inteira
                        default_config[section] = values
            
            logger.info(f"Configuração carregada de {config_path}")
            return default_config
        except Exception as e:
            logger.warning(f"Erro ao carregar configuração de {config_path}: {str(e)}")
            logger.info("Usando configuração padrão")
            return default_config
    
    def _initialize_engines(self):
        """Inicializa os motores de extração configurados"""
        try:
            # Verificar quais motores estão habilitados na configuração
            enabled_engines = []
            for engine_name, engine_config in self.config["engines"].items():
                if engine_config.get("enabled", False):
                    enabled_engines.append(engine_name)
            
            logger.info(f"Motores habilitados: {', '.join(enabled_engines)}")
            
            # Inicializar motores (lazy loading)
            # Os motores serão carregados apenas quando necessário
        except Exception as e:
            logger.error(f"Erro ao inicializar motores: {str(e)}")
    
    def _get_engine(self, engine_name: str) -> Any:
        """
        Obtém instância de um motor de extração (lazy loading)
        
        Args:
            engine_name: Nome do motor
            
        Returns:
            Instância do motor ou None se não disponível
        """
        # Se o motor já foi carregado, retornar instância existente
        if engine_name in self.engines:
            return self.engines[engine_name]
        
        # Verificar se o motor está habilitado
        if engine_name not in self.config["engines"] or not self.config["engines"][engine_name].get("enabled", False):
            logger.warning(f"Motor {engine_name} não está habilitado")
            return None
        
        try:
            # Carregar motor sob demanda
            if engine_name == "paddleocr":
                # Importar PaddleOCR
                from services.ia_extractor.ia_extractor import IAExtractor
                engine = IAExtractor()
                self.engines[engine_name] = engine.paddle_ocr
            
            elif engine_name == "tesseract":
                # Importar Tesseract
                import pytesseract
                self.engines[engine_name] = pytesseract
            
            elif engine_name == "layoutlm":
                # Importar LayoutLM
                from services.ia_extractor.ia_extractor import IAExtractor
                engine = IAExtractor()
                self.engines[engine_name] = engine.layout_model
            
            elif engine_name == "bertimbau":
                # Importar BERTimbau
                from services.ia_extractor.ia_extractor import IAExtractor
                engine = IAExtractor()
                self.engines[engine_name] = engine.nlp_model
            
            elif engine_name == "validation":
                # Importar sistema de validação cruzada
                from services.validation.cross_validation import CrossValidationSystem
                self.engines[engine_name] = CrossValidationSystem()
            
            else:
                logger.warning(f"Motor desconhecido: {engine_name}")
                return None
            
            logger.info(f"Motor {engine_name} carregado com sucesso")
            return self.engines[engine_name]
        
        except Exception as e:
            logger.error(f"Erro ao carregar motor {engine_name}: {str(e)}")
            return None
    
    def process_document(self, document_path: str) -> Dict[str, Any]:
        """
        Processa documento usando múltiplos motores e votação por consenso
        
        Args:
            document_path: Caminho para o documento
            
        Returns:
            Dicionário com resultados consolidados
        """
        try:
            # Verificar tipo de documento
            is_pdf = document_path.lower().endswith('.pdf')
            is_image = document_path.lower().endswith(('.jpg', '.jpeg', '.png', '.tiff', '.tif', '.bmp'))
            
            if not (is_pdf or is_image):
                raise ValueError(f"Formato de documento não suportado: {document_path}")
            
            # Resultados de cada motor
            engine_results = {}
            
            # Processar com cada motor habilitado
            for engine_name in self.config["engines"]:
                if not self.config["engines"][engine_name].get("enabled", False):
                    continue
                
                try:
                    # Processar documento com o motor
                    if engine_name == "paddleocr":
                        result = self._process_with_paddleocr(document_path)
                    elif engine_name == "tesseract":
                        result = self._process_with_tesseract(document_path)
                    elif engine_name == "layoutlm":
                        result = self._process_with_layoutlm(document_path)
                    elif engine_name == "bertimbau":
                        # BERTimbau precisa de texto extraído por outro motor
                        if "paddleocr" in engine_results:
                            text = engine_results["paddleocr"].get("text", "")
                        elif "tesseract" in engine_results:
                            text = engine_results["tesseract"].get("text", "")
                        else:
                            logger.warning("Nenhum texto disponível para processamento com BERTimbau")
                            continue
                        
                        result = self._process_with_bertimbau(text)
                    elif engine_name == "validation":
                        # Validação precisa de dados extraídos por outros motores
                        if not engine_results:
                            logger.warning("Nenhum dado disponível para validação")
                            continue
                        
                        # Combinar resultados para validação
                        combined_data = self._combine_results_for_validation(engine_results)
                        result = self._process_with_validation(combined_data)
                    else:
                        logger.warning(f"Processamento não implementado para motor: {engine_name}")
                        continue
                    
                    # Armazenar resultado
                    engine_results[engine_name] = result
                    logger.info(f"Documento processado com sucesso pelo motor {engine_name}")
                
                except Exception as e:
                    logger.error(f"Erro ao processar documento com motor {engine_name}: {str(e)}")
            
            # Verificar se temos resultados suficientes
            min_engines = self.config["consensus"]["min_engines"]
            if len(engine_results) < min_engines:
                logger.warning(f"Número insuficiente de motores ({len(engine_results)}/{min_engines})")
                
                # Usar estratégia de fallback
                fallback_strategy = self.config["consensus"]["fallback_strategy"]
                if fallback_strategy == "highest_confidence" and engine_results:
                    # Usar resultado do motor com maior confiança
                    best_engine = max(engine_results.items(), key=lambda x: x[1].get("confidence", {}).get("overall", 0.0))
                    logger.info(f"Usando resultado do motor {best_engine[0]} como fallback")
                    return best_engine[1]
                else:
                    # Retornar erro
                    return {"error": f"Número insuficiente de motores ({len(engine_results)}/{min_engines})"}
            
            # Aplicar votação por consenso
            consensus_result = self._apply_consensus(engine_results)
            
            return consensus_result
        
        except Exception as e:
            logger.error(f"Erro ao processar documento: {str(e)}")
            return {"error": str(e)}
    
    def _process_with_paddleocr(self, document_path: str) -> Dict[str, Any]:
        """
        Processa documento com PaddleOCR
        
        Args:
            document_path: Caminho para o documento
            
        Returns:
            Dicionário com resultados
        """
        try:
            # Obter instância do motor
            engine = self._get_engine("paddleocr")
            if not engine:
                raise ValueError("Motor PaddleOCR não disponível")
            
            # Verificar tipo de documento
            is_pdf = document_path.lower().endswith('.pdf')
            
            if is_pdf:
                # Processar PDF
                from services.ia_extractor.ia_extractor import IAExtractor
                extractor = IAExtractor()
                result = extractor.process_pdf(document_path)
            else:
                # Processar imagem
                import cv2
                image = cv2.imread(document_path)
                from services.ia_extractor.ia_extractor import IAExtractor
                extractor = IAExtractor()
                result = extractor.process_document_image(image)
            
            return result
        except Exception as e:
            logger.error(f"Erro ao processar com PaddleOCR: {str(e)}")
            return {"error": str(e)}
    
    def _process_with_tesseract(self, document_path: str) -> Dict[str, Any]:
        """
        Processa documento com Tesseract
        
        Args:
            document_path: Caminho para o documento
            
        Returns:
            Dicionário com resultados
        """
        try:
            # Obter instância do motor
            engine = self._get_engine("tesseract")
            if not engine:
                raise ValueError("Motor Tesseract não disponível")
            
            # Verificar tipo de documento
            is_pdf = document_path.lower().endswith('.pdf')
            
            # Extrair texto
            if is_pdf:
                # Converter PDF para imagens
                from pdf2image import convert_from_path
                images = convert_from_path(document_path)
                
                # Processar cada página
                pages_text = []
                for i, image in enumerate(images):
                    # Extrair texto com Tesseract
                    text = engine.image_to_string(image, lang='por')
                    pages_text.append({"page_num": i+1, "text": text})
                
                # Consolidar resultados
                full_text = "\n\n".join([page["text"] for page in pages_text])
                
                result = {
                    "text": full_text,
                    "pages": pages_text,
                    "confidence": {
                        "overall": 0.7  # Confiança estimada para Tesseract
                    }
                }
            else:
                # Processar imagem diretamente
                import cv2
                image = cv2.imread(document_path)
                text = engine.image_to_string(image, lang='por')
                
                result = {
                    "text": text,
                    "confidence": {
                        "overall": 0.7  # Confiança estimada para Tesseract
                    }
                }
            
            # Extrair entidades básicas
            result["entities"] = self._extract_basic_entities(result["text"])
            
            return result
        except Exception as e:
            logger.error(f"Erro ao processar com Tesseract: {str(e)}")
            return {"error": str(e)}
    
    def _extract_basic_entities(self, text: str) -> Dict[str, Any]:
        """
        Extrai entidades básicas usando expressões regulares
        
        Args:
            text: Texto extraído
            
        Returns:
            Dicionário com entidades extraídas
        """
        import re
        
        entities = {
            "cnpj": [],
            "valores": [],
            "datas": [],
            "empresa": ""
        }
        
        # Extrair CNPJs
        cnpj_pattern = r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}'
        entities["cnpj"] = re.findall(cnpj_pattern, text)
        
        # Extrair valores monetários
        valores_pattern = r'R\$\s*[\d\.,]+|\d+[\.,]\d{3}[\.,]\d{2}'
        entities["valores"] = re.findall(valores_pattern, text)
        
        # Extrair datas
        datas_pattern = r'\d{2}/\d{2}/\d{4}|\d{2}\.\d{2}\.\d{4}|\d{2}-\d{2}-\d{4}'
        entities["datas"] = re.findall(datas_pattern, text)
        
        # Tentar extrair nome da empresa (heurística simples)
        # Procurar linha próxima ao CNPJ
        if entities["cnpj"]:
            cnpj_pos = text.find(entities["cnpj"][0])
            if cnpj_pos > 0:
                # Pegar contexto ao redor do CNPJ
                start_pos = max(0, cnpj_pos - 200)
                end_pos = min(len(text), cnpj_pos + 200)
                context = text[start_pos:end_pos]
                
                # Dividir em linhas
                lines = context.split('\n')
                
                # Procurar linha com possível nome de empresa
                for i, line in enumerate(lines):
                    if entities["cnpj"][0] in line:
                        # Verificar linhas anteriores
                        for j in range(i-1, max(0, i-5), -1):
                            candidate = lines[j].strip()
                            # Heurística simples: linha não vazia, sem números, com mais de 5 caracteres
                            if candidate and len(candidate) > 5 and not re.search(r'\d', candidate):
                                entities["empresa"] = candidate
                                break
                        break
        
        return entities
    
    def _process_with_layoutlm(self, document_path: str) -> Dict[str, Any]:
        """
        Processa documento com LayoutLM
        
        Args:
            document_path: Caminho para o documento
            
        Returns:
            Dicionário com resultados
        """
        try:
            # Obter instância do motor
            engine = self._get_engine("layoutlm")
            if not engine:
                raise ValueError("Motor LayoutLM não disponível")
            
            # Verificar tipo de documento
            is_pdf = document_path.lower().endswith('.pdf')
            
            if is_pdf:
                # Processar PDF
                from services.ia_extractor.ia_extractor import IAExtractor
                extractor = IAExtractor()
                result = extractor.process_pdf(document_path)
                
                # Filtrar apenas informações de layout
                layout_result = {
                    "layout": result.get("consolidated", {}).get("layout", {}),
                    "document_type": result.get("consolidated", {}).get("document_type", "desconhecido"),
                    "confidence": {
                        "layout": result.get("consolidated", {}).get("confidence", {}).get("layout", 0.0),
                        "overall": result.get("consolidated", {}).get("confidence", {}).get("layout", 0.0)
                    }
                }
                
                return layout_result
            else:
                # Processar imagem
                import cv2
                image = cv2.imread(document_path)
                from services.ia_extractor.ia_extractor import IAExtractor
                extractor = IAExtractor()
                result = extractor.process_document_image(image)
                
                # Filtrar apenas informações de layout
                layout_result = {
                    "layout": result.get("layout", {}),
                    "document_type": result.get("document_type", "desconhecido"),
                    "confidence": {
                        "layout": result.get("confidence", {}).get("layout", 0.0),
                        "overall": result.get("confidence", {}).get("layout", 0.0)
                    }
                }
                
                return layout_result
            
        except Exception as e:
            logger.error(f"Erro ao processar com LayoutLM: {str(e)}")
            return {"error": str(e)}
    
    def _process_with_bertimbau(self, text: str) -> Dict[str, Any]:
        """
        Processa texto com BERTimbau
        
        Args:
            text: Texto a ser processado
            
        Returns:
            Dicionário com resultados
        """
        try:
            # Obter instância do motor
            engine = self._get_engine("bertimbau")
            if not engine:
                raise ValueError("Motor BERTimbau não disponível")
            
            # Extrair entidades
            from services.ia_extractor.ia_extractor import IAExtractor
            extractor = IAExtractor()
            entities = extractor.extract_entities_with_nlp(text)
            
            result = {
                "entities": entities,
                "confidence": {
                    "entities": 0.85,  # Confiança estimada para BERTimbau
                    "overall": 0.85
                }
            }
            
            return result
        except Exception as e:
            logger.error(f"Erro ao processar com BERTimbau: {str(e)}")
            return {"error": str(e)}
    
    def _combine_results_for_validation(self, engine_results: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Combina resultados de diferentes motores para validação
        
        Args:
            engine_results: Resultados de cada motor
            
        Returns:
            Dados combinados para validação
        """
        # Inicializar dados combinados
        combined_data = {
            "entities": {},
            "text": "",
            "document_type": ""
        }
        
        # Combinar entidades
        entities_sources = []
        for engine_name, result in engine_results.items():
            if "entities" in result:
                entities_sources.append((engine_name, result["entities"]))
        
        # Se temos entidades de múltiplas fontes, usar a mais completa
        if entities_sources:
            # Escolher fonte com mais entidades
            best_source = max(entities_sources, key=lambda x: sum(len(v) if isinstance(v, list) else 1 for v in x[1].values() if v))
            combined_data["entities"] = best_source[1]
        
        # Combinar texto
        text_sources = []
        for engine_name, result in engine_results.items():
            if "text" in result:
                text_sources.append((engine_name, result["text"]))
        
        # Se temos texto de múltiplas fontes, usar o mais longo
        if text_sources:
            best_source = max(text_sources, key=lambda x: len(x[1]))
            combined_data["text"] = best_source[1]
        
        # Combinar tipo de documento
        doc_type_sources = []
        for engine_name, result in engine_results.items():
            if "document_type" in result:
                doc_type_sources.append((engine_name, result["document_type"]))
        
        # Se temos tipo de documento de múltiplas fontes, usar o mais frequente
        if doc_type_sources:
            from collections import Counter
            doc_types = [source[1] for source in doc_type_sources]
            most_common = Counter(doc_types).most_common(1)
            if most_common:
                combined_data["document_type"] = most_common[0][0]
        
        return combined_data
    
    def _process_with_validation(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Processa dados com sistema de validação cruzada
        
        Args:
            data: Dados a serem validados
            
        Returns:
            Dicionário com resultados da validação
        """
        try:
            # Obter instância do motor
            engine = self._get_engine("validation")
            if not engine:
                raise ValueError("Motor de validação não disponível")
            
            # Validar dados
            validation_result = engine.validate_data(data)
            
            return validation_result
        except Exception as e:
            logger.error(f"Erro ao processar com validação: {str(e)}")
            return {"error": str(e)}
    
    def _apply_consensus(self, engine_results: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Aplica votação por consenso aos resultados dos motores
        
        Args:
            engine_results: Resultados de cada motor
            
        Returns:
            Resultado consolidado por consenso
        """
        # Inicializar resultado de consenso
        consensus_result = {
            "text": "",
            "entities": {},
            "layout": {},
            "document_type": "",
            "confidence": {
                "text": 0.0,
                "entities": 0.0,
                "layout": 0.0,
                "overall": 0.0
            },
            "consensus": {
                "engines_used": list(engine_results.keys()),
                "strategy": {}
            }
        }
        
        # Aplicar estratégias de consenso para cada tipo de dado
        for data_type, consensus_func in self.consensus_strategies.items():
            if data_type == "text":
                # Coletar texto de cada motor
                texts = {}
                for engine_name, result in engine_results.items():
                    if "text" in result:
                        texts[engine_name] = {
                            "text": result["text"],
                            "confidence": result.get("confidence", {}).get("overall", 0.0)
                        }
                
                if texts:
                    text_consensus, text_confidence, text_strategy = consensus_func(texts)
                    consensus_result["text"] = text_consensus
                    consensus_result["confidence"]["text"] = text_confidence
                    consensus_result["consensus"]["strategy"]["text"] = text_strategy
            
            elif data_type == "entities":
                # Coletar entidades de cada motor
                entities_by_engine = {}
                for engine_name, result in engine_results.items():
                    if "entities" in result:
                        entities_by_engine[engine_name] = {
                            "entities": result["entities"],
                            "confidence": result.get("confidence", {}).get("entities", 0.0)
                        }
                
                if entities_by_engine:
                    entities_consensus, entities_confidence, entities_strategy = consensus_func(entities_by_engine)
                    consensus_result["entities"] = entities_consensus
                    consensus_result["confidence"]["entities"] = entities_confidence
                    consensus_result["consensus"]["strategy"]["entities"] = entities_strategy
            
            elif data_type == "layout":
                # Coletar layout de cada motor
                layouts = {}
                for engine_name, result in engine_results.items():
                    if "layout" in result:
                        layouts[engine_name] = {
                            "layout": result["layout"],
                            "confidence": result.get("confidence", {}).get("layout", 0.0)
                        }
                
                if layouts:
                    layout_consensus, layout_confidence, layout_strategy = consensus_func(layouts)
                    consensus_result["layout"] = layout_consensus
                    consensus_result["confidence"]["layout"] = layout_confidence
                    consensus_result["consensus"]["strategy"]["layout"] = layout_strategy
            
            elif data_type == "classification":
                # Coletar classificação (tipo de documento) de cada motor
                classifications = {}
                for engine_name, result in engine_results.items():
                    if "document_type" in result:
                        classifications[engine_name] = {
                            "class": result["document_type"],
                            "confidence": result.get("confidence", {}).get("overall", 0.0)
                        }
                
                if classifications:
                    class_consensus, class_confidence, class_strategy = consensus_func(classifications)
                    consensus_result["document_type"] = class_consensus
                    consensus_result["confidence"]["classification"] = class_confidence
                    consensus_result["consensus"]["strategy"]["classification"] = class_strategy
        
        # Calcular confiança geral
        confidence_values = [v for k, v in consensus_result["confidence"].items() if k != "overall" and v > 0]
        if confidence_values:
            consensus_result["confidence"]["overall"] = sum(confidence_values) / len(confidence_values)
        
        # Adicionar metadados
        import time
        consensus_result["timestamp"] = time.strftime("%Y-%m-%d %H:%M:%S")
        
        return consensus_result
    
    def _text_consensus(self, texts: Dict[str, Dict[str, Any]]) -> Tuple[str, float, str]:
        """
        Aplica consenso para texto extraído
        
        Args:
            texts: Textos extraídos por diferentes motores
            
        Returns:
            Tuple com texto de consenso, confiança e estratégia usada
        """
        if not texts:
            return "", 0.0, "none"
        
        # Estratégias de consenso para texto
        strategies = ["weighted_confidence", "longest_text", "highest_confidence"]
        
        # Tentar cada estratégia
        for strategy in strategies:
            if strategy == "weighted_confidence":
                # Verificar se temos pelo menos 2 motores com confiança
                engines_with_confidence = [engine for engine, data in texts.items() 
                                          if data.get("confidence", 0.0) > 0]
                
                if len(engines_with_confidence) >= 2:
                    # Calcular texto ponderado por confiança
                    # Para texto, isso não faz muito sentido, então vamos usar o texto do motor com maior confiança
                    best_engine = max(texts.items(), key=lambda x: x[1].get("confidence", 0.0))
                    
                    return best_engine[1]["text"], best_engine[1].get("confidence", 0.0), "weighted_confidence"
            
            elif strategy == "longest_text":
                # Usar o texto mais longo
                longest_text = max(texts.items(), key=lambda x: len(x[1]["text"]))
                
                # Calcular confiança como média ponderada pelo comprimento
                total_length = sum(len(data["text"]) for data in texts.values())
                if total_length > 0:
                    confidence = sum(len(data["text"]) / total_length * data.get("confidence", 0.7) 
                                    for data in texts.values())
                else:
                    confidence = 0.7  # Valor padrão
                
                return longest_text[1]["text"], confidence, "longest_text"
            
            elif strategy == "highest_confidence":
                # Usar o texto do motor com maior confiança
                best_engine = max(texts.items(), key=lambda x: x[1].get("confidence", 0.0))
                
                return best_engine[1]["text"], best_engine[1].get("confidence", 0.0), "highest_confidence"
        
        # Fallback: usar o primeiro texto
        first_engine = next(iter(texts.items()))
        return first_engine[1]["text"], first_engine[1].get("confidence", 0.0), "fallback"
    
    def _entities_consensus(self, entities_by_engine: Dict[str, Dict[str, Any]]) -> Tuple[Dict[str, Any], float, str]:
        """
        Aplica consenso para entidades extraídas
        
        Args:
            entities_by_engine: Entidades extraídas por diferentes motores
            
        Returns:
            Tuple com entidades de consenso, confiança e estratégia usada
        """
        if not entities_by_engine:
            return {}, 0.0, "none"
        
        # Inicializar resultado de consenso
        consensus_entities = {
            "cnpj": [],
            "valores": [],
            "datas": [],
            "empresa": ""
        }
        
        # Estratégia: votação por maioria para listas, ponderada por confiança
        
        # Processar CNPJs
        all_cnpjs = {}
        for engine, data in entities_by_engine.items():
            engine_confidence = data.get("confidence", 0.7)
            entities = data.get("entities", {})
            
            for cnpj in entities.get("cnpj", []):
                # Normalizar CNPJ para comparação
                clean_cnpj = ''.join(filter(str.isdigit, cnpj))
                
                if clean_cnpj in all_cnpjs:
                    all_cnpjs[clean_cnpj]["count"] += 1
                    all_cnpjs[clean_cnpj]["confidence"] += engine_confidence
                    all_cnpjs[clean_cnpj]["engines"].append(engine)
                else:
                    all_cnpjs[clean_cnpj] = {
                        "original": cnpj,
                        "count": 1,
                        "confidence": engine_confidence,
                        "engines": [engine]
                    }
        
        # Filtrar CNPJs por consenso
        for cnpj_data in sorted(all_cnpjs.values(), key=lambda x: (x["count"], x["confidence"]), reverse=True):
            # Adicionar CNPJs que aparecem em mais de um motor ou têm alta confiança
            if cnpj_data["count"] > 1 or cnpj_data["confidence"] > 0.8:
                consensus_entities["cnpj"].append(cnpj_data["original"])
        
        # Processar valores monetários
        all_values = {}
        for engine, data in entities_by_engine.items():
            engine_confidence = data.get("confidence", 0.7)
            entities = data.get("entities", {})
            
            for value in entities.get("valores", []):
                # Normalizar valor para comparação
                clean_value = self._normalize_monetary_value(value)
                if clean_value is None:
                    continue
                
                key = str(clean_value)
                
                if key in all_values:
                    all_values[key]["count"] += 1
                    all_values[key]["confidence"] += engine_confidence
                    all_values[key]["engines"].append(engine)
                else:
                    all_values[key] = {
                        "original": value,
                        "normalized": clean_value,
                        "count": 1,
                        "confidence": engine_confidence,
                        "engines": [engine]
                    }
        
        # Filtrar valores por consenso
        for value_data in sorted(all_values.values(), key=lambda x: (x["count"], x["confidence"]), reverse=True):
            # Adicionar valores que aparecem em mais de um motor ou têm alta confiança
            if value_data["count"] > 1 or value_data["confidence"] > 0.8:
                consensus_entities["valores"].append(value_data["original"])
        
        # Processar datas
        all_dates = {}
        for engine, data in entities_by_engine.items():
            engine_confidence = data.get("confidence", 0.7)
            entities = data.get("entities", {})
            
            for date in entities.get("datas", []):
                # Normalizar data para comparação
                clean_date = self._normalize_date(date)
                if clean_date is None:
                    continue
                
                key = clean_date.isoformat()
                
                if key in all_dates:
                    all_dates[key]["count"] += 1
                    all_dates[key]["confidence"] += engine_confidence
                    all_dates[key]["engines"].append(engine)
                else:
                    all_dates[key] = {
                        "original": date,
                        "normalized": clean_date,
                        "count": 1,
                        "confidence": engine_confidence,
                        "engines": [engine]
                    }
        
        # Filtrar datas por consenso
        for date_data in sorted(all_dates.values(), key=lambda x: (x["count"], x["confidence"]), reverse=True):
            # Adicionar datas que aparecem em mais de um motor ou têm alta confiança
            if date_data["count"] > 1 or date_data["confidence"] > 0.8:
                consensus_entities["datas"].append(date_data["original"])
        
        # Processar nome da empresa
        company_names = {}
        for engine, data in entities_by_engine.items():
            engine_confidence = data.get("confidence", 0.7)
            entities = data.get("entities", {})
            
            company = entities.get("empresa", "")
            if company:
                # Normalizar nome para comparação
                clean_company = self._normalize_company_name(company)
                
                if clean_company in company_names:
                    company_names[clean_company]["count"] += 1
                    company_names[clean_company]["confidence"] += engine_confidence
                    company_names[clean_company]["engines"].append(engine)
                else:
                    company_names[clean_company] = {
                        "original": company,
                        "count": 1,
                        "confidence": engine_confidence,
                        "engines": [engine]
                    }
        
        # Escolher nome da empresa por consenso
        if company_names:
            # Ordenar por contagem e confiança
            sorted_companies = sorted(company_names.values(), key=lambda x: (x["count"], x["confidence"]), reverse=True)
            consensus_entities["empresa"] = sorted_companies[0]["original"]
        
        # Calcular confiança geral
        entity_confidences = []
        
        # Confiança para CNPJs
        if consensus_entities["cnpj"]:
            cnpj_confidence = sum(all_cnpjs.get(''.join(filter(str.isdigit, cnpj)), {}).get("confidence", 0.0) 
                                 for cnpj in consensus_entities["cnpj"]) / len(consensus_entities["cnpj"])
            entity_confidences.append(cnpj_confidence)
        
        # Confiança para valores
        if consensus_entities["valores"]:
            value_confidence = sum(all_values.get(str(self._normalize_monetary_value(value)), {}).get("confidence", 0.0) 
                                  for value in consensus_entities["valores"] 
                                  if self._normalize_monetary_value(value) is not None) / len(consensus_entities["valores"])
            entity_confidences.append(value_confidence)
        
        # Confiança para datas
        if consensus_entities["datas"]:
            date_confidence = sum(all_dates.get(self._normalize_date(date).isoformat() if self._normalize_date(date) else "", {}).get("confidence", 0.0) 
                                 for date in consensus_entities["datas"] 
                                 if self._normalize_date(date) is not None) / len(consensus_entities["datas"])
            entity_confidences.append(date_confidence)
        
        # Confiança para nome da empresa
        if consensus_entities["empresa"]:
            company_confidence = company_names.get(self._normalize_company_name(consensus_entities["empresa"]), {}).get("confidence", 0.0)
            entity_confidences.append(company_confidence)
        
        # Calcular confiança média
        overall_confidence = sum(entity_confidences) / len(entity_confidences) if entity_confidences else 0.0
        
        return consensus_entities, overall_confidence, "weighted_voting"
    
    def _normalize_monetary_value(self, value: str) -> Optional[float]:
        """
        Normaliza valor monetário para formato numérico
        
        Args:
            value: Valor monetário como string
            
        Returns:
            Valor como float ou None se inválido
        """
        try:
            import re
            
            # Remover prefixo de moeda
            clean_value = re.sub(r'^R\$\s*', '', value)
            
            # Remover pontos de milhar
            clean_value = clean_value.replace('.', '')
            
            # Substituir vírgula por ponto decimal
            clean_value = clean_value.replace(',', '.')
            
            # Converter para float
            return float(clean_value)
        except:
            return None
    
    def _normalize_date(self, date: str) -> Optional[object]:
        """
        Normaliza data para formato padrão
        
        Args:
            date: Data como string
            
        Returns:
            Objeto date ou None se inválido
        """
        import re
        import datetime
        
        # Padrões de data comuns no Brasil
        patterns = [
            # DD/MM/YYYY
            (r'(\d{2})/(\d{2})/(\d{4})', lambda m: datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))),
            # DD.MM.YYYY
            (r'(\d{2})\.(\d{2})\.(\d{4})', lambda m: datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))),
            # DD-MM-YYYY
            (r'(\d{2})-(\d{2})-(\d{4})', lambda m: datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))),
            # YYYY-MM-DD
            (r'(\d{4})-(\d{2})-(\d{2})', lambda m: datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3))))
        ]
        
        for pattern, date_constructor in patterns:
            match = re.match(pattern, date)
            if match:
                try:
                    return date_constructor(match)
                except ValueError:
                    # Data inválida (ex: 31/02/2023)
                    continue
        
        return None
    
    def _normalize_company_name(self, name: str) -> str:
        """
        Normaliza nome de empresa para comparação
        
        Args:
            name: Nome da empresa
            
        Returns:
            Nome normalizado
        """
        import re
        import unicodedata
        
        # Converter para minúsculas
        normalized = name.lower()
        
        # Remover acentos
        normalized = unicodedata.normalize('NFKD', normalized).encode('ASCII', 'ignore').decode('ASCII')
        
        # Remover termos comuns de razão social
        terms_to_remove = [
            "ltda", "limitada", "s/a", "s.a.", "sa", "mei", "eireli", 
            "epp", "me", "microempresa", "empresa individual", 
            "sociedade anonima", "companhia", "cia"
        ]
        
        for term in terms_to_remove:
            normalized = re.sub(r'\b' + term + r'\b', '', normalized)
        
        # Remover pontuação e caracteres especiais
        normalized = re.sub(r'[^\w\s]', '', normalized)
        
        # Remover espaços extras
        normalized = re.sub(r'\s+', ' ', normalized).strip()
        
        return normalized
    
    def _layout_consensus(self, layouts: Dict[str, Dict[str, Any]]) -> Tuple[Dict[str, Any], float, str]:
        """
        Aplica consenso para análise de layout
        
        Args:
            layouts: Análises de layout por diferentes motores
            
        Returns:
            Tuple com layout de consenso, confiança e estratégia usada
        """
        if not layouts:
            return {}, 0.0, "none"
        
        # Para layout, vamos usar o resultado do motor com maior confiança
        best_engine = max(layouts.items(), key=lambda x: x[1].get("confidence", 0.0))
        
        return best_engine[1]["layout"], best_engine[1].get("confidence", 0.0), "highest_confidence"
    
    def _classification_consensus(self, classifications: Dict[str, Dict[str, Any]]) -> Tuple[str, float, str]:
        """
        Aplica consenso para classificação de documento
        
        Args:
            classifications: Classificações por diferentes motores
            
        Returns:
            Tuple com classificação de consenso, confiança e estratégia usada
        """
        if not classifications:
            return "", 0.0, "none"
        
        # Contar ocorrências de cada classe
        class_counts = {}
        class_confidences = {}
        
        for engine, data in classifications.items():
            doc_class = data.get("class", "")
            confidence = data.get("confidence", 0.0)
            
            if doc_class:
                if doc_class in class_counts:
                    class_counts[doc_class] += 1
                    class_confidences[doc_class] += confidence
                else:
                    class_counts[doc_class] = 1
                    class_confidences[doc_class] = confidence
        
        # Escolher classe mais frequente
        if class_counts:
            # Ordenar por contagem e confiança
            sorted_classes = sorted(class_counts.keys(), 
                                   key=lambda x: (class_counts[x], class_confidences[x]), 
                                   reverse=True)
            
            best_class = sorted_classes[0]
            confidence = class_confidences[best_class] / class_counts[best_class]
            
            return best_class, confidence, "majority_voting"
        
        # Fallback: usar a primeira classificação
        first_engine = next(iter(classifications.items()))
        return first_engine[1].get("class", ""), first_engine[1].get("confidence", 0.0), "fallback"

# Função principal para processamento multicamadas
def process_document_with_consensus(document_path: str, config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Função principal para processar documento com múltiplos motores e votação por consenso
    
    Args:
        document_path: Caminho para o documento
        config_path: Caminho para arquivo de configuração (opcional)
        
    Returns:
        Dicionário com resultados consolidados
    """
    try:
        # Inicializar motor de consenso
        engine = ConsensusEngine(config_path=config_path)
        
        # Processar documento
        result = engine.process_document(document_path)
        
        return result
    except Exception as e:
        logger.error(f"Erro ao processar documento com consenso: {str(e)}")
        return {"error": str(e)}

# Função para instalação de dependências em ambiente Windows
def install_dependencies_windows():
    """
    Instala dependências necessárias em ambiente Windows
    
    Returns:
        True se sucesso, False caso contrário
    """
    try:
        import subprocess
        import sys
        
        # Verificar se pip está disponível
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "--version"])
        except:
            logger.error("Pip não está disponível. Por favor, instale o pip primeiro.")
            return False
        
        # Instalar dependências
        dependencies = [
            "numpy",
            "opencv-python",
            "pdf2image"
        ]
        
        for dep in dependencies:
            logger.info(f"Instalando {dep}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", dep])
        
        logger.info("Todas as dependências Python foram instaladas com sucesso!")
        return True
    except Exception as e:
        logger.error(f"Erro ao instalar dependências: {str(e)}")
        return False

if __name__ == "__main__":
    # Exemplo de uso
    if len(sys.argv) > 1:
        document_path = sys.argv[1]
        config_path = sys.argv[2] if len(sys.argv) > 2 else None
        
        result = process_document_with_consensus(document_path, config_path)
        
        # Imprimir resultado
        import json
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("Uso: python consensus_engine.py caminho/para/documento.pdf [caminho/para/config.json]")
