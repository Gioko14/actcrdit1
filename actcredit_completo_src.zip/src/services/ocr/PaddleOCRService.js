/**
 * Serviço de OCR com PaddleOCR (Deep Learning)
 * Fornece funcionalidades avançadas de reconhecimento ótico de caracteres para o extrator
 * usando a biblioteca PaddleOCR da Baidu (gratuita e open-source)
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const util = require('util');
const PathUtils = require('../../utils/PathUtils');

// Promisificar funções do fs
const fsExists = util.promisify(fs.exists);
const fsMkdir = util.promisify(fs.mkdir);
const fsReadFile = util.promisify(fs.readFile);
const fsWriteFile = util.promisify(fs.writeFile);
const fsUnlink = util.promisify(fs.unlink);

/**
 * Serviço de OCR com PaddleOCR (Deep Learning)
 */
class PaddleOCRService {
  constructor() {
    this.pythonPath = 'python3';
    this.tempDir = path.join(__dirname, 'temp');
    this.ensureTempDir();
  }

  /**
   * Garante que o diretório temporário exista
   * @private
   */
  async ensureTempDir() {
    try {
      if (!await fsExists(this.tempDir)) {
        await fsMkdir(this.tempDir, { recursive: true });
      }
    } catch (error) {
      console.error('Erro ao criar diretório temporário:', error);
    }
  }

  /**
   * Verifica se o PaddleOCR está instalado e funcional
   * @returns {Promise<boolean>} True se o PaddleOCR estiver funcionando
   */
  async checkPaddleOCRInstallation() {
    return new Promise((resolve) => {
      const pythonScript = `
import sys
try:
    from paddleocr import PaddleOCR
    print("PaddleOCR está instalado corretamente.")
    sys.exit(0)
except ImportError as e:
    print(f"Erro ao importar PaddleOCR: {e}")
    sys.exit(1)
`;

      const scriptPath = path.join(this.tempDir, 'check_paddleocr.py');
      
      // Salvar script temporário
      fs.writeFileSync(scriptPath, pythonScript);
      
      // Executar script Python
      const process = spawn(this.pythonPath, [scriptPath]);
      
      let output = '';
      process.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      let errorOutput = '';
      process.stderr.on('data', (data) => {
        errorOutput += data.toString();
      });
      
      process.on('close', (code) => {
        // Limpar arquivo temporário
        try {
          fs.unlinkSync(scriptPath);
        } catch (error) {
          console.error('Erro ao remover script temporário:', error);
        }
        
        if (code === 0) {
          console.log('PaddleOCR está instalado e funcional.');
          console.log(output);
          resolve(true);
        } else {
          console.error('PaddleOCR não está instalado ou não está funcional.');
          console.error(errorOutput);
          resolve(false);
        }
      });
    });
  }

  /**
   * Realiza OCR em uma imagem usando PaddleOCR
   * @param {string} imagePath Caminho da imagem
   * @param {Object} options Opções adicionais
   * @returns {Promise<string>} Texto extraído
   */
  async extractTextFromImage(imagePath, options = {}) {
    return new Promise(async (resolve, reject) => {
      try {
        // Verificar se o arquivo existe
        if (!await fsExists(imagePath)) {
          throw new Error(`Arquivo não encontrado: ${imagePath}`);
        }

        console.log(`Iniciando OCR com PaddleOCR na imagem: ${imagePath}`);
        
        // Usar o script de extração dedicado
        const extractScriptPath = path.join(__dirname, 'paddleocr_extract.py');
        
        // Executar script Python
        const process = spawn(this.pythonPath, [extractScriptPath, imagePath]);
        
        let output = '';
        process.stdout.on('data', (data) => {
          output += data.toString();
        });
        
        let errorOutput = '';
        process.stderr.on('data', (data) => {
          errorOutput += data.toString();
        });
        
        process.on('close', async (code) => {
          if (code === 0) {
            try {
              // Parsear resultado JSON
              const result = JSON.parse(output);
              
              if (result.success) {
                console.log(`OCR concluído com sucesso para: ${imagePath}`);
                console.log(`Confiança média: ${result.confidence.toFixed(2)}`);
                resolve(result.text);
              } else {
                console.error(`Erro no OCR: ${result.error}`);
                reject(new Error(result.error));
              }
            } catch (error) {
              console.error('Erro ao parsear resultado do OCR:', error);
              console.error('Output:', output);
              reject(error);
            }
          } else {
            console.error(`Processo de OCR falhou com código ${code}`);
            console.error(errorOutput);
            reject(new Error(`Processo de OCR falhou: ${errorOutput}`));
          }
        });
      } catch (error) {
        console.error('Erro ao extrair texto da imagem com PaddleOCR:', error);
        reject(error);
      }
    });
  }

  /**
   * Converte PDF para imagens e realiza OCR com PaddleOCR
   * @param {string} pdfPath Caminho do arquivo PDF
   * @param {Object} options Opções adicionais
   * @returns {Promise<string>} Texto extraído de todas as páginas
   */
  async extractTextFromPDF(pdfPath, options = {}) {
    try {
      // Verificar se o arquivo existe
      if (!await fsExists(pdfPath)) {
        throw new Error(`Arquivo PDF não encontrado: ${pdfPath}`);
      }

      // Criar diretório temporário para as imagens
      const tempDir = path.join(this.tempDir, 'pdf_' + Date.now());
      if (!await fsExists(tempDir)) {
        await fsMkdir(tempDir, { recursive: true });
      }

      console.log(`Convertendo PDF para imagens: ${pdfPath}`);
      
      // Criar script Python para converter PDF e realizar OCR
      const pythonScript = `
import sys
import json
import os
import fitz  # PyMuPDF
from paddleocr import PaddleOCR

try:
    # Abrir PDF
    pdf_path = '${pdfPath.replace(/\\/g, '\\\\')}'
    temp_dir = '${tempDir.replace(/\\/g, '\\\\')}'
    
    # Inicializar PaddleOCR com suporte a português
    ocr = PaddleOCR(use_angle_cls=True, lang='por')
    
    # Abrir PDF
    pdf_document = fitz.open(pdf_path)
    
    # Extrair texto de cada página
    all_text = []
    
    for page_num in range(len(pdf_document)):
        page = pdf_document[page_num]
        
        # Renderizar página como imagem
        pix = page.get_pixmap(matrix=fitz.Matrix(300/72, 300/72))
        image_path = os.path.join(temp_dir, f"page_{page_num+1}.png")
        pix.save(image_path)
        
        # Realizar OCR na imagem
        result = ocr.ocr(image_path, cls=True)
        
        # Extrair texto
        page_text = ""
        for idx in range(len(result)):
            res = result[idx]
            for line in res:
                page_text += line[1][0] + "\\n"
        
        all_text.append(page_text)
        
        # Remover imagem temporária
        os.remove(image_path)
    
    # Fechar PDF
    pdf_document.close()
    
    # Combinar texto de todas as páginas
    combined_text = "\\n\\n--- Nova Página ---\\n\\n".join(all_text)
    
    # Imprimir resultado como JSON
    output = {
        "success": True,
        "text": combined_text,
        "pages": len(all_text)
    }
    print(json.dumps(output))
    sys.exit(0)
except Exception as e:
    # Imprimir erro como JSON
    error_output = {
        "success": False,
        "error": str(e)
    }
    print(json.dumps(error_output))
    sys.exit(1)
`;

      const scriptPath = path.join(this.tempDir, `paddleocr_pdf_${Date.now()}.py`);
      
      // Salvar script temporário
      await fsWriteFile(scriptPath, pythonScript);
      
      // Executar script Python
      return new Promise((resolve, reject) => {
        const process = spawn(this.pythonPath, [scriptPath]);
        
        let output = '';
        process.stdout.on('data', (data) => {
          output += data.toString();
        });
        
        let errorOutput = '';
        process.stderr.on('data', (data) => {
          errorOutput += data.toString();
        });
        
        process.on('close', async (code) => {
          // Limpar arquivos temporários
          try {
            await fsUnlink(scriptPath);
            // O script Python já remove as imagens temporárias
          } catch (error) {
            console.error('Erro ao remover arquivos temporários:', error);
          }
          
          if (code === 0) {
            try {
              // Parsear resultado JSON
              const result = JSON.parse(output);
              
              if (result.success) {
                console.log(`OCR concluído com sucesso para PDF: ${pdfPath}`);
                console.log(`Páginas processadas: ${result.pages}`);
                resolve(result.text);
              } else {
                console.error(`Erro no OCR do PDF: ${result.error}`);
                reject(new Error(result.error));
              }
            } catch (error) {
              console.error('Erro ao parsear resultado do OCR do PDF:', error);
              console.error('Output:', output);
              reject(error);
            }
          } else {
            console.error(`Processo de OCR do PDF falhou com código ${code}`);
            console.error(errorOutput);
            reject(new Error(`Processo de OCR do PDF falhou: ${errorOutput}`));
          }
        });
      });
    } catch (error) {
      console.error('Erro ao extrair texto do PDF com PaddleOCR:', error);
      throw error;
    }
  }

  /**
   * Extrai dados estruturados de texto usando regras simples
   * @param {string} text Texto extraído via OCR
   * @param {Object} patterns Padrões de expressões regulares para extração
   * @returns {Object} Dados estruturados extraídos
   */
  extractStructuredData(text, patterns) {
    const result = {};
    
    // Processar cada padrão de extração
    for (const [key, pattern] of Object.entries(patterns)) {
      const regex = new RegExp(pattern, 'i');
      const match = text.match(regex);
      
      if (match && match[1]) {
        result[key] = match[1].trim();
      }
    }
    
    return result;
  }

  /**
   * Instala dependências Python necessárias para o PaddleOCR
   * @returns {Promise<boolean>} True se a instalação for bem-sucedida
   */
  async installDependencies() {
    return new Promise((resolve) => {
      console.log('Instalando dependências do PaddleOCR...');
      
      // Comando para instalar dependências
      const process = spawn(this.pythonPath, [
        '-m', 'pip', 'install', 
        'paddlepaddle', 'paddleocr', 'pymupdf', 
        '--quiet'
      ]);
      
      let output = '';
      process.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      let errorOutput = '';
      process.stderr.on('data', (data) => {
        errorOutput += data.toString();
      });
      
      process.on('close', (code) => {
        if (code === 0) {
          console.log('Dependências do PaddleOCR instaladas com sucesso.');
          resolve(true);
        } else {
          console.error('Falha ao instalar dependências do PaddleOCR.');
          console.error(errorOutput);
          resolve(false);
        }
      });
    });
  }
}

// Exportar instância única do serviço
const paddleOCRService = new PaddleOCRService();

module.exports = paddleOCRService;
