import sys
import json
import os
from paddleocr import PaddleOCR

# Script para extração de texto do PaddleOCR para integração com Node.js
try:
    # Caminho da imagem de teste
    image_path = sys.argv[1] if len(sys.argv) > 1 else '/home/ubuntu/actcredit/actcredit/src/tests/test_ocr/test_text.png'
    
    # Verificar se o arquivo existe
    if not os.path.exists(image_path):
        print(json.dumps({"success": False, "error": f"Arquivo não encontrado: {image_path}"}))
        sys.exit(1)
    
    # Inicializar PaddleOCR com configurações básicas
    ocr = PaddleOCR(lang='por')
    
    # Realizar OCR na imagem
    result = ocr.predict(image_path)
    
    # Extrair texto do formato correto do resultado
    extracted_text = ""
    confidence = 0.0
    count = 0
    
    if result and len(result) > 0:
        # Verificar se temos o campo rec_texts no resultado
        if hasattr(result[0], 'rec_texts') or (isinstance(result[0], dict) and 'rec_texts' in result[0]):
            # Acessar rec_texts como atributo ou chave de dicionário
            rec_texts = result[0].rec_texts if hasattr(result[0], 'rec_texts') else result[0]['rec_texts']
            rec_scores = result[0].rec_scores if hasattr(result[0], 'rec_scores') else result[0]['rec_scores']
            
            # Juntar todos os textos reconhecidos
            for i, text in enumerate(rec_texts):
                extracted_text += text + "\n"
                if i < len(rec_scores):
                    confidence += rec_scores[i]
                    count += 1
    
    # Calcular confiança média
    avg_confidence = confidence / count if count > 0 else 0
    
    # Imprimir resultado como JSON para facilitar parsing no Node.js
    output = {
        "success": True,
        "text": extracted_text,
        "confidence": avg_confidence,
        "result_length": len(result) if result else 0
    }
    print(json.dumps(output))
    sys.exit(0)
except Exception as e:
    import traceback
    # Imprimir erro como JSON com stack trace
    error_output = {
        "success": False,
        "error": str(e),
        "traceback": traceback.format_exc()
    }
    print(json.dumps(error_output))
    sys.exit(1)
