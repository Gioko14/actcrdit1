/**
 * Serviço de OCR utilizando Tesseract
 * Fornece funcionalidades de reconhecimento ótico de caracteres para o extrator
 */

const tesseract = require('node-tesseract-ocr');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

// Configuração padrão do Tesseract
const defaultConfig = {
  lang: 'por+eng', // Português e Inglês
  oem: 1,          // Modo de OCR Engine (1 = Neural nets LSTM)
  psm: 3,          // Page Segmentation Mode (3 = Auto com OSD)
  dpi: 300,
  'tessdata-dir': '/usr/share/tesseract-ocr/4.00/tessdata'
};

/**
 * Serviço de OCR com Tesseract
 */
class TesseractService {
  constructor(config = {}) {
    this.config = { ...defaultConfig, ...config };
  }

  /**
   * Realiza OCR em uma imagem
   * @param {string} imagePath Caminho da imagem
   * @param {Object} options Opções adicionais
   * @returns {Promise<string>} Texto extraído
   */
  async extractTextFromImage(imagePath, options = {}) {
    try {
      // Verificar se o arquivo existe
      if (!fs.existsSync(imagePath)) {
        throw new Error(`Arquivo não encontrado: ${imagePath}`);
      }

      const config = { ...this.config, ...options };
      console.log(`Iniciando OCR na imagem: ${imagePath}`);
      
      const text = await tesseract.recognize(imagePath, config);
      console.log(`OCR concluído com sucesso para: ${imagePath}`);
      
      return text;
    } catch (error) {
      console.error('Erro ao extrair texto da imagem:', error);
      throw error;
    }
  }

  /**
   * Converte PDF para imagens e realiza OCR
   * @param {string} pdfPath Caminho do arquivo PDF
   * @param {Object} options Opções adicionais
   * @returns {Promise<string>} Texto extraído de todas as páginas
   */
  async extractTextFromPDF(pdfPath, options = {}) {
    try {
      // Verificar se o arquivo existe
      if (!fs.existsSync(pdfPath)) {
        throw new Error(`Arquivo PDF não encontrado: ${pdfPath}`);
      }

      // Criar diretório temporário para as imagens
      const tempDir = path.join(path.dirname(pdfPath), 'temp_ocr_' + Date.now());
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir);
      }

      console.log(`Convertendo PDF para imagens: ${pdfPath}`);
      
      // Converter PDF para imagens usando pdftoppm (parte do poppler-utils)
      const outputPrefix = path.join(tempDir, 'page');
      await execPromise(`pdftoppm -png -r 300 "${pdfPath}" "${outputPrefix}"`);
      
      // Listar todas as imagens geradas
      const files = fs.readdirSync(tempDir).filter(file => file.startsWith('page') && file.endsWith('.png'));
      files.sort(); // Garantir ordem correta das páginas
      
      console.log(`PDF convertido em ${files.length} imagens`);
      
      // Processar cada imagem com OCR
      const textPromises = files.map(file => {
        const imagePath = path.join(tempDir, file);
        return this.extractTextFromImage(imagePath, options);
      });
      
      // Aguardar processamento de todas as imagens
      const textResults = await Promise.all(textPromises);
      
      // Concatenar resultados
      const fullText = textResults.join('\n\n--- Nova Página ---\n\n');
      
      // Limpar arquivos temporários
      files.forEach(file => {
        fs.unlinkSync(path.join(tempDir, file));
      });
      fs.rmdirSync(tempDir);
      
      return fullText;
    } catch (error) {
      console.error('Erro ao extrair texto do PDF:', error);
      throw error;
    }
  }

  /**
   * Extrai dados estruturados de texto usando regras simples
   * @param {string} text Texto extraído via OCR
   * @param {Object} patterns Padrões de expressões regulares para extração
   * @returns {Object} Dados estruturados extraídos
   */
  extractStructuredData(text, patterns) {
    const result = {};
    
    // Processar cada padrão de extração
    for (const [key, pattern] of Object.entries(patterns)) {
      const regex = new RegExp(pattern, 'i');
      const match = text.match(regex);
      
      if (match && match[1]) {
        result[key] = match[1].trim();
      }
    }
    
    return result;
  }

  /**
   * Verifica se o Tesseract está instalado e funcionando
   * @returns {Promise<boolean>} True se o Tesseract estiver funcionando
   */
  async checkTesseractInstallation() {
    try {
      const { stdout } = await execPromise('tesseract --version');
      console.log('Tesseract instalado:', stdout.split('\n')[0]);
      return true;
    } catch (error) {
      console.error('Erro ao verificar instalação do Tesseract:', error);
      return false;
    }
  }
}

// Exportar instância única do serviço
const tesseractService = new TesseractService();

module.exports = tesseractService;
