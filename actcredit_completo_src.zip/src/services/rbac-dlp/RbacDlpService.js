/**
 * Serviço de RBAC (Role-Based Access Control) e DLP (Data Loss Prevention)
 * Implementação com SQLite para substituir simulações por dados reais
 */

import { v4 as uuidv4 } from 'uuid';
import ApiClient from '../../utils/ApiClient';
import logger from '../../utils/Logger';

/**
 * Classe para gerenciamento de controle de acesso baseado em papéis e prevenção de perda de dados
 * Integrada com SQLite para dados reais
 */
export class RbacDlpService {
  constructor(config = {}) {
    this.config = {
      apiBaseUrl: config.apiBaseUrl || '/api',
      cacheEnabled: config.cacheEnabled !== undefined ? config.cacheEnabled : true,
      cacheTTL: config.cacheTTL || 300000, // 5 minutos em ms
      ...config
    };

    // Cliente API para comunicação com o backend SQLite
    this.apiClient = new ApiClient(this.config.apiBaseUrl);
    
    // Cache de resultados
    this.cache = new Map();
    
    // Cache de permissões do usuário
    this.userPermissionsCache = new Map();
  }

  /**
   * Verifica se um usuário tem uma permissão específica
   * @param {string} userId ID do usuário
   * @param {string} permission Permissão a ser verificada
   * @returns {Promise<boolean>} Resultado da verificação
   */
  async hasPermission(userId, permission) {
    try {
      logger.info(`[RbacDlpService] Verificando permissão ${permission} para usuário ${userId}`);
      
      // Verificar cache de permissões do usuário
      const cacheKey = `permissions_${userId}`;
      let userPermissions;
      
      if (this.config.cacheEnabled) {
        const cachedPermissions = this.userPermissionsCache.get(cacheKey);
        if (cachedPermissions && cachedPermissions.expiresAt > Date.now()) {
          userPermissions = cachedPermissions.permissions;
        }
      }
      
      // Se não estiver em cache, buscar permissões do usuário
      if (!userPermissions) {
        const response = await this.apiClient.get(`/rbac/permissions/${userId}`);
        userPermissions = response.data.permissions || [];
        
        // Armazenar no cache
        if (this.config.cacheEnabled) {
          this.userPermissionsCache.set(cacheKey, {
            permissions: userPermissions,
            expiresAt: Date.now() + this.config.cacheTTL
          });
        }
      }
      
      // Verificar se o usuário tem a permissão específica
      const hasPermission = userPermissions.includes(permission);
      
      logger.info(`[RbacDlpService] Usuário ${userId} ${hasPermission ? 'tem' : 'não tem'} permissão ${permission}`);
      return hasPermission;
    } catch (error) {
      logger.error('[RbacDlpService] Erro ao verificar permissão:', error);
      // Em caso de erro, negar acesso por segurança
      return false;
    }
  }

  /**
   * Verifica se um usuário tem um papel específico
   * @param {string} userId ID do usuário
   * @param {string} role Papel a ser verificado
   * @returns {Promise<boolean>} Resultado da verificação
   */
  async hasRole(userId, role) {
    try {
      logger.info(`[RbacDlpService] Verificando papel ${role} para usuário ${userId}`);
      
      // Verificar cache de papéis do usuário
      const cacheKey = `roles_${userId}`;
      let userRoles;
      
      if (this.config.cacheEnabled) {
        const cachedRoles = this.cache.get(cacheKey);
        if (cachedRoles && cachedRoles.expiresAt > Date.now()) {
          userRoles = cachedRoles.roles;
        }
      }
      
      // Se não estiver em cache, buscar papéis do usuário
      if (!userRoles) {
        const response = await this.apiClient.get(`/rbac/roles/${userId}`);
        userRoles = response.data.roles || [];
        
        // Armazenar no cache
        if (this.config.cacheEnabled) {
          this.cache.set(cacheKey, {
            roles: userRoles,
            expiresAt: Date.now() + this.config.cacheTTL
          });
        }
      }
      
      // Verificar se o usuário tem o papel específico
      const hasRole = userRoles.includes(role);
      
      logger.info(`[RbacDlpService] Usuário ${userId} ${hasRole ? 'tem' : 'não tem'} papel ${role}`);
      return hasRole;
    } catch (error) {
      logger.error('[RbacDlpService] Erro ao verificar papel:', error);
      // Em caso de erro, negar acesso por segurança
      return false;
    }
  }

  /**
   * Obtém todos os papéis de um usuário
   * @param {string} userId ID do usuário
   * @returns {Promise<Object>} Papéis do usuário
   */
  async getUserRoles(userId) {
    try {
      logger.info(`[RbacDlpService] Obtendo papéis do usuário ${userId}`);
      
      // Verificar cache
      const cacheKey = `roles_${userId}`;
      if (this.config.cacheEnabled) {
        const cachedRoles = this.cache.get(cacheKey);
        if (cachedRoles && cachedRoles.expiresAt > Date.now()) {
          logger.info('[RbacDlpService] Retornando papéis do cache');
          return { success: true, roles: cachedRoles.roles };
        }
      }
      
      // Obter papéis da API
      const response = await this.apiClient.get(`/rbac/roles/${userId}`);
      
      // Processar resultado
      const result = response.data;
      
      // Armazenar no cache
      if (this.config.cacheEnabled) {
        this.cache.set(cacheKey, {
          roles: result.roles || [],
          expiresAt: Date.now() + this.config.cacheTTL
        });
      }
      
      logger.info('[RbacDlpService] Papéis obtidos com sucesso');
      return result;
    } catch (error) {
      logger.error('[RbacDlpService] Erro ao obter papéis:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao obter papéis'
      };
    }
  }

  /**
   * Obtém todas as permissões de um usuário
   * @param {string} userId ID do usuário
   * @returns {Promise<Object>} Permissões do usuário
   */
  async getUserPermissions(userId) {
    try {
      logger.info(`[RbacDlpService] Obtendo permissões do usuário ${userId}`);
      
      // Verificar cache
      const cacheKey = `permissions_${userId}`;
      if (this.config.cacheEnabled) {
        const cachedPermissions = this.userPermissionsCache.get(cacheKey);
        if (cachedPermissions && cachedPermissions.expiresAt > Date.now()) {
          logger.info('[RbacDlpService] Retornando permissões do cache');
          return { success: true, permissions: cachedPermissions.permissions };
        }
      }
      
      // Obter permissões da API
      const response = await this.apiClient.get(`/rbac/permissions/${userId}`);
      
      // Processar resultado
      const result = response.data;
      
      // Armazenar no cache
      if (this.config.cacheEnabled) {
        this.userPermissionsCache.set(cacheKey, {
          permissions: result.permissions || [],
          expiresAt: Date.now() + this.config.cacheTTL
        });
      }
      
      logger.info('[RbacDlpService] Permissões obtidas com sucesso');
      return result;
    } catch (error) {
      logger.error('[RbacDlpService] Erro ao obter permissões:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao obter permissões'
      };
    }
  }

  /**
   * Aplica políticas de DLP a dados sensíveis
   * @param {Object} data Dados a serem processados
   * @param {Array} policies Políticas de DLP a serem aplicadas
   * @returns {Promise<Object>} Dados processados
   */
  async applyDlpPolicies(data, policies) {
    try {
      logger.info('[RbacDlpService] Aplicando políticas de DLP aos dados');
      
      // Validar dados de entrada
      if (!data) {
        throw new Error('Dados não fornecidos');
      }
      
      if (!Array.isArray(policies) || policies.length === 0) {
        // Se não houver políticas, retornar os dados originais
        return { success: true, data };
      }
      
      // Enviar dados para API de DLP
      const payload = {
        data,
        policies
      };
      
      const response = await this.apiClient.post('/dlp/apply', payload);
      
      logger.info('[RbacDlpService] Políticas de DLP aplicadas com sucesso');
      return response.data;
    } catch (error) {
      logger.error('[RbacDlpService] Erro ao aplicar políticas de DLP:', error);
      return {
        success: false,
        error: error.response?.data?.error || error.message || 'Erro ao aplicar políticas de DLP'
      };
    }
  }
}

// Exportar instância singleton para uso em toda a aplicação
const rbacDlpService = new RbacDlpService();
export default rbacDlpService;
