import React from 'react';
import { FileText, Image, FileSpreadsheet, Eye, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

const RealTimePreview = ({ fileType, fileName }) => {
  // Função para renderizar o ícone apropriado com base no tipo de arquivo
  const renderFileIcon = (fileType) => {
    switch(fileType) {
      case 'pdf':
        return <FileText className="h-5 w-5 text-red-500" />;
      case 'docx':
        return <FileText className="h-5 w-5 text-purple-500" />;
      case 'xlsx':
        return <FileSpreadsheet className="h-5 w-5 text-green-500" />;
      case 'image':
        return <Image className="h-5 w-5 text-blue-500" />;
      default:
        return <FileText className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <div className="bg-[#0f2544] border border-[#1e3a5f] rounded-lg p-4">
      {fileType === 'pdf' ? (
        <div className="flex flex-col items-center justify-center py-8">
          <FileText className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">{fileName}</h3>
          <p className="text-gray-400 text-sm mb-4">Documento PDF</p>
          <div className="flex space-x-2">
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Eye className="h-4 w-4 mr-2" />
              Visualizar
            </Button>
            <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
              <Download className="h-4 w-4 mr-2" />
              Download
            </Button>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            {renderFileIcon(fileType)}
            <div className="ml-3">
              <h4 className="font-medium">{fileName}</h4>
              <p className="text-gray-400 text-sm">
                {fileType === 'docx' && 'Documento Word'}
                {fileType === 'xlsx' && 'Planilha Excel'}
                {fileType === 'image' && 'Imagem'}
                {!['docx', 'xlsx', 'image'].includes(fileType) && 'Documento'}
              </p>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button variant="ghost" size="sm" className="text-blue-500 hover:text-blue-400">
              <Eye className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default RealTimePreview;
