import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import BiAnalyticsService from '@/services/bi-analytics/BiAnalyticsService';

const NovaAnaliseModal = ({ isOpen, onClose }) => {
  const navigate = useNavigate();
  const [cnpj, setCnpj] = useState('');
  const [tipoAnalise, setTipoAnalise] = useState('Majoração');
  const [loading, setLoading] = useState(false);

  // Fechar o modal
  const handleClose = () => {
    setCnpj('');
    setTipoAnalise('Majoração');
    onClose();
  };

  // Iniciar análise
  const handleIniciarAnalise = async () => {
    if (!cnpj.trim()) {
      toast.error("Por favor, informe o CNPJ");
      return;
    }

    try {
      setLoading(true);
      
      // Criar objeto de análise
      const novaAnalise = {
        nomeCliente: "Cliente " + cnpj.substring(0, 6),
        cnpjCliente: cnpj,
        tipoAnalise: tipoAnalise,
        dataAnalise: new Date().toISOString(),
        score: Math.floor(Math.random() * 40) + 60,
        decisao: Math.random() > 0.3 ? 'Aprovado' : Math.random() > 0.5 ? 'Aprovado com Condições' : 'Análise Manual',
        modalidadeCredito: tipoAnalise,
        serasaScore: Math.floor(Math.random() * 700) + 300,
        serasaPendencias: Math.random() > 0.8 ? ['Pendência Financeira XPTO', 'Protesto Cartório Y'] : [],
        serasaConsultado: true,
        valorSolicitado: Math.floor(Math.random() * 500000) + 100000,
        faturamentoAnual: Math.floor(Math.random() * 5000000) + 1000000,
        percentualEndividamento: Math.floor(Math.random() * 40) + 10,
        tempoAtividade: Math.floor(Math.random() * 10) + 1
      };
      
      // Adicionar à lista usando o serviço
      await BiAnalyticsService.adicionarAnalise(novaAnalise);
      
      // Fechar modal e mostrar mensagem de sucesso
      handleClose();
      toast.success("Análise iniciada com sucesso!");
      
      // Redirecionar para a lista de análises
      navigate('/dashboard/analises');
    } catch (error) {
      console.error('Erro ao iniciar análise:', error);
      toast.error("Erro ao iniciar análise. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  // Formatar CNPJ enquanto digita
  const handleCnpjChange = (e) => {
    let value = e.target.value;
    value = value.replace(/\D/g, ''); // Remove caracteres não numéricos
    
    if (value.length <= 14) {
      // Formatar como CNPJ: 00.000.000/0000-00
      value = value.replace(/^(\d{2})(\d)/, '$1.$2');
      value = value.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3');
      value = value.replace(/\.(\d{3})(\d)/, '.$1/$2');
      value = value.replace(/(\d{4})(\d)/, '$1-$2');
      
      setCnpj(value);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-[#0f2544] border border-[#1e3a5f] rounded-lg w-full max-w-md p-6 relative">
        <button 
          onClick={handleClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
        >
          <X className="h-5 w-5" />
        </button>
        
        <h2 className="text-xl font-semibold mb-6">Nova Análise</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">CNPJ</label>
            <input 
              type="text"
              value={cnpj}
              onChange={handleCnpjChange}
              className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
              placeholder="00.000.000/0000-00"
            />
            <p className="text-xs text-gray-400 mt-1">Insira o CNPJ da empresa para análise</p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">Tipo de Análise</label>
            <select 
              value={tipoAnalise}
              onChange={(e) => setTipoAnalise(e.target.value)}
              className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
            >
              <option value="Majoração">Majoração</option>
              <option value="Reativação">Reativação</option>
              <option value="Prospecção">Prospecção</option>
              <option value="Revisão">Revisão</option>
            </select>
            <p className="text-xs text-gray-400 mt-1">Selecione o tipo de análise a ser realizada</p>
          </div>
        </div>
        
        <div className="flex justify-end space-x-3 mt-6">
          <Button 
            variant="outline" 
            className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white"
            onClick={handleClose}
            disabled={loading}
          >
            Cancelar
          </Button>
          <Button 
            className="bg-blue-600 hover:bg-blue-700"
            onClick={handleIniciarAnalise}
            disabled={loading}
          >
            {loading ? 'Processando...' : 'Iniciar Análise'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NovaAnaliseModal;
