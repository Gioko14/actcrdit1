import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Printer, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  ChevronRight,
  ChevronDown,
  Shield,
  TrendingUp,
  TrendingDown,
  Percent,
  DollarSign,
  Calendar,
  Building,
  MapPin,
  User,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { formatCurrency } from '@/lib/utils';

const RelatorioAnaliseCompleto = ({ analise }) => {
  const [expandedSections, setExpandedSections] = useState({
    dadosCliente: true,
    dadosAnalise: true,
    resultadosPoliticas: true,
    fatores: true,
    condicoes: true
  });

  // Função para alternar a expansão de uma seção
  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  // Renderizar badge de status com cor apropriada
  const renderStatusBadge = (status) => {
    let color = '';
    let icon = null;
    
    switch(status) {
      case 'Aprovado':
        color = 'bg-green-500/20 text-green-500 border-green-500/50';
        icon = <CheckCircle className="h-4 w-4 mr-1" />;
        break;
      case 'Aprovado com Condições':
        color = 'bg-blue-500/20 text-blue-500 border-blue-500/50';
        icon = <CheckCircle className="h-4 w-4 mr-1" />;
        break;
      case 'Análise Manual':
        color = 'bg-yellow-500/20 text-yellow-500 border-yellow-500/50';
        icon = <AlertTriangle className="h-4 w-4 mr-1" />;
        break;
      case 'Reprovado':
        color = 'bg-red-500/20 text-red-500 border-red-500/50';
        icon = <XCircle className="h-4 w-4 mr-1" />;
        break;
      default:
        color = 'bg-gray-500/20 text-gray-500 border-gray-500/50';
    }
    
    return (
      <span className={`px-2 py-1 rounded text-xs border flex items-center ${color}`}>
        {icon}
        {status}
      </span>
    );
  };

  // Renderizar barra de score com cor apropriada
  const renderScoreBar = (score) => {
    if (!score && score !== 0) return <span className="text-gray-400">N/A</span>;
    
    let color = '';
    
    if (score >= 80) {
      color = 'bg-green-500';
    } else if (score >= 60) {
      color = 'bg-yellow-500';
    } else {
      color = 'bg-red-500';
    }
    
    return (
      <div className="flex items-center">
        <span className="mr-2 font-semibold">{score}</span>
        <div className="h-2 w-16 bg-gray-700 rounded-full">
          <div className={`h-2 rounded-full ${color}`} style={{ width: `${score}%` }}></div>
        </div>
      </div>
    );
  };

  // Renderizar resultado de política
  const renderResultadoPolitica = (resultado) => {
    let color = '';
    let icon = null;
    
    switch(resultado) {
      case 'Cumprida':
        color = 'text-green-500';
        icon = <CheckCircle className="h-4 w-4 mr-1" />;
        break;
      case 'Não Cumprida':
        color = 'text-red-500';
        icon = <XCircle className="h-4 w-4 mr-1" />;
        break;
      default:
        color = 'text-gray-500';
        icon = <AlertTriangle className="h-4 w-4 mr-1" />;
    }
    
    return (
      <span className={`flex items-center ${color}`}>
        {icon}
        {resultado}
      </span>
    );
  };

  // Verificar se a análise existe
  if (!analise) {
    return (
      <div className="p-8 text-center">
        <FileText className="h-12 w-12 mx-auto mb-4 text-gray-500" />
        <h3 className="text-xl font-medium mb-2">Análise não encontrada</h3>
        <p className="text-gray-400">
          Não foi possível carregar os detalhes da análise solicitada.
        </p>
      </div>
    );
  }

  // Formatar data
  const formatarData = (dataString) => {
    if (!dataString) return 'N/A';
    
    try {
      if (dataString.includes('/')) {
        return dataString; // Já está formatada
      }
      
      const data = new Date(dataString);
      return data.toLocaleDateString('pt-BR');
    } catch (error) {
      console.error('Erro ao formatar data:', error);
      return 'N/A';
    }
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho do Relatório */}
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-2xl font-bold mb-1">
            Relatório de Análise de Crédito
          </h2>
          <p className="text-gray-400">
            {analise.nomeCliente || analise.cliente || 'Cliente não identificado'} • {formatarData(analise.dataAnalise || analise.data)}
          </p>
        </div>
        
        <div className="flex space-x-2">
          <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
          <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
            <Printer className="h-4 w-4 mr-2" />
            Imprimir
          </Button>
        </div>
      </div>
      
      {/* Resumo da Análise */}
      <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-400 mb-1">Score ActCredit</h3>
              <div className="flex items-center">
                <div className="text-3xl font-bold mr-3">{analise.score || 'N/A'}</div>
                {renderScoreBar(analise.score)}
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-400 mb-1">Score Serasa</h3>
              <div className="flex items-center">
                {analise.serasaConsultado ? (
                  <>
                    <Shield className="h-5 w-5 mr-2 text-blue-500" />
                    <div className="text-3xl font-bold">{analise.serasaScore || 'OK'}</div>
                  </>
                ) : (
                  <span className="text-gray-500">Não consultado</span>
                )}
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-400 mb-1">Decisão</h3>
              <div className="text-xl">
                {renderStatusBadge(analise.decisao || analise.status || 'N/A')}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Dados do Cliente */}
      <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
        <CardHeader 
          className="p-4 border-b border-[#1e3a5f] cursor-pointer"
          onClick={() => toggleSection('dadosCliente')}
        >
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg font-medium flex items-center">
              <Building className="h-5 w-5 mr-2" />
              Dados do Cliente
            </CardTitle>
            {expandedSections.dadosCliente ? (
              <ChevronDown className="h-5 w-5" />
            ) : (
              <ChevronRight className="h-5 w-5" />
            )}
          </div>
        </CardHeader>
        
        {expandedSections.dadosCliente && (
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">Nome/Razão Social</h4>
                  <p>{analise.nomeCliente || analise.cliente || 'N/A'}</p>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">CNPJ</h4>
                  <p>{analise.cnpjCliente || 'N/A'}</p>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">Setor</h4>
                  <p>{analise.setorCliente || 'N/A'}</p>
                </div>
              </div>
              
              <div>
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">Região</h4>
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1 text-gray-400" />
                    <p>{analise.regiaoCliente || 'N/A'}</p>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">Tempo de Atividade</h4>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1 text-gray-400" />
                    <p>{analise.tempoAtividade ? `${analise.tempoAtividade} anos` : 'N/A'}</p>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">Faturamento Anual</h4>
                  <div className="flex items-center">
                    <DollarSign className="h-4 w-4 mr-1 text-gray-400" />
                    <p>{analise.faturamentoAnual ? formatCurrency(analise.faturamentoAnual) : 'N/A'}</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        )}
      </Card>
      
      {/* Dados da Análise */}
      <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
        <CardHeader 
          className="p-4 border-b border-[#1e3a5f] cursor-pointer"
          onClick={() => toggleSection('dadosAnalise')}
        >
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg font-medium flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Dados da Análise
            </CardTitle>
            {expandedSections.dadosAnalise ? (
              <ChevronDown className="h-5 w-5" />
            ) : (
              <ChevronRight className="h-5 w-5" />
            )}
          </div>
        </CardHeader>
        
        {expandedSections.dadosAnalise && (
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">ID da Análise</h4>
                  <p>{analise.id || 'N/A'}</p>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">Data da Análise</h4>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1 text-gray-400" />
                    <p>{formatarData(analise.dataAnalise || analise.data)}</p>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">Tipo de Análise</h4>
                  <p>{analise.tipoAnalise || analise.tipo || 'N/A'}</p>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">Modalidade de Crédito</h4>
                  <p>{analise.modalidadeCredito || 'N/A'}</p>
                </div>
              </div>
              
              <div>
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">Valor Solicitado</h4>
                  <div className="flex items-center">
                    <DollarSign className="h-4 w-4 mr-1 text-gray-400" />
                    <p>{analise.valorSolicitado ? formatCurrency(analise.valorSolicitado) : 'N/A'}</p>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">Percentual de Endividamento</h4>
                  <div className="flex items-center">
                    <Percent className="h-4 w-4 mr-1 text-gray-400" />
                    <p>{analise.percentualEndividamento ? `${analise.percentualEndividamento}%` : 'N/A'}</p>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">Prazo Desejado</h4>
                  <p>{analise.prazoDesejado ? `${analise.prazoDesejado} meses` : 'N/A'}</p>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-1">Probabilidade de Default</h4>
                  <p>{analise.probabilidadeDefault !== undefined ? `${(analise.probabilidadeDefault * 100).toFixed(2)}%` : 'N/A'}</p>
                </div>
              </div>
            </div>
            
            <div className="mt-4">
              <h4 className="text-sm font-medium text-gray-400 mb-1">Justificativa</h4>
              <p className="text-sm">{analise.justificativa || 'Não informada'}</p>
            </div>
          </CardContent>
        )}
      </Card>
      
      {/* Resultados das Políticas */}
      <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
        <CardHeader 
          className="p-4 border-b border-[#1e3a5f] cursor-pointer"
          onClick={() => toggleSection('resultadosPoliticas')}
        >
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg font-medium flex items-center">
              <Shield className="h-5 w-5 mr-2" />
              Resultados das Políticas
            </CardTitle>
            {expandedSections.resultadosPoliticas ? (
              <ChevronDown className="h-5 w-5" />
            ) : (
              <ChevronRight className="h-5 w-5" />
            )}
          </div>
        </CardHeader>
        
        {expandedSections.resultadosPoliticas && (
          <CardContent className="p-6">
            {analise.resultadosPoliticas && analise.resultadosPoliticas.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#1e3a5f]">
                      <th className="text-left p-2 text-gray-400 font-medium">Política</th>
                      <th className="text-left p-2 text-gray-400 font-medium">Critério</th>
                      <th className="text-left p-2 text-gray-400 font-medium">Dado Verificado</th>
                      <th className="text-left p-2 text-gray-400 font-medium">Resultado</th>
                    </tr>
                  </thead>
                  <tbody>
                    {analise.resultadosPoliticas.map((politica, index) => (
                      <tr key={index} className="border-b border-[#1e3a5f]">
                        <td className="p-2">{politica.politica}</td>
                        <td className="p-2 text-sm">{politica.criterio}</td>
                        <td className="p-2">{politica.dadoVerificado}</td>
                        <td className="p-2">{renderResultadoPolitica(politica.resultado)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-400">Nenhuma política aplicada a esta análise.</p>
            )}
          </CardContent>
        )}
      </Card>
      
      {/* Fatores que Influenciaram o Score */}
      <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
        <CardHeader 
          className="p-4 border-b border-[#1e3a5f] cursor-pointer"
          onClick={() => toggleSection('fatores')}
        >
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg font-medium flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Fatores que Influenciaram o Score
            </CardTitle>
            {expandedSections.fatores ? (
              <ChevronDown className="h-5 w-5" />
            ) : (
              <ChevronRight className="h-5 w-5" />
            )}
          </div>
        </CardHeader>
        
        {expandedSections.fatores && (
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-sm font-medium text-gray-400 mb-3 flex items-center">
                  <TrendingUp className="h-4 w-4 mr-1 text-green-500" />
                  Fatores Positivos
                </h4>
                
                {analise.fatoresPositivos && analise.fatoresPositivos.length > 0 ? (
                  <ul className="space-y-2">
                    {analise.fatoresPositivos.map((fator, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-4 w-4 mr-2 text-green-500 mt-0.5" />
                        <span>{fator}</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-gray-400">Nenhum fator positivo identificado.</p>
                )}
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-400 mb-3 flex items-center">
                  <TrendingDown className="h-4 w-4 mr-1 text-red-500" />
                  Fatores Negativos
                </h4>
                
                {analise.fatoresNegativos && analise.fatoresNegativos.length > 0 ? (
                  <ul className="space-y-2">
                    {analise.fatoresNegativos.map((fator, index) => (
                      <li key={index} className="flex items-start">
                        <XCircle className="h-4 w-4 mr-2 text-red-500 mt-0.5" />
                        <span>{fator}</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-gray-400">Nenhum fator negativo identificado.</p>
                )}
              </div>
            </div>
          </CardContent>
        )}
      </Card>
      
      {/* Condições Aprovadas */}
      {(analise.decisao === 'Aprovado' || analise.decisao === 'Aprovado com Condições' || 
        analise.status === 'Aprovado' || analise.status === 'Aprovado com Condições') && (
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader 
            className="p-4 border-b border-[#1e3a5f] cursor-pointer"
            onClick={() => toggleSection('condicoes')}
          >
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg font-medium flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                Condições Aprovadas
              </CardTitle>
              {expandedSections.condicoes ? (
                <ChevronDown className="h-5 w-5" />
              ) : (
                <ChevronRight className="h-5 w-5" />
              )}
            </div>
          </CardHeader>
          
          {expandedSections.condicoes && (
            <CardContent className="p-6">
              {analise.condicoes ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-gray-400 mb-1">Limite Aprovado</h4>
                      <div className="text-xl font-semibold">
                        {formatCurrency(analise.condicoes.limiteAprovado)}
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-gray-400 mb-1">Taxa Aprovada</h4>
                      <div className="text-xl font-semibold">
                        {analise.condicoes.taxaAprovada}% a.m.
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-gray-400 mb-1">Prazo Aprovado</h4>
                      <div className="text-xl font-semibold">
                        {analise.condicoes.prazoAprovado} meses
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-gray-400 mb-1">Garantias Exigidas</h4>
                      {analise.condicoes.garantiasExigidas && analise.condicoes.garantiasExigidas.length > 0 ? (
                        <ul className="space-y-1">
                          {analise.condicoes.garantiasExigidas.map((garantia, index) => (
                            <li key={index} className="flex items-center">
                              <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                              {garantia}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-gray-400">Nenhuma garantia exigida</p>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-gray-400">Informações sobre condições aprovadas não disponíveis.</p>
              )}
            </CardContent>
          )}
        </Card>
      )}
    </div>
  );
};

export default RelatorioAnaliseCompleto;
