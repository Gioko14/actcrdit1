import React from 'react';
import { FileText, Image, FileSpreadsheet, FileCode, Upload, CheckCircle, AlertCircle } from 'lucide-react';

const MultiFormatSupport = ({ format }) => {
  // Função para renderizar o ícone apropriado com base no formato
  const renderFormatIcon = (format) => {
    switch(format) {
      case 'image': return <Image className="h-6 w-6" />;
      case 'spreadsheet': return <FileSpreadsheet className="h-6 w-6" />;
      case 'code': return <FileCode className="h-6 w-6" />;
      case 'document': return <FileText className="h-6 w-6" />;
      default: return <FileText className="h-6 w-6" />;
    }
  };

  return (
    <div className="flex items-center">
      {renderFormatIcon(format)}
      <span className="ml-2">{format}</span>
    </div>
  );
};

export default MultiFormatSupport;
