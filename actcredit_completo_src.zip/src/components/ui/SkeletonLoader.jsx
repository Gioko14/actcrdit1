import React from 'react';
import { Loader2 } from 'lucide-react';

/**
 * Componente de Skeleton para carregamento de dados
 * Exibe um estado de carregamento visualmente agradável enquanto os dados são buscados
 */
const SkeletonLoader = ({
  type = 'card', // 'card', 'chart', 'table', 'kpi'
  rows = 3,
  height = null
}) => {
  // Skeleton para cards
  if (type === 'card') {
    return (
      <div className="bg-[#0f2544] border border-[#1e3a5f] rounded-lg p-4 w-full">
        <div className="flex items-center justify-between mb-4">
          <div className="h-4 bg-gray-700 rounded w-1/3 animate-pulse"></div>
          <div className="h-8 w-8 bg-gray-700 rounded-full animate-pulse"></div>
        </div>
        <div className="h-8 bg-gray-700 rounded w-1/2 mb-2 animate-pulse"></div>
        <div className="h-4 bg-gray-700 rounded w-1/4 animate-pulse"></div>
      </div>
    );
  }
  
  // Skeleton para gráficos
  if (type === 'chart') {
    return (
      <div 
        className="bg-[#0f2544] border border-[#1e3a5f] rounded-lg p-4 w-full flex flex-col"
        style={{ height: height || '300px' }}
      >
        <div className="h-4 bg-gray-700 rounded w-1/4 mb-4 animate-pulse"></div>
        <div className="flex-1 bg-gray-700/30 rounded animate-pulse"></div>
      </div>
    );
  }
  
  // Skeleton para tabelas
  if (type === 'table') {
    return (
      <div className="bg-[#0f2544] border border-[#1e3a5f] rounded-lg p-4 w-full">
        <div className="h-4 bg-gray-700 rounded w-1/4 mb-4 animate-pulse"></div>
        <div className="space-y-2">
          <div className="h-8 bg-gray-700/50 rounded w-full animate-pulse"></div>
          {Array(rows).fill(0).map((_, index) => (
            <div key={index} className="h-12 bg-gray-700/30 rounded w-full animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }
  
  // Skeleton para KPIs
  if (type === 'kpi') {
    return (
      <div className="bg-[#0f2544] border border-[#1e3a5f] rounded-lg p-4 w-full">
        <div className="h-4 bg-gray-700 rounded w-1/3 mb-3 animate-pulse"></div>
        <div className="h-8 bg-gray-700 rounded w-1/2 mb-2 animate-pulse"></div>
        <div className="h-4 bg-gray-700 rounded w-1/4 animate-pulse"></div>
      </div>
    );
  }
  
  // Loader genérico
  return (
    <div className="flex items-center justify-center p-4 h-full w-full">
      <Loader2 className="h-8 w-8 text-blue-500 animate-spin" />
    </div>
  );
};

export default SkeletonLoader;
