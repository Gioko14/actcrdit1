import React from 'react';
import { AlertCircle, AlertTriangle, Info } from 'lucide-react';

/**
 * Componente para exibição amigável de erros
 * Usado para mostrar mensagens de erro de forma visualmente agradável
 */
const ErrorDisplay = ({
  type = 'error', // 'error', 'warning', 'info'
  title,
  message,
  retryAction = null,
  compact = false
}) => {
  // Definir ícone e cores com base no tipo
  const getTypeStyles = () => {
    switch (type) {
      case 'warning':
        return {
          icon: <AlertTriangle className="h-5 w-5" />,
          bgColor: 'bg-yellow-500/20',
          textColor: 'text-yellow-500',
          borderColor: 'border-yellow-500/50'
        };
      case 'info':
        return {
          icon: <Info className="h-5 w-5" />,
          bgColor: 'bg-blue-500/20',
          textColor: 'text-blue-500',
          borderColor: 'border-blue-500/50'
        };
      default: // error
        return {
          icon: <AlertCircle className="h-5 w-5" />,
          bgColor: 'bg-red-500/20',
          textColor: 'text-red-500',
          borderColor: 'border-red-500/50'
        };
    }
  };
  
  const { icon, bgColor, textColor, borderColor } = getTypeStyles();
  
  // Versão compacta para uso em componentes menores
  if (compact) {
    return (
      <div className={`flex items-center p-2 rounded-md ${bgColor} ${borderColor} border`}>
        <div className={`mr-2 ${textColor}`}>{icon}</div>
        <div className="text-sm text-white">{message}</div>
        {retryAction && (
          <button 
            onClick={retryAction}
            className="ml-auto text-xs underline text-white hover:text-gray-300"
          >
            Tentar novamente
          </button>
        )}
      </div>
    );
  }
  
  // Versão completa para erros mais sérios ou que ocupam uma seção inteira
  return (
    <div className={`flex flex-col items-center justify-center p-6 rounded-lg ${bgColor} ${borderColor} border text-center h-full`}>
      <div className={`mb-3 ${textColor}`}>
        {React.cloneElement(icon, { className: 'h-10 w-10' })}
      </div>
      {title && <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>}
      <p className="text-sm text-gray-300 mb-4">{message}</p>
      {retryAction && (
        <button 
          onClick={retryAction}
          className={`px-4 py-2 rounded-md ${textColor} ${borderColor} border hover:bg-opacity-20 hover:bg-white transition-colors`}
        >
          Tentar novamente
        </button>
      )}
    </div>
  );
};

export default ErrorDisplay;
