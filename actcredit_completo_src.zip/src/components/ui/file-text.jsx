import React from 'react';
import { FileText as FileTextIcon } from 'lucide-react';

// Componente FileText que encapsula o ícone FileText do Lucide
const FileText = ({ className, size, ...props }) => {
  return (
    <FileTextIcon 
      className={className} 
      size={size || 24} 
      {...props} 
    />
  );
};

export { FileText };
