import React, { useState, useEffect } from 'react';
import { Button, notification, Tooltip } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import { isAppInstalled, installApp, initPWA } from '@/lib/pwaUtils';

/**
 * Componente para instalação do PWA
 * Exibe botão de instalação quando disponível
 */
const PWAInstallButton = () => {
  const [canInstall, setCanInstall] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // Inicializa recursos PWA
    initPWA(setCanInstall);
    
    // Verifica se já está instalado
    setIsInstalled(isAppInstalled());
    
    // Monitora mudanças no modo de exibição
    const mediaQuery = window.matchMedia('(display-mode: standalone)');
    const handleChange = (e) => setIsInstalled(e.matches);
    mediaQuery.addEventListener('change', handleChange);
    
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  const handleInstall = async () => {
    try {
      const installed = await installApp();
      
      if (installed) {
        notification.success({
          message: 'Instalação concluída',
          description: 'O ActCredit Premium foi instalado com sucesso!',
          placement: 'bottomRight',
        });
      }
    } catch (error) {
      console.error('Erro ao instalar o app:', error);
      notification.error({
        message: 'Erro na instalação',
        description: 'Não foi possível instalar o aplicativo. Tente novamente mais tarde.',
        placement: 'bottomRight',
      });
    }
  };

  // Não exibe o botão se já estiver instalado ou não puder ser instalado
  if (isInstalled || !canInstall) {
    return null;
  }

  return (
    <Tooltip title="Instalar ActCredit Premium">
      <Button 
        type="primary" 
        icon={<DownloadOutlined />} 
        onClick={handleInstall}
        aria-label="Instalar aplicativo"
      >
        Instalar App
      </Button>
    </Tooltip>
  );
};

export default PWAInstallButton;
