import React, { useState } from 'react';
import { 
  FileText, 
  Upload, 
  Check, 
  AlertCircle,
  Loader2
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import PDFImportService from '@/services/pdf-import/PDFImportService';

/**
 * Componente para importação de PDFs de cadastro de empresas
 */
const PDFImportComponent = () => {
  const [file, setFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  
  // Manipula a seleção de arquivo
  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setError(null);
    } else {
      setFile(null);
      setError('Por favor, selecione um arquivo PDF válido.');
    }
  };
  
  // Processa o arquivo PDF selecionado
  const handleProcessPDF = async () => {
    if (!file) {
      setError('Nenhum arquivo selecionado.');
      return;
    }
    
    setIsProcessing(true);
    setError(null);
    
    try {
      // Validar o fluxo de importação
      const validationResult = await PDFImportService.validarFluxoImportacao(file);
      
      if (validationResult.status === 'error') {
        throw new Error(validationResult.message);
      }
      
      // Cadastrar a empresa Censi (primeira empresa no banco)
      const cadastroResult = await PDFImportService.cadastrarEmpresaCensi();
      
      if (cadastroResult.status === 'error') {
        throw new Error(cadastroResult.message);
      }
      
      setResult({
        validacao: validationResult,
        cadastro: cadastroResult
      });
    } catch (err) {
      setError(err.message || 'Ocorreu um erro ao processar o PDF.');
    } finally {
      setIsProcessing(false);
    }
  };
  
  // Importar diretamente a empresa Censi do PDF de exemplo
  const handleImportCensi = async () => {
    setIsProcessing(true);
    setError(null);
    
    try {
      const cadastroResult = await PDFImportService.cadastrarEmpresaCensi();
      
      if (cadastroResult.status === 'error') {
        throw new Error(cadastroResult.message);
      }
      
      setResult({
        cadastro: cadastroResult
      });
    } catch (err) {
      setError(err.message || 'Ocorreu um erro ao cadastrar a empresa Censi.');
    } finally {
      setIsProcessing(false);
    }
  };
  
  return (
    <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileText className="h-5 w-5 mr-2" />
          Importação de Cadastro via PDF
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="bg-[#1e3a5f]/50 p-4 rounded-lg">
            <h3 className="text-lg font-medium mb-4">Selecione um arquivo PDF</h3>
            
            <div className="flex flex-col items-center justify-center border-2 border-dashed border-[#1e3a5f] rounded-lg p-6 cursor-pointer hover:border-blue-500 transition-colors">
              <input
                type="file"
                id="pdf-upload"
                accept="application/pdf"
                onChange={handleFileChange}
                className="hidden"
              />
              <label htmlFor="pdf-upload" className="cursor-pointer text-center">
                <Upload className="h-10 w-10 mb-2 mx-auto text-gray-400" />
                <p className="text-sm text-gray-400 mb-1">Clique para selecionar ou arraste um arquivo PDF</p>
                <p className="text-xs text-gray-500">PDF (max. 10MB)</p>
              </label>
            </div>
            
            {file && (
              <div className="mt-4 p-3 bg-[#1e3a5f] rounded-lg flex items-center">
                <FileText className="h-5 w-5 mr-2 text-blue-500" />
                <span className="flex-1 truncate">{file.name}</span>
                <span className="text-xs text-gray-400">{(file.size / 1024 / 1024).toFixed(2)} MB</span>
              </div>
            )}
            
            {error && (
              <div className="mt-4 p-3 bg-red-500/20 text-red-500 border border-red-500/50 rounded-lg flex items-center">
                <AlertCircle className="h-5 w-5 mr-2" />
                <span>{error}</span>
              </div>
            )}
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              className="bg-blue-600 hover:bg-blue-700 flex-1"
              onClick={handleProcessPDF}
              disabled={!file || isProcessing}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Processando...
                </>
              ) : (
                <>
                  <FileText className="h-4 w-4 mr-2" />
                  Processar PDF
                </>
              )}
            </Button>
            
            <Button
              className="bg-green-600 hover:bg-green-700 flex-1"
              onClick={handleImportCensi}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Importando...
                </>
              ) : (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Importar Censi (Exemplo)
                </>
              )}
            </Button>
          </div>
          
          {result && (
            <div className="mt-4 p-4 bg-green-500/20 text-green-500 border border-green-500/50 rounded-lg">
              <h4 className="font-medium flex items-center">
                <Check className="h-5 w-5 mr-2" />
                Operação concluída com sucesso
              </h4>
              
              <div className="mt-2 text-sm">
                <p>A empresa CENSI INDÚSTRIA DE PRODUTOS HIDROSSANITÁRIOS S.A. foi cadastrada com sucesso no banco de dados.</p>
                <p className="mt-1">CNPJ: 02.308.456/0001-49</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default PDFImportComponent;
