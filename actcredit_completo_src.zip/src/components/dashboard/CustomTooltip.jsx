import React from 'react';
import { formatCurrency, formatPercent } from '@/lib/utils';

/**
 * Componente de tooltip personalizado para gráficos
 * Exibe informações detalhadas ao passar o mouse sobre elementos dos gráficos
 */
const CustomTooltip = ({ active, payload, label, valueFormatter, labelFormatter, tooltipConfig }) => {
  if (!active || !payload || !payload.length) {
    return null;
  }

  // Configurações padrão do tooltip
  const config = {
    showLabel: true,
    showValue: true,
    showPercent: false,
    valuePrefix: '',
    valueSuffix: '',
    isCurrency: false,
    isPercent: false,
    showComparison: false,
    comparisonLabel: 'Variação',
    ...tooltipConfig
  };

  // Formatar valor com base nas configurações
  const formatValue = (value) => {
    if (valueFormatter) {
      return valueFormatter(value);
    }
    
    if (config.isCurrency) {
      return formatCurrency(value);
    }
    
    if (config.isPercent) {
      return formatPercent(value);
    }
    
    return value;
  };

  // Formatar label com base nas configurações
  const getFormattedLabel = () => {
    if (labelFormatter) {
      return labelFormatter(label);
    }
    return label;
  };

  return (
    <div className="bg-[#0f2544] border border-[#1e3a5f] rounded-md shadow-lg p-3 text-white">
      {config.showLabel && (
        <div className="font-medium mb-2">{getFormattedLabel()}</div>
      )}
      
      <div className="space-y-1">
        {payload.map((entry, index) => (
          <div key={`item-${index}`} className="flex items-center">
            <div 
              className="w-3 h-3 rounded-full mr-2" 
              style={{ backgroundColor: entry.color }}
            />
            <div className="flex justify-between items-center w-full">
              <span className="text-sm text-gray-300">{entry.name}:</span>
              <span className="font-medium ml-2">
                {config.valuePrefix}
                {formatValue(entry.value)}
                {config.valueSuffix}
              </span>
            </div>
          </div>
        ))}
        
        {config.showComparison && payload.length > 1 && (
          <div className="mt-2 pt-2 border-t border-[#1e3a5f]">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-300">{config.comparisonLabel}:</span>
              <span className={`font-medium ml-2 ${payload[0].value > payload[1].value ? 'text-green-500' : 'text-red-500'}`}>
                {formatPercent(Math.abs((payload[0].value - payload[1].value) / payload[1].value * 100))}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CustomTooltip;
