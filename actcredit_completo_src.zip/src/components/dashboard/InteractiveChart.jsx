import React from 'react';
import { LineChart, Line, AreaChart, Area, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import CustomTooltip from './CustomTooltip';

/**
 * Componente de gráfico interativo que suporta diferentes tipos (linha, área, pizza)
 * Permite interatividade com tooltips ricos e eventos de clique
 */
const InteractiveChart = ({
  data,
  type = 'line',
  dataKeys,
  xAxisKey,
  title,
  height = 300,
  tooltipConfig,
  onClick,
  showGrid = true,
  showLegend = true,
  valueFormatter,
  labelFormatter,
  colors = ['#3b82f6', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444']
}) => {
  // Verificar se há dados
  if (!data || data.length === 0 || !dataKeys || dataKeys.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 bg-[#0f2544] border border-[#1e3a5f] rounded-lg">
        <p className="text-gray-400">Sem dados para exibir</p>
      </div>
    );
  }

  // Renderizar gráfico de linha
  const renderLineChart = () => (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart
        data={data}
        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
      >
        {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />}
        <XAxis dataKey={xAxisKey} stroke="#6b7280" />
        <YAxis stroke="#6b7280" />
        <Tooltip 
          content={
            <CustomTooltip 
              valueFormatter={valueFormatter} 
              labelFormatter={labelFormatter}
              tooltipConfig={tooltipConfig}
            />
          }
        />
        {showLegend && (
          <Legend 
            wrapperStyle={{ paddingTop: 10 }}
            formatter={(value) => <span className="text-white">{value}</span>}
          />
        )}
        {dataKeys.map((key, index) => (
          <Line 
            key={key.dataKey}
            type="monotone" 
            dataKey={key.dataKey} 
            name={key.name || key.dataKey}
            stroke={key.color || colors[index % colors.length]} 
            activeDot={{ r: 8, onClick: (data) => onClick && onClick(data) }}
            isAnimationActive={true}
            animationDuration={500}
          />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );

  // Renderizar gráfico de área
  const renderAreaChart = () => (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart
        data={data}
        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
      >
        {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />}
        <XAxis dataKey={xAxisKey} stroke="#6b7280" />
        <YAxis stroke="#6b7280" />
        <Tooltip 
          content={
            <CustomTooltip 
              valueFormatter={valueFormatter} 
              labelFormatter={labelFormatter}
              tooltipConfig={tooltipConfig}
            />
          }
        />
        {showLegend && (
          <Legend 
            wrapperStyle={{ paddingTop: 10 }}
            formatter={(value) => <span className="text-white">{value}</span>}
          />
        )}
        {dataKeys.map((key, index) => (
          <Area 
            key={key.dataKey}
            type="monotone" 
            dataKey={key.dataKey} 
            name={key.name || key.dataKey}
            fill={key.color || colors[index % colors.length]} 
            stroke={key.color || colors[index % colors.length]}
            fillOpacity={0.3}
            isAnimationActive={true}
            animationDuration={500}
            onClick={(data) => onClick && onClick(data)}
          />
        ))}
      </AreaChart>
    </ResponsiveContainer>
  );

  // Renderizar gráfico de pizza
  const renderPieChart = () => (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          outerRadius={80}
          innerRadius={type === 'donut' ? 40 : 0}
          dataKey={dataKeys[0].dataKey}
          nameKey={xAxisKey}
          isAnimationActive={true}
          animationDuration={500}
          onClick={(data) => onClick && onClick(data)}
        >
          {data.map((entry, index) => (
            <Cell 
              key={`cell-${index}`} 
              fill={dataKeys[0].colors ? dataKeys[0].colors[index % dataKeys[0].colors.length] : colors[index % colors.length]} 
            />
          ))}
        </Pie>
        <Tooltip 
          content={
            <CustomTooltip 
              valueFormatter={valueFormatter} 
              labelFormatter={labelFormatter}
              tooltipConfig={tooltipConfig}
            />
          }
        />
        {showLegend && (
          <Legend 
            formatter={(value) => <span className="text-white">{value}</span>}
          />
        )}
      </PieChart>
    </ResponsiveContainer>
  );

  // Renderizar o tipo de gráfico apropriado
  const renderChart = () => {
    switch (type) {
      case 'line':
        return renderLineChart();
      case 'area':
        return renderAreaChart();
      case 'pie':
      case 'donut':
        return renderPieChart();
      default:
        return renderLineChart();
    }
  };

  return (
    <div className="w-full">
      {title && <h3 className="text-lg font-semibold mb-2">{title}</h3>}
      {renderChart()}
    </div>
  );
};

export default InteractiveChart;
