import React from 'react';
import { DashboardPanel } from '@/components/dashboard/DashboardPanel';
import { motion } from 'framer-motion';

const formatCurrency = (value) => {
  if (typeof value !== 'number') return 'R$ 0,00';
  return `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

const analiseRegionalData = [
  { regiao: 'Sudeste', clientes: 523, taxaAprovacao: '72.4%', scoreMedio: 760, valorMedio: 4250.75 },
  { regiao: 'Sul', clientes: 312, taxaAprovacao: '68.2%', scoreMedio: 740, valorMedio: 3780.50 },
  { regiao: 'Nordeste', clientes: 256, taxaAprovacao: '65.8%', scoreMedio: 710, valorMedio: 2990.00 },
  { regiao: 'Centro-Oeste', clientes: 178, taxaAprovacao: '67.5%', scoreMedio: 730, valorMedio: 3150.20 },
  { regiao: 'Norte', clientes: 79, taxaAprovacao: '62.3%', scoreMedio: 680, valorMedio: 2750.00 },
];

const RegionalAnalysisTableSection = () => {
  const rowVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: (i) => ({
      opacity: 1,
      x: 0,
      transition: {
        delay: i * 0.05,
        type: 'spring',
        stiffness: 100,
        damping: 10
      }
    })
  };

  return (
    <DashboardPanel title="Análise Regional Detalhada">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border/30 dark:border-border/20">
              <th className="p-3 text-left font-semibold text-muted-foreground tracking-wider">Região</th>
              <th className="p-3 text-right font-semibold text-muted-foreground tracking-wider">Clientes</th>
              <th className="p-3 text-right font-semibold text-muted-foreground tracking-wider">Taxa Aprovação</th>
              <th className="p-3 text-right font-semibold text-muted-foreground tracking-wider">Score Médio</th>
              <th className="p-3 text-right font-semibold text-muted-foreground tracking-wider">Valor Médio Aprov.</th>
            </tr>
          </thead>
          <tbody>
            {analiseRegionalData.map((item, index) => (
              <motion.tr 
                key={index} 
                className="border-b border-border/20 dark:border-border/10 last:border-b-0 hover:bg-primary/5 dark:hover:bg-primary/10 transition-colors duration-150"
                custom={index}
                variants={rowVariants}
                initial="hidden"
                animate="visible"
              >
                <td className="p-3 text-foreground font-medium">{item.regiao}</td>
                <td className="p-3 text-right text-foreground">{item.clientes.toLocaleString('pt-BR')}</td>
                <td className="p-3 text-right">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${parseFloat(item.taxaAprovacao) > 70 ? 'bg-emerald-500/10 text-emerald-400' : parseFloat(item.taxaAprovacao) > 65 ? 'bg-amber-500/10 text-amber-400' : 'bg-red-500/10 text-red-400'}`}>
                    {item.taxaAprovacao}
                  </span>
                </td>
                <td className="p-3 text-right text-foreground">{item.scoreMedio}</td>
                <td className="p-3 text-right text-foreground">{formatCurrency(item.valorMedio)}</td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </DashboardPanel>
  );
};

export default RegionalAnalysisTableSection;