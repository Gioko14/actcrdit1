import React from 'react';
import { motion } from 'framer-motion';
import { DashboardPanel } from '@/components/dashboard/DashboardPanel';
import { TrendingUp, TrendingDown, DollarSign } from 'lucide-react';

const formatCurrency = (value) => {
  if (typeof value !== 'number') return 'R$ 0,00';
  return `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

const valorTotalData = {
  total: 9635305.51,
  aprovado: 6619454.88,
  emAnalise: 3015850.63,
};

const TotalValueSection = () => {
  const approvedPercent = (valorTotalData.aprovado / valorTotalData.total * 100).toFixed(1);
  const inAnalysisPercent = (valorTotalData.emAnalise / valorTotalData.total * 100).toFixed(1);

  return (
    <DashboardPanel title="Valor Total Analisado" className="flex flex-col justify-center items-center">
      <div className="text-center p-4">
        <motion.p 
          className="text-5xl font-bold text-primary mb-2 bg-clip-text text-transparent bg-gradient-to-r from-chart-blue to-chart-purple"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {formatCurrency(valorTotalData.total)}
        </motion.p>
        <p className="text-sm text-muted-foreground mb-6">Valor total de crédito processado no período</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left w-full max-w-md mx-auto">
          <motion.div 
            className="bg-card/50 dark:bg-card/30 p-4 rounded-lg border border-border/50"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: 0.2 }}
          >
            <div className="flex items-center text-emerald-400 mb-1">
              <TrendingUp className="h-5 w-5 mr-2" />
              <p className="text-xs uppercase font-semibold tracking-wider">Aprovado</p>
            </div>
            <p className="text-xl font-semibold text-emerald-400">{formatCurrency(valorTotalData.aprovado)}</p>
            <p className="text-xs text-muted-foreground">{approvedPercent}% do total</p>
          </motion.div>
          
          <motion.div 
            className="bg-card/50 dark:bg-card/30 p-4 rounded-lg border border-border/50"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: 0.3 }}
          >
            <div className="flex items-center text-amber-400 mb-1">
              <DollarSign className="h-5 w-5 mr-2" />
              <p className="text-xs uppercase font-semibold tracking-wider">Em Análise</p>
            </div>
            <p className="text-xl font-semibold text-amber-400">{formatCurrency(valorTotalData.emAnalise)}</p>
            <p className="text-xs text-muted-foreground">{inAnalysisPercent}% do total</p>
          </motion.div>
        </div>
      </div>
    </DashboardPanel>
  );
};

export default TotalValueSection;