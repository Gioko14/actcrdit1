import React from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { DashboardPanel } from '@/components/dashboard/DashboardPanel';
import { CustomTooltip } from '@/components/dashboard/CustomTooltip';

const comparacaoScoreData = [
  { name: 'Varejo', 'Score ActCredit': 78, 'Score Mercado': 72 },
  { name: 'Serviços', 'Score ActCredit': 85, 'Score Mercado': 80 },
  { name: 'Indústria', 'Score ActCredit': 72, 'Score Mercado': 68 },
  { name: 'Agronegócio', 'Score ActCredit': 88, 'Score Mercado': 82 },
  { name: 'Tecnologia', 'Score ActCredit': 90, 'Score Mercado': 85 },
  { name: 'Saúde', 'Score ActCredit': 75, 'Score Mercado': 70 },
];

const ScoreComparisonChart = () => {
  return (
    <DashboardPanel title="Comparação de Score (Setorial)">
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={comparacaoScoreData} margin={{ top: 10, right: 5, left: -20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border)/0.2)" vertical={false} />
          <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={{ stroke: 'hsl(var(--border)/0.5)' }} />
          <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={{ stroke: 'hsl(var(--border)/0.5)' }} />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'hsl(var(--primary)/0.05)' }}/>
          <Legend wrapperStyle={{fontSize: "11px", paddingTop: "15px"}} iconSize={10} />
          <Bar dataKey="Score ActCredit" fill="hsl(var(--chart-blue))" radius={[5, 5, 0, 0]} barSize={18} />
          <Bar dataKey="Score Mercado" fill="hsl(var(--chart-teal))" radius={[5, 5, 0, 0]} barSize={18} />
        </BarChart>
      </ResponsiveContainer>
    </DashboardPanel>
  );
};

export default ScoreComparisonChart;