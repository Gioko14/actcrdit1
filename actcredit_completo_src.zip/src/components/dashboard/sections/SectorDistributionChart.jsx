import React from 'react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import { DashboardPanel } from '@/components/dashboard/DashboardPanel';
import { CustomTooltip } from '@/components/dashboard/CustomTooltip';

const distribuicaoSetorData = [
  { name: 'Varejo', value: 400 }, { name: 'Serviços', value: 300 },
  { name: 'Indústria', value: 300 }, { name: 'Agronegócio', value: 200 },
  { name: 'Tecnologia', value: 250 }, { name: 'Saúde', value: 150 },
];
const PIE_COLORS = ['hsl(var(--chart-blue))', 'hsl(var(--chart-purple))', 'hsl(var(--chart-pink))', 'hsl(var(--chart-teal))', 'hsl(var(--chart-orange))', 'hsl(var(--chart-green))'];

const SectorDistributionChart = () => {
  return (
    <DashboardPanel title="Distribuição por Setor">
      <ResponsiveContainer width="100%" height={300}>
        <PieChart margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
          <Pie 
            data={distribuicaoSetorData} 
            dataKey="value" 
            nameKey="name" 
            cx="50%" 
            cy="50%" 
            outerRadius={100} 
            innerRadius={60}
            paddingAngle={2}
            labelLine={false}
            label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
          >
            {distribuicaoSetorData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} stroke="hsl(var(--card))" strokeWidth={3}/>
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
          <Legend wrapperStyle={{fontSize: "11px", paddingTop: "15px"}} iconSize={10} layout="horizontal" verticalAlign="bottom" align="center" />
        </PieChart>
      </ResponsiveContainer>
    </DashboardPanel>
  );
};

export default SectorDistributionChart;