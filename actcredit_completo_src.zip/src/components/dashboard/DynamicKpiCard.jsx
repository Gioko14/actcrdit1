import React, { useState, useEffect } from 'react';
import { ArrowUp, ArrowDown, Minus, Target, Info } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

/**
 * KPI Card dinâmico e comparativo
 * Exibe métricas com comparação ao período anterior e metas
 */
const DynamicKpiCard = ({
  title,
  value,
  icon,
  previousValue = null,
  target = null,
  format = 'number', // 'number', 'currency', 'percentage'
  color = 'blue',
  tooltipContent = null,
  isLoading = false
}) => {
  // Calcular a variação percentual em relação ao período anterior
  const [trend, setTrend] = useState({
    value: 0,
    direction: 'neutral'
  });
  
  // Calcular o progresso em relação à meta
  const [targetProgress, setTargetProgress] = useState({
    percentage: 0,
    status: 'neutral' // 'success', 'warning', 'danger', 'neutral'
  });
  
  useEffect(() => {
    // Calcular tendência se houver valor anterior
    if (previousValue !== null && previousValue !== 0) {
      const trendValue = ((value - previousValue) / previousValue) * 100;
      setTrend({
        value: Math.abs(trendValue).toFixed(1),
        direction: trendValue > 0 ? 'up' : trendValue < 0 ? 'down' : 'neutral'
      });
    }
    
    // Calcular progresso em relação à meta se houver meta
    if (target !== null && target !== 0) {
      const progressPercentage = (value / target) * 100;
      let status = 'neutral';
      
      if (progressPercentage >= 100) {
        status = 'success';
      } else if (progressPercentage >= 80) {
        status = 'warning';
      } else if (progressPercentage < 60) {
        status = 'danger';
      }
      
      setTargetProgress({
        percentage: Math.min(progressPercentage, 100).toFixed(0),
        status
      });
    }
  }, [value, previousValue, target]);
  
  // Formatar o valor conforme o tipo
  const formatValue = (val) => {
    if (val === null || val === undefined) return '-';
    
    switch (format) {
      case 'currency':
        return `R$ ${Number(val).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'percentage':
        return `${Number(val).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}%`;
      default:
        return Number(val).toLocaleString('pt-BR');
    }
  };
  
  // Definir cores com base no parâmetro color
  const getColors = () => {
    switch (color) {
      case 'green':
        return {
          bg: 'bg-green-500/20',
          text: 'text-green-500',
          border: 'border-green-500/50'
        };
      case 'red':
        return {
          bg: 'bg-red-500/20',
          text: 'text-red-500',
          border: 'border-red-500/50'
        };
      case 'yellow':
        return {
          bg: 'bg-yellow-500/20',
          text: 'text-yellow-500',
          border: 'border-yellow-500/50'
        };
      case 'purple':
        return {
          bg: 'bg-purple-500/20',
          text: 'text-purple-500',
          border: 'border-purple-500/50'
        };
      default:
        return {
          bg: 'bg-blue-500/20',
          text: 'text-blue-500',
          border: 'border-blue-500/50'
        };
    }
  };
  
  const colors = getColors();
  
  // Renderizar o indicador de tendência
  const renderTrendIndicator = () => {
    if (trend.direction === 'up') {
      return (
        <div className="flex items-center text-green-500">
          <ArrowUp className="h-3 w-3 mr-1" />
          <span>{trend.value}%</span>
        </div>
      );
    } else if (trend.direction === 'down') {
      return (
        <div className="flex items-center text-red-500">
          <ArrowDown className="h-3 w-3 mr-1" />
          <span>{trend.value}%</span>
        </div>
      );
    } else {
      return (
        <div className="flex items-center text-gray-400">
          <Minus className="h-3 w-3 mr-1" />
          <span>0%</span>
        </div>
      );
    }
  };
  
  // Renderizar o progresso em relação à meta
  const renderTargetProgress = () => {
    if (target === null) return null;
    
    const statusColors = {
      success: 'bg-green-500',
      warning: 'bg-yellow-500',
      danger: 'bg-red-500',
      neutral: 'bg-gray-500'
    };
    
    return (
      <div className="mt-2">
        <div className="flex items-center justify-between text-xs mb-1">
          <div className="flex items-center">
            <Target className="h-3 w-3 mr-1 text-gray-400" />
            <span className="text-gray-400">Meta: {formatValue(target)}</span>
          </div>
          <span className={targetProgress.status === 'success' ? 'text-green-500' : 'text-gray-400'}>
            {targetProgress.percentage}%
          </span>
        </div>
        <div className="h-1 w-full bg-[#1e3a5f] rounded-full">
          <div 
            className={`h-1 rounded-full ${statusColors[targetProgress.status]}`} 
            style={{ width: `${targetProgress.percentage}%` }}
          ></div>
        </div>
      </div>
    );
  };
  
  // Renderizar o skeleton loader durante carregamento
  if (isLoading) {
    return (
      <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium text-gray-400 animate-pulse bg-gray-700 h-4 w-24 rounded"></CardTitle>
          <div className={`p-2 rounded-full ${colors.bg} animate-pulse`}>
            <div className={`h-6 w-6 ${colors.text}`}></div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold animate-pulse bg-gray-700 h-8 w-16 rounded mb-1"></div>
          <div className="animate-pulse bg-gray-700 h-4 w-20 rounded"></div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-gray-400 flex items-center">
          {title}
          {tooltipContent && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-3 w-3 ml-1 text-gray-400 cursor-help" />
                </TooltipTrigger>
                <TooltipContent className="bg-[#0f2544] border-[#1e3a5f] text-white text-xs max-w-xs">
                  {tooltipContent}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </CardTitle>
        <div className={`p-2 rounded-full ${colors.bg}`}>
          <div className={colors.text}>{icon}</div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{formatValue(value)}</div>
        <div className="flex items-center justify-between">
          {previousValue !== null ? (
            <div className="text-xs mt-1">
              {renderTrendIndicator()}
            </div>
          ) : (
            <div></div>
          )}
          
          {previousValue !== null && (
            <div className="text-xs text-gray-400">
              vs. período anterior
            </div>
          )}
        </div>
        
        {renderTargetProgress()}
      </CardContent>
    </Card>
  );
};

export default DynamicKpiCard;
