import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Check, ChevronDown, Filter, Calendar as CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const FilterBar = ({ onFilterChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [dateRange, setDateRange] = useState({ from: null, to: null });
  const [selectedPeriod, setSelectedPeriod] = useState('all');
  const [selectedFilters, setSelectedFilters] = useState({
    status: [],
    type: [],
    region: [],
    sector: []
  });
  
  // Opções de filtro
  const filterOptions = {
    status: [
      { id: 'approved', label: 'Aprovado' },
      { id: 'rejected', label: 'Rejeitado' },
      { id: 'pending', label: 'Em Análise' },
      { id: 'manual', label: 'Análise Manual' }
    ],
    type: [
      { id: 'new', label: 'Nova Análise' },
      { id: 'increase', label: 'Majoração' },
      { id: 'renewal', label: 'Renovação' },
      { id: 'reactivation', label: 'Reativação' }
    ],
    region: [
      { id: 'southeast', label: 'Sudeste' },
      { id: 'south', label: 'Sul' },
      { id: 'northeast', label: 'Nordeste' },
      { id: 'midwest', label: 'Centro-Oeste' },
      { id: 'north', label: 'Norte' }
    ],
    sector: [
      { id: 'retail', label: 'Varejo' },
      { id: 'industry', label: 'Indústria' },
      { id: 'technology', label: 'Tecnologia' },
      { id: 'agribusiness', label: 'Agronegócio' },
      { id: 'services', label: 'Serviços' }
    ]
  };
  
  // Opções de período pré-definidas
  const periodOptions = [
    { id: 'all', label: 'Todos os períodos' },
    { id: 'today', label: 'Hoje' },
    { id: 'yesterday', label: 'Ontem' },
    { id: 'last7days', label: 'Últimos 7 dias' },
    { id: 'last30days', label: 'Últimos 30 dias' },
    { id: 'thisMonth', label: 'Este mês' },
    { id: 'lastMonth', label: 'Mês passado' },
    { id: 'custom', label: 'Personalizado' }
  ];
  
  // Função para alternar a seleção de um filtro
  const toggleFilter = (category, id) => {
    setSelectedFilters(prev => {
      const newFilters = { ...prev };
      if (newFilters[category].includes(id)) {
        newFilters[category] = newFilters[category].filter(item => item !== id);
      } else {
        newFilters[category] = [...newFilters[category], id];
      }
      return newFilters;
    });
  };
  
  // Função para selecionar um período pré-definido
  const selectPeriod = (periodId) => {
    setSelectedPeriod(periodId);
    
    // Calcular datas com base no período selecionado
    const today = new Date();
    let from = null;
    let to = null;
    
    switch (periodId) {
      case 'today':
        from = new Date(today);
        to = new Date(today);
        break;
      case 'yesterday':
        from = new Date(today);
        from.setDate(from.getDate() - 1);
        to = new Date(from);
        break;
      case 'last7days':
        from = new Date(today);
        from.setDate(from.getDate() - 7);
        to = new Date(today);
        break;
      case 'last30days':
        from = new Date(today);
        from.setDate(from.getDate() - 30);
        to = new Date(today);
        break;
      case 'thisMonth':
        from = new Date(today.getFullYear(), today.getMonth(), 1);
        to = new Date(today);
        break;
      case 'lastMonth':
        from = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        to = new Date(today.getFullYear(), today.getMonth(), 0);
        break;
      case 'custom':
        // Manter as datas selecionadas pelo usuário
        break;
      default:
        // 'all' - sem filtro de data
        from = null;
        to = null;
    }
    
    setDateRange({ from, to });
  };
  
  // Função para aplicar os filtros
  const applyFilters = () => {
    const filters = {
      dateRange,
      selectedPeriod,
      ...selectedFilters
    };
    
    if (onFilterChange) {
      onFilterChange(filters);
    }
    
    setIsOpen(false);
  };
  
  // Função para limpar todos os filtros
  const clearFilters = () => {
    setSelectedFilters({
      status: [],
      type: [],
      region: [],
      sector: []
    });
    setDateRange({ from: null, to: null });
    setSelectedPeriod('all');
    
    if (onFilterChange) {
      onFilterChange({
        dateRange: { from: null, to: null },
        selectedPeriod: 'all',
        status: [],
        type: [],
        region: [],
        sector: []
      });
    }
  };
  
  // Formatar a exibição do período selecionado
  const formatDateRange = () => {
    if (selectedPeriod !== 'custom' && selectedPeriod !== 'all') {
      return periodOptions.find(p => p.id === selectedPeriod)?.label;
    }
    
    if (dateRange.from && dateRange.to) {
      return `${format(dateRange.from, 'dd/MM/yyyy')} - ${format(dateRange.to, 'dd/MM/yyyy')}`;
    }
    
    return 'Todos os períodos';
  };
  
  // Contar o número total de filtros ativos
  const countActiveFilters = () => {
    return Object.values(selectedFilters).reduce((acc, curr) => acc + curr.length, 0) + 
           (selectedPeriod !== 'all' ? 1 : 0);
  };
  
  return (
    <div className="flex flex-col md:flex-row gap-2 mb-4">
      {/* Botão de Filtros */}
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button 
            variant="outline" 
            className="flex items-center gap-2 bg-[#1e3a5f] hover:bg-[#2a4a73] text-white border-[#1e3a5f]"
          >
            <Filter className="h-4 w-4" />
            <span>Filtros</span>
            {countActiveFilters() > 0 && (
              <span className="ml-1 px-1.5 py-0.5 rounded-full bg-blue-600 text-white text-xs">
                {countActiveFilters()}
              </span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-96 p-0 bg-[#0f2544] border-[#1e3a5f] text-white">
          <div className="p-4 border-b border-[#1e3a5f]">
            <h3 className="font-medium">Filtros</h3>
          </div>
          
          <div className="p-4 max-h-[60vh] overflow-y-auto">
            {/* Filtro de Status */}
            <div className="mb-4">
              <h4 className="text-sm font-medium mb-2 text-gray-400">Status</h4>
              <div className="grid grid-cols-2 gap-2">
                {filterOptions.status.map(option => (
                  <Button
                    key={option.id}
                    variant="outline"
                    size="sm"
                    className={`justify-start ${
                      selectedFilters.status.includes(option.id)
                        ? 'bg-blue-600 text-white'
                        : 'bg-[#1e3a5f] text-gray-300'
                    }`}
                    onClick={() => toggleFilter('status', option.id)}
                  >
                    {selectedFilters.status.includes(option.id) && (
                      <Check className="mr-2 h-4 w-4" />
                    )}
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>
            
            {/* Filtro de Tipo */}
            <div className="mb-4">
              <h4 className="text-sm font-medium mb-2 text-gray-400">Tipo de Análise</h4>
              <div className="grid grid-cols-2 gap-2">
                {filterOptions.type.map(option => (
                  <Button
                    key={option.id}
                    variant="outline"
                    size="sm"
                    className={`justify-start ${
                      selectedFilters.type.includes(option.id)
                        ? 'bg-blue-600 text-white'
                        : 'bg-[#1e3a5f] text-gray-300'
                    }`}
                    onClick={() => toggleFilter('type', option.id)}
                  >
                    {selectedFilters.type.includes(option.id) && (
                      <Check className="mr-2 h-4 w-4" />
                    )}
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>
            
            {/* Filtro de Região */}
            <div className="mb-4">
              <h4 className="text-sm font-medium mb-2 text-gray-400">Região</h4>
              <div className="grid grid-cols-2 gap-2">
                {filterOptions.region.map(option => (
                  <Button
                    key={option.id}
                    variant="outline"
                    size="sm"
                    className={`justify-start ${
                      selectedFilters.region.includes(option.id)
                        ? 'bg-blue-600 text-white'
                        : 'bg-[#1e3a5f] text-gray-300'
                    }`}
                    onClick={() => toggleFilter('region', option.id)}
                  >
                    {selectedFilters.region.includes(option.id) && (
                      <Check className="mr-2 h-4 w-4" />
                    )}
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>
            
            {/* Filtro de Setor */}
            <div className="mb-4">
              <h4 className="text-sm font-medium mb-2 text-gray-400">Setor</h4>
              <div className="grid grid-cols-2 gap-2">
                {filterOptions.sector.map(option => (
                  <Button
                    key={option.id}
                    variant="outline"
                    size="sm"
                    className={`justify-start ${
                      selectedFilters.sector.includes(option.id)
                        ? 'bg-blue-600 text-white'
                        : 'bg-[#1e3a5f] text-gray-300'
                    }`}
                    onClick={() => toggleFilter('sector', option.id)}
                  >
                    {selectedFilters.sector.includes(option.id) && (
                      <Check className="mr-2 h-4 w-4" />
                    )}
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>
          </div>
          
          <div className="p-4 border-t border-[#1e3a5f] flex justify-between">
            <Button 
              variant="ghost" 
              size="sm"
              className="text-gray-400 hover:text-white"
              onClick={clearFilters}
            >
              Limpar Filtros
            </Button>
            <Button 
              variant="default" 
              size="sm"
              className="bg-blue-600 hover:bg-blue-700"
              onClick={applyFilters}
            >
              Aplicar Filtros
            </Button>
          </div>
        </PopoverContent>
      </Popover>
      
      {/* Seletor de Período */}
      <Popover>
        <PopoverTrigger asChild>
          <Button 
            variant="outline" 
            className="flex items-center gap-2 bg-[#1e3a5f] hover:bg-[#2a4a73] text-white border-[#1e3a5f]"
          >
            <CalendarIcon className="h-4 w-4" />
            <span>{formatDateRange()}</span>
            <ChevronDown className="h-4 w-4 ml-2" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0 bg-[#0f2544] border-[#1e3a5f] text-white">
          <div className="p-4 border-b border-[#1e3a5f]">
            <h3 className="font-medium">Selecione o Período</h3>
          </div>
          
          <div className="p-4 grid grid-cols-1 gap-2">
            {periodOptions.map(option => (
              <Button
                key={option.id}
                variant="ghost"
                size="sm"
                className={`justify-start ${
                  selectedPeriod === option.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-300 hover:bg-[#1e3a5f]'
                }`}
                onClick={() => selectPeriod(option.id)}
              >
                {selectedPeriod === option.id && (
                  <Check className="mr-2 h-4 w-4" />
                )}
                {option.label}
              </Button>
            ))}
          </div>
          
          {selectedPeriod === 'custom' && (
            <div className="p-4 border-t border-[#1e3a5f]">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <p className="text-sm text-gray-400 mb-1">Data Inicial</p>
                  <Calendar
                    mode="single"
                    selected={dateRange.from}
                    onSelect={(date) => setDateRange(prev => ({ ...prev, from: date }))}
                    locale={ptBR}
                    className="bg-[#0f2544] border-[#1e3a5f] text-white"
                  />
                </div>
                <div>
                  <p className="text-sm text-gray-400 mb-1">Data Final</p>
                  <Calendar
                    mode="single"
                    selected={dateRange.to}
                    onSelect={(date) => setDateRange(prev => ({ ...prev, to: date }))}
                    locale={ptBR}
                    className="bg-[#0f2544] border-[#1e3a5f] text-white"
                  />
                </div>
              </div>
            </div>
          )}
          
          <div className="p-4 border-t border-[#1e3a5f] flex justify-end">
            <Button 
              variant="default" 
              size="sm"
              className="bg-blue-600 hover:bg-blue-700"
              onClick={applyFilters}
            >
              Aplicar
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default FilterBar;
