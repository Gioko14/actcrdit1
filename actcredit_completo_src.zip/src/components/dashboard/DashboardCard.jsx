import React from 'react';
import { CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'; // Card is not used directly here
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

const DashboardCard = ({ title, description, children, className, titleClassName, contentClassName, headerClassName, id }) => {
  return (
    <motion.div
      className={cn("dashboard-panel bg-card", className)} // Ensure bg-card is applied
      id={id}
      whileHover={{ y: -5, boxShadow: "var(--tw-shadow-card-hover)" }} // Use Tailwind variable
      transition={{ type: "spring", stiffness: 280, damping: 22 }}
    >
      {(title || description) && (
        <CardHeader className={cn("dashboard-panel-header", headerClassName)}>
          {title && <CardTitle className={cn("dashboard-panel-title", titleClassName)}>{title}</CardTitle>}
          {description && <CardDescription className="text-sm text-muted-foreground mt-0.5">{description}</CardDescription>}
        </CardHeader>
      )}
      <CardContent className={cn("dashboard-panel-content", contentClassName)}>
        {children}
      </CardContent>
    </motion.div>
  );
};

export default DashboardCard;