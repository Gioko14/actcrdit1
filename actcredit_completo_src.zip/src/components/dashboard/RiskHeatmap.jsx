import React from 'react';
import { ResponsiveContainer, Tooltip, XAxis, YAxis, HeatMapGrid } from 'recharts';
import { CustomTooltip } from './CustomTooltip';

/**
 * Componente de Heatmap para visualização de concentração de dados
 * Útil para análise de risco cruzando duas dimensões
 */
const RiskHeatmap = ({
  data,
  xLabels,
  yLabels,
  title,
  height = 300,
  colorRange = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#FF0000'],
  isLoading = false
}) => {
  // Formatar dados para o heatmap
  const formattedData = data.map((item, index) => ({
    name: yLabels[index],
    ...item
  }));

  // Renderizar o skeleton loader durante carregamento
  if (isLoading) {
    return (
      <div className="w-full h-full flex flex-col">
        <div className="text-sm font-medium text-gray-400 mb-2 animate-pulse bg-gray-700 h-4 w-32 rounded"></div>
        <div className="flex-1 bg-[#0f2544] border border-[#1e3a5f] rounded-lg p-4 animate-pulse">
          <div className="h-full w-full bg-gray-700/30 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full flex flex-col">
      {title && <div className="text-sm font-medium text-gray-400 mb-2">{title}</div>}
      <div className="flex-1 bg-[#0f2544] border border-[#1e3a5f] rounded-lg p-4">
        <ResponsiveContainer width="100%" height={height}>
          <HeatMapGrid
            data={formattedData}
            xLabels={xLabels}
            yLabels={yLabels}
            onClick={(x, y) => console.log(`Clicked: ${x}, ${y}`)}
            cellStyle={(background, value, min, max, data, x, y) => ({
              background: `${background}`,
              fontSize: '11px',
              color: '#fff'
            })}
            cellRender={(value) => value && <div>{value}</div>}
            title={(x, y) => `${yLabels[y]} / ${xLabels[x]}: ${formattedData[y][xLabels[x]]}`}
            xLabelsStyle={(index) => ({
              color: '#94a3b8',
              fontSize: '10px'
            })}
            yLabelsStyle={() => ({
              color: '#94a3b8',
              fontSize: '10px',
              textAlign: 'right'
            })}
          />
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default RiskHeatmap;
