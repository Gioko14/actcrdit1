import React from 'react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Slider } from '@/components/ui/slider';

const SlidersSection = () => {
  return (
    <DashboardCard className="h-full">
      <div className="space-y-8">
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-dashboard-text-primary">Lorem ipsum</span>
            <span className="text-sm font-semibold text-dashboard-accent-purple">52%</span>
          </div>
          <Slider defaultValue={[52]} max={100} step={1} className="[&>span]:bg-dashboard-accent-purple [&>div>span]:bg-dashboard-accent-purple" />
        </div>
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-dashboard-text-primary">Lorem ipsum</span>
            <span className="text-sm font-semibold text-dashboard-accent-blue">34%</span>
          </div>
          <Slider defaultValue={[34]} max={100} step={1} className="[&>span]:bg-dashboard-accent-blue [&>div>span]:bg-dashboard-accent-blue" />
        </div>
      </div>
    </DashboardCard>
  );
};

export default SlidersSection;