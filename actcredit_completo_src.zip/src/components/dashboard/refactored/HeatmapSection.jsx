import React from 'react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Cell } from 'recharts';
import { useTheme } from '@/contexts/ThemeContext';
import { MapPin } from 'lucide-react';

const HeatmapSection = ({ heatmapData }) => {
  const { theme } = useTheme();
  const textColor = theme === 'dark' ? 'hsl(var(--dashboard-text-secondary))' : 'hsl(var(--muted-foreground))';
  const gridColor = theme === 'dark' ? 'hsla(var(--dashboard-text-secondary), 0.1)' : 'hsla(var(--muted-foreground), 0.1)';

  const maxValue = Math.max(...heatmapData.map(item => item.value));
  
  const getColor = (value) => {
    const intensity = value / maxValue;
    if (intensity > 0.8) return theme === 'dark' ? 'hsl(var(--dashboard-accent-pink))' : 'hsl(var(--destructive))';
    if (intensity > 0.5) return theme === 'dark' ? 'hsl(var(--dashboard-accent-purple))' : 'hsl(var(--primary))';
    if (intensity > 0.2) return theme === 'dark' ? 'hsl(var(--dashboard-accent-blue))' : 'hsl(var(--secondary))';
    return theme === 'dark' ? 'hsl(var(--muted-foreground))' : 'hsl(var(--muted))';
  };

  return (
    <DashboardCard title="Densidade de Análises por Região (Simulado)">
      <div className="flex flex-col items-center justify-center h-full p-4">
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={heatmapData} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
            <XAxis type="number" stroke={textColor} tick={{ fontSize: 10 }} />
            <YAxis dataKey="name" type="category" stroke={textColor} tick={{ fontSize: 10 }} width={70} />
            <Tooltip
              contentStyle={{ backgroundColor: theme === 'dark' ? 'hsl(var(--card))' : '#fff', borderRadius: '0.5rem' }}
              formatter={(value) => [`${value.toLocaleString()} análises`, null]}
            />
            <Bar dataKey="value" name="Total de Análises" barSize={20}>
              {heatmapData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={getColor(entry.value)} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
        <div className="flex items-center text-xs text-muted-foreground mt-3">
            <MapPin size={14} className="mr-1"/>
            Este gráfico simula um mapa de calor usando barras coloridas por intensidade.
        </div>
      </div>
    </DashboardCard>
  );
};

export default HeatmapSection;