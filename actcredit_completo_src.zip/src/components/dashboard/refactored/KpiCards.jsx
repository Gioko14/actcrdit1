import React from 'react';
import { motion } from 'framer-motion';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Progress } from "@/components/ui/progress";
import { TrendingUp, TrendingDown, CheckCircle, Target, ShieldAlert, DollarSign, Clock, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const KpiCard = ({ title, value, variation, tendency, icon: Icon, unit = "", meta, description }) => {
  const isPositiveTendency = tendency === 'up';
  const isGoodVariation = (title.includes("Alertas de Risco") || title.includes("Tempo Médio de Análise")) ? variation < 0 : variation >= 0;

  const variationColor = isGoodVariation ? 'text-emerald-500' : 'text-red-500';
  const VariationIcon = isGoodVariation ? ArrowUpRight : ArrowDownRight; // Consistent icon for variation

  const progressoMeta = meta && meta !== 0 ? Math.min((value / meta) * 100, 100) : 0;
  let metaProgressColor = "bg-primary";
  if (meta !== undefined && meta !== null) {
     if (title.includes("Alertas de Risco") || title.includes("Tempo Médio de Análise")) {
        // For these, lower is better. Progress is distance from meta towards zero.
        const rawProgress = (value / meta) * 100;
        if (rawProgress <= 100) metaProgressColor = "bg-emerald-500"; // At or better than meta
        else if (rawProgress <= 120) metaProgressColor = "bg-yellow-500"; // Slightly worse
        else metaProgressColor = "bg-red-500"; // Significantly worse
     } else {
        // For these, higher is better
        if (progressoMeta >= 90) metaProgressColor = "bg-emerald-500";
        else if (progressoMeta >= 60) metaProgressColor = "bg-yellow-500";
        else metaProgressColor = "bg-red-500";
     }
  }


  return (
    <DashboardCard 
      titleClassName="text-sm font-medium text-muted-foreground"
      className="h-full flex flex-col justify-between hover:shadow-card-hover dark:hover:shadow-primary/20"
    >
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
          <Icon className={cn("h-5 w-5", isGoodVariation ? 'text-emerald-500' : 'text-red-400')} />
        </div>
        <p className="text-3xl font-bold text-foreground mb-1.5">
          {unit === "R$" ? unit + value.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) : value.toLocaleString('pt-BR', { maximumFractionDigits: title.includes("Taxa") || title.includes("Score") ? 1:0 }) + unit}
        </p>
        <div className="flex items-center text-xs">
          <VariationIcon className={`h-4 w-4 mr-1 ${variationColor}`} />
          <span className={variationColor}>{variation.toFixed(1)}{unit === "%" || title.includes("Score") || title.includes("Tempo") ? "" : "%"}</span>
          <span className="text-muted-foreground ml-1.5">vs mês anterior</span>
        </div>
        {description && <p className="text-xs text-muted-foreground mt-1">{description}</p>}
      </div>
      {meta !== undefined && meta !== null && (
        <div className="mt-3 pt-2 border-t border-border/50">
          <div className="flex justify-between text-xs text-muted-foreground mb-1">
            <span>Meta: {unit === "R$" ? unit + meta.toLocaleString('pt-BR') : meta.toLocaleString('pt-BR', {maximumFractionDigits: 0}) + (unit === "%" || title.includes("Score") ? "" : unit)}</span>
            <span>{progressoMeta.toFixed(0)}%</span>
          </div>
          <Progress value={progressoMeta} className="h-2 rounded-full" indicatorClassName={cn(metaProgressColor, "rounded-full")} />
        </div>
      )}
    </DashboardCard>
  );
};

const KpiCards = ({ kpiData }) => {
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.6, -0.05, 0.01, 0.99] } }
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 md:gap-5"
    >
        <motion.div variants={itemVariants}>
            <KpiCard title="Análises Realizadas" value={kpiData.analisesRealizadas.total} variation={kpiData.analisesRealizadas.variacao} tendency={kpiData.analisesRealizadas.tendencia} icon={TrendingUp} meta={kpiData.analisesRealizadas.meta} description="Total de propostas de crédito analisadas."/>
        </motion.div>
        <motion.div variants={itemVariants}>
            <KpiCard title="Taxa de Aprovação" value={kpiData.taxaAprovacao.percentual} variation={kpiData.taxaAprovacao.variacao} tendency={kpiData.taxaAprovacao.tendencia} icon={CheckCircle} unit="%" meta={kpiData.taxaAprovacao.meta} description="Percentual de análises aprovadas."/>
        </motion.div>
        <motion.div variants={itemVariants}>
            <KpiCard title="Score Médio ActCred" value={kpiData.scoreMedio.valor} variation={kpiData.scoreMedio.variacao} tendency={kpiData.scoreMedio.tendencia} icon={Target} meta={kpiData.scoreMedio.meta} description="Pontuação média de crédito dos clientes."/>
        </motion.div>
        <motion.div variants={itemVariants}>
            <KpiCard title="Alertas de Risco Ativos" value={kpiData.alertasRisco.quantidade} variation={kpiData.alertasRisco.variacao} tendency={kpiData.alertasRisco.tendencia} icon={ShieldAlert} meta={kpiData.alertasRisco.meta} description="Clientes com indicadores de risco elevado."/>
        </motion.div>
        <motion.div variants={itemVariants}>
            <KpiCard title="Valor Total de Operações" value={kpiData.valorTotalOperacoes.valor} variation={kpiData.valorTotalOperacoes.variacao} tendency={kpiData.valorTotalOperacoes.tendencia} icon={DollarSign} unit="R$" meta={kpiData.valorTotalOperacoes.meta} description="Soma dos valores aprovados em operações."/>
        </motion.div>
        <motion.div variants={itemVariants}>
            <KpiCard title="Tempo Médio de Análise" value={kpiData.tempoMedioAnalise.valor} unit={` ${kpiData.tempoMedioAnalise.unidade}`} variation={kpiData.tempoMedioAnalise.variacao} tendency={kpiData.tempoMedioAnalise.tendencia} icon={Clock} meta={kpiData.tempoMedioAnalise.meta} description="Duração média para concluir uma análise."/>
        </motion.div>
    </motion.div>
  );
};

export default KpiCards;