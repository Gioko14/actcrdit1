import React from 'react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';
import { useTheme } from '@/contexts/ThemeContext';

const ComparativeScoresSection = ({ comparacaoScoreData }) => {
  const { theme } = useTheme();
  const secondaryColor = theme === 'dark' ? 'hsl(var(--dashboard-accent-purple))' : 'hsl(var(--secondary))';
  const textColor = theme === 'dark' ? 'hsl(var(--dashboard-text-secondary))' : 'hsl(var(--muted-foreground))';
  const gridColor = theme === 'dark' ? 'hsla(var(--dashboard-text-secondary), 0.1)' : 'hsla(var(--muted-foreground), 0.1)';

  return (
    <DashboardCard title="Comparativo de Score Médio por Setor">
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={comparacaoScoreData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
            <XAxis type="number" stroke={textColor} tick={{ fontSize: 12 }} domain={[0,1000]}/>
            <YAxis dataKey="setor" type="category" stroke={textColor} tick={{ fontSize: 12 }} width={80} />
            <Tooltip contentStyle={{ backgroundColor: theme === 'dark' ? 'hsl(var(--card))' : '#fff', borderRadius: '0.5rem' }}/>
            <Legend wrapperStyle={{ fontSize: '12px' }}/>
            <Bar dataKey="scoreMedio" fill={secondaryColor} radius={[0, 4, 4, 0]} name="Score Médio" barSize={15}/>
        </BarChart>
      </ResponsiveContainer>
    </DashboardCard>
  );
};

export default ComparativeScoresSection;