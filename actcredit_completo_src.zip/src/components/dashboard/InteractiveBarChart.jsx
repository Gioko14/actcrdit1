import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import CustomTooltip from './CustomTooltip';

/**
 * Componente de gráfico de barras interativo
 * Permite interatividade com tooltips e drill-down
 */
const InteractiveBarChart = ({
  data,
  xDataKey,
  bars,
  title,
  height = 300,
  tooltipConfig,
  onBarClick,
  showGrid = true,
  showLegend = true,
  horizontal = false,
  stacked = false,
  valueFormatter,
  labelFormatter
}) => {
  // Verificar se há dados
  if (!data || data.length === 0 || !bars || bars.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 bg-[#0f2544] border border-[#1e3a5f] rounded-lg">
        <p className="text-gray-400">Sem dados para exibir</p>
      </div>
    );
  }

  // Configurar layout do gráfico
  const layout = horizontal ? 'vertical' : 'horizontal';
  
  // Renderizar barras com base na configuração
  const renderBars = () => {
    return bars.map((bar, index) => (
      <Bar
        key={index}
        dataKey={bar.dataKey}
        name={bar.name || bar.dataKey}
        fill={bar.color}
        stackId={stacked ? 'stack' : undefined}
        onClick={(data, index) => onBarClick && onBarClick(data, index)}
        style={{ cursor: onBarClick ? 'pointer' : 'default' }}
        isAnimationActive={true}
        animationDuration={500}
      />
    ));
  };

  return (
    <div className="w-full">
      {title && <h3 className="text-lg font-semibold mb-2">{title}</h3>}
      <ResponsiveContainer width="100%" height={height}>
        <BarChart
          data={data}
          layout={layout}
          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
        >
          {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />}
          
          {horizontal ? (
            <>
              <XAxis type="number" stroke="#6b7280" />
              <YAxis dataKey={xDataKey} type="category" stroke="#6b7280" />
            </>
          ) : (
            <>
              <XAxis dataKey={xDataKey} stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
            </>
          )}
          
          <Tooltip 
            content={
              <CustomTooltip 
                valueFormatter={valueFormatter} 
                labelFormatter={labelFormatter}
                tooltipConfig={tooltipConfig}
              />
            }
          />
          
          {showLegend && (
            <Legend 
              wrapperStyle={{ paddingTop: 10 }}
              formatter={(value) => <span className="text-white">{value}</span>}
            />
          )}
          
          {renderBars()}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default InteractiveBarChart;
