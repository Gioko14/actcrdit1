import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Plus, Trash, Save, AlertTriangle, Check, Info } from 'lucide-react';
import { formatCurrency, formatPercent } from '@/lib/utils';

const PolicyManager = () => {
  const [policies, setPolicies] = useState([
    {
      id: 1,
      name: 'Limite de Crédito Padrão',
      description: 'Define o limite de crédito padrão baseado no faturamento da empresa',
      isActive: true,
      parameters: [
        { id: 'minRevenue', label: 'Faturamento Mínimo', value: 100000, type: 'currency' },
        { id: 'maxCreditPercentage', label: 'Percentual Máximo do Faturamento', value: 0.3, type: 'percent' }
      ],
      exceptions: 5,
      effectiveness: 0.95
    },
    {
      id: 2,
      name: 'Score Mínimo Setorial',
      description: 'Define o score mínimo para aprovação baseado no setor da empresa',
      isActive: true,
      parameters: [
        { id: 'retailMinScore', label: 'Score Mínimo - Varejo', value: 60, type: 'number' },
        { id: 'industryMinScore', label: 'Score Mínimo - Indústria', value: 65, type: 'number' },
        { id: 'techMinScore', label: 'Score Mínimo - Tecnologia', value: 55, type: 'number' }
      ],
      exceptions: 8,
      effectiveness: 0.92
    },
    {
      id: 3,
      name: 'Restrição por Região',
      description: 'Define regiões com restrições específicas para análise de crédito',
      isActive: true,
      parameters: [
        { id: 'restrictedRegions', label: 'Regiões com Restrição', value: 'Norte, Nordeste', type: 'text' },
        { id: 'additionalScoreRequired', label: 'Score Adicional Necessário', value: 10, type: 'number' }
      ],
      exceptions: 12,
      effectiveness: 0.88
    },
    {
      id: 4,
      name: 'Limite por Faturamento',
      description: 'Define limites de crédito baseados em faixas de faturamento',
      isActive: true,
      parameters: [
        { id: 'tier1MaxCredit', label: 'Limite Máximo - Faturamento até 1M', value: 100000, type: 'currency' },
        { id: 'tier2MaxCredit', label: 'Limite Máximo - Faturamento até 5M', value: 500000, type: 'currency' },
        { id: 'tier3MaxCredit', label: 'Limite Máximo - Faturamento até 10M', value: 1000000, type: 'currency' }
      ],
      exceptions: 6,
      effectiveness: 0.94
    },
    {
      id: 5,
      name: 'Restrição por Tempo de Mercado',
      description: 'Define restrições baseadas no tempo de operação da empresa',
      isActive: true,
      parameters: [
        { id: 'minTimeInMarket', label: 'Tempo Mínimo de Mercado (anos)', value: 2, type: 'number' },
        { id: 'newCompanyMaxCredit', label: 'Limite Máximo para Empresas Novas', value: 50000, type: 'currency' }
      ],
      exceptions: 10,
      effectiveness: 0.90
    }
  ]);
  
  const [editingPolicy, setEditingPolicy] = useState(null);
  const [isCreating, setIsCreating] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  
  // Função para alternar o status ativo/inativo de uma política
  const togglePolicyStatus = (policyId) => {
    setPolicies(prev => 
      prev.map(policy => 
        policy.id === policyId 
          ? { ...policy, isActive: !policy.isActive } 
          : policy
      )
    );
  };
  
  // Função para iniciar a edição de uma política
  const startEditing = (policy) => {
    setEditingPolicy({ ...policy });
    setIsCreating(false);
  };
  
  // Função para iniciar a criação de uma nova política
  const startCreating = () => {
    setEditingPolicy({
      id: Math.max(...policies.map(p => p.id), 0) + 1,
      name: 'Nova Política',
      description: 'Descrição da nova política',
      isActive: true,
      parameters: [
        { id: 'param1', label: 'Parâmetro 1', value: 0, type: 'number' }
      ],
      exceptions: 0,
      effectiveness: 1.0
    });
    setIsCreating(true);
  };
  
  // Função para cancelar a edição/criação
  const cancelEditing = () => {
    setEditingPolicy(null);
    setIsCreating(false);
  };
  
  // Função para atualizar um parâmetro da política em edição
  const updateParameter = (paramId, value) => {
    setEditingPolicy(prev => ({
      ...prev,
      parameters: prev.parameters.map(param => 
        param.id === paramId 
          ? { ...param, value } 
          : param
      )
    }));
  };
  
  // Função para adicionar um novo parâmetro à política em edição
  const addParameter = () => {
    setEditingPolicy(prev => ({
      ...prev,
      parameters: [
        ...prev.parameters,
        { 
          id: `param${prev.parameters.length + 1}`, 
          label: `Parâmetro ${prev.parameters.length + 1}`, 
          value: 0, 
          type: 'number' 
        }
      ]
    }));
  };
  
  // Função para remover um parâmetro da política em edição
  const removeParameter = (paramId) => {
    setEditingPolicy(prev => ({
      ...prev,
      parameters: prev.parameters.filter(param => param.id !== paramId)
    }));
  };
  
  // Função para salvar as alterações na política
  const savePolicy = () => {
    if (isCreating) {
      setPolicies(prev => [...prev, editingPolicy]);
    } else {
      setPolicies(prev => 
        prev.map(policy => 
          policy.id === editingPolicy.id 
            ? editingPolicy 
            : policy
        )
      );
    }
    
    setEditingPolicy(null);
    setIsCreating(false);
    setShowSuccess(true);
    
    // Esconder a mensagem de sucesso após 3 segundos
    setTimeout(() => {
      setShowSuccess(false);
    }, 3000);
  };
  
  // Função para excluir uma política
  const deletePolicy = (policyId) => {
    setPolicies(prev => prev.filter(policy => policy.id !== policyId));
  };
  
  // Renderizar o valor do parâmetro de acordo com seu tipo
  const renderParameterValue = (param) => {
    switch (param.type) {
      case 'currency':
        return formatCurrency(param.value);
      case 'percent':
        return formatPercent(param.value);
      default:
        return param.value.toString();
    }
  };
  
  // Renderizar o formulário de edição de política
  const renderPolicyForm = () => {
    if (!editingPolicy) return null;
    
    return (
      <Card className="mb-6 bg-[#0f2544] border-[#1e3a5f] text-white">
        <CardHeader>
          <CardTitle>{isCreating ? 'Nova Política' : 'Editar Política'}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">Nome da Política</label>
              <input
                type="text"
                value={editingPolicy.name}
                onChange={(e) => setEditingPolicy(prev => ({ ...prev, name: e.target.value }))}
                className="w-full p-2 rounded bg-[#1e3a5f] border border-[#2a4a73] text-white"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">Descrição</label>
              <textarea
                value={editingPolicy.description}
                onChange={(e) => setEditingPolicy(prev => ({ ...prev, description: e.target.value }))}
                className="w-full p-2 rounded bg-[#1e3a5f] border border-[#2a4a73] text-white h-20"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">Status</label>
              <div className="flex items-center">
                <Switch
                  checked={editingPolicy.isActive}
                  onCheckedChange={(checked) => setEditingPolicy(prev => ({ ...prev, isActive: checked }))}
                />
                <span className="ml-2">{editingPolicy.isActive ? 'Ativa' : 'Inativa'}</span>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-sm font-medium text-gray-400">Parâmetros</label>
                <Button
                  variant="outline"
                  size="sm"
                  className="bg-[#1e3a5f] hover:bg-[#2a4a73] text-white border-[#1e3a5f]"
                  onClick={addParameter}
                >
                  <Plus className="h-4 w-4 mr-1" /> Adicionar
                </Button>
              </div>
              
              {editingPolicy.parameters.map((param, index) => (
                <div key={param.id} className="flex items-center gap-2 mb-2">
                  <input
                    type="text"
                    value={param.label}
                    onChange={(e) => {
                      const newParams = [...editingPolicy.parameters];
                      newParams[index].label = e.target.value;
                      setEditingPolicy(prev => ({ ...prev, parameters: newParams }));
                    }}
                    className="flex-1 p-2 rounded bg-[#1e3a5f] border border-[#2a4a73] text-white"
                  />
                  
                  <select
                    value={param.type}
                    onChange={(e) => {
                      const newParams = [...editingPolicy.parameters];
                      newParams[index].type = e.target.value;
                      setEditingPolicy(prev => ({ ...prev, parameters: newParams }));
                    }}
                    className="p-2 rounded bg-[#1e3a5f] border border-[#2a4a73] text-white"
                  >
                    <option value="number">Número</option>
                    <option value="currency">Moeda</option>
                    <option value="percent">Percentual</option>
                    <option value="text">Texto</option>
                  </select>
                  
                  <input
                    type={param.type === 'text' ? 'text' : 'number'}
                    value={param.value}
                    onChange={(e) => {
                      const value = param.type === 'text' ? e.target.value : parseFloat(e.target.value) || 0;
                      updateParameter(param.id, value);
                    }}
                    className="w-24 p-2 rounded bg-[#1e3a5f] border border-[#2a4a73] text-white"
                  />
                  
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-red-500 hover:text-red-400 hover:bg-transparent"
                    onClick={() => removeParameter(param.id)}
                  >
                    <Trash className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex justify-end gap-2 mt-4">
            <Button
              variant="outline"
              className="bg-[#1e3a5f] hover:bg-[#2a4a73] text-white border-[#1e3a5f]"
              onClick={cancelEditing}
            >
              Cancelar
            </Button>
            <Button
              variant="default"
              className="bg-blue-600 hover:bg-blue-700"
              onClick={savePolicy}
            >
              <Save className="h-4 w-4 mr-1" /> Salvar
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };
  
  return (
    <div>
      {/* Mensagem de sucesso */}
      {showSuccess && (
        <div className="mb-4 p-3 bg-green-600 text-white rounded flex items-center">
          <Check className="h-5 w-5 mr-2" />
          Política salva com sucesso!
        </div>
      )}
      
      {/* Formulário de edição/criação */}
      {renderPolicyForm()}
      
      {/* Botão para adicionar nova política */}
      {!editingPolicy && (
        <Button
          variant="default"
          className="mb-4 bg-blue-600 hover:bg-blue-700"
          onClick={startCreating}
        >
          <Plus className="h-4 w-4 mr-1" /> Nova Política
        </Button>
      )}
      
      {/* Lista de políticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {policies.map(policy => (
          <Card 
            key={policy.id} 
            className={`bg-[#0f2544] border-[#1e3a5f] text-white ${!policy.isActive && 'opacity-70'}`}
          >
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">{policy.name}</CardTitle>
                <div className="flex items-center">
                  <Switch
                    checked={policy.isActive}
                    onCheckedChange={() => togglePolicyStatus(policy.id)}
                    className="mr-2"
                  />
                  <span className={policy.isActive ? 'text-green-500' : 'text-gray-400'}>
                    {policy.isActive ? 'Ativa' : 'Inativa'}
                  </span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-400 mb-3">{policy.description}</p>
              
              <div className="mb-3">
                <h4 className="text-sm font-medium text-gray-400 mb-1">Parâmetros</h4>
                <ul className="space-y-1">
                  {policy.parameters.map(param => (
                    <li key={param.id} className="text-sm flex justify-between">
                      <span>{param.label}:</span>
                      <span className="font-medium">{renderParameterValue(param)}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="flex justify-between text-sm mb-3">
                <div>
                  <span className="text-gray-400">Exceções:</span>
                  <span className="ml-1 text-yellow-500">{policy.exceptions}%</span>
                </div>
                <div>
                  <span className="text-gray-400">Efetividade:</span>
                  <span className="ml-1 text-green-500">{formatPercent(policy.effectiveness)}</span>
                </div>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-red-500 hover:text-red-400 hover:bg-transparent"
                  onClick={() => deletePolicy(policy.id)}
                >
                  <Trash className="h-4 w-4 mr-1" /> Excluir
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="bg-[#1e3a5f] hover:bg-[#2a4a73] text-white border-[#1e3a5f]"
                  onClick={() => startEditing(policy)}
                >
                  Editar
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* Mensagem informativa */}
      {policies.length === 0 && (
        <div className="p-4 bg-[#0f2544] border border-[#1e3a5f] text-white rounded flex items-center">
          <Info className="h-5 w-5 mr-2 text-blue-500" />
          Nenhuma política configurada. Clique em "Nova Política" para começar.
        </div>
      )}
    </div>
  );
};

export default PolicyManager;
