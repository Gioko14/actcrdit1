import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { User, Briefcase, Home, MapPin, Phone, Mail, Search } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';

const CEP_API_URL_TEMPLATE = "https://brasilapi.com.br/api/cep/v1/{cep}";

const ClientDataForm = ({ formData, setFormData, handleInputChange, handleCheckboxChange, handleSelectChange, formatCurrency, formatCNPJ, formatCEP, formatPhone }) => {
  const { toast } = useToast();
  const [isFetchingCep, setIsFetchingCep] = useState(false);

  const handleCepBlur = async (e) => {
    const cepValue = e.target.value.replace(/\D/g, '');
    if (cepValue.length === 8) {
      setIsFetchingCep(true);
      try {
        const apiUrl = CEP_API_URL_TEMPLATE.replace("{cep}", cepValue);
        const response = await fetch(apiUrl);
        if (!response.ok) {
          const errorData = await response.json().catch(() => ({ message: "CEP não encontrado ou inválido." }));
          throw new Error(errorData.message || `Erro ${response.status}`);
        }
        const data = await response.json();
        setFormData(prev => ({
          ...prev,
          logradouro: data.street || '',
          bairro: data.neighborhood || '',
          cidade: data.city || '',
          // UF (data.state) também está disponível se você tiver um campo para isso
        }));
        toast({ title: "Endereço Encontrado", description: "Logradouro, bairro e cidade preenchidos." });
      } catch (error) {
        toast({ title: "Erro ao Buscar CEP", description: error.message, variant: "destructive" });
        setFormData(prev => ({
          ...prev,
          logradouro: '',
          bairro: '',
          cidade: '',
        }));
      } finally {
        setIsFetchingCep(false);
      }
    }
  };


  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <User className="mr-2 h-5 w-5" />
          Dados da Empresa/Cliente
        </CardTitle>
        <CardDescription>
          Informações cadastrais e financeiras.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="nome">Nome da Empresa / Razão Social</Label>
            <Input
              id="nome"
              name="nome"
              placeholder="Nome completo ou Razão Social"
              value={formData.nome}
              onChange={handleInputChange}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="cnpj">CNPJ</Label>
            <Input
              id="cnpj"
              name="cnpj"
              placeholder="00.000.000/0000-00"
              value={formData.cnpj}
              onChange={formatCNPJ}
            />
          </div>
        </div>

        <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
            <div className="space-y-2">
                <Label htmlFor="dataFundacao">Data de Fundação</Label>
                <Input
                id="dataFundacao"
                name="dataFundacao"
                type="date"
                value={formData.dataFundacao}
                onChange={handleInputChange}
                />
            </div>
            <div className="space-y-2">
                <Label htmlFor="setorAtividade">Setor de Atividade</Label>
                <Select
                    value={formData.setorAtividade}
                    onValueChange={(value) => handleSelectChange('setorAtividade', value)}
                >
                    <SelectTrigger><SelectValue placeholder="Selecione o setor" /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="varejo">Varejo</SelectItem>
                        <SelectItem value="industria">Indústria</SelectItem>
                        <SelectItem value="servicos">Serviços</SelectItem>
                        <SelectItem value="agronegocio">Agronegócio</SelectItem>
                        <SelectItem value="tecnologia">Tecnologia</SelectItem>
                        <SelectItem value="construcao">Construção Civil</SelectItem>
                        <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                </Select>
            </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="faturamentoAnual">Faturamento Anual (último exercício)</Label>
          <Input
            id="faturamentoAnual"
            name="faturamentoAnual"
            placeholder="R$ 0,00"
            value={formData.faturamentoAnual}
            onChange={formatCurrency}
          />
        </div>
        
        <div className="pt-4 border-t">
            <h3 className="text-md font-semibold text-foreground mb-2 flex items-center">
                <MapPin size={18} className="mr-2"/> Endereço
            </h3>
            <div className="grid gap-4 grid-cols-1 md:grid-cols-3 items-end">
                <div className="space-y-2 md:col-span-1">
                    <Label htmlFor="cep">CEP</Label>
                    <div className="flex items-center space-x-2">
                        <Input 
                            id="cep" 
                            name="cep" 
                            placeholder="00000-000" 
                            value={formData.cep} 
                            onChange={formatCEP}
                            onBlur={handleCepBlur}
                            maxLength={9}
                        />
                        <Button type="button" variant="ghost" size="icon" onClick={() => handleCepBlur({ target: { value: formData.cep }})} disabled={isFetchingCep} title="Buscar CEP">
                            {isFetchingCep ? <Search className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                        </Button>
                    </div>
                </div>
                <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="logradouro">Logradouro</Label>
                    <Input id="logradouro" name="logradouro" placeholder="Rua, Av." value={formData.logradouro} onChange={handleInputChange} />
                </div>
            </div>
             <div className="grid gap-4 grid-cols-1 md:grid-cols-3 mt-4">
                <div className="space-y-2">
                    <Label htmlFor="numero">Número</Label>
                    <Input id="numero" name="numero" placeholder="Ex: 123" value={formData.numero} onChange={handleInputChange} />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="bairro">Bairro</Label>
                    <Input id="bairro" name="bairro" placeholder="Bairro" value={formData.bairro} onChange={handleInputChange} />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="cidade">Cidade</Label>
                    <Input id="cidade" name="cidade" placeholder="Cidade" value={formData.cidade} onChange={handleInputChange} />
                </div>
            </div>
        </div>

         <div className="pt-4 border-t">
            <h3 className="text-md font-semibold text-foreground mb-2 flex items-center">
                <Phone size={18} className="mr-2"/> Contato
            </h3>
            <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
                <div className="space-y-2">
                    <Label htmlFor="telefoneComercial">Telefone Comercial</Label>
                    <Input id="telefoneComercial" name="telefoneComercial" placeholder="(00) 0000-0000" value={formData.telefoneComercial} onChange={formatPhone} />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="emailComercial">E-mail Comercial</Label>
                    <Input id="emailComercial" name="emailComercial" type="email" placeholder="contato@empresa.com" value={formData.emailComercial} onChange={handleInputChange} />
                </div>
            </div>
        </div>


        <div className="space-y-2 pt-4 border-t">
          <Label>Informações Adicionais</Label>
          <div className="flex flex-col space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="possuiRestricao"
                checked={formData.possuiRestricao}
                onCheckedChange={() => handleCheckboxChange('possuiRestricao')}
              />
              <Label htmlFor="possuiRestricao" className="text-sm">Possui restrição cadastral (Serasa, SPC) - (Verificar manualmente)</Label>
            </div>
             <div className="flex items-center space-x-2">
              <Checkbox
                id="informacoesVerificadas"
                checked={formData.informacoesVerificadas}
                onCheckedChange={() => handleCheckboxChange('informacoesVerificadas')}
              />
              <Label htmlFor="informacoesVerificadas" className="text-sm">Informações cadastrais verificadas</Label>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="score">Score de Crédito (Bureaus Externos - Informar Manualmente)</Label>
          <Input
            id="score"
            name="score"
            type="number"
            placeholder="0-1000"
            min="0"
            max="1000"
            value={formData.score}
            onChange={handleInputChange}
          />
          {formData.score && (
            <div className="mt-2">
              <Progress value={formData.score / 10} className="h-2" />
              <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                <span>0</span>
                <span>500</span>
                <span>1000</span>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ClientDataForm;