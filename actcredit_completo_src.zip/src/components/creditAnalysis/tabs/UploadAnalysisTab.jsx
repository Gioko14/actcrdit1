import React, { useState } from 'react';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { UploadCloud, FileScan, AlertTriangle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Progress } from '@/components/ui/progress';

const UploadAnalysisTab = ({ policies, onDataExtracted }) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const { toast } = useToast();

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file && file.type === "application/pdf") {
      setSelectedFile(file);
    } else {
      setSelectedFile(null);
      toast({ title: "Arquivo Inválido", description: "Por favor, selecione um arquivo PDF.", variant: "destructive" });
    }
  };

  const handleProcessDocument = () => {
    if (!selectedFile) {
      toast({ title: "Nenhum Arquivo", description: "Por favor, selecione um arquivo PDF para processar.", variant: "destructive" });
      return;
    }
    setIsProcessing(true);
    setUploadProgress(0);

    // Simulação de upload e processamento
    // LÓGICA DE PROCESSAMENTO DE PDF REMOVIDA
    // Uma implementação real aqui envolveria:
    // 1. Fazer upload do arquivo para um storage (ex: Supabase Storage).
    // 2. Chamar uma API/backend (ex: Supabase Edge Function) que usa OCR/IA para processar o PDF.
    // 3. Receber os dados extraídos e chamar onDataExtracted(extractedData).
    
    // Exemplo de simulação de progresso (pode ser mantido para UI)
    let progress = 0;
    const interval = setInterval(() => {
      progress += 20; // Mais rápido para a simulação
      setUploadProgress(progress);
      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setIsProcessing(false);
          toast({ 
            title: "Simulação Concluída", 
            description: `O arquivo "${selectedFile.name}" foi "processado". Em uma implementação real, os dados seriam extraídos.`,
            variant: "info",
            duration: 7000
          });
          // Em uma implementação real, você chamaria onDataExtracted aqui com os dados do PDF
          // Exemplo:
          // const extractedData = { nome: "Empresa do PDF", cnpj: "00111222000133", ... };
          // if (onDataExtracted) onDataExtracted(extractedData);
        }, 500);
      }
    }, 200);
  };

  return (
    <DashboardCard title="Análise por Upload de Documentos (PDF)">
      <p className="text-muted-foreground mb-4">
        Faça o upload de demonstrativos financeiros ou outros documentos PDF.
        A extração de dados real requer uma integração com serviços de OCR/IA no backend.
      </p>
      <div className="space-y-4 max-w-md">
        <div>
          <Label htmlFor="docUpload">Selecione o Documento PDF</Label>
          <Input 
            id="docUpload" 
            type="file" 
            accept=".pdf"
            onChange={handleFileChange} 
            className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
          />
        </div>
        {selectedFile && (
          <div className="text-sm text-muted-foreground">
            Arquivo selecionado: {selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} KB)
          </div>
        )}
        {isProcessing && (
          <div className="space-y-1">
            <Label>Simulando processamento...</Label>
            <Progress value={uploadProgress} className="h-2" />
          </div>
        )}
        <Button onClick={handleProcessDocument} disabled={!selectedFile || isProcessing}>
          {isProcessing ? (
            <><FileScan className="mr-2 h-4 w-4 animate-spin" /> Processando PDF...</>
          ) : (
            <><UploadCloud className="mr-2 h-4 w-4" /> Enviar e Processar Documento</>
          )}
        </Button>
      </div>
       <div className="mt-6 p-6 border border-dashed rounded-md text-center text-muted-foreground bg-amber-50 dark:bg-amber-900/20 border-amber-300 dark:border-amber-700">
          <AlertTriangle className="mx-auto h-12 w-12 text-amber-500 mb-3" />
          <p className="font-semibold text-amber-700 dark:text-amber-400">Funcionalidade de Extração de PDF Avançada</p>
          <p className="text-sm">
            A extração automática de dados de PDFs é um recurso complexo que geralmente requer:
          </p>
          <ul className="list-disc list-inside text-left text-xs mt-2 mx-auto max-w-sm">
            <li>Serviços de OCR (Reconhecimento Óptico de Caracteres).</li>
            <li>Modelos de Inteligência Artificial/Machine Learning para interpretar os dados extraídos.</li>
            <li>Um ambiente de backend seguro para processar os documentos.</li>
          </ul>
          <p className="text-xs mt-2">
            Esta interface simula o envio. A lógica de backend e IA precisa ser desenvolvida separadamente.
          </p>
      </div>
    </DashboardCard>
  );
};

export default UploadAnalysisTab;