import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { FileText, RefreshCw, CheckCircle, XCircle } from 'lucide-react';

const AnalysisResultCard = ({ analysisResult, onReset }) => {
  if (!analysisResult) return null;

  const {
    decisao,
    motivo,
    risco,
    score,
    comprometimento,
    valorAprovado,
    parcela,
    prazo,
    taxaJuros,
    data,
  } = analysisResult;

  const cardBorderColor = decisao === 'aprovado' ? 'border-green-500' : 'border-red-500';
  const cardHeaderBgColor = decisao === 'aprovado' ? 'bg-green-50 dark:bg-green-900/20' : 'bg-red-50 dark:bg-red-900/20';
  const decisionColor = decisao === 'aprovado' ? 'text-green-500' : 'text-red-500';
  const IconComponent = decisao === 'aprovado' ? CheckCircle : XCircle;

  let riskColor;
  if (risco === 'baixo') riskColor = 'text-green-500';
  else if (risco === 'médio') riskColor = 'text-yellow-500';
  else riskColor = 'text-red-500';

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Card className={`border-2 ${cardBorderColor}`}>
        <CardHeader className={cardHeaderBgColor}>
          <CardTitle className="flex items-center">
            <IconComponent className={`mr-2 h-5 w-5 ${decisionColor}`} />
            Resultado da Análise
          </CardTitle>
          <CardDescription>
            {decisao === 'aprovado' ? 'Crédito aprovado com sucesso' : 'Crédito não aprovado'}
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Decisão</p>
              <p className={`font-medium ${decisionColor}`}>
                {decisao === 'aprovado' ? 'Aprovado' : 'Rejeitado'}
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Data</p>
              <p className="font-medium">{data}</p>
            </div>
          </div>

          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Motivo</p>
            <p className="font-medium">{motivo}</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Score</p>
              <p className="font-medium">{score}</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Nível de Risco</p>
              <p className={`font-medium ${riskColor}`}>
                {risco.charAt(0).toUpperCase() + risco.slice(1)}
              </p>
            </div>
          </div>

          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Comprometimento de Renda</p>
            <div className="flex items-center space-x-2">
              <Progress
                value={Math.min(parseFloat(comprometimento), 100)}
                className="h-2"
                indicatorClassName={parseFloat(comprometimento) > 30 ? (parseFloat(comprometimento) > 50 ? "bg-red-500" : "bg-yellow-500") : "bg-green-500"}
              />
              <span className="text-sm font-medium">{comprometimento}%</span>
            </div>
          </div>

          {decisao === 'aprovado' && (
            <>
              <div className="pt-2 border-t">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Valor Aprovado</p>
                  <p className="text-xl font-bold text-green-500">
                    {parseFloat(valorAprovado).toLocaleString('pt-BR', {
                      style: 'currency',
                      currency: 'BRL'
                    })}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Parcela</p>
                  <p className="font-medium">
                    {parseFloat(parcela).toLocaleString('pt-BR', {
                      style: 'currency',
                      currency: 'BRL'
                    })}
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Prazo</p>
                  <p className="font-medium">{prazo} meses</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Taxa</p>
                  <p className="font-medium">{taxaJuros}% a.m.</p>
                </div>
              </div>
            </>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={onReset}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Nova Análise
          </Button>
          <Button>
            <FileText className="mr-2 h-4 w-4" />
            Gerar Relatório
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default AnalysisResultCard;