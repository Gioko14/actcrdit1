import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Eye, Download, Printer, X, ZoomIn, ZoomOut } from 'lucide-react';
import { formatCurrency, formatPercent } from '@/lib/utils';
import BiAnalyticsService from '@/services/bi-analytics/BiAnalyticsService';

// Componente para visualização de relatórios na plataforma
const ReportViewer = ({ report, onClose }) => {
  const [zoom, setZoom] = useState(100);
  const [currentPage, setCurrentPage] = useState(1);
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Buscar dados do relatório ao montar o componente
  useEffect(() => {
    const fetchReportData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Determinar qual tipo de dados buscar com base no relatório
        let data = {};
        
        if (report.title.includes('Performance')) {
          const metricas = await BiAnalyticsService.getMetricasAnalise();
          const graficos = await BiAnalyticsService.getDadosGraficos();
          data = { metricas, graficos, tipo: 'performance' };
        } 
        else if (report.title.includes('Cliente')) {
          const clientes = await BiAnalyticsService.getClientes();
          const metricas = await BiAnalyticsService.getMetricasDashboard();
          data = { clientes, metricas, tipo: 'clients' };
        }
        else if (report.title.includes('Analista')) {
          const analises = await BiAnalyticsService.getAnalises();
          const metricas = await BiAnalyticsService.getMetricasAnalise();
          data = { analises, metricas, tipo: 'analysts' };
        }
        else if (report.title.includes('Política')) {
          const metricas = await BiAnalyticsService.getMetricasAnalise();
          const graficos = await BiAnalyticsService.getDadosGraficos();
          data = { metricas, graficos, tipo: 'policies' };
        }
        else {
          // Relatório genérico ou não reconhecido
          data = { 
            tipo: report.type || 'generic',
            titulo: report.title,
            descricao: report.description
          };
        }
        
        setReportData(data);
      } catch (err) {
        console.error('Erro ao carregar dados do relatório:', err);
        setError('Não foi possível carregar os dados do relatório. Tente novamente mais tarde.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchReportData();
  }, [report]);
  
  // Função para aumentar o zoom
  const zoomIn = () => {
    if (zoom < 200) setZoom(zoom + 25);
  };
  
  // Função para diminuir o zoom
  const zoomOut = () => {
    if (zoom > 50) setZoom(zoom - 25);
  };
  
  // Função para baixar o relatório
  const downloadReport = () => {
    // Simulação de download
    alert('Relatório sendo baixado...');
  };
  
  // Função para imprimir o relatório
  const printReport = () => {
    window.print();
  };
  
  // Renderização do conteúdo baseado no tipo de relatório
  const renderReportContent = () => {
    if (loading) {
      return (
        <div className="flex items-center justify-center p-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto mb-4"></div>
            <p className="text-gray-400">Carregando dados do relatório...</p>
          </div>
        </div>
      );
    }
    
    if (error) {
      return (
        <div className="p-8 text-center">
          <div className="bg-red-500/20 text-red-500 p-4 rounded-md mb-4">
            <p>{error}</p>
          </div>
          <Button 
            onClick={() => window.location.reload()}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Tentar Novamente
          </Button>
        </div>
      );
    }
    
    if (!reportData) {
      return <div className="p-4 text-center">Nenhum dado disponível para este relatório</div>;
    }
    
    switch (reportData.tipo) {
      case 'performance':
        return renderPerformanceReport();
      case 'clients':
        return renderClientsReport();
      case 'analysts':
        return renderAnalystsReport();
      case 'policies':
        return renderPoliciesReport();
      default:
        return (
          <div className="p-4 text-center">
            <h2 className="text-xl font-bold mb-4">{reportData.titulo || 'Relatório'}</h2>
            <p className="text-gray-400 mb-8">{reportData.descricao || 'Detalhes do relatório'}</p>
            <div className="bg-[#1e3a5f]/30 p-6 rounded-md">
              <p>Este tipo de relatório ainda não possui visualização detalhada.</p>
            </div>
          </div>
        );
    }
  };
  
  // Relatório de Performance
  const renderPerformanceReport = () => {
    const { metricas, graficos } = reportData;
    
    // Extrair dados dos gráficos para o relatório
    const evolucaoMensal = graficos?.analisePorMes || { labels: [], datasets: [] };
    const setores = graficos?.scoreMedioPorSetor?.labels || [];
    const scoresPorSetor = graficos?.scoreMedioPorSetor?.datasets?.[0]?.data || [];
    
    // Calcular totais
    const totalAnalises = metricas?.totalAnalises || 0;
    const taxaAprovacao = metricas?.taxaAprovacao || 0;
    const taxaRejeicao = 100 - taxaAprovacao - (metricas?.taxaAnaliseManual || 7);
    const taxaAnaliseManual = metricas?.taxaAnaliseManual || 7;
    
    return (
      <div className="p-4">
        <h2 className="text-xl font-bold mb-4">Métricas de aprovação, rejeição e análise manual</h2>
        
        <div className="grid grid-cols-3 gap-4 mb-6">
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Taxa de Aprovação</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{taxaAprovacao}%</div>
              <p className="text-sm text-green-500">+5% em relação ao mês anterior</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Taxa de Rejeição</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{taxaRejeicao}%</div>
              <p className="text-sm text-green-500">-3% em relação ao mês anterior</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Análise Manual</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{taxaAnaliseManual}%</div>
              <p className="text-sm text-yellow-500">-2% em relação ao mês anterior</p>
            </CardContent>
          </Card>
        </div>
        
        <h3 className="text-lg font-bold mb-2">Distribuição por Setor</h3>
        <table className="w-full mb-6">
          <thead>
            <tr className="border-b border-[#1e3a5f]">
              <th className="text-left py-2 px-4 text-gray-400">Setor</th>
              <th className="text-left py-2 px-4 text-gray-400">Aprovação</th>
              <th className="text-left py-2 px-4 text-gray-400">Rejeição</th>
              <th className="text-left py-2 px-4 text-gray-400">Análise Manual</th>
              <th className="text-left py-2 px-4 text-gray-400">Score Médio</th>
            </tr>
          </thead>
          <tbody>
            {setores.map((setor, index) => (
              <tr key={setor} className="border-b border-[#1e3a5f]">
                <td className="py-2 px-4">{setor}</td>
                <td className="py-2 px-4 text-green-500">
                  {Math.round(70 + Math.random() * 20)}%
                </td>
                <td className="py-2 px-4 text-red-500">
                  {Math.round(5 + Math.random() * 15)}%
                </td>
                <td className="py-2 px-4 text-yellow-500">
                  {Math.round(5 + Math.random() * 10)}%
                </td>
                <td className="py-2 px-4">
                  {scoresPorSetor[index] || 0}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        
        <h3 className="text-lg font-bold mb-2">Evolução Mensal</h3>
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#1e3a5f]">
              <th className="text-left py-2 px-4 text-gray-400">Mês</th>
              <th className="text-left py-2 px-4 text-gray-400">Aprovação</th>
              <th className="text-left py-2 px-4 text-gray-400">Rejeição</th>
              <th className="text-left py-2 px-4 text-gray-400">Análise Manual</th>
              <th className="text-left py-2 px-4 text-gray-400">Total</th>
            </tr>
          </thead>
          <tbody>
            {evolucaoMensal.labels.map((mes, index) => {
              const aprovadas = evolucaoMensal.datasets[0]?.data[index] || 0;
              const reprovadas = evolucaoMensal.datasets[1]?.data[index] || 0;
              const emAnalise = evolucaoMensal.datasets[2]?.data[index] || 0;
              const total = aprovadas + reprovadas + emAnalise;
              
              return (
                <tr key={mes} className="border-b border-[#1e3a5f]">
                  <td className="py-2 px-4">{mes}</td>
                  <td className="py-2 px-4 text-green-500">
                    {Math.round((aprovadas / total) * 100)}%
                  </td>
                  <td className="py-2 px-4 text-red-500">
                    {Math.round((reprovadas / total) * 100)}%
                  </td>
                  <td className="py-2 px-4 text-yellow-500">
                    {Math.round((emAnalise / total) * 100)}%
                  </td>
                  <td className="py-2 px-4">{total}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  };
  
  // Relatório de Clientes
  const renderClientsReport = () => {
    const { clientes, metricas } = reportData;
    
    // Calcular métricas
    const totalClientes = metricas?.totalClientes || clientes?.length || 0;
    const novosClientes = metricas?.novosMes || 0;
    const faturamentoMedio = metricas?.faturamentoMedio || 850000;
    
    // Agrupar clientes por segmento
    const segmentos = {};
    const regioes = {};
    
    clientes?.forEach(cliente => {
      // Contagem por segmento
      if (!segmentos[cliente.segmento]) {
        segmentos[cliente.segmento] = {
          quantidade: 0,
          faturamento: 0
        };
      }
      segmentos[cliente.segmento].quantidade += 1;
      segmentos[cliente.segmento].faturamento += Math.random() * 100000000;
      
      // Contagem por região
      const regiao = cliente.localizacao.split(',')[1]?.trim() || 'Outros';
      if (!regioes[regiao]) {
        regioes[regiao] = {
          quantidade: 0,
          faturamento: 0
        };
      }
      regioes[regiao].quantidade += 1;
      regioes[regiao].faturamento += Math.random() * 100000000;
    });
    
    return (
      <div className="p-4">
        <h2 className="text-xl font-bold mb-4">Distribuição de clientes por segmento, região e faturamento</h2>
        
        <div className="grid grid-cols-3 gap-4 mb-6">
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Total de Clientes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalClientes}</div>
              <p className="text-sm text-green-500">+12.5% em relação ao mês anterior</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Novos Clientes (Mês)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{novosClientes}</div>
              <p className="text-sm text-green-500">+15% em relação ao mês anterior</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Faturamento Médio</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">R$ {(faturamentoMedio / 1000).toFixed(0)}k</div>
              <p className="text-sm text-green-500">+8% em relação ao mês anterior</p>
            </CardContent>
          </Card>
        </div>
        
        <h3 className="text-lg font-bold mb-2">Distribuição por Segmento</h3>
        <table className="w-full mb-6">
          <thead>
            <tr className="border-b border-[#1e3a5f]">
              <th className="text-left py-2 px-4 text-gray-400">Segmento</th>
              <th className="text-left py-2 px-4 text-gray-400">Quantidade</th>
              <th className="text-left py-2 px-4 text-gray-400">Percentual</th>
              <th className="text-left py-2 px-4 text-gray-400">Faturamento Total</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(segmentos).map(([segmento, dados]) => (
              <tr key={segmento} className="border-b border-[#1e3a5f]">
                <td className="py-2 px-4">{segmento}</td>
                <td className="py-2 px-4">{dados.quantidade}</td>
                <td className="py-2 px-4">
                  {((dados.quantidade / totalClientes) * 100).toFixed(1)}%
                </td>
                <td className="py-2 px-4">
                  R$ {(dados.faturamento / 1000000).toFixed(1)} milhões
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        
        <h3 className="text-lg font-bold mb-2">Distribuição por Região</h3>
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#1e3a5f]">
              <th className="text-left py-2 px-4 text-gray-400">Região</th>
              <th className="text-left py-2 px-4 text-gray-400">Quantidade</th>
              <th className="text-left py-2 px-4 text-gray-400">Percentual</th>
              <th className="text-left py-2 px-4 text-gray-400">Faturamento Total</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(regioes).map(([regiao, dados]) => (
              <tr key={regiao} className="border-b border-[#1e3a5f]">
                <td className="py-2 px-4">{regiao}</td>
                <td className="py-2 px-4">{dados.quantidade}</td>
                <td className="py-2 px-4">
                  {((dados.quantidade / totalClientes) * 100).toFixed(1)}%
                </td>
                <td className="py-2 px-4">
                  R$ {(dados.faturamento / 1000000).toFixed(1)} milhões
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };
  
  // Relatório de Analistas
  const renderAnalystsReport = () => {
    const { analises, metricas } = reportData;
    
    // Dados simulados para analistas
    const analistas = [
      { nome: 'Ana Silva', analises: 42, aprovacao: 82, tempo: 2.1 },
      { nome: 'Carlos Santos', analises: 38, aprovacao: 78, tempo: 2.3 },
      { nome: 'Mariana Costa', analises: 45, aprovacao: 85, tempo: 1.9 },
      { nome: 'Pedro Oliveira', analises: 32, aprovacao: 76, tempo: 2.5 },
      { nome: 'Juliana Lima', analises: 36, aprovacao: 80, tempo: 2.2 },
      { nome: 'Roberto Alves', analises: 28, aprovacao: 74, tempo: 2.7 },
      { nome: 'Fernanda Dias', analises: 40, aprovacao: 81, tempo: 2.0 },
      { nome: 'Lucas Mendes', analises: 35, aprovacao: 79, tempo: 2.4 }
    ];
    
    // Calcular métricas
    const totalAnalistas = analistas.length;
    const analisesPorAnalista = Math.round(analistas.reduce((acc, a) => acc + a.analises, 0) / totalAnalistas);
    const tempoMedioAnalise = metricas?.tempoMedioAnalise || 2.4;
    
    return (
      <div className="p-4">
        <h2 className="text-xl font-bold mb-4">Performance individual dos analistas e volume de análises</h2>
        
        <div className="grid grid-cols-3 gap-4 mb-6">
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Total de Analistas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalAnalistas}</div>
              <p className="text-sm text-green-500">+2 em relação ao mês anterior</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Análises por Analista</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analisesPorAnalista}</div>
              <p className="text-sm text-green-500">+8% em relação ao mês anterior</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Tempo Médio de Análise</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{tempoMedioAnalise}h</div>
              <p className="text-sm text-red-500">+0.3h em relação ao mês anterior</p>
            </CardContent>
          </Card>
        </div>
        
        <h3 className="text-lg font-bold mb-2">Performance por Analista</h3>
        <table className="w-full mb-6">
          <thead>
            <tr className="border-b border-[#1e3a5f]">
              <th className="text-left py-2 px-4 text-gray-400">Analista</th>
              <th className="text-left py-2 px-4 text-gray-400">Análises</th>
              <th className="text-left py-2 px-4 text-gray-400">Taxa de Aprovação</th>
              <th className="text-left py-2 px-4 text-gray-400">Tempo Médio</th>
              <th className="text-left py-2 px-4 text-gray-400">Performance</th>
            </tr>
          </thead>
          <tbody>
            {analistas.map((analista) => {
              // Calcular indicador de performance (0-100)
              const performance = Math.round(
                (analista.aprovacao * 0.5) + 
                ((50 - analista.analises) * 0.3) + 
                ((5 - analista.tempo) * 20 * 0.2)
              );
              
              // Determinar classe de cor com base na performance
              let performanceClass = 'text-yellow-500';
              if (performance >= 80) performanceClass = 'text-green-500';
              else if (performance < 60) performanceClass = 'text-red-500';
              
              return (
                <tr key={analista.nome} className="border-b border-[#1e3a5f]">
                  <td className="py-2 px-4">{analista.nome}</td>
                  <td className="py-2 px-4">{analista.analises}</td>
                  <td className="py-2 px-4">{analista.aprovacao}%</td>
                  <td className="py-2 px-4">{analista.tempo}h</td>
                  <td className={`py-2 px-4 ${performanceClass}`}>
                    {performance}/100
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        
        <h3 className="text-lg font-bold mb-2">Análises Recentes</h3>
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#1e3a5f]">
              <th className="text-left py-2 px-4 text-gray-400">Cliente</th>
              <th className="text-left py-2 px-4 text-gray-400">Data</th>
              <th className="text-left py-2 px-4 text-gray-400">Tipo</th>
              <th className="text-left py-2 px-4 text-gray-400">Score</th>
              <th className="text-left py-2 px-4 text-gray-400">Status</th>
              <th className="text-left py-2 px-4 text-gray-400">Analista</th>
            </tr>
          </thead>
          <tbody>
            {analises?.map((analise, index) => {
              // Atribuir um analista aleatório
              const analistaIndex = index % analistas.length;
              
              return (
                <tr key={analise.id} className="border-b border-[#1e3a5f]">
                  <td className="py-2 px-4">{analise.cliente}</td>
                  <td className="py-2 px-4">{analise.data}</td>
                  <td className="py-2 px-4">{analise.tipo}</td>
                  <td className="py-2 px-4">{analise.score}</td>
                  <td className="py-2 px-4">
                    <span className={`px-2 py-1 rounded text-xs ${
                      analise.status === 'Aprovado' 
                        ? 'bg-green-500/20 text-green-500 border border-green-500/50' 
                        : analise.status === 'Reprovado'
                          ? 'bg-red-500/20 text-red-500 border border-red-500/50'
                          : 'bg-yellow-500/20 text-yellow-500 border border-yellow-500/50'
                    }`}>
                      {analise.status}
                    </span>
                  </td>
                  <td className="py-2 px-4">{analistas[analistaIndex].nome}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  };
  
  // Relatório de Políticas
  const renderPoliciesReport = () => {
    const { metricas, graficos } = reportData;
    
    // Dados simulados para políticas
    const politicas = [
      { nome: 'Limite de Endividamento', aplicacoes: 320, aprovacoes: 245, rejeicoes: 75, impacto: 'Alto' },
      { nome: 'Tempo Mínimo de Atividade', aplicacoes: 320, aprovacoes: 290, rejeicoes: 30, impacto: 'Médio' },
      { nome: 'Histórico de Crédito', aplicacoes: 320, aprovacoes: 260, rejeicoes: 60, impacto: 'Alto' },
      { nome: 'Faturamento Mínimo', aplicacoes: 320, aprovacoes: 280, rejeicoes: 40, impacto: 'Médio' },
      { nome: 'Concentração Setorial', aplicacoes: 320, aprovacoes: 300, rejeicoes: 20, impacto: 'Baixo' },
      { nome: 'Garantias Exigidas', aplicacoes: 320, aprovacoes: 270, rejeicoes: 50, impacto: 'Alto' },
    ];
    
    return (
      <div className="p-4">
        <h2 className="text-xl font-bold mb-4">Efetividade das políticas de crédito e exceções</h2>
        
        <div className="grid grid-cols-3 gap-4 mb-6">
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Políticas Ativas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{politicas.length}</div>
              <p className="text-sm text-green-500">+1 em relação ao mês anterior</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Taxa de Aprovação por Políticas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {Math.round(politicas.reduce((acc, p) => acc + (p.aprovacoes / p.aplicacoes * 100), 0) / politicas.length)}%
              </div>
              <p className="text-sm text-green-500">+3% em relação ao mês anterior</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Exceções Aprovadas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">18</div>
              <p className="text-sm text-yellow-500">+5 em relação ao mês anterior</p>
            </CardContent>
          </Card>
        </div>
        
        <h3 className="text-lg font-bold mb-2">Efetividade das Políticas</h3>
        <table className="w-full mb-6">
          <thead>
            <tr className="border-b border-[#1e3a5f]">
              <th className="text-left py-2 px-4 text-gray-400">Política</th>
              <th className="text-left py-2 px-4 text-gray-400">Aplicações</th>
              <th className="text-left py-2 px-4 text-gray-400">Aprovações</th>
              <th className="text-left py-2 px-4 text-gray-400">Rejeições</th>
              <th className="text-left py-2 px-4 text-gray-400">Taxa de Aprovação</th>
              <th className="text-left py-2 px-4 text-gray-400">Impacto</th>
            </tr>
          </thead>
          <tbody>
            {politicas.map((politica) => {
              const taxaAprovacao = Math.round((politica.aprovacoes / politica.aplicacoes) * 100);
              
              // Determinar classe de cor com base na taxa de aprovação
              let taxaClass = 'text-yellow-500';
              if (taxaAprovacao >= 85) taxaClass = 'text-green-500';
              else if (taxaAprovacao < 70) taxaClass = 'text-red-500';
              
              // Determinar classe de cor com base no impacto
              let impactoClass = 'text-yellow-500';
              if (politica.impacto === 'Alto') impactoClass = 'text-red-500';
              else if (politica.impacto === 'Baixo') impactoClass = 'text-green-500';
              
              return (
                <tr key={politica.nome} className="border-b border-[#1e3a5f]">
                  <td className="py-2 px-4">{politica.nome}</td>
                  <td className="py-2 px-4">{politica.aplicacoes}</td>
                  <td className="py-2 px-4 text-green-500">{politica.aprovacoes}</td>
                  <td className="py-2 px-4 text-red-500">{politica.rejeicoes}</td>
                  <td className={`py-2 px-4 ${taxaClass}`}>{taxaAprovacao}%</td>
                  <td className={`py-2 px-4 ${impactoClass}`}>{politica.impacto}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        
        <h3 className="text-lg font-bold mb-2">Exceções por Política</h3>
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#1e3a5f]">
              <th className="text-left py-2 px-4 text-gray-400">Política</th>
              <th className="text-left py-2 px-4 text-gray-400">Exceções Solicitadas</th>
              <th className="text-left py-2 px-4 text-gray-400">Exceções Aprovadas</th>
              <th className="text-left py-2 px-4 text-gray-400">Taxa de Aprovação</th>
              <th className="text-left py-2 px-4 text-gray-400">Impacto no Risco</th>
            </tr>
          </thead>
          <tbody>
            {politicas.map((politica) => {
              // Gerar dados simulados para exceções
              const excecoesSolicitadas = Math.round(politica.rejeicoes * 0.4);
              const excecoesAprovadas = Math.round(excecoesSolicitadas * 0.6);
              const taxaAprovacaoExcecoes = Math.round((excecoesAprovadas / excecoesSolicitadas) * 100);
              
              // Determinar impacto no risco com base no impacto da política
              let impactoRisco = 'Moderado';
              if (politica.impacto === 'Alto') impactoRisco = 'Significativo';
              else if (politica.impacto === 'Baixo') impactoRisco = 'Mínimo';
              
              // Determinar classe de cor com base no impacto no risco
              let impactoClass = 'text-yellow-500';
              if (impactoRisco === 'Significativo') impactoClass = 'text-red-500';
              else if (impactoRisco === 'Mínimo') impactoClass = 'text-green-500';
              
              return (
                <tr key={`exc-${politica.nome}`} className="border-b border-[#1e3a5f]">
                  <td className="py-2 px-4">{politica.nome}</td>
                  <td className="py-2 px-4">{excecoesSolicitadas}</td>
                  <td className="py-2 px-4">{excecoesAprovadas}</td>
                  <td className="py-2 px-4">{taxaAprovacaoExcecoes}%</td>
                  <td className={`py-2 px-4 ${impactoClass}`}>{impactoRisco}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-[#0a1929] border border-[#1e3a5f] rounded-lg w-full max-w-6xl max-h-[90vh] flex flex-col">
        {/* Cabeçalho */}
        <div className="flex items-center justify-between border-b border-[#1e3a5f] p-4">
          <div>
            <h2 className="text-xl font-bold">{report.title}</h2>
            <p className="text-sm text-gray-400">{report.description}</p>
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="border-[#1e3a5f] hover:bg-[#1e3a5f]"
              onClick={zoomOut}
            >
              <ZoomOut className="h-4 w-4" />
            </Button>
            <span className="text-sm">{zoom}%</span>
            <Button 
              variant="outline" 
              size="sm" 
              className="border-[#1e3a5f] hover:bg-[#1e3a5f]"
              onClick={zoomIn}
            >
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="border-[#1e3a5f] hover:bg-[#1e3a5f]"
              onClick={downloadReport}
            >
              <Download className="h-4 w-4 mr-1" />
              Baixar
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="border-[#1e3a5f] hover:bg-[#1e3a5f]"
              onClick={printReport}
            >
              <Printer className="h-4 w-4 mr-1" />
              Imprimir
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-gray-400 hover:text-white"
              onClick={onClose}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        {/* Conteúdo do relatório */}
        <div 
          className="flex-1 overflow-y-auto"
          style={{ zoom: `${zoom}%` }}
        >
          {renderReportContent()}
        </div>
        
        {/* Rodapé */}
        <div className="border-t border-[#1e3a5f] p-3 flex items-center justify-between text-sm text-gray-400">
          <div>
            ActCredit • Relatório gerado em {new Date().toLocaleDateString('pt-BR')}
          </div>
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
            >
              &lt;
            </Button>
            <span>Página {currentPage}</span>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0"
              onClick={() => setCurrentPage(currentPage + 1)}
            >
              &gt;
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportViewer;
