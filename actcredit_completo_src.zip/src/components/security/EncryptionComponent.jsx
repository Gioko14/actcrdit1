import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Lock, Key, Shield, Eye, EyeOff, CheckCircle, AlertCircle } from 'lucide-react';

/**
 * Componente de criptografia avançada para dados sensíveis
 * Implementa criptografia client-side usando a Web Crypto API
 */
const EncryptionComponent = () => {
  const [text, setText] = useState('');
  const [password, setPassword] = useState('');
  const [encryptedText, setEncryptedText] = useState('');
  const [decryptedText, setDecryptedText] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isEncrypting, setIsEncrypting] = useState(false);
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  // Função para derivar chave a partir da senha
  const deriveKey = async (password, salt, iterations = 100000) => {
    const encoder = new TextEncoder();
    const passwordBuffer = encoder.encode(password);
    const saltBuffer = salt || crypto.getRandomValues(new Uint8Array(16));
    
    // Importar a senha como chave
    const importedKey = await crypto.subtle.importKey(
      'raw',
      passwordBuffer,
      { name: 'PBKDF2' },
      false,
      ['deriveKey']
    );
    
    // Derivar chave AES-GCM
    const derivedKey = await crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: saltBuffer,
        iterations,
        hash: 'SHA-256'
      },
      importedKey,
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
    
    return { key: derivedKey, salt: saltBuffer };
  };

  // Função para criptografar texto
  const encryptText = async () => {
    if (!text || !password) {
      setError('Por favor, insira o texto e a senha para criptografar.');
      return;
    }
    
    setIsEncrypting(true);
    setError(null);
    setSuccess(null);
    
    try {
      const encoder = new TextEncoder();
      const data = encoder.encode(text);
      
      // Gerar salt e derivar chave
      const { key, salt } = await deriveKey(password);
      
      // Gerar IV (vetor de inicialização)
      const iv = crypto.getRandomValues(new Uint8Array(12));
      
      // Criptografar dados
      const encryptedBuffer = await crypto.subtle.encrypt(
        {
          name: 'AES-GCM',
          iv
        },
        key,
        data
      );
      
      // Combinar salt, iv e dados criptografados em um único buffer
      const encryptedArray = new Uint8Array(salt.byteLength + iv.byteLength + encryptedBuffer.byteLength);
      encryptedArray.set(salt, 0);
      encryptedArray.set(iv, salt.byteLength);
      encryptedArray.set(new Uint8Array(encryptedBuffer), salt.byteLength + iv.byteLength);
      
      // Converter para base64 para armazenamento/transmissão
      const base64Encrypted = btoa(String.fromCharCode(...encryptedArray));
      setEncryptedText(base64Encrypted);
      setSuccess('Texto criptografado com sucesso!');
    } catch (err) {
      console.error('Erro ao criptografar:', err);
      setError('Erro ao criptografar o texto. ' + err.message);
    } finally {
      setIsEncrypting(false);
    }
  };

  // Função para descriptografar texto
  const decryptText = async () => {
    if (!encryptedText || !password) {
      setError('Por favor, insira o texto criptografado e a senha para descriptografar.');
      return;
    }
    
    setIsDecrypting(true);
    setError(null);
    setSuccess(null);
    
    try {
      // Converter de base64 para array de bytes
      const encryptedArray = new Uint8Array(
        atob(encryptedText).split('').map(char => char.charCodeAt(0))
      );
      
      // Extrair salt, iv e dados criptografados
      const salt = encryptedArray.slice(0, 16);
      const iv = encryptedArray.slice(16, 28);
      const encryptedData = encryptedArray.slice(28);
      
      // Derivar chave usando o mesmo salt
      const { key } = await deriveKey(password, salt);
      
      // Descriptografar dados
      const decryptedBuffer = await crypto.subtle.decrypt(
        {
          name: 'AES-GCM',
          iv
        },
        key,
        encryptedData
      );
      
      // Converter para texto
      const decoder = new TextDecoder();
      const decryptedText = decoder.decode(decryptedBuffer);
      
      setDecryptedText(decryptedText);
      setSuccess('Texto descriptografado com sucesso!');
    } catch (err) {
      console.error('Erro ao descriptografar:', err);
      setError('Erro ao descriptografar o texto. Verifique se a senha está correta.');
    } finally {
      setIsDecrypting(false);
    }
  };

  // Limpar todos os campos
  const clearAll = () => {
    setText('');
    setPassword('');
    setEncryptedText('');
    setDecryptedText('');
    setError(null);
    setSuccess(null);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Shield className="h-5 w-5 mr-2 text-primary" />
          Criptografia Avançada
        </CardTitle>
        <CardDescription>
          Proteja dados sensíveis com criptografia AES-GCM de 256 bits
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Mensagens de erro/sucesso */}
        {error && (
          <div className="p-3 bg-red-50 dark:bg-red-900/10 border border-red-200 dark:border-red-800 rounded-md flex items-start">
            <AlertCircle className="h-5 w-5 text-red-500 mt-0.5 mr-2 flex-shrink-0" />
            <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
          </div>
        )}
        
        {success && (
          <div className="p-3 bg-green-50 dark:bg-green-900/10 border border-green-200 dark:border-green-800 rounded-md flex items-start">
            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
            <p className="text-sm text-green-600 dark:text-green-400">{success}</p>
          </div>
        )}
        
        {/* Seção de criptografia */}
        <div className="space-y-2">
          <Label htmlFor="text-to-encrypt">Texto para criptografar</Label>
          <textarea
            id="text-to-encrypt"
            className="w-full min-h-[100px] p-2 border border-border rounded-md bg-background"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Digite o texto que deseja criptografar..."
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="password">Senha de criptografia</Label>
          <div className="relative">
            <Input
              id="password"
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Digite uma senha forte..."
              className="pr-10"
            />
            <button
              type="button"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          <p className="text-xs text-muted-foreground">
            Use uma senha forte que você possa lembrar. A senha não é recuperável.
          </p>
        </div>
        
        <div className="flex space-x-2">
          <Button 
            onClick={encryptText} 
            disabled={isEncrypting || !text || !password}
            className="flex-1"
          >
            <Lock className="h-4 w-4 mr-2" />
            {isEncrypting ? 'Criptografando...' : 'Criptografar'}
          </Button>
          
          <Button 
            onClick={decryptText} 
            disabled={isDecrypting || !encryptedText || !password}
            variant="outline"
            className="flex-1"
          >
            <Key className="h-4 w-4 mr-2" />
            {isDecrypting ? 'Descriptografando...' : 'Descriptografar'}
          </Button>
        </div>
        
        {/* Resultado da criptografia */}
        {encryptedText && (
          <div className="space-y-2">
            <Label htmlFor="encrypted-text">Texto criptografado</Label>
            <textarea
              id="encrypted-text"
              className="w-full min-h-[80px] p-2 border border-border rounded-md bg-muted"
              value={encryptedText}
              readOnly
            />
            <p className="text-xs text-muted-foreground">
              Este é o texto criptografado. Você pode copiar e armazenar com segurança.
            </p>
          </div>
        )}
        
        {/* Resultado da descriptografia */}
        {decryptedText && (
          <div className="space-y-2">
            <Label htmlFor="decrypted-text">Texto descriptografado</Label>
            <textarea
              id="decrypted-text"
              className="w-full min-h-[80px] p-2 border border-border rounded-md bg-muted"
              value={decryptedText}
              readOnly
            />
          </div>
        )}
      </CardContent>
      
      <CardFooter>
        <Button variant="ghost" onClick={clearAll} className="ml-auto">
          Limpar tudo
        </Button>
      </CardFooter>
    </Card>
  );
};

export default EncryptionComponent;
