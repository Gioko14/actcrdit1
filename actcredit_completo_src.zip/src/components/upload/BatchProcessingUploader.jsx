import React, { useState } from 'react';
import { FileText, Upload, X, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const BatchProcessingUploader = ({ onUpload }) => {
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState(null);

  // Função para lidar com a seleção de arquivos
  const handleFileSelect = (e) => {
    const selectedFiles = Array.from(e.target.files);
    setFiles([...files, ...selectedFiles]);
  };

  // Função para remover um arquivo da lista
  const removeFile = (index) => {
    const newFiles = [...files];
    newFiles.splice(index, 1);
    setFiles(newFiles);
  };

  // Função para iniciar o upload em lote
  const startBatchUpload = async () => {
    if (files.length === 0) return;
    
    setUploading(true);
    
    // Simulação de upload
    setTimeout(() => {
      setUploading(false);
      setUploadStatus('success');
      
      // Callback para o componente pai
      if (onUpload) {
        onUpload(files);
      }
    }, 2000);
  };

  // Função para renderizar o ícone apropriado com base no tipo de arquivo
  const renderFileIcon = (file) => {
    const extension = file.name.split('.').pop().toLowerCase();
    
    switch(extension) {
      case 'pdf':
        return <FileText className="h-5 w-5 text-red-500" />;
      case 'doc':
      case 'docx':
        return <FileText className="h-5 w-5 text-blue-500" />;
      case 'xls':
      case 'xlsx':
        return <FileText className="h-5 w-5 text-green-500" />;
      default:
        return <FileText className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <div className="bg-[#0f2544] border border-[#1e3a5f] rounded-lg p-6">
      <div className="mb-4">
        <h3 className="text-lg font-semibold mb-1">Processamento em Lote</h3>
        <p className="text-gray-400 text-sm">
          Faça upload de múltiplos arquivos para processamento em lote.
        </p>
      </div>
      
      {/* Área de upload */}
      <div 
        className="border-2 border-dashed border-[#1e3a5f] rounded-lg p-8 mb-4 text-center cursor-pointer hover:border-blue-500 transition-colors"
        onClick={() => document.getElementById('file-upload').click()}
      >
        <input
          id="file-upload"
          type="file"
          multiple
          className="hidden"
          onChange={handleFileSelect}
        />
        <Upload className="h-12 w-12 mx-auto mb-4 text-gray-400" />
        <p className="text-gray-300 mb-1">Arraste arquivos aqui ou clique para selecionar</p>
        <p className="text-gray-400 text-sm">Suporta PDF, Word, Excel (máx. 10MB por arquivo)</p>
      </div>
      
      {/* Lista de arquivos selecionados */}
      {files.length > 0 && (
        <div className="mb-4">
          <h4 className="text-sm font-medium text-gray-300 mb-2">Arquivos Selecionados ({files.length})</h4>
          <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
            {files.map((file, index) => (
              <div key={index} className="flex items-center justify-between bg-[#1e3a5f] p-2 rounded-md">
                <div className="flex items-center">
                  {renderFileIcon(file)}
                  <span className="ml-2 text-sm truncate max-w-xs">{file.name}</span>
                </div>
                <button 
                  className="text-gray-400 hover:text-red-500"
                  onClick={() => removeFile(index)}
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Botão de upload e status */}
      <div className="flex items-center justify-between">
        <Button 
          className="bg-blue-600 hover:bg-blue-700"
          disabled={files.length === 0 || uploading}
          onClick={startBatchUpload}
        >
          {uploading ? (
            <>
              <div className="animate-spin h-4 w-4 border-2 border-white border-opacity-50 border-t-transparent rounded-full mr-2"></div>
              Processando...
            </>
          ) : (
            <>
              <Upload className="h-4 w-4 mr-2" />
              Iniciar Processamento
            </>
          )}
        </Button>
        
        {uploadStatus && (
          <div className="flex items-center">
            {uploadStatus === 'success' ? (
              <>
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <span className="text-green-500 text-sm">Upload concluído com sucesso</span>
              </>
            ) : (
              <>
                <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                <span className="text-red-500 text-sm">Erro no upload</span>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default BatchProcessingUploader;
