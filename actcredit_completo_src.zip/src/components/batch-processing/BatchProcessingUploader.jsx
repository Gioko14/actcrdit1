import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Upload, FileText, CheckCircle, AlertCircle } from 'lucide-react';

/**
 * Componente avançado para processamento em lote de arquivos
 * Utiliza Web Workers para processamento paralelo sem bloquear a UI
 */
const BatchProcessingUploader = ({ 
  onFilesProcessed, 
  allowedFileTypes = ['.pdf', '.jpg', '.jpeg', '.png', '.docx', '.xlsx'],
  maxFiles = 50,
  maxSizePerFile = 10 // em MB
}) => {
  const [files, setFiles] = useState([]);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState([]);
  const [errors, setErrors] = useState([]);
  const fileInputRef = useRef(null);
  const workerRef = useRef(null);

  // Inicializar Web Worker para processamento paralelo
  const initWorker = () => {
    if (typeof Worker === 'undefined') {
      console.error('Web Workers não são suportados neste navegador');
      return false;
    }
    
    try {
      // Código inline para o Web Worker
      const workerCode = `
        self.onmessage = function(e) {
          const { files, action } = e.data;
          
          if (action === 'process') {
            let processed = 0;
            const results = [];
            const errors = [];
            
            // Simular processamento de cada arquivo
            files.forEach((file, index) => {
              try {
                // Aqui seria a lógica real de processamento
                // Por enquanto, apenas simulamos o tempo de processamento
                
                // Reportar progresso
                self.postMessage({
                  type: 'progress',
                  progress: Math.round(((index + 1) / files.length) * 100)
                });
                
                // Adicionar resultado
                results.push({
                  id: file.id,
                  name: file.name,
                  size: file.size,
                  type: file.type,
                  status: 'success',
                  processedAt: new Date().toISOString()
                });
                
              } catch (error) {
                errors.push({
                  id: file.id,
                  name: file.name,
                  error: error.message || 'Erro desconhecido'
                });
              }
              
              processed++;
            });
            
            // Enviar resultados finais
            self.postMessage({
              type: 'complete',
              results,
              errors
            });
          }
        };
      `;
      
      // Criar Blob com o código do worker
      const blob = new Blob([workerCode], { type: 'application/javascript' });
      const workerUrl = URL.createObjectURL(blob);
      
      // Criar e armazenar o worker
      workerRef.current = new Worker(workerUrl);
      
      // Configurar handlers para mensagens do worker
      workerRef.current.onmessage = (e) => {
        const { type, progress, results: workerResults, errors: workerErrors } = e.data;
        
        if (type === 'progress') {
          setProgress(progress);
        } else if (type === 'complete') {
          setResults(workerResults);
          setErrors(workerErrors);
          setProcessing(false);
          setProgress(100);
          
          // Notificar componente pai
          if (onFilesProcessed) {
            onFilesProcessed(workerResults, workerErrors);
          }
        }
      };
      
      return true;
    } catch (error) {
      console.error('Erro ao inicializar Web Worker:', error);
      return false;
    }
  };

  // Manipular seleção de arquivos
  const handleFileSelect = (e) => {
    const selectedFiles = Array.from(e.target.files);
    
    // Validar número máximo de arquivos
    if (selectedFiles.length > maxFiles) {
      alert(`Você pode selecionar no máximo ${maxFiles} arquivos.`);
      return;
    }
    
    // Validar tipos de arquivo e tamanho
    const validFiles = selectedFiles.filter(file => {
      const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
      const isValidType = allowedFileTypes.includes(fileExtension);
      const isValidSize = file.size <= maxSizePerFile * 1024 * 1024;
      
      if (!isValidType) {
        setErrors(prev => [...prev, { 
          id: Math.random().toString(36).substr(2, 9),
          name: file.name, 
          error: `Tipo de arquivo não permitido. Tipos permitidos: ${allowedFileTypes.join(', ')}` 
        }]);
      }
      
      if (!isValidSize) {
        setErrors(prev => [...prev, { 
          id: Math.random().toString(36).substr(2, 9),
          name: file.name, 
          error: `Arquivo muito grande. Tamanho máximo: ${maxSizePerFile}MB` 
        }]);
      }
      
      return isValidType && isValidSize;
    });
    
    // Adicionar IDs aos arquivos para rastreamento
    const filesWithIds = validFiles.map(file => ({
      ...file,
      id: Math.random().toString(36).substr(2, 9)
    }));
    
    setFiles(filesWithIds);
  };

  // Iniciar processamento
  const startProcessing = () => {
    if (files.length === 0) {
      alert('Selecione pelo menos um arquivo para processar.');
      return;
    }
    
    setProcessing(true);
    setProgress(0);
    setResults([]);
    setErrors([]);
    
    // Inicializar worker se ainda não existir
    if (!workerRef.current && !initWorker()) {
      // Fallback para processamento síncrono se worker falhar
      processFilesSynchronously();
      return;
    }
    
    // Enviar arquivos para o worker
    workerRef.current.postMessage({
      action: 'process',
      files: files.map(file => ({
        id: file.id,
        name: file.name,
        size: file.size,
        type: file.type
      }))
    });
  };

  // Fallback: processamento síncrono (sem Web Workers)
  const processFilesSynchronously = () => {
    const processedResults = [];
    const processedErrors = [];
    
    // Simular processamento
    let processed = 0;
    
    const processNextFile = () => {
      if (processed >= files.length) {
        // Concluído
        setResults(processedResults);
        setErrors(processedErrors);
        setProcessing(false);
        setProgress(100);
        
        // Notificar componente pai
        if (onFilesProcessed) {
          onFilesProcessed(processedResults, processedErrors);
        }
        return;
      }
      
      const file = files[processed];
      
      try {
        // Aqui seria a lógica real de processamento
        // Por enquanto, apenas simulamos o resultado
        
        processedResults.push({
          id: file.id,
          name: file.name,
          size: file.size,
          type: file.type,
          status: 'success',
          processedAt: new Date().toISOString()
        });
      } catch (error) {
        processedErrors.push({
          id: file.id,
          name: file.name,
          error: error.message || 'Erro desconhecido'
        });
      }
      
      processed++;
      setProgress(Math.round((processed / files.length) * 100));
      
      // Processar próximo arquivo após um pequeno delay
      setTimeout(processNextFile, 100);
    };
    
    // Iniciar processamento
    processNextFile();
  };

  // Limpar seleção
  const clearSelection = () => {
    setFiles([]);
    setResults([]);
    setErrors([]);
    setProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="w-full p-6 border border-border rounded-lg bg-card">
      <h3 className="text-lg font-semibold mb-4">Processamento em Lote</h3>
      
      {/* Área de upload */}
      <div 
        className="border-2 border-dashed border-border rounded-lg p-8 text-center mb-4 hover:border-primary transition-colors cursor-pointer"
        onClick={() => fileInputRef.current?.click()}
      >
        <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
        <p className="text-muted-foreground mb-2">
          Arraste arquivos aqui ou clique para selecionar
        </p>
        <p className="text-xs text-muted-foreground/70">
          Tipos permitidos: {allowedFileTypes.join(', ')} • Máximo {maxFiles} arquivos • {maxSizePerFile}MB por arquivo
        </p>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          multiple
          onChange={handleFileSelect}
          accept={allowedFileTypes.join(',')}
        />
      </div>
      
      {/* Lista de arquivos selecionados */}
      {files.length > 0 && (
        <div className="mb-4">
          <h4 className="text-sm font-medium mb-2">Arquivos selecionados ({files.length})</h4>
          <div className="max-h-40 overflow-y-auto border border-border rounded-lg divide-y divide-border">
            {files.map(file => (
              <div key={file.id} className="p-2 flex items-center text-sm">
                <FileText className="h-4 w-4 mr-2 text-muted-foreground" />
                <span className="flex-1 truncate">{file.name}</span>
                <span className="text-xs text-muted-foreground ml-2">
                  {(file.size / 1024).toFixed(1)} KB
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Barra de progresso */}
      {processing && (
        <div className="mb-4">
          <div className="flex justify-between text-sm mb-1">
            <span>Processando...</span>
            <span>{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
      )}
      
      {/* Resultados e erros */}
      {results.length > 0 && (
        <div className="mb-4">
          <h4 className="text-sm font-medium mb-2 flex items-center">
            <CheckCircle className="h-4 w-4 mr-1 text-green-500" />
            Processados com sucesso ({results.length})
          </h4>
          <div className="max-h-40 overflow-y-auto border border-border rounded-lg divide-y divide-border">
            {results.map(result => (
              <div key={result.id} className="p-2 flex items-center text-sm">
                <FileText className="h-4 w-4 mr-2 text-green-500" />
                <span className="flex-1 truncate">{result.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {errors.length > 0 && (
        <div className="mb-4">
          <h4 className="text-sm font-medium mb-2 flex items-center">
            <AlertCircle className="h-4 w-4 mr-1 text-red-500" />
            Erros ({errors.length})
          </h4>
          <div className="max-h-40 overflow-y-auto border border-border rounded-lg divide-y divide-border">
            {errors.map(error => (
              <div key={error.id} className="p-2 flex items-center text-sm">
                <AlertCircle className="h-4 w-4 mr-2 text-red-500" />
                <span className="flex-1 truncate">{error.name}</span>
                <span className="text-xs text-red-500 ml-2">{error.error}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Botões de ação */}
      <div className="flex space-x-2">
        <Button 
          onClick={startProcessing} 
          disabled={processing || files.length === 0}
          className="flex-1"
        >
          {processing ? 'Processando...' : 'Iniciar Processamento'}
        </Button>
        <Button 
          variant="outline" 
          onClick={clearSelection}
          disabled={processing}
        >
          Limpar
        </Button>
      </div>
    </div>
  );
};

export default BatchProcessingUploader;
