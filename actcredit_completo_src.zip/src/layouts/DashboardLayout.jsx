import React from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  BarChart, 
  Users, 
  CreditCard, 
  Shield, 
  User, 
  Settings,
  Menu,
  Bell,
  Sun,
  Moon,
  LogOut
} from 'lucide-react';
import { Link, useLocation, Outlet } from 'react-router-dom';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';

// Componentes
import { Button } from '@/components/ui/button';
import ThemeSwitcher from '@/components/ui/ThemeSwitcher';

const DashboardLayout = () => {
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();
  const { user, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = React.useState(true);
  
  // Definição dos links de navegação
  const navLinks = [
    { icon: <LayoutDashboard className="h-5 w-5" />, label: 'Dashboard', path: '/dashboard' },
    { icon: <FileText className="h-5 w-5" />, label: 'Análises', path: '/dashboard/analises' },
    { icon: <BarChart className="h-5 w-5" />, label: 'Relatórios', path: '/dashboard/relatorios' },
    { icon: <Users className="h-5 w-5" />, label: 'Clientes', path: '/dashboard/clientes' },
    { icon: <CreditCard className="h-5 w-5" />, label: 'Crédito', path: '/dashboard/credito' },
    { icon: <Shield className="h-5 w-5" />, label: 'Políticas', path: '/dashboard/politicas' },
    { icon: <User className="h-5 w-5" />, label: 'Perfil', path: '/dashboard/perfil' },
    { icon: <Settings className="h-5 w-5" />, label: 'Configurações', path: '/dashboard/configuracoes' },
  ];
  
  // Verificar se um link está ativo
  const isActive = (path) => {
    if (path === '/dashboard' && location.pathname === '/dashboard') {
      return true;
    }
    return location.pathname.startsWith(path) && path !== '/dashboard';
  };
  
  return (
    <div className="flex h-screen bg-[#0a1629] text-white">
      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 w-64 transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out md:relative md:translate-x-0 bg-[#0f2544] border-r border-[#1e3a5f]`}>
        {/* Logo */}
        <div className="flex items-center h-16 px-4 border-b border-[#1e3a5f]">
          <div className="flex items-center">
            <div className="bg-blue-600 text-white rounded-md h-10 w-10 flex items-center justify-center mr-2 font-bold text-xl">
              AC
            </div>
            <span className="text-xl font-bold">Actcredit</span>
          </div>
          <button 
            className="ml-auto md:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <Menu className="h-6 w-6" />
          </button>
        </div>
        
        {/* Links de navegação */}
        <nav className="px-2 py-4">
          <ul className="space-y-1">
            {navLinks.map((link, index) => (
              <li key={index}>
                <Link
                  to={link.path}
                  className={`flex items-center px-4 py-3 rounded-md transition-colors ${
                    isActive(link.path)
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-300 hover:bg-[#1e3a5f] hover:text-white'
                  }`}
                >
                  {link.icon}
                  <span className="ml-3">{link.label}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        {/* Perfil do usuário */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-[#1e3a5f]">
          <div className="flex items-center">
            <div className="bg-blue-600 rounded-full h-10 w-10 flex items-center justify-center text-white font-bold">
              A
            </div>
            <div className="ml-3">
              <p className="font-medium">Administrador</p>
              <p className="text-sm text-gray-400">admin@actcredit.com</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Conteúdo principal */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-[#0f2544] border-b border-[#1e3a5f] flex items-center px-4">
          <button 
            className="md:hidden mr-4"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="h-6 w-6" />
          </button>
          
          <div className="ml-auto flex items-center space-x-4">
            <ThemeSwitcher />
            
            <button className="relative">
              <Bell className="h-6 w-6" />
              <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
            </button>
            
            <button 
              className="text-gray-300 hover:text-white"
              onClick={logout}
            >
              <LogOut className="h-6 w-6" />
            </button>
          </div>
        </header>
        
        {/* Área de conteúdo */}
        <main className="flex-1 overflow-auto bg-[#0a1629] p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
