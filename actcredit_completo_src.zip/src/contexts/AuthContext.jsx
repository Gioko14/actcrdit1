import React, { createContext, useContext, useState, useEffect } from 'react';

// Criar o contexto de autenticação
const AuthContext = createContext(null);

// Hook personalizado para usar o contexto de autenticação
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Provider de autenticação
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Simular verificação de autenticação ao carregar
  useEffect(() => {
    // Simulação de verificação de autenticação
    const checkAuth = async () => {
      try {
        // Em um ambiente real, verificaria tokens, cookies, etc.
        // Para teste, vamos simular um usuário autenticado
        const mockUser = {
          id: '1',
          name: 'Usuário de Teste',
          email: 'teste@actcredit.com',
          role: 'admin'
        };
        
        setUser(mockUser);
      } catch (error) {
        console.error('Erro ao verificar autenticação:', error);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  // Função de login simulada
  const login = async (credentials) => {
    setLoading(true);
    try {
      // Simulação de login bem-sucedido
      const mockUser = {
        id: '1',
        name: 'Usuário de Teste',
        email: credentials.email || 'teste@actcredit.com',
        role: 'admin'
      };
      
      setUser(mockUser);
      return { success: true };
    } catch (error) {
      console.error('Erro ao fazer login:', error);
      return { success: false, error: 'Credenciais inválidas' };
    } finally {
      setLoading(false);
    }
  };

  // Função de logout simulada
  const logout = () => {
    setUser(null);
  };

  // Valor do contexto
  const value = {
    user,
    loading,
    login,
    logout,
    isAuthenticated: !!user
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export default AuthProvider;
