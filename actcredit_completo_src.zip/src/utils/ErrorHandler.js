/**
 * Utilitário para tratamento de erros centralizado
 * Fornece funções para capturar, registrar e responder a erros de forma consistente
 */

class ErrorHandler {
  /**
   * Registra um erro no console e opcionalmente em um arquivo de log
   * @param {Error} error Objeto de erro
   * @param {string} source Fonte do erro (nome do serviço ou componente)
   * @param {Object} context Informações adicionais sobre o contexto do erro
   */
  static logError(error, source, context = {}) {
    const timestamp = new Date().toISOString();
    const errorMessage = error.message || 'Erro desconhecido';
    const errorStack = error.stack || '';
    
    // Formatar mensagem de erro
    const logMessage = `[${timestamp}] [ERRO] [${source}] ${errorMessage}\n${errorStack}\nContexto: ${JSON.stringify(context)}`;
    
    // Registrar no console
    console.error(logMessage);
    
    // Aqui poderia ser adicionada lógica para registrar em arquivo ou serviço de logging
  }

  /**
   * Captura e trata erros em funções assíncronas
   * @param {Function} fn Função assíncrona a ser executada
   * @param {string} source Fonte do erro (nome do serviço ou componente)
   * @param {Object} context Informações adicionais sobre o contexto
   * @returns {Promise<any>} Resultado da função ou erro tratado
   */
  static async handleAsync(fn, source, context = {}) {
    try {
      return await fn();
    } catch (error) {
      this.logError(error, source, context);
      throw this.formatError(error, source);
    }
  }

  /**
   * Formata um erro para apresentação consistente
   * @param {Error} error Objeto de erro original
   * @param {string} source Fonte do erro
   * @returns {Error} Erro formatado
   */
  static formatError(error, source) {
    // Criar novo erro com mensagem formatada
    const formattedError = new Error(`[${source}] ${error.message}`);
    formattedError.originalError = error;
    formattedError.source = source;
    formattedError.timestamp = new Date().toISOString();
    
    return formattedError;
  }

  /**
   * Verifica se um erro é de um tipo específico
   * @param {Error} error Objeto de erro
   * @param {string} errorType Tipo de erro a verificar
   * @returns {boolean} True se o erro for do tipo especificado
   */
  static isErrorType(error, errorType) {
    if (!error) return false;
    
    // Verificar por nome de erro
    if (error.name === errorType) return true;
    
    // Verificar por tipo de instância
    if (error.constructor && error.constructor.name === errorType) return true;
    
    // Verificar mensagem para erros específicos
    if (errorType === 'FileNotFound' && error.message.includes('não encontrado')) return true;
    if (errorType === 'Permission' && error.message.includes('permissão')) return true;
    if (errorType === 'Network' && error.message.includes('rede')) return true;
    
    return false;
  }

  /**
   * Gera uma resposta de erro padronizada para APIs
   * @param {Error} error Objeto de erro
   * @param {string} source Fonte do erro
   * @returns {Object} Objeto de resposta de erro padronizado
   */
  static getErrorResponse(error, source) {
    // Determinar código de erro HTTP apropriado
    let statusCode = 500;
    if (this.isErrorType(error, 'FileNotFound')) statusCode = 404;
    if (this.isErrorType(error, 'Permission')) statusCode = 403;
    if (this.isErrorType(error, 'Validation')) statusCode = 400;
    
    // Criar resposta padronizada
    return {
      success: false,
      error: {
        message: error.message,
        code: statusCode,
        source: source,
        timestamp: new Date().toISOString()
      }
    };
  }

  /**
   * Trata erros específicos do extrator OCR
   * @param {Error} error Objeto de erro
   * @param {string} ocrType Tipo de OCR (Tesseract ou PaddleOCR)
   * @returns {Object} Informações de erro tratadas
   */
  static handleOCRError(error, ocrType) {
    let errorType = 'OCRGeneric';
    let suggestion = 'Tente novamente com uma imagem de melhor qualidade.';
    
    // Identificar tipo específico de erro OCR
    if (error.message.includes('não encontrado')) {
      errorType = 'OCRFileNotFound';
      suggestion = 'Verifique se o arquivo existe e tem permissões corretas.';
    } else if (error.message.includes('instalado')) {
      errorType = 'OCRNotInstalled';
      suggestion = `Instale o ${ocrType} seguindo as instruções da documentação.`;
    } else if (error.message.includes('timeout') || error.message.includes('tempo esgotado')) {
      errorType = 'OCRTimeout';
      suggestion = 'A imagem pode ser muito grande ou complexa. Tente reduzir seu tamanho.';
    } else if (error.message.includes('memória')) {
      errorType = 'OCROutOfMemory';
      suggestion = 'A imagem é muito grande. Tente reduzir seu tamanho ou liberar memória do sistema.';
    }
    
    // Registrar erro específico
    this.logError(error, `OCR-${ocrType}`, { errorType });
    
    // Retornar informações tratadas
    return {
      errorType,
      suggestion,
      originalError: error.message
    };
  }

  /**
   * Trata erros específicos de compatibilidade com Windows
   * @param {Error} error Objeto de erro
   * @returns {Object} Informações de erro tratadas
   */
  static handleWindowsCompatibilityError(error) {
    let errorType = 'WindowsGeneric';
    let suggestion = 'Verifique a compatibilidade com Windows na documentação.';
    
    // Identificar tipo específico de erro de compatibilidade
    if (error.message.includes('caminho')) {
      errorType = 'WindowsPathError';
      suggestion = 'Use o utilitário PathUtils para garantir compatibilidade de caminhos.';
    } else if (error.message.includes('permissão')) {
      errorType = 'WindowsPermissionError';
      suggestion = 'Execute como administrador ou ajuste as permissões da pasta.';
    } else if (error.message.includes('Python')) {
      errorType = 'WindowsPythonError';
      suggestion = 'Verifique se o Python está instalado e no PATH do sistema.';
    }
    
    // Registrar erro específico
    this.logError(error, 'WindowsCompatibility', { errorType });
    
    // Retornar informações tratadas
    return {
      errorType,
      suggestion,
      originalError: error.message
    };
  }
}

module.exports = ErrorHandler;
