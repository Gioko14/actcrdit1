/**
 * Utilitário para manipulação de caminhos compatível com Windows
 * Garante que todos os caminhos sejam tratados de forma consistente em diferentes sistemas operacionais
 */

const path = require('path');
const fs = require('fs');
const { promisify } = require('util');

// Promisificar funções do fs
const fsExists = promisify(fs.exists);
const fsMkdir = promisify(fs.mkdir);
const fsReaddir = promisify(fs.readdir);
const fsReadFile = promisify(fs.readFile);
const fsWriteFile = promisify(fs.writeFile);
const fsUnlink = promisify(fs.unlink);

/**
 * Utilitário de caminhos multiplataforma
 */
class PathUtils {
  /**
   * Normaliza um caminho para o sistema operacional atual
   * @param {string} filePath Caminho a ser normalizado
   * @returns {string} Caminho normalizado
   */
  static normalize(filePath) {
    return path.normalize(filePath);
  }

  /**
   * Junta segmentos de caminho de forma compatível com o sistema operacional
   * @param {...string} paths Segmentos de caminho
   * @returns {string} Caminho combinado
   */
  static join(...paths) {
    return path.join(...paths);
  }

  /**
   * Resolve um caminho absoluto
   * @param {...string} paths Segmentos de caminho
   * @returns {string} Caminho absoluto
   */
  static resolve(...paths) {
    return path.resolve(...paths);
  }

  /**
   * Verifica se um caminho existe
   * @param {string} filePath Caminho a verificar
   * @returns {Promise<boolean>} True se o caminho existir
   */
  static async exists(filePath) {
    try {
      return await fsExists(filePath);
    } catch (error) {
      console.error(`Erro ao verificar existência do caminho: ${filePath}`, error);
      return false;
    }
  }

  /**
   * Cria um diretório recursivamente
   * @param {string} dirPath Caminho do diretório
   * @returns {Promise<void>}
   */
  static async mkdir(dirPath) {
    try {
      await fsMkdir(dirPath, { recursive: true });
    } catch (error) {
      // Ignora erro se o diretório já existir
      if (error.code !== 'EEXIST') {
        console.error(`Erro ao criar diretório: ${dirPath}`, error);
        throw error;
      }
    }
  }

  /**
   * Lista arquivos em um diretório
   * @param {string} dirPath Caminho do diretório
   * @returns {Promise<string[]>} Lista de arquivos
   */
  static async listFiles(dirPath) {
    try {
      return await fsReaddir(dirPath);
    } catch (error) {
      console.error(`Erro ao listar arquivos no diretório: ${dirPath}`, error);
      throw error;
    }
  }

  /**
   * Lê conteúdo de um arquivo
   * @param {string} filePath Caminho do arquivo
   * @param {string} encoding Codificação (padrão: 'utf8')
   * @returns {Promise<string|Buffer>} Conteúdo do arquivo
   */
  static async readFile(filePath, encoding = 'utf8') {
    try {
      return await fsReadFile(filePath, encoding);
    } catch (error) {
      console.error(`Erro ao ler arquivo: ${filePath}`, error);
      throw error;
    }
  }

  /**
   * Escreve conteúdo em um arquivo
   * @param {string} filePath Caminho do arquivo
   * @param {string|Buffer} content Conteúdo a ser escrito
   * @returns {Promise<void>}
   */
  static async writeFile(filePath, content) {
    try {
      // Garantir que o diretório exista
      const dirPath = path.dirname(filePath);
      await PathUtils.mkdir(dirPath);
      
      await fsWriteFile(filePath, content);
    } catch (error) {
      console.error(`Erro ao escrever arquivo: ${filePath}`, error);
      throw error;
    }
  }

  /**
   * Remove um arquivo
   * @param {string} filePath Caminho do arquivo
   * @returns {Promise<void>}
   */
  static async removeFile(filePath) {
    try {
      await fsUnlink(filePath);
    } catch (error) {
      // Ignora erro se o arquivo não existir
      if (error.code !== 'ENOENT') {
        console.error(`Erro ao remover arquivo: ${filePath}`, error);
        throw error;
      }
    }
  }

  /**
   * Obtém o separador de caminho do sistema atual
   * @returns {string} Separador de caminho
   */
  static getSeparator() {
    return path.sep;
  }

  /**
   * Verifica se o sistema operacional é Windows
   * @returns {boolean} True se for Windows
   */
  static isWindows() {
    return process.platform === 'win32';
  }

  /**
   * Converte um caminho para formato compatível com Windows se necessário
   * @param {string} filePath Caminho a ser convertido
   * @returns {string} Caminho compatível
   */
  static toWindowsPath(filePath) {
    if (PathUtils.isWindows()) {
      return filePath.replace(/\//g, '\\');
    }
    return filePath;
  }

  /**
   * Converte um caminho para formato com barras (Unix-like)
   * @param {string} filePath Caminho a ser convertido
   * @returns {string} Caminho com barras
   */
  static toUnixPath(filePath) {
    return filePath.replace(/\\/g, '/');
  }
}

module.exports = PathUtils;
