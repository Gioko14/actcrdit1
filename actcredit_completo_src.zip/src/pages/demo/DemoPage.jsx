import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import ThemeSwitcher from '@/components/ui/ThemeSwitcher';
import BatchProcessingUploader from '@/components/batch-processing/BatchProcessingUploader';
import MultiFormatSupport from '@/components/file-formats/MultiFormatSupport';
import InteractiveChart from '@/components/dashboard-interactive/InteractiveChart';
import EncryptionComponent from '@/components/security/EncryptionComponent';
import DragDropContainer from '@/components/drag-drop/DragDropContainer';
import MultiFactorAuth from '@/components/auth/MultiFactorAuth';
import RealTimePreview from '@/components/preview/RealTimePreview';

/**
 * Página de demonstração das melhorias implementadas
 * Permite testar e validar todas as funcionalidades em um único local
 */
const DemoPage = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewData, setPreviewData] = useState(null);
  
  // Dados de exemplo para o DragDropContainer
  const [dragDropItems, setDragDropItems] = useState([
    { id: 1, content: 'Item de exemplo 1' },
    { id: 2, content: 'Item de exemplo 2' },
    { id: 3, content: 'Item de exemplo 3' },
  ]);
  
  // Manipular arquivo processado para pré-visualização
  const handleFileProcessed = (file, result) => {
    setSelectedFile(file);
    setPreviewData(result);
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-2xl">Demonstração de Melhorias - ActCredit</CardTitle>
          <CardDescription>
            Teste e valide todas as novas funcionalidades implementadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            Esta página permite testar e validar todas as melhorias implementadas na plataforma ActCredit.
            Cada aba contém uma funcionalidade diferente para você explorar.
          </p>
          
          <div className="flex items-center justify-end mb-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">Tema:</span>
              <ThemeSwitcher />
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Tabs defaultValue="theme" className="w-full">
        <TabsList className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 mb-8">
          <TabsTrigger value="theme">Tema</TabsTrigger>
          <TabsTrigger value="batch">Processamento em Lote</TabsTrigger>
          <TabsTrigger value="formats">Múltiplos Formatos</TabsTrigger>
          <TabsTrigger value="dashboard">Dashboard Interativo</TabsTrigger>
          <TabsTrigger value="security">Criptografia</TabsTrigger>
          <TabsTrigger value="dragdrop">Drag-and-Drop</TabsTrigger>
          <TabsTrigger value="mfa">Autenticação MFA</TabsTrigger>
          <TabsTrigger value="preview">Pré-visualização</TabsTrigger>
        </TabsList>
        
        <TabsContent value="theme" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Tema Escuro/Claro Aprimorado</CardTitle>
              <CardDescription>
                Alternância de tema com detecção automática de preferência do sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center space-y-4">
              <ThemeSwitcher />
              <p className="text-center text-muted-foreground">
                O tema agora detecta automaticamente a preferência do sistema e oferece transições suaves entre temas.
                Experimente alternar entre os temas claro, escuro e preferência do sistema.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="batch" className="space-y-4">
          <BatchProcessingUploader 
            onFilesProcessed={(results, errors) => {
              console.log('Arquivos processados:', results);
              console.log('Erros:', errors);
            }}
          />
        </TabsContent>
        
        <TabsContent value="formats" className="space-y-4">
          <MultiFormatSupport 
            onFileProcessed={(data) => {
              console.log('Arquivo processado:', data);
              handleFileProcessed(data.file, data.result);
            }}
          />
        </TabsContent>
        
        <TabsContent value="dashboard" className="space-y-4">
          <InteractiveChart 
            title="Análise de Crédito por Região"
            description="Visualização interativa com filtros e exportação"
            initialType="bar"
            initialPeriod="month"
            allowedTypes={['bar', 'line', 'pie']}
          />
        </TabsContent>
        
        <TabsContent value="security" className="space-y-4">
          <EncryptionComponent />
        </TabsContent>
        
        <TabsContent value="dragdrop" className="space-y-4">
          <DragDropContainer 
            items={dragDropItems}
            onOrderChange={(items) => {
              setDragDropItems(items);
              console.log('Nova ordem:', items);
            }}
            onItemRemove={(id, items) => {
              setDragDropItems(items);
              console.log('Item removido:', id);
            }}
            onItemAdd={(item, items) => {
              setDragDropItems(items);
              console.log('Item adicionado:', item);
            }}
            title="Organização de Elementos"
          />
        </TabsContent>
        
        <TabsContent value="mfa" className="space-y-4">
          <MultiFactorAuth />
        </TabsContent>
        
        <TabsContent value="preview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <MultiFormatSupport 
                onFileProcessed={(data) => {
                  console.log('Arquivo para pré-visualização:', data);
                  handleFileProcessed(data.file, data.result);
                }}
              />
            </div>
            <div>
              <RealTimePreview 
                file={selectedFile}
                data={previewData}
                title="Pré-visualização do Arquivo"
                onDownload={(file) => {
                  console.log('Download solicitado:', file);
                  // Lógica de download seria implementada aqui
                }}
              />
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DemoPage;
