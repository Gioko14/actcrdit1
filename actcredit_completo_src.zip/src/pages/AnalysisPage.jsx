import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  BarChart, 
  Filter, 
  Calendar, 
  Download, 
  Eye, 
  Edit, 
  Trash,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Shield,
  Upload,
  X
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

import RelatorioAnaliseCompleto from '@/components/analise/RelatorioAnaliseCompleto';
import NovaAnaliseModal from '@/components/analise/NovaAnaliseModal';

// Serviços
import BiAnalyticsService from '@/services/bi-analytics/BiAnalyticsService';
import RulesEngineService from '@/services/rules-engine/RulesEngineService';
import MLScoringService from '@/services/ml-scoring/MLScoringService';
import { toast } from 'sonner';

const AnalysisPage = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('recentes');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPeriod, setFilterPeriod] = useState('todos');
  const [analises, setAnalises] = useState([]);
  const [metricas, setMetricas] = useState({
    totalAnalises: 0,
    taxaAprovacao: 0,
    scoreMedio: 0,
    tempoMedioAnalise: 0
  });
  const [selectedAnalise, setSelectedAnalise] = useState(null);
  const [showRelatorio, setShowRelatorio] = useState(false);
  const [showNovaAnaliseModal, setShowNovaAnaliseModal] = useState(false);
  const [pdfFile, setPdfFile] = useState(null);
  const [showPdfUpload, setShowPdfUpload] = useState(false);
  const [isProcessingPdf, setIsProcessingPdf] = useState(false);
  
  // Carregar dados iniciais
  useEffect(() => {
    const carregarDados = async () => {
      try {
        // Carregar métricas
        const metricasResponse = await BiAnalyticsService.getMetricasAnalise();
        setMetricas(metricasResponse);
        
        // Carregar análises
        const analisesResponse = await BiAnalyticsService.getAnalises(activeTab);
        setAnalises(analisesResponse);
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
        toast.error("Erro ao carregar dados. Tente novamente.");
      }
    };
    
    carregarDados();
  }, [activeTab]);
  
  // Filtrar análises com base na busca
  const analisesFiltradas = analises.filter(analise => {
    if (!searchTerm.trim()) return true;
    
    const termoBusca = searchTerm.toLowerCase();
    return (
      (analise.cliente?.toLowerCase().includes(termoBusca) || 
       analise.nomeCliente?.toLowerCase().includes(termoBusca)) ||
      (analise.tipo?.toLowerCase().includes(termoBusca) || 
       analise.modalidadeCredito?.toLowerCase().includes(termoBusca)) ||
      (analise.status?.toLowerCase().includes(termoBusca) || 
       analise.decisao?.toLowerCase().includes(termoBusca))
    );
  });
  
  // Abrir modal de nova análise
  const handleNovaAnalise = () => {
    setShowNovaAnaliseModal(true);
  };

  // Abrir upload de PDF
  const handlePdfUpload = () => {
    setPdfFile(null);
    setShowPdfUpload(true);
  };

  // Processar upload de PDF
  const handlePdfSubmit = async () => {
    if (!pdfFile) {
      toast.error("Por favor, selecione um arquivo PDF");
      return;
    }

    try {
      setIsProcessingPdf(true);
      
      // Simular processamento do PDF
      toast.info("Processando PDF...");
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Simular criação de análise a partir do PDF
      const novaAnalise = {
        nomeCliente: `Empresa ${pdfFile.name.substring(0, 10)}`,
        cnpjCliente: "00.000.000/0000-00",
        tipoAnalise: "Prospecção",
        dataAnalise: new Date().toISOString(),
        score: Math.floor(Math.random() * 40) + 60,
        decisao: Math.random() > 0.3 ? 'Aprovado' : Math.random() > 0.5 ? 'Aprovado com Condições' : 'Análise Manual',
        modalidadeCredito: "Importação PDF",
        justificativa: "Análise importada via PDF, dados extraídos automaticamente.",
        serasaScore: Math.floor(Math.random() * 700) + 300,
        serasaPendencias: Math.random() > 0.8 ? ['Pendência Financeira XPTO', 'Protesto Cartório Y'] : [],
        serasaConsultado: true,
        valorSolicitado: Math.floor(Math.random() * 500000) + 100000,
        faturamentoAnual: Math.floor(Math.random() * 5000000) + 1000000,
        percentualEndividamento: Math.floor(Math.random() * 40) + 10,
        tempoAtividade: Math.floor(Math.random() * 10) + 1
      };
      
      // Adicionar à lista local
      const analiseAdicionada = await BiAnalyticsService.adicionarAnalise(novaAnalise);
      
      // Fechar modal e mostrar mensagem de sucesso
      setShowPdfUpload(false);
      setPdfFile(null);
      toast.success("PDF processado com sucesso!");
      
      // Recarregar análises
      const analisesResponse = await BiAnalyticsService.getAnalises(activeTab);
      setAnalises(analisesResponse);
      
      // Opcional: Mostrar relatório da análise criada
      visualizarRelatorio(analiseAdicionada);
    } catch (error) {
      console.error('Erro ao processar PDF:', error);
      toast.error("Erro ao processar PDF. Tente novamente.");
    } finally {
      setIsProcessingPdf(false);
    }
  };
  
  // Renderizar badge de status com cor apropriada
  const renderStatusBadge = (status) => {
    if (!status) return <span className="text-gray-500">-</span>;
    
    let color = '';
    let icon = null;
    
    switch(status) {
      case 'Aprovado':
        color = 'bg-green-500/20 text-green-500 border-green-500/50';
        icon = <CheckCircle className="h-4 w-4 mr-1" />;
        break;
      case 'Aprovado com Condições':
        color = 'bg-blue-500/20 text-blue-500 border-blue-500/50';
        icon = <CheckCircle className="h-4 w-4 mr-1" />;
        break;
      case 'Análise Manual':
        color = 'bg-yellow-500/20 text-yellow-500 border-yellow-500/50';
        icon = <AlertTriangle className="h-4 w-4 mr-1" />;
        break;
      case 'Reprovado':
        color = 'bg-red-500/20 text-red-500 border-red-500/50';
        icon = <XCircle className="h-4 w-4 mr-1" />;
        break;
      default:
        color = 'bg-gray-500/20 text-gray-500 border-gray-500/50';
    }
    
    return (
      <span className={`px-2 py-1 rounded text-xs border flex items-center ${color}`}>
        {icon}
        {status}
      </span>
    );
  };
  
  // Renderizar barra de score com cor apropriada
  const renderScoreBar = (score) => {
    if (!score && score !== 0) return <span className="text-gray-400">N/A</span>;
    
    let color = '';
    
    if (score >= 80) {
      color = 'bg-green-500';
    } else if (score >= 60) {
      color = 'bg-yellow-500';
    } else {
      color = 'bg-red-500';
    }
    
    return (
      <div className="flex items-center">
        <span className="mr-2 font-semibold">{score}</span>
        <div className="h-2 w-16 bg-gray-700 rounded-full">
          <div className={`h-2 rounded-full ${color}`} style={{ width: `${score}%` }}></div>
        </div>
      </div>
    );
  };
  
  // Visualizar relatório completo
  const visualizarRelatorio = async (analise) => {
    try {
      // Se a análise já tem todos os campos necessários, usamos diretamente
      if (analise.nomeCliente && analise.dataAnalise) {
        setSelectedAnalise({
          ...analise,
          // Garantir que campos essenciais existam para evitar erros
          resultadosPoliticas: analise.resultadosPoliticas || [],
          fatoresPositivos: analise.fatoresPositivos || [],
          fatoresNegativos: analise.fatoresNegativos || [],
          probabilidadeDefault: analise.probabilidadeDefault || (100 - analise.score) / 100,
          condicoes: analise.condicoes || null
        });
        setShowRelatorio(true);
        return;
      }
      
      // Caso contrário, montamos um objeto completo com os dados disponíveis
      // Simular dados do cliente
      const dadosCliente = {
        nomeCliente: analise.nomeCliente || analise.cliente || "Cliente não identificado",
        cnpjCliente: analise.cnpjCliente || "12.345.678/0001-99",
        setorCliente: analise.setorCliente || 
                      (analise.tipo === 'Majoração' ? 'Tecnologia' : 
                      analise.tipo === 'Renovação' ? 'Indústria' : 'Varejo'),
        regiaoCliente: analise.regiaoCliente || 'Sudeste',
        tempoAtividade: analise.tempoAtividade || 5
      };
      
      // Simular dados da análise
      const dadosAnalise = {
        id: analise.id || Math.floor(Math.random() * 1000),
        dataAnalise: analise.dataAnalise || analise.data || new Date().toISOString(),
        tipoAnalise: analise.tipoAnalise || 'Manual',
        responsavelAnalise: analise.responsavelAnalise || 'Administrador',
        valorSolicitado: analise.valorSolicitado || 500000,
        faturamentoAnual: analise.faturamentoAnual || 2500000,
        percentualEndividamento: analise.percentualEndividamento || 35,
        modalidadeCredito: analise.modalidadeCredito || 'Capital de Giro',
        prazoDesejado: analise.prazoDesejado || 36,
        score: analise.score,
        decisao: analise.decisao || analise.status,
        justificativa: analise.justificativa || 
                      `${analise.status || analise.decisao} devido a score ${analise.score} e análise de políticas de crédito.`
      };
      
      // Simular dados do Serasa
      const dadosSerasa = analise.serasaConsultado ? analise : {
        serasaScore: Math.floor(Math.random() * 700) + 300, // Score entre 300 e 999
        serasaPendencias: Math.random() > 0.8 ? ['Pendência Financeira XPTO', 'Protesto Cartório Y'] : [],
        serasaConsultado: true
      };
      
      // Simular resultados de políticas
      const resultadosPoliticas = analise.resultadosPoliticas || [
        {
          politica: 'Score Mínimo',
          criterio: 'Score deve ser maior ou igual a 60',
          dadoVerificado: `Score: ${analise.score}`,
          resultado: analise.score >= 60 ? 'Cumprida' : 'Não Cumprida',
          detalhes: analise.score >= 60 ? 
            `Score ${analise.score} é maior ou igual ao mínimo exigido (60)` : 
            `Score ${analise.score} é menor que o mínimo exigido (60)`
        },
        {
          politica: 'Score Mínimo Serasa',
          criterio: 'Score Serasa >= 400',
          dadoVerificado: `Score: ${dadosSerasa.serasaScore}`,
          resultado: dadosSerasa.serasaScore >= 400 ? 'Cumprida' : 'Não Cumprida',
          detalhes: dadosSerasa.serasaScore >= 400 ? 'Score Serasa OK.' : 'Score Serasa abaixo do mínimo.'
        },
        {
          politica: 'Faturamento Mínimo',
          criterio: 'Faturamento anual deve ser maior ou igual a R$ 1.000.000,00',
          dadoVerificado: 'Faturamento: R$ 2.500.000,00',
          resultado: 'Cumprida',
          detalhes: 'Faturamento R$ 2.500.000,00 é maior ou igual ao mínimo exigido (R$ 1.000.000,00)'
        }
      ];
      
      // Simular fatores XAI
      const fatoresPositivos = analise.fatoresPositivos || [
        'Faturamento anual elevado (R$ 2.500.000,00)',
        'Tempo de atividade significativo (5 anos)',
        'Atuação em setor de baixo risco (Tecnologia)'
      ];
      
      const fatoresNegativos = analise.fatoresNegativos || [
        'Percentual de endividamento moderado (35%)',
        'Histórico de crédito com restrições pontuais'
      ];
      
      // Simular condições aprovadas
      const condicoes = analise.condicoes || ((analise.status === 'Aprovado' || analise.decisao === 'Aprovado' || 
                      analise.status === 'Aprovado com Condições' || analise.decisao === 'Aprovado com Condições') ? {
        limiteAprovado: 450000,
        taxaAprovada: 1.2,
        prazoAprovado: 36,
        garantiasExigidas: ['Aval dos Sócios']
      } : null);
      
      // Montar objeto completo da análise
      const analiseCompleta = {
        ...dadosCliente,
        ...dadosAnalise,
        ...dadosSerasa,
        resultadosPoliticas,
        fatoresPositivos,
        fatoresNegativos,
        probabilidadeDefault: analise.probabilidadeDefault || (100 - analise.score) / 100,
        condicoes
      };
      
      setSelectedAnalise(analiseCompleta);
      setShowRelatorio(true);
    } catch (error) {
      console.error('Erro ao carregar relatório:', error);
      toast.error("Erro ao carregar relatório. Tente novamente.");
    }
  };
  
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Análises de Crédito</h1>
          <p className="text-gray-400">Visualize e gerencie análises de crédito realizadas.</p>
        </div>
        {!showRelatorio && (
          <Button 
            className="bg-blue-600 hover:bg-blue-700"
            onClick={handleNovaAnalise}
          >
            <FileText className="h-4 w-4 mr-2" />
            Nova Análise
          </Button>
        )}
        {showRelatorio && (
          <Button 
            variant="outline" 
            className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white"
            onClick={() => setShowRelatorio(false)}
          >
            Voltar para Lista
          </Button>
        )}
      </div>
      
      {!showRelatorio ? (
        <>
          {/* Métricas */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Total de Análises (Mês)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metricas.totalAnalises}</div>
                <p className="text-sm text-green-500">+15% em relação ao mês anterior</p>
              </CardContent>
            </Card>
            
            <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Taxa de Aprovação</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metricas.taxaAprovacao}%</div>
                <p className="text-sm text-green-500">+5% em relação ao mês anterior</p>
              </CardContent>
            </Card>
            
            <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Score Médio</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metricas.scoreMedio}</div>
                <p className="text-sm text-green-500">+3 pontos em relação ao mês anterior</p>
              </CardContent>
            </Card>
            
            <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Tempo Médio de Análise</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metricas.tempoMedioAnalise}h</div>
                <p className="text-sm text-red-500">+0.3h em relação ao mês anterior</p>
              </CardContent>
            </Card>
          </div>
          
          {/* Opções de Análise */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">Via Protheus</h3>
                <p className="text-gray-400 text-sm mb-4">
                  Integração direta com o sistema Protheus para análise de crédito.
                </p>
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={handleNovaAnalise}
                >
                  Nova Análise
                </Button>
              </CardContent>
            </Card>
            
            <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">Imputação Manual</h3>
                <p className="text-gray-400 text-sm mb-4">
                  Cadastro manual de dados para análise de crédito.
                </p>
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={handleNovaAnalise}
                >
                  Nova Análise
                </Button>
              </CardContent>
            </Card>
            
            <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">Upload de Documentos</h3>
                <p className="text-gray-400 text-sm mb-4">
                  Análise automática a partir de documentos PDF.
                </p>
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={handlePdfUpload}
                >
                  Nova Análise
                </Button>
              </CardContent>
            </Card>
          </div>
          
          {/* Tabs e Filtros */}
          <div className="mb-6">
            <Tabs defaultValue="recentes" onValueChange={setActiveTab}>
              <div className="flex justify-between items-center mb-4">
                <TabsList className="bg-[#1e3a5f] border border-[#1e3a5f]">
                  <TabsTrigger value="recentes" className="data-[state=active]:bg-blue-600">Análises Recentes</TabsTrigger>
                  <TabsTrigger value="pendentes" className="data-[state=active]:bg-blue-600">Pendentes de Análise</TabsTrigger>
                  <TabsTrigger value="manual" className="data-[state=active]:bg-blue-600">Análise Manual</TabsTrigger>
                </TabsList>
              </div>
              
              <div className="flex items-center space-x-4 mb-4">
                <div className="flex-1">
                  <Input 
                    placeholder="Buscar análises..." 
                    className="bg-[#1e3a5f] border-[#1e3a5f] text-white placeholder:text-gray-400"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                      <Filter className="h-4 w-4 mr-2" />
                      Filtros
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-[#0f2544] border-[#1e3a5f] text-white">
                    <DropdownMenuItem onClick={() => setFilterPeriod('todos')}>Todos os períodos</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setFilterPeriod('hoje')}>Hoje</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setFilterPeriod('semana')}>Esta semana</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setFilterPeriod('mes')}>Este mês</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                
                <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                  <Calendar className="h-4 w-4 mr-2" />
                  Período
                </Button>
              </div>
              
              {/* Tabela de Análises */}
              <div className="bg-[#0f2544] border border-[#1e3a5f] rounded-lg overflow-hidden">
                {analisesFiltradas.length > 0 ? (
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-[#1e3a5f]">
                        <th className="text-left p-4 text-gray-400 font-medium">Cliente</th>
                        <th className="text-left p-4 text-gray-400 font-medium">Data</th>
                        <th className="text-left p-4 text-gray-400 font-medium">Tipo</th>
                        <th className="text-left p-4 text-gray-400 font-medium">Score</th>
                        <th className="text-left p-4 text-gray-400 font-medium">Serasa</th>
                        <th className="text-left p-4 text-gray-400 font-medium">Status</th>
                        <th className="text-right p-4 text-gray-400 font-medium">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {analisesFiltradas.map((analise, index) => (
                        <tr key={index} className="border-b border-[#1e3a5f] hover:bg-[#1e3a5f]/30">
                          <td className="p-4">{analise.nomeCliente || analise.cliente}</td>
                          <td className="p-4">{analise.dataAnalise ? new Date(analise.dataAnalise).toLocaleDateString('pt-BR') : analise.data}</td>
                          <td className="p-4">{analise.modalidadeCredito || analise.tipo || analise.tipoAnalise}</td>
                          <td className="p-4">{renderScoreBar(analise.score)}</td>
                          <td className="p-4">
                            {analise.serasaConsultado ? (
                              <div className="flex items-center">
                                <Shield className="h-4 w-4 mr-1 text-blue-500" />
                                <span>{analise.serasaScore || "OK"}</span>
                              </div>
                            ) : (
                              <span className="text-gray-500">-</span>
                            )}
                          </td>
                          <td className="p-4">{renderStatusBadge(analise.decisao || analise.status)}</td>
                          <td className="p-4 text-right">
                            <div className="flex justify-end space-x-2">
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                className="h-8 w-8 p-0" 
                                title="Visualizar"
                                onClick={() => visualizarRelatorio(analise)}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Editar">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0" title="Excluir">
                                <Trash className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="p-8 text-center">
                    <FileText className="h-12 w-12 mx-auto mb-4 text-gray-500" />
                    <h3 className="text-xl font-medium mb-2">Nenhuma análise encontrada</h3>
                    <p className="text-gray-400 mb-4">
                      Não foram encontradas análises com os filtros selecionados.
                    </p>
                    <Button 
                      className="bg-blue-600 hover:bg-blue-700"
                      onClick={handleNovaAnalise}
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      Criar Nova Análise
                    </Button>
                  </div>
                )}
              </div>
            </Tabs>
          </div>
        </>
      ) : (
        <RelatorioAnaliseCompleto analise={selectedAnalise} />
      )}

      {/* Modal de Nova Análise */}
      <NovaAnaliseModal 
        isOpen={showNovaAnaliseModal} 
        onClose={() => setShowNovaAnaliseModal(false)} 
      />

      {/* Modal de Upload de PDF */}
      {showPdfUpload && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-[#0f2544] border border-[#1e3a5f] rounded-lg w-full max-w-md p-6 relative">
            <button 
              onClick={() => setShowPdfUpload(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white"
              disabled={isProcessingPdf}
            >
              <X className="h-5 w-5" />
            </button>
            
            <h2 className="text-xl font-semibold mb-6">Upload de PDF para Análise</h2>
            
            <div className="space-y-4">
              <div className="border-2 border-dashed border-[#1e3a5f] rounded-lg p-6 text-center">
                {pdfFile ? (
                  <div className="flex flex-col items-center">
                    <FileText className="h-12 w-12 text-blue-500 mb-2" />
                    <p className="text-sm font-medium">{pdfFile.name}</p>
                    <p className="text-xs text-gray-400 mt-1">{(pdfFile.size / 1024 / 1024).toFixed(2)} MB</p>
                    <Button 
                      variant="outline" 
                      className="mt-4 border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white"
                      onClick={() => setPdfFile(null)}
                      disabled={isProcessingPdf}
                    >
                      Remover
                    </Button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center">
                    <Upload className="h-12 w-12 text-gray-400 mb-2" />
                    <p className="text-sm text-gray-400 mb-2">Arraste e solte um arquivo PDF ou</p>
                    <label className="cursor-pointer">
                      <span className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md">
                        Selecionar arquivo
                      </span>
                      <input 
                        type="file" 
                        className="hidden" 
                        accept=".pdf" 
                        onChange={(e) => e.target.files && e.target.files[0] && setPdfFile(e.target.files[0])}
                        disabled={isProcessingPdf}
                      />
                    </label>
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex justify-end space-x-3 mt-6">
              <Button 
                variant="outline" 
                className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white"
                onClick={() => setShowPdfUpload(false)}
                disabled={isProcessingPdf}
              >
                Cancelar
              </Button>
              <Button 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={handlePdfSubmit}
                disabled={!pdfFile || isProcessingPdf}
              >
                {isProcessingPdf ? 'Processando...' : 'Processar PDF'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AnalysisPage;
