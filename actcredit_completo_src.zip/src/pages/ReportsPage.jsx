import React, { useState, useEffect } from 'react';
import { 
  BarChart4, 
  FileText, 
  Download, 
  Filter, 
  Calendar, 
  Printer, 
  ChevronDown,
  Eye 
} from 'lucide-react';

// Componentes
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ReportViewer from '@/components/reports/ReportViewer';
import FilterBar from '@/components/dashboard/FilterBar';
import BiAnalyticsService from '@/services/bi-analytics/BiAnalyticsService';

const ReportsPage = () => {
  // Estado para controlar a visualização de relatórios
  const [viewingReport, setViewingReport] = useState(null);
  const [filteredReports, setFilteredReports] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);

  // Dados para os relatórios disponíveis
  const availableReports = [
    { 
      id: 1, 
      title: 'Relatório de Performance', 
      description: 'Métricas de aprovação, rejeição e análise manual', 
      icon: <BarChart4 className="h-6 w-6" />,
      type: 'performance'
    },
    { 
      id: 2, 
      title: 'Relatório de Clientes', 
      description: 'Distribuição de clientes por segmento, região e faturamento', 
      icon: <FileText className="h-6 w-6" />,
      type: 'clients'
    },
    { 
      id: 3, 
      title: 'Relatório de Analistas', 
      description: 'Performance individual dos analistas e volume de análises', 
      icon: <FileText className="h-6 w-6" />,
      type: 'analysts'
    },
    { 
      id: 4, 
      title: 'Relatório de Políticas', 
      description: 'Efetividade das políticas de crédito e exceções', 
      icon: <BarChart4 className="h-6 w-6" />,
      type: 'policies'
    },
  ];
  
  // Dados para os relatórios recentes
  const recentReports = [
    { 
      id: 1, 
      title: 'Performance Mensal', 
      date: '01/05/2025', 
      type: 'performance', 
      size: '2.4 MB',
      status: 'Completo',
      description: 'Relatório mensal de performance com métricas de aprovação, rejeição e análise manual.'
    },
    { 
      id: 2, 
      title: 'Análise de Segmentos', 
      date: '15/04/2025', 
      type: 'clients', 
      size: '1.8 MB',
      status: 'Completo',
      description: 'Análise detalhada dos segmentos de clientes e sua distribuição por região.'
    },
    { 
      id: 3, 
      title: 'Distribuição Regional', 
      date: '01/04/2025', 
      type: 'clients', 
      size: '3.1 MB',
      status: 'Completo',
      description: 'Distribuição geográfica dos clientes e análises por região.'
    },
    { 
      id: 4, 
      title: 'Análise de Risco Q1', 
      date: '31/03/2025', 
      type: 'policies', 
      size: '4.5 MB',
      status: 'Completo',
      description: 'Análise de risco do primeiro trimestre com indicadores de performance.'
    },
  ];

  // Inicializar relatórios filtrados
  useEffect(() => {
    setFilteredReports(recentReports);
  }, []);

  // Função para lidar com mudanças nos filtros
  const handleFilterChange = (filters) => {
    setLoading(true);
    
    // Aplicar filtros aos relatórios
    let filtered = [...recentReports];
    
    // Filtrar por período
    if (filters.period !== 'all') {
      const today = new Date();
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      
      filtered = filtered.filter(report => {
        const reportDate = new Date(report.date.split('/').reverse().join('-'));
        
        switch (filters.period) {
          case 'today':
            return reportDate.toDateString() === today.toDateString();
          case 'yesterday':
            return reportDate.toDateString() === yesterday.toDateString();
          case 'last7days':
            const last7Days = new Date(today);
            last7Days.setDate(last7Days.getDate() - 7);
            return reportDate >= last7Days;
          case 'last30days':
            const last30Days = new Date(today);
            last30Days.setDate(last30Days.getDate() - 30);
            return reportDate >= last30Days;
          case 'custom':
            if (filters.dateRange.from) {
              const fromDate = new Date(filters.dateRange.from);
              if (filters.dateRange.to) {
                const toDate = new Date(filters.dateRange.to);
                return reportDate >= fromDate && reportDate <= toDate;
              }
              return reportDate >= fromDate;
            }
            return true;
          default:
            return true;
        }
      });
    }
    
    // Aplicar termo de busca
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(report => 
        report.title.toLowerCase().includes(term) || 
        report.description.toLowerCase().includes(term)
      );
    }
    
    // Simular carregamento de dados
    setTimeout(() => {
      setFilteredReports(filtered);
      setLoading(false);
    }, 500);
  };

  // Função para abrir o visualizador de relatórios
  const handleViewReport = (report) => {
    setViewingReport(report);
  };

  // Função para fechar o visualizador de relatórios
  const handleCloseViewer = () => {
    setViewingReport(null);
  };

  // Renderizar o badge de status com cor apropriada
  const renderStatusBadge = (status) => {
    let color = '';
    
    switch(status) {
      case 'Completo':
        color = 'bg-green-500/20 text-green-500 border-green-500/50';
        break;
      case 'Em Progresso':
        color = 'bg-blue-500/20 text-blue-500 border-blue-500/50';
        break;
      case 'Falha':
        color = 'bg-red-500/20 text-red-500 border-red-500/50';
        break;
      default:
        color = 'bg-gray-500/20 text-gray-500 border-gray-500/50';
    }
    
    return (
      <span className={`px-2 py-1 rounded text-xs border ${color}`}>
        {status}
      </span>
    );
  };

  return (
    <div className="p-6">
      {/* Cabeçalho */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Relatórios</h1>
        <p className="text-gray-400 mt-1">
          Gere e visualize relatórios detalhados sobre análises de crédito.
        </p>
      </div>

      {/* Filtros interativos */}
      <FilterBar 
        availableFilters={['period']}
        onFilterChange={handleFilterChange}
      />

      {/* Tabs para diferentes tipos de relatórios */}
      <Tabs defaultValue="available" className="mb-8">
        <TabsList className="bg-[#1e3a5f] border border-[#1e3a5f]">
          <TabsTrigger value="available" className="data-[state=active]:bg-blue-600">Relatórios Disponíveis</TabsTrigger>
          <TabsTrigger value="recent" className="data-[state=active]:bg-blue-600">Relatórios Recentes</TabsTrigger>
          <TabsTrigger value="scheduled" className="data-[state=active]:bg-blue-600">Relatórios Agendados</TabsTrigger>
        </TabsList>
        
        {/* Relatórios Disponíveis */}
        <TabsContent value="available" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {availableReports.map((report) => (
              <Card key={report.id} className="bg-[#0f2544] border-[#1e3a5f] text-white hover:border-blue-500 transition-colors cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-start">
                    <div className="bg-[#1e3a5f] rounded-lg p-3 mr-4">
                      {report.icon}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-1">{report.title}</h3>
                      <p className="text-gray-400 text-sm mb-4">{report.description}</p>
                      <div className="flex space-x-2">
                        <Button 
                          className="bg-blue-600 hover:bg-blue-700"
                          onClick={() => handleViewReport(report)}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          Visualizar
                        </Button>
                        <Button variant="outline" className="border-[#1e3a5f] hover:bg-[#1e3a5f]">
                          <Download className="h-4 w-4 mr-2" />
                          Baixar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        {/* Relatórios Recentes */}
        <TabsContent value="recent" className="mt-4">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <input 
                type="text"
                className="w-full pl-10 py-2 bg-[#0f2544] border border-[#1e3a5f] rounded-md text-white"
                placeholder="Buscar relatórios..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  handleFilterChange({period: 'all'});
                }}
              />
              <svg className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>
          
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                {loading ? (
                  <div className="flex items-center justify-center p-12">
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto mb-4"></div>
                      <p className="text-gray-400">Carregando relatórios...</p>
                    </div>
                  </div>
                ) : filteredReports.length === 0 ? (
                  <div className="text-center py-12">
                    <FileText className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <h3 className="text-xl font-semibold mb-2">Nenhum relatório encontrado</h3>
                    <p className="text-gray-400">
                      Tente ajustar os filtros ou termos de busca.
                    </p>
                  </div>
                ) : (
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-[#1e3a5f] text-left">
                        <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                          Relatório
                        </th>
                        <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                          Data
                        </th>
                        <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                          Tipo
                        </th>
                        <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                          Tamanho
                        </th>
                        <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                          Ações
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredReports.map((report) => (
                        <tr key={report.id} className="border-b border-[#1e3a5f] hover:bg-[#1e3a5f]/30">
                          <td className="px-6 py-4 whitespace-nowrap font-medium">
                            <div className="flex items-center">
                              <FileText className="h-4 w-4 mr-2 text-blue-500" />
                              {report.title}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {report.date}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {report.type === 'performance' ? 'Performance' : 
                             report.type === 'clients' ? 'Clientes' :
                             report.type === 'analysts' ? 'Analistas' :
                             report.type === 'policies' ? 'Políticas' : report.type}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {report.size}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {renderStatusBadge(report.status)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex space-x-2">
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-8 w-8 p-0"
                                onClick={() => handleViewReport(report)}
                                title="Visualizar"
                              >
                                <Eye className="h-4 w-4 text-blue-500" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-8 w-8 p-0"
                                title="Baixar"
                              >
                                <Download className="h-4 w-4 text-blue-500" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-8 w-8 p-0"
                                title="Imprimir"
                              >
                                <Printer className="h-4 w-4 text-gray-400" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Relatórios Agendados */}
        <TabsContent value="scheduled" className="mt-4">
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white p-6">
            <div className="text-center py-8">
              <Calendar className="h-16 w-16 mx-auto mb-4 text-gray-400" />
              <h3 className="text-xl font-semibold mb-2">Nenhum relatório agendado</h3>
              <p className="text-gray-400 mb-6">
                Você ainda não tem relatórios agendados. Agende relatórios para geração automática.
              </p>
              <Button className="bg-blue-600 hover:bg-blue-700">
                Agendar Novo Relatório
              </Button>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Estatísticas de Relatórios */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Relatórios Gerados (Mês)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <p className="text-sm text-green-500">+12% em relação ao mês anterior</p>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Relatórios Baixados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">18</div>
            <p className="text-sm text-green-500">+8% em relação ao mês anterior</p>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Relatórios Compartilhados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">7</div>
            <p className="text-sm text-red-500">-3% em relação ao mês anterior</p>
          </CardContent>
        </Card>
      </div>

      {/* Visualizador de Relatórios */}
      {viewingReport && (
        <ReportViewer 
          report={viewingReport} 
          onClose={handleCloseViewer} 
        />
      )}
    </div>
  );
};

export default ReportsPage;
