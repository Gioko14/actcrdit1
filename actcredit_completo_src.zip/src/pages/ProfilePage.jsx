import React, { useState } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { 
  User, 
  Mail,
  Phone,
  Building,
  MapPin,
  Edit,
  Camera,
  Lock,
  LogOut
} from 'lucide-react';

// Componentes
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const ProfilePage = () => {
  const { theme } = useTheme();
  const { user, logout } = useAuth();
  
  return (
    <div className="p-6">
      {/* Cabeçalho */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Perfil</h1>
        <p className="text-gray-400 mt-1">
          Gerencie suas informações pessoais e preferências.
        </p>
      </div>

      {/* Perfil do Usuário */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="col-span-1">
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardContent className="p-6">
              <div className="flex flex-col items-center">
                <div className="relative mb-4">
                  <div className="bg-blue-600 rounded-full h-24 w-24 flex items-center justify-center text-2xl font-bold">
                    A
                  </div>
                  <button className="absolute bottom-0 right-0 bg-[#1e3a5f] p-2 rounded-full border border-[#0f2544]">
                    <Camera className="h-4 w-4" />
                  </button>
                </div>
                
                <h3 className="text-xl font-semibold">Administrador</h3>
                <p className="text-gray-400">admin@actcredit.com</p>
                
                <div className="mt-6 w-full space-y-2">
                  <Button variant="outline" className="w-full border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                    <Edit className="h-4 w-4 mr-2" />
                    Editar Perfil
                  </Button>
                  
                  <Button variant="outline" className="w-full border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                    <Lock className="h-4 w-4 mr-2" />
                    Alterar Senha
                  </Button>
                  
                  <Button variant="outline" className="w-full border-[#1e3a5f] text-red-400 hover:bg-red-500/20 hover:text-red-300">
                    <LogOut className="h-4 w-4 mr-2" />
                    Sair
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="col-span-3">
          <Tabs defaultValue="info">
            <TabsList className="bg-[#0f2544] border border-[#1e3a5f]">
              <TabsTrigger value="info" className="data-[state=active]:bg-blue-600">Informações</TabsTrigger>
              <TabsTrigger value="security" className="data-[state=active]:bg-blue-600">Segurança</TabsTrigger>
              <TabsTrigger value="activity" className="data-[state=active]:bg-blue-600">Atividade</TabsTrigger>
            </TabsList>
            
            <TabsContent value="info" className="mt-6">
              <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
                <CardHeader>
                  <CardTitle>Informações Pessoais</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-2">Nome Completo</label>
                      <Input 
                        className="bg-[#1e3a5f] border-[#1e3a5f] text-white"
                        value="Administrador do Sistema"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-2">Email</label>
                      <Input 
                        className="bg-[#1e3a5f] border-[#1e3a5f] text-white"
                        value="admin@actcredit.com"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-2">Cargo</label>
                      <Input 
                        className="bg-[#1e3a5f] border-[#1e3a5f] text-white"
                        value="Administrador"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-2">Departamento</label>
                      <Input 
                        className="bg-[#1e3a5f] border-[#1e3a5f] text-white"
                        value="TI"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-2">Telefone</label>
                      <Input 
                        className="bg-[#1e3a5f] border-[#1e3a5f] text-white"
                        value="(11) 98765-4321"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-2">Data de Admissão</label>
                      <Input 
                        className="bg-[#1e3a5f] border-[#1e3a5f] text-white"
                        value="01/01/2023"
                        disabled
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-end mt-6">
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      Salvar Alterações
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="security" className="mt-6">
              <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
                <CardHeader>
                  <CardTitle>Segurança</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Alterar Senha</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-400 mb-2">Senha Atual</label>
                          <Input 
                            className="bg-[#1e3a5f] border-[#1e3a5f] text-white"
                            type="password"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-400 mb-2">Nova Senha</label>
                          <Input 
                            className="bg-[#1e3a5f] border-[#1e3a5f] text-white"
                            type="password"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-400 mb-2">Confirmar Nova Senha</label>
                          <Input 
                            className="bg-[#1e3a5f] border-[#1e3a5f] text-white"
                            type="password"
                          />
                        </div>
                      </div>
                      
                      <div className="flex justify-end mt-4">
                        <Button className="bg-blue-600 hover:bg-blue-700">
                          Atualizar Senha
                        </Button>
                      </div>
                    </div>
                    
                    <div className="pt-6 border-t border-[#1e3a5f]">
                      <h3 className="text-lg font-semibold mb-4">Autenticação de Dois Fatores</h3>
                      <p className="text-gray-400 mb-4">
                        Adicione uma camada extra de segurança à sua conta ativando a autenticação de dois fatores.
                      </p>
                      
                      <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                        Configurar 2FA
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="activity" className="mt-6">
              <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
                <CardHeader>
                  <CardTitle>Atividade Recente</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-[#1e3a5f] p-4 rounded-lg">
                      <div className="flex justify-between">
                        <div>
                          <h4 className="font-medium">Login no Sistema</h4>
                          <p className="text-gray-400 text-sm">IP: 192.168.1.1 | Navegador: Chrome</p>
                        </div>
                        <span className="text-sm text-gray-400">Hoje, 09:45</span>
                      </div>
                    </div>
                    
                    <div className="bg-[#1e3a5f] p-4 rounded-lg">
                      <div className="flex justify-between">
                        <div>
                          <h4 className="font-medium">Análise de Crédito Aprovada</h4>
                          <p className="text-gray-400 text-sm">Cliente: Tech Solutions Ltda</p>
                        </div>
                        <span className="text-sm text-gray-400">Ontem, 15:30</span>
                      </div>
                    </div>
                    
                    <div className="bg-[#1e3a5f] p-4 rounded-lg">
                      <div className="flex justify-between">
                        <div>
                          <h4 className="font-medium">Política de Crédito Atualizada</h4>
                          <p className="text-gray-400 text-sm">Política: Política Padrão de Crédito</p>
                        </div>
                        <span className="text-sm text-gray-400">15/05/2025, 11:20</span>
                      </div>
                    </div>
                    
                    <div className="bg-[#1e3a5f] p-4 rounded-lg">
                      <div className="flex justify-between">
                        <div>
                          <h4 className="font-medium">Relatório Gerado</h4>
                          <p className="text-gray-400 text-sm">Relatório: Performance Mensal</p>
                        </div>
                        <span className="text-sm text-gray-400">10/05/2025, 14:15</span>
                      </div>
                    </div>
                    
                    <div className="bg-[#1e3a5f] p-4 rounded-lg">
                      <div className="flex justify-between">
                        <div>
                          <h4 className="font-medium">Cliente Cadastrado</h4>
                          <p className="text-gray-400 text-sm">Cliente: Mercado Central S.A.</p>
                        </div>
                        <span className="text-sm text-gray-400">05/05/2025, 10:30</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-center mt-6">
                    <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                      Carregar Mais
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Preferências */}
      <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
        <CardHeader>
          <CardTitle>Preferências</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-4">Tema</h3>
              <div className="flex space-x-4">
                <div className="flex items-center">
                  <input 
                    type="radio" 
                    id="theme-dark" 
                    name="theme" 
                    className="mr-2" 
                    checked={theme === 'dark'} 
                  />
                  <label htmlFor="theme-dark">Escuro</label>
                </div>
                
                <div className="flex items-center">
                  <input 
                    type="radio" 
                    id="theme-light" 
                    name="theme" 
                    className="mr-2" 
                    checked={theme === 'light'} 
                  />
                  <label htmlFor="theme-light">Claro</label>
                </div>
                
                <div className="flex items-center">
                  <input 
                    type="radio" 
                    id="theme-system" 
                    name="theme" 
                    className="mr-2" 
                    checked={theme === 'system'} 
                  />
                  <label htmlFor="theme-system">Sistema</label>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Notificações</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label htmlFor="notify-email">Notificações por Email</label>
                  <input 
                    type="checkbox" 
                    id="notify-email" 
                    className="h-4 w-4" 
                    checked 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <label htmlFor="notify-system">Notificações no Sistema</label>
                  <input 
                    type="checkbox" 
                    id="notify-system" 
                    className="h-4 w-4" 
                    checked 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <label htmlFor="notify-reports">Relatórios Automáticos</label>
                  <input 
                    type="checkbox" 
                    id="notify-reports" 
                    className="h-4 w-4" 
                    checked 
                  />
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex justify-end mt-6">
            <Button className="bg-blue-600 hover:bg-blue-700">
              Salvar Preferências
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfilePage;
