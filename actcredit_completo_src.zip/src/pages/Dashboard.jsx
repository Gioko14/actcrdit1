import React, { useState, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import CustomTooltip from '@/components/dashboard/CustomTooltip';
import { formatCurrency, formatPercent } from '@/lib/utils';

// Dados para gráfico de comparação de score (corrigido para Score Actcredit > Score Mercado)
const scoreComparisonData = [
  { name: 'Varejo', scoreActcredit: 78, scoreMercado: 65 },
  { name: 'Indústria', scoreActcredit: 82, scoreMercado: 70 },
  { name: 'Tecnologia', scoreActcredit: 85, scoreMercado: 72 },
  { name: 'Agronegócio', scoreActcredit: 75, scoreMercado: 63 },
  { name: 'Serviços', scoreActcredit: 80, scoreMercado: 68 }
];

// Dados para gráfico de aprovações por região
const approvalsByRegionData = [
  { name: 'Sudeste', value: 540 },
  { name: 'Sul', value: 320 },
  { name: 'Nordeste', value: 280 },
  { name: 'Centro-Oeste', value: 190 },
  { name: 'Norte', value: 120 }
];

// Dados para gráfico de tendências de aprovações
const approvalTrendsData = [
  { name: 'Jan', aprovados: 42, reprovados: 18 },
  { name: 'Fev', aprovados: 48, reprovados: 15 },
  { name: 'Mar', aprovados: 55, reprovados: 12 },
  { name: 'Abr', aprovados: 62, reprovados: 10 },
  { name: 'Mai', aprovados: 68, reprovados: 8 }
];

// Dados para gráfico de distribuição por setor
const sectorDistributionData = [
  { name: 'Varejo', value: 30 },
  { name: 'Serviços', value: 25 },
  { name: 'Indústria', value: 20 },
  { name: 'Agronegócio', value: 15 },
  { name: 'Tecnologia', value: 10 },
  { name: 'Saúde', value: 5 }
];

// Dados para gráfico de distribuição por tipo de análise
const analysisTypeDistributionData = [
  { name: 'Majoração', value: 35 },
  { name: 'Reativação', value: 25 },
  { name: 'Prospecção', value: 30 },
  { name: 'Revisão', value: 10 }
];

// Dados para gráfico de valor total
const totalValueData = [
  { name: 'Aprovado', value: 6619454.88, percent: 68.7 },
  { name: 'Em análise', value: 3015850.63, percent: 31.3 },
  { name: 'Recusado', value: 2500000, percent: 20.0 } // Adicionado "Recusado" conforme solicitado
];

// Dados para tabela de análise regional
const regionalAnalysisData = [
  { regiao: 'Sudeste', clientes: 540, taxaAprovacao: 72, scoreMedia: 68, valorTotal: 4200000 },
  { regiao: 'Sul', clientes: 320, taxaAprovacao: 65, scoreMedia: 63, valorTotal: 2500000 },
  { regiao: 'Nordeste', clientes: 280, taxaAprovacao: 58, scoreMedia: 59, valorTotal: 1800000 },
  { regiao: 'Centro-Oeste', clientes: 190, taxaAprovacao: 61, scoreMedia: 60, valorTotal: 1200000 },
  { regiao: 'Norte', clientes: 120, taxaAprovacao: 52, scoreMedia: 55, valorTotal: 800000 }
];

// Cores para os gráficos
const COLORS = ['#3b82f6', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444', '#06b6d4'];
const STATUS_COLORS = {
  aprovados: '#10b981',
  reprovados: '#ef4444',
  analiseManual: '#f59e0b',
  Aprovado: '#10b981',
  'Em análise': '#f59e0b',
  Recusado: '#ef4444'
};

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [period, setPeriod] = useState('month');
  
  // Formatadores para valores específicos
  const currencyFormatter = (value) => formatCurrency(value);
  const percentFormatter = (value) => formatPercent(value);
  
  // Configurações de tooltip para diferentes gráficos
  const scoreTooltipConfig = {
    showLabel: true,
    showValue: true,
    valuePrefix: '',
    valueSuffix: ' pontos',
    showComparison: true,
    comparisonLabel: 'Diferença'
  };
  
  const valueTooltipConfig = {
    showLabel: true,
    showValue: true,
    isCurrency: true,
    showPercent: true
  };
  
  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-gray-400 mt-1">
          Visualize os principais indicadores e métricas do sistema Actcredit.
        </p>
      </div>
      
      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Clientes Registrados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,058</div>
            <p className="text-sm text-green-500">+12.5% em relação ao mês anterior</p>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Taxa de Aprovação</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">58%</div>
            <p className="text-sm text-green-500">+3.2% em relação ao mês anterior</p>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Score Médio Actcredit</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">61</div>
            <p className="text-sm text-green-500">+2.5% em relação ao mês anterior</p>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Alerta de Risco</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">31%</div>
            <p className="text-sm text-red-500">+5.3% em relação ao mês anterior</p>
          </CardContent>
        </Card>
      </div>
      
      {/* Gráficos - Primeira linha */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* Aprovações por Região */}
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Aprovações por Região</CardTitle>
            <button className="text-xs text-gray-400 hover:text-white">Exportar</button>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart
                data={approvalsByRegionData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                <XAxis dataKey="name" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip 
                  content={
                    <CustomTooltip 
                      tooltipConfig={{
                        showLabel: true,
                        showValue: true
                      }}
                    />
                  }
                />
                <Bar dataKey="value" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        
        {/* Tendências de Aprovações */}
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Tendências de Aprovações</CardTitle>
            <button className="text-xs text-gray-400 hover:text-white">Exportar</button>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart
                data={approvalTrendsData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                <XAxis dataKey="name" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip 
                  content={
                    <CustomTooltip 
                      tooltipConfig={{
                        showLabel: true,
                        showValue: true
                      }}
                    />
                  }
                />
                <Legend formatter={(value) => <span className="text-white">{value}</span>} />
                <Line type="monotone" dataKey="aprovados" name="Aprovados" stroke={STATUS_COLORS.aprovados} activeDot={{ r: 8 }} />
                <Line type="monotone" dataKey="reprovados" name="Reprovados" stroke={STATUS_COLORS.reprovados} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
      
      {/* Gráficos - Segunda linha */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* Distribuição por Setor */}
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Distribuição por Setor</CardTitle>
            <button className="text-xs text-gray-400 hover:text-white">Exportar</button>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={sectorDistributionData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  nameKey="name"
                >
                  {sectorDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  content={
                    <CustomTooltip 
                      tooltipConfig={{
                        showLabel: true,
                        showValue: true,
                        showPercent: true
                      }}
                    />
                  }
                />
                <Legend formatter={(value) => <span className="text-white">{value}</span>} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        
        {/* Distribuição por Tipo de Análise */}
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Distribuição por Tipo de Análise</CardTitle>
            <button className="text-xs text-gray-400 hover:text-white">Exportar</button>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart
                data={analysisTypeDistributionData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                <XAxis dataKey="name" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip 
                  content={
                    <CustomTooltip 
                      tooltipConfig={{
                        showLabel: true,
                        showValue: true,
                        showPercent: true
                      }}
                    />
                  }
                />
                <Bar dataKey="value" fill="#3b82f6">
                  {analysisTypeDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
      
      {/* Gráficos - Terceira linha */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* Comparação de Score */}
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Comparação de Score</CardTitle>
            <button className="text-xs text-gray-400 hover:text-white">Exportar</button>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart
                data={scoreComparisonData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                <XAxis dataKey="name" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip 
                  content={
                    <CustomTooltip 
                      tooltipConfig={scoreTooltipConfig}
                    />
                  }
                />
                <Legend formatter={(value) => <span className="text-white">{value}</span>} />
                <Bar dataKey="scoreActcredit" name="Score Actcredit" fill="#3b82f6" />
                <Bar dataKey="scoreMercado" name="Score Mercado" fill="#8b5cf6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        
        {/* Valor Total */}
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Valor Total</CardTitle>
            <button className="text-xs text-gray-400 hover:text-white">Exportar</button>
          </CardHeader>
          <CardContent>
            <div className="text-center mb-4">
              <h3 className="text-2xl font-bold">R$ 9.635.305,51</h3>
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={totalValueData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  nameKey="name"
                >
                  {totalValueData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={STATUS_COLORS[entry.name] || COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  content={
                    <CustomTooltip 
                      valueFormatter={currencyFormatter}
                      tooltipConfig={valueTooltipConfig}
                    />
                  }
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-3 gap-4 mt-4">
              <div>
                <p className="text-sm text-gray-400">Aprovado</p>
                <p className="text-sm font-bold text-green-500">R$ 6.619.454,88</p>
                <p className="text-xs text-gray-400">68.7% do total</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Em análise</p>
                <p className="text-sm font-bold text-yellow-500">R$ 3.015.850,63</p>
                <p className="text-xs text-gray-400">31.3% do total</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Recusado</p>
                <p className="text-sm font-bold text-red-500">R$ 2.500.000,00</p>
                <p className="text-xs text-gray-400">20.0% do total</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Tabela de Análise Regional */}
      <div className="mb-8">
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Análise Regional</CardTitle>
            <button className="text-xs text-gray-400 hover:text-white">Exportar</button>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[#1e3a5f]">
                    <th className="text-left py-3 px-4 text-gray-400">REGIÃO</th>
                    <th className="text-left py-3 px-4 text-gray-400">CLIENTES</th>
                    <th className="text-left py-3 px-4 text-gray-400">TAXA DE APROVAÇÃO</th>
                    <th className="text-left py-3 px-4 text-gray-400">SCORE MÉDIO</th>
                    <th className="text-left py-3 px-4 text-gray-400">VALOR TOTAL</th>
                  </tr>
                </thead>
                <tbody>
                  {regionalAnalysisData.map((row, index) => (
                    <tr key={index} className="border-b border-[#1e3a5f]">
                      <td className="py-3 px-4">{row.regiao}</td>
                      <td className="py-3 px-4">{row.clientes}</td>
                      <td className="py-3 px-4">
                        <span className={row.taxaAprovacao >= 60 ? "text-green-500" : "text-yellow-500"}>
                          {row.taxaAprovacao}%
                        </span>
                      </td>
                      <td className="py-3 px-4">{row.scoreMedia}</td>
                      <td className="py-3 px-4">{formatCurrency(row.valorTotal)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
