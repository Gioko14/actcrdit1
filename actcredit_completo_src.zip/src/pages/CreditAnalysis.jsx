import React, { useState } from 'react';
import { 
  FileText, 
  Upload, 
  Database, 
  FileSpreadsheet,
  ArrowLeft,
  HelpCircle,
  ShieldCheck, // Ícone para Serasa
  TrendingUp, // Ícone para Financeiro
  Lock // Ícone para Garantias
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

import BatchProcessingUploader from '@/components/upload/BatchProcessingUploader';
import MultiFormatSupport from '@/components/file-formats/MultiFormatSupport';
import RealTimePreview from '@/components/preview/RealTimePreview';
import BiAnalyticsService from '@/services/bi-analytics/BiAnalyticsService';

const CreditAnalysis = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('manual');
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    // Dados Cliente
    clientName: '',
    clientDocument: '',
    clientSector: '',
    activityTime: '',
    // Dados Financeiros
    annualRevenue: '',
    currentDebt: '',
    ebitda: '',
    netProfit: '',
    // Dados Solicitação
    requestedAmount: '',
    term: '',
    purpose: '',
    guarantees: '',
    // Outros campos necessários
  });
  
  // Voltar para a lista de análises
  const handleBack = () => {
    navigate('/dashboard/analises');
  };
  
  // Avançar para o próximo passo
  const handleNextStep = () => {
    setStep(step + 1);
  };
  
  // Voltar para o passo anterior
  const handlePreviousStep = () => {
    setStep(step - 1);
  };
  
  // Atualizar dados do formulário
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  // Simular consulta Serasa
  const simularConsultaSerasa = () => {
    const score = Math.floor(Math.random() * 700) + 300; // Score entre 300 e 999
    const pendencias = Math.random() > 0.8 ? ['Pendência Financeira XPTO', 'Protesto Cartório Y'] : [];
    return {
      serasaScore: score,
      serasaPendencias: pendencias,
      serasaConsultado: true
    };
  };

  // Enviar análise para processamento
  const handleSubmitAnalise = async () => {
    try {
      setLoading(true);
      
      // Simular consulta Serasa
      const dadosSerasa = simularConsultaSerasa();
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simular tempo da consulta
      
      // Simular envio para API
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Criar objeto de análise COMPLETO
      const novaAnalise = {
        // Dados Cliente
        nomeCliente: formData.clientName || "Cliente não identificado",
        cnpjCliente: formData.clientDocument || "Não informado",
        setorCliente: formData.clientSector || "Não informado",
        tempoAtividade: formData.activityTime || 0,
        regiaoCliente: 'Sudeste', // Simulado
        
        // Dados Financeiros
        faturamentoAnual: parseFloat(formData.annualRevenue?.replace(/[^0-9,-]/g, '').replace(',', '.')) || 0,
        percentualEndividamento: parseFloat(formData.currentDebt) || 0,
        ebitda: parseFloat(formData.ebitda?.replace(/[^0-9,-]/g, '').replace(',', '.')) || 0,
        lucroLiquido: parseFloat(formData.netProfit?.replace(/[^0-9,-]/g, '').replace(',', '.')) || 0,
        
        // Dados Solicitação
        valorSolicitado: parseFloat(formData.requestedAmount?.replace(/[^0-9,-]/g, '').replace(',', '.')) || 0,
        prazoDesejado: parseInt(formData.term) || 0,
        modalidadeCredito: formData.purpose ? 
          formData.purpose.charAt(0).toUpperCase() + formData.purpose.slice(1).replace('_', ' ') : 
          'Não informado',
        garantiasOferecidas: formData.guarantees || 'Não informado',
        
        // Dados Análise
        id: Math.floor(Math.random() * 10000) + 1000, // ID simulado
        dataAnalise: new Date().toISOString(),
        tipoAnalise: 'Manual',
        responsavelAnalise: 'Sistema (Simulado)',
        score: Math.floor(Math.random() * 40) + 60, // Score ActCredit
        decisao: Math.random() > 0.3 ? 'Aprovado' : Math.random() > 0.5 ? 'Aprovado com Condições' : 'Análise Manual',
        justificativa: `Decisão baseada em score ActCredit, políticas e dados Serasa.`, 
        probabilidadeDefault: (100 - (Math.floor(Math.random() * 40) + 60)) / 100, // Simulado
        
        // Dados Serasa
        ...dadosSerasa,
        
        // Políticas (Simulado)
        resultadosPoliticas: [
          {
            politica: 'Score Mínimo ActCredit',
            criterio: 'Score >= 60',
            dadoVerificado: `Score: ${Math.floor(Math.random() * 40) + 60}`,
            resultado: 'Cumprida',
            detalhes: 'Score dentro do aceitável.'
          },
          {
            politica: 'Score Mínimo Serasa',
            criterio: 'Score Serasa >= 400',
            dadoVerificado: `Score: ${dadosSerasa.serasaScore}`,
            resultado: dadosSerasa.serasaScore >= 400 ? 'Cumprida' : 'Não Cumprida',
            detalhes: dadosSerasa.serasaScore >= 400 ? 'Score Serasa OK.' : 'Score Serasa abaixo do mínimo.'
          },
          {
            politica: 'Pendências Serasa',
            criterio: 'Não possuir pendências financeiras ou protestos',
            dadoVerificado: `${dadosSerasa.serasaPendencias.length} pendências encontradas`,
            resultado: dadosSerasa.serasaPendencias.length === 0 ? 'Cumprida' : 'Não Cumprida',
            detalhes: dadosSerasa.serasaPendencias.length === 0 ? 'Sem pendências.' : `Encontradas pendências: ${dadosSerasa.serasaPendencias.join(', ')}`
          }
        ],
        
        // XAI (Simulado)
        fatoresPositivos: [
          'Faturamento anual consistente.',
          'Bom tempo de atividade.'
        ],
        fatoresNegativos: [
          dadosSerasa.serasaPendencias.length > 0 ? 'Presença de pendências no Serasa.' : 'Endividamento ligeiramente elevado.'
        ],
        
        // Condições (Simulado)
        condicoes: (Math.random() > 0.3) ? {
          limiteAprovado: (parseFloat(formData.requestedAmount?.replace(/[^0-9,-]/g, '').replace(',', '.')) || 0) * 0.9,
          taxaAprovada: 1.5,
          prazoAprovado: parseInt(formData.term) || 0,
          garantiasExigidas: ['Aval dos Sócios']
        } : null
      };
      
      // Adicionar à lista local através do serviço
      await BiAnalyticsService.adicionarAnalise(novaAnalise);
      
      // Mostrar mensagem de sucesso
      toast.success("Análise enviada com sucesso!");
      
      // Redirecionar para a lista de análises
      navigate('/dashboard/analises');
    } catch (error) {
      console.error('Erro ao enviar análise:', error);
      toast.error("Erro ao enviar análise. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  // Processar upload de PDF (simplificado para manter o foco)
  const handlePdfUpload = async (file) => {
    try {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 2000));
      const dadosSerasa = simularConsultaSerasa();
      const novaAnalise = {
        nomeCliente: "Empresa do PDF",
        cnpjCliente: "00.000.000/0000-00",
        setorCliente: "Importado",
        tempoAtividade: 5,
        faturamentoAnual: 1500000,
        percentualEndividamento: 25,
        valorSolicitado: 300000,
        prazoDesejado: 24,
        modalidadeCredito: "Importação PDF",
        id: Math.floor(Math.random() * 10000) + 1000,
        dataAnalise: new Date().toISOString(),
        tipoAnalise: 'PDF',
        score: Math.floor(Math.random() * 40) + 60,
        decisao: 'Análise Manual',
        justificativa: 'Análise importada via PDF, requer revisão manual.',
        ...dadosSerasa,
        resultadosPoliticas: [],
        fatoresPositivos: [],
        fatoresNegativos: [],
        condicoes: null
      };
      await BiAnalyticsService.adicionarAnalise(novaAnalise);
      toast.success("PDF processado! Análise criada para revisão manual.");
      navigate('/dashboard/analises');
    } catch (error) {
      console.error('Erro ao processar PDF:', error);
      toast.error("Erro ao processar PDF. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  // Processar dados do Protheus (simplificado)
  const handleProtheusImport = async () => {
    try {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1800));
      const dadosSerasa = simularConsultaSerasa();
      const novaAnalise = {
        nomeCliente: "Cliente Protheus XPTO",
        cnpjCliente: "11.111.111/0001-11",
        setorCliente: "Integrado",
        tempoAtividade: 10,
        faturamentoAnual: 5000000,
        percentualEndividamento: 15,
        valorSolicitado: 1000000,
        prazoDesejado: 48,
        modalidadeCredito: "Importação Protheus",
        id: Math.floor(Math.random() * 10000) + 1000,
        dataAnalise: new Date().toISOString(),
        tipoAnalise: 'Protheus',
        score: Math.floor(Math.random() * 30) + 70,
        decisao: 'Aprovado',
        justificativa: 'Análise importada via Protheus e aprovada automaticamente.',
        ...dadosSerasa,
        resultadosPoliticas: [],
        fatoresPositivos: ['Integração Protheus OK'],
        fatoresNegativos: [],
        condicoes: { limiteAprovado: 1000000, taxaAprovada: 1.1, prazoAprovado: 48, garantiasExigidas: [] }
      };
      await BiAnalyticsService.adicionarAnalise(novaAnalise);
      toast.success("Dados do Protheus importados e análise criada!");
      navigate('/dashboard/analises');
    } catch (error) {
      console.error('Erro ao importar dados do Protheus:', error);
      toast.error("Erro ao importar dados do Protheus. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };
  
  // Renderizar o passo atual da análise manual
  const renderManualStep = () => {
    switch(step) {
      case 1: // Dados do Cliente
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold flex items-center">
              <User className="h-5 w-5 mr-2 text-blue-500" /> Dados do Cliente
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Nome do Cliente</label>
                <input 
                  type="text"
                  name="clientName"
                  value={formData.clientName}
                  onChange={handleInputChange}
                  className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
                  placeholder="Nome da empresa"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">CNPJ</label>
                <input 
                  type="text"
                  name="clientDocument"
                  value={formData.clientDocument}
                  onChange={handleInputChange}
                  className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
                  placeholder="00.000.000/0001-00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Setor</label>
                <select 
                  name="clientSector"
                  value={formData.clientSector}
                  onChange={handleInputChange}
                  className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
                >
                  <option value="">Selecione o setor</option>
                  <option value="Tecnologia">Tecnologia</option>
                  <option value="Varejo">Varejo</option>
                  <option value="Indústria">Indústria</option>
                  <option value="Agronegócio">Agronegócio</option>
                  <option value="Saúde">Saúde</option>
                  <option value="Serviços">Serviços</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Tempo de Atividade (anos)</label>
                <input 
                  type="number"
                  name="activityTime"
                  value={formData.activityTime}
                  onChange={handleInputChange}
                  className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
                  placeholder="5"
                />
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <Button 
                variant="outline" 
                className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white"
                onClick={handleBack}
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Cancelar
              </Button>
              <Button 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={handleNextStep}
              >
                Próximo: Dados Financeiros
              </Button>
            </div>
          </div>
        );
      case 2: // Dados Financeiros
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-green-500" /> Dados Financeiros
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Faturamento Anual (R$)</label>
                <input 
                  type="text"
                  name="annualRevenue"
                  value={formData.annualRevenue}
                  onChange={handleInputChange}
                  className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
                  placeholder="1.000.000,00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Endividamento Atual (%)</label>
                <input 
                  type="number"
                  name="currentDebt"
                  value={formData.currentDebt}
                  onChange={handleInputChange}
                  className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
                  placeholder="30"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">EBITDA (R$)</label>
                <input 
                  type="text"
                  name="ebitda"
                  value={formData.ebitda}
                  onChange={handleInputChange}
                  className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
                  placeholder="300.000,00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Lucro Líquido (R$)</label>
                <input 
                  type="text"
                  name="netProfit"
                  value={formData.netProfit}
                  onChange={handleInputChange}
                  className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
                  placeholder="150.000,00"
                />
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <Button 
                variant="outline" 
                className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white"
                onClick={handlePreviousStep}
              >
                Voltar: Dados do Cliente
              </Button>
              <Button 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={handleNextStep}
              >
                Próximo: Dados da Solicitação
              </Button>
            </div>
          </div>
        );
      case 3: // Dados da Solicitação
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold flex items-center">
              <DollarSign className="h-5 w-5 mr-2 text-yellow-500" /> Dados da Solicitação
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Valor Solicitado (R$)</label>
                <input 
                  type="text"
                  name="requestedAmount"
                  value={formData.requestedAmount}
                  onChange={handleInputChange}
                  className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
                  placeholder="500.000,00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">Prazo (meses)</label>
                <input 
                  type="number"
                  name="term"
                  value={formData.term}
                  onChange={handleInputChange}
                  className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
                  placeholder="36"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-400 mb-1">Finalidade do Crédito</label>
                <select 
                  name="purpose"
                  value={formData.purpose}
                  onChange={handleInputChange}
                  className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
                >
                  <option value="">Selecione a finalidade</option>
                  <option value="capital_giro">Capital de Giro</option>
                  <option value="investimento">Investimento</option>
                  <option value="expansao">Expansão</option>
                  <option value="aquisicao">Aquisição de Equipamentos</option>
                  <option value="reestruturacao">Reestruturação de Dívidas</option>
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-400 mb-1">Garantias Oferecidas</label>
                <textarea 
                  name="guarantees"
                  value={formData.guarantees}
                  onChange={handleInputChange}
                  className="w-full p-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white"
                  placeholder="Ex: Aval dos sócios, Imóvel X, Recebíveis Y"
                  rows={3}
                />
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <Button 
                variant="outline" 
                className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white"
                onClick={handlePreviousStep}
              >
                Voltar: Dados Financeiros
              </Button>
              <Button 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={handleNextStep}
              >
                Próximo: Documentos e Confirmação
              </Button>
            </div>
          </div>
        );
      case 4: // Documentos e Confirmação
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold flex items-center">
              <FileText className="h-5 w-5 mr-2 text-purple-500" /> Documentos e Confirmação
            </h2>
            {/* Seção de Upload de Documentos (Simplificada) */}
            <div className="bg-[#1e3a5f]/50 p-4 rounded-lg">
              <h3 className="text-lg font-medium mb-4">Anexar Documentos (Opcional)</h3>
              <div className="space-y-4">
                {/* ... (botões de anexar como antes) ... */}
                 <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <FileText className="h-5 w-5 mr-2 text-blue-500" />
                    <span>Demonstrações Financeiras</span>
                  </div>
                  <Button size="sm" variant="outline" className="border-[#1e3a5f] hover:bg-[#1e3a5f]">
                    <Upload className="h-4 w-4 mr-1" />
                    Anexar
                  </Button>
                </div>
                {/* ... (outros botões) ... */}
              </div>
            </div>
            
            {/* Resumo da Solicitação */}
            <div className="bg-[#1e3a5f]/50 p-4 rounded-lg">
              <h3 className="text-lg font-medium mb-4">Resumo da Solicitação</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                <div><span className="text-gray-400">Cliente:</span> {formData.clientName || "-"}</div>
                <div><span className="text-gray-400">CNPJ:</span> {formData.clientDocument || "-"}</div>
                <div><span className="text-gray-400">Setor:</span> {formData.clientSector || "-"}</div>
                <div><span className="text-gray-400">Faturamento:</span> R$ {formData.annualRevenue || "-"}</div>
                <div><span className="text-gray-400">Valor Solicitado:</span> R$ {formData.requestedAmount || "-"}</div>
                <div><span className="text-gray-400">Prazo:</span> {formData.term || "-"} meses</div>
                <div className="col-span-2 md:col-span-3"><span className="text-gray-400">Finalidade:</span> {formData.purpose?.replace('_', ' ') || "-"}</div>
                <div className="col-span-2 md:col-span-3"><span className="text-gray-400">Garantias:</span> {formData.guarantees || "-"}</div>
              </div>
            </div>
            
            <div className="flex justify-between mt-8">
              <Button 
                variant="outline" 
                className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white"
                onClick={handlePreviousStep}
                disabled={loading}
              >
                Voltar: Dados da Solicitação
              </Button>
              <Button 
                className="bg-green-600 hover:bg-green-700"
                onClick={handleSubmitAnalise}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="animate-spin mr-2">⏳</span>
                    Consultando Serasa e Processando...
                  </>
                ) : (
                  <>
                    <ShieldCheck className="h-4 w-4 mr-2" />
                    Enviar para Análise Completa
                  </>
                )}
              </Button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };
  
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Nova Análise de Crédito</h1>
          <p className="text-gray-400">Inicie uma nova análise de crédito completa para um cliente.</p>
        </div>
        <Button 
          variant="outline" 
          className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white"
        >
          <HelpCircle className="h-4 w-4 mr-2" />
          Ajuda
        </Button>
      </div>
      
      <Tabs defaultValue="manual" onValueChange={setActiveTab} className="mb-6">
        <TabsList className="bg-[#1e3a5f] border border-[#1e3a5f]">
          <TabsTrigger value="manual" className="data-[state=active]:bg-blue-600">
            <FileText className="h-4 w-4 mr-2" />
            Imputação Manual Completa
          </TabsTrigger>
          <TabsTrigger value="pdf" className="data-[state=active]:bg-blue-600">
            <FileText className="h-4 w-4 mr-2" />
            Via PDF (Simplificado)
          </TabsTrigger>
          <TabsTrigger value="protheus" className="data-[state=active]:bg-blue-600">
            <Database className="h-4 w-4 mr-2" />
            Protheus (Simplificado)
          </TabsTrigger>
          <TabsTrigger value="batch" className="data-[state=active]:bg-blue-600">
            <FileSpreadsheet className="h-4 w-4 mr-2" />
            Processamento em Lote
          </TabsTrigger>
        </TabsList>
        
        <div className="mt-6">
          <TabsContent value="manual" className="mt-0">
            <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
              <CardContent className="p-6">
                {/* Indicador de Passos */}
                <div className="flex justify-center space-x-4 mb-6">
                  {[1, 2, 3, 4].map(s => (
                    <div key={s} className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${step >= s ? 'bg-blue-600 border-blue-600' : 'border-gray-500 text-gray-400'}`}>
                        {s}
                      </div>
                      <span className={`mt-1 text-xs ${step >= s ? 'text-white' : 'text-gray-400'}`}>
                        {s === 1 ? 'Cliente' : s === 2 ? 'Financeiro' : s === 3 ? 'Solicitação' : 'Confirmar'}
                      </span>
                    </div>
                  ))}
                </div>
                {renderManualStep()}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Outras Tabs (PDF, Protheus, Lote) - Mantidas simplificadas */}
          <TabsContent value="pdf" className="mt-0">
            <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
              <CardContent className="p-6">
                {/* ... (Conteúdo PDF como antes) ... */}
                 <div className="space-y-6">
                  <h2 className="text-xl font-semibold">Importação via PDF</h2>
                  <p className="text-gray-400">
                    Faça upload de um arquivo PDF contendo os dados financeiros e cadastrais do cliente.
                    O sistema extrairá automaticamente as informações relevantes.
                  </p>
                  
                  <div className="mt-6">
                    <MultiFormatSupport 
                      acceptedFormats={['application/pdf']}
                      maxFileSize={10}
                      onUploadComplete={handlePdfUpload}
                    />
                  </div>
                  
                  <div className="flex justify-between mt-8">
                    <Button 
                      variant="outline" 
                      className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white"
                      onClick={handleBack}
                    >
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Voltar para Lista
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="protheus" className="mt-0">
            <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
              <CardContent className="p-6">
                {/* ... (Conteúdo Protheus como antes) ... */}
                 <div className="space-y-6">
                  <h2 className="text-xl font-semibold">Importação via Protheus</h2>
                  {/* ... (Inputs CNPJ/Código) ... */}
                  <div className="mt-4">
                    <Button 
                      className="bg-blue-600 hover:bg-blue-700"
                      onClick={handleProtheusImport}
                      disabled={loading}
                    >
                      {/* ... (Botão Buscar Dados) ... */}
                    </Button>
                  </div>
                  {/* ... (Preview) ... */}
                  <div className="flex justify-between mt-8">
                    <Button 
                      variant="outline" 
                      className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white"
                      onClick={handleBack}
                    >
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Voltar para Lista
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="batch" className="mt-0">
            <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
              <CardContent className="p-6">
                {/* ... (Conteúdo Lote como antes) ... */}
                 <div className="space-y-6">
                  <h2 className="text-xl font-semibold">Processamento em Lote</h2>
                  <p className="text-gray-400">
                    Faça upload de um arquivo CSV ou Excel contendo múltiplos clientes para análise em lote.
                  </p>
                  <BatchProcessingUploader />
                  <div className="flex justify-between mt-8">
                    <Button 
                      variant="outline" 
                      className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white"
                      onClick={handleBack}
                    >
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Voltar para Lista
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
};

export default CreditAnalysis;

