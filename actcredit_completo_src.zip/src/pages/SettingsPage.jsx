import React from 'react';
import { 
  Settings, 
  FileText, 
  Bell, 
  Shield, 
  Lock, 
  User, 
  Globe, 
  Database,
  Save
} from 'lucide-react';

// Componentes
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';

const SettingsPage = () => {
  return (
    <div className="p-6">
      {/* Cabeçalho */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Configurações</h1>
        <p className="text-gray-400 mt-1">
          Gerencie as configurações do sistema e preferências.
        </p>
      </div>

      {/* Tabs para diferentes configurações */}
      <Tabs defaultValue="general" className="mb-8">
        <TabsList className="bg-[#1e3a5f] border border-[#1e3a5f]">
          <TabsTrigger value="general" className="data-[state=active]:bg-blue-600">Geral</TabsTrigger>
          <TabsTrigger value="notifications" className="data-[state=active]:bg-blue-600">Notificações</TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-blue-600">Segurança</TabsTrigger>
          <TabsTrigger value="integrations" className="data-[state=active]:bg-blue-600">Integrações</TabsTrigger>
        </TabsList>
        
        {/* Configurações Gerais */}
        <TabsContent value="general" className="mt-4">
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader>
              <CardTitle>Configurações Gerais</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Modo Escuro</h3>
                  <p className="text-gray-400 text-sm">Ativar tema escuro para a interface</p>
                </div>
                <Switch checked={true} />
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Idioma</h3>
                  <p className="text-gray-400 text-sm">Selecione o idioma da interface</p>
                </div>
                <select className="bg-[#1e3a5f] border border-[#1e3a5f] rounded-md px-3 py-2 text-white">
                  <option>Português</option>
                  <option>English</option>
                  <option>Español</option>
                </select>
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Formato de Data</h3>
                  <p className="text-gray-400 text-sm">Selecione o formato de data preferido</p>
                </div>
                <select className="bg-[#1e3a5f] border border-[#1e3a5f] rounded-md px-3 py-2 text-white">
                  <option>DD/MM/YYYY</option>
                  <option>MM/DD/YYYY</option>
                  <option>YYYY-MM-DD</option>
                </select>
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Formato de Moeda</h3>
                  <p className="text-gray-400 text-sm">Selecione o formato de moeda preferido</p>
                </div>
                <select className="bg-[#1e3a5f] border border-[#1e3a5f] rounded-md px-3 py-2 text-white">
                  <option>R$ (BRL)</option>
                  <option>$ (USD)</option>
                  <option>€ (EUR)</option>
                </select>
              </div>
              
              <div className="pt-4">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Alterações
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Configurações de Notificações */}
        <TabsContent value="notifications" className="mt-4">
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader>
              <CardTitle>Configurações de Notificações</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Notificações por E-mail</h3>
                  <p className="text-gray-400 text-sm">Receber notificações por e-mail</p>
                </div>
                <Switch checked={true} />
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Notificações no Sistema</h3>
                  <p className="text-gray-400 text-sm">Receber notificações no sistema</p>
                </div>
                <Switch checked={true} />
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Novas Análises</h3>
                  <p className="text-gray-400 text-sm">Notificar sobre novas análises de crédito</p>
                </div>
                <Switch checked={true} />
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Atualizações de Políticas</h3>
                  <p className="text-gray-400 text-sm">Notificar sobre atualizações nas políticas de crédito</p>
                </div>
                <Switch checked={true} />
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Relatórios Gerados</h3>
                  <p className="text-gray-400 text-sm">Notificar quando relatórios forem gerados</p>
                </div>
                <Switch checked={false} />
              </div>
              
              <div className="pt-4">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Alterações
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Configurações de Segurança */}
        <TabsContent value="security" className="mt-4">
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader>
              <CardTitle>Configurações de Segurança</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Autenticação de Dois Fatores</h3>
                  <p className="text-gray-400 text-sm">Ativar autenticação de dois fatores</p>
                </div>
                <Switch checked={false} />
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Tempo de Sessão</h3>
                  <p className="text-gray-400 text-sm">Tempo até o encerramento automático da sessão</p>
                </div>
                <select className="bg-[#1e3a5f] border border-[#1e3a5f] rounded-md px-3 py-2 text-white">
                  <option>30 minutos</option>
                  <option>1 hora</option>
                  <option>2 horas</option>
                  <option>4 horas</option>
                </select>
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Histórico de Login</h3>
                  <p className="text-gray-400 text-sm">Visualizar histórico de login</p>
                </div>
                <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                  <FileText className="h-4 w-4 mr-2" />
                  Visualizar
                </Button>
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Alterar Senha</h3>
                  <p className="text-gray-400 text-sm">Alterar senha de acesso</p>
                </div>
                <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                  <Lock className="h-4 w-4 mr-2" />
                  Alterar
                </Button>
              </div>
              
              <div className="pt-4">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Alterações
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Configurações de Integrações */}
        <TabsContent value="integrations" className="mt-4">
          <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
            <CardHeader>
              <CardTitle>Configurações de Integrações</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="bg-blue-600 rounded-md h-10 w-10 flex items-center justify-center mr-4">
                    <Database className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-medium">Protheus</h3>
                    <p className="text-gray-400 text-sm">Integração com sistema Protheus</p>
                  </div>
                </div>
                <Switch checked={true} />
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="bg-green-600 rounded-md h-10 w-10 flex items-center justify-center mr-4">
                    <Globe className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-medium">Open Finance</h3>
                    <p className="text-gray-400 text-sm">Integração com Open Finance</p>
                  </div>
                </div>
                <Switch checked={true} />
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="bg-purple-600 rounded-md h-10 w-10 flex items-center justify-center mr-4">
                    <FileText className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-medium">Serasa</h3>
                    <p className="text-gray-400 text-sm">Integração com Serasa</p>
                  </div>
                </div>
                <Switch checked={false} />
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="bg-red-600 rounded-md h-10 w-10 flex items-center justify-center mr-4">
                    <Shield className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-medium">Bureau de Crédito</h3>
                    <p className="text-gray-400 text-sm">Integração com Bureau de Crédito</p>
                  </div>
                </div>
                <Switch checked={false} />
              </div>
              
              <div className="pt-4">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Alterações
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SettingsPage;
