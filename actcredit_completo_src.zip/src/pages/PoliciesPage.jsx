import React, { useState } from 'react';
import { 
  Shield, 
  FileText, 
  Download, 
  Filter, 
  Calendar, 
  Printer, 
  ChevronDown,
  Plus,
  Clock,
  CheckCircle,
  AlertCircle,
  Search,
  Edit,
  Trash2
} from 'lucide-react';

// Componentes
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';

const PoliciesPage = () => {
  // Estado para as políticas de crédito
  const [creditPolicies, setCreditPolicies] = useState([
    { 
      id: 1, 
      name: 'Política Padrão para Varejo', 
      description: 'Política de crédito padrão para clientes do setor de varejo', 
      createdAt: '10/05/2025',
      createdBy: 'Carlos Silva', 
      status: 'Ativa'
    },
    { 
      id: 2, 
      name: 'Política para Clientes Premium', 
      description: 'Política de crédito para clientes com histórico excelente', 
      createdAt: '08/05/2025',
      createdBy: 'Ana Oliveira', 
      status: 'Ativa'
    },
    { 
      id: 3, 
      name: 'Política Restritiva', 
      description: 'Política de crédito para clientes com histórico de atrasos', 
      createdAt: '05/05/2025',
      createdBy: 'Roberto Almeida', 
      status: 'Ativa'
    },
    { 
      id: 4, 
      name: 'Política para Novos Clientes', 
      description: 'Política de crédito para clientes sem histórico anterior', 
      createdAt: '01/05/2025',
      createdBy: 'Juliana Costa', 
      status: 'Ativa'
    },
    { 
      id: 5, 
      name: 'Política Sazonal - Fim de Ano', 
      description: 'Política temporária para período de fim de ano', 
      createdAt: '28/04/2025',
      createdBy: 'Carlos Silva', 
      status: 'Inativa'
    },
    { 
      id: 6, 
      name: 'Política para Agronegócio', 
      description: 'Política específica para clientes do setor de agronegócio', 
      createdAt: '25/04/2025',
      createdBy: 'Ana Oliveira', 
      status: 'Ativa'
    },
  ]);

  // Estado para o filtro de status
  const [statusFilter, setStatusFilter] = useState('Todas');

  // Função para alternar o status de uma política
  const togglePolicyStatus = (id) => {
    setCreditPolicies(policies => 
      policies.map(policy => 
        policy.id === id 
          ? { ...policy, status: policy.status === 'Ativa' ? 'Inativa' : 'Ativa' } 
          : policy
      )
    );
  };

  // Filtrar políticas com base no filtro de status
  const filteredPolicies = creditPolicies.filter(policy => {
    if (statusFilter === 'Todas') return true;
    return policy.status === statusFilter;
  });

  // Renderizar o badge de status com cor apropriada
  const renderStatusBadge = (status) => {
    let color = '';
    
    switch(status) {
      case 'Ativa':
        color = 'bg-green-500/20 text-green-500 border-green-500/50';
        break;
      case 'Inativa':
        color = 'bg-yellow-500/20 text-yellow-500 border-yellow-500/50';
        break;
      default:
        color = 'bg-gray-500/20 text-gray-500 border-gray-500/50';
    }
    
    return (
      <span className={`px-2 py-1 rounded text-xs border ${color}`}>
        {status}
      </span>
    );
  };

  return (
    <div className="p-6">
      {/* Cabeçalho */}
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Políticas</h1>
          <p className="text-gray-400 mt-1">
            Defina e gerencie as políticas de crédito da sua empresa.
          </p>
        </div>
        <Button variant="outline" className="border-[#1e3a5f] text-white hover:bg-[#1e3a5f]">
          <AlertCircle className="h-4 w-4 mr-2" /> Ajuda
        </Button>
      </div>

      {/* Filtros de status */}
      <div className="flex mb-6 space-x-2">
        <Button 
          variant={statusFilter === 'Todas' ? 'default' : 'outline'} 
          className={statusFilter === 'Todas' ? 'bg-blue-600 hover:bg-blue-700' : 'border-[#1e3a5f] text-white hover:bg-[#1e3a5f]'}
          onClick={() => setStatusFilter('Todas')}
        >
          Todas
        </Button>
        <Button 
          variant={statusFilter === 'Ativa' ? 'default' : 'outline'} 
          className={statusFilter === 'Ativa' ? 'bg-green-600 hover:bg-green-700' : 'border-[#1e3a5f] text-white hover:bg-[#1e3a5f]'}
          onClick={() => setStatusFilter('Ativa')}
        >
          Ativas
        </Button>
        <Button 
          variant={statusFilter === 'Inativa' ? 'default' : 'outline'} 
          className={statusFilter === 'Inativa' ? 'bg-yellow-600 hover:bg-yellow-700' : 'border-[#1e3a5f] text-white hover:bg-[#1e3a5f]'}
          onClick={() => setStatusFilter('Inativa')}
        >
          Inativas
        </Button>
      </div>

      {/* Barra de busca e botões */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <input 
            type="text"
            className="w-full pl-10 py-2 bg-[#0f2544] border border-[#1e3a5f] rounded-md text-white"
            placeholder="Buscar por nome, descrição ou critérios..."
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        </div>
        
        <Button variant="outline" className="border-[#1e3a5f] text-white hover:bg-[#1e3a5f]">
          <Filter className="h-4 w-4 mr-2" />
          Filtros
        </Button>
        
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="h-4 w-4 mr-2" />
          Nova Política
        </Button>
      </div>
      
      {/* Tabela de políticas */}
      <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1e3a5f] text-left">
                  <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Nome
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Descrição
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Criado Em
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Criado Por
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredPolicies.map((policy) => (
                  <tr key={policy.id} className="border-b border-[#1e3a5f] hover:bg-[#1e3a5f]/30">
                    <td className="px-6 py-4 whitespace-nowrap font-medium">
                      {policy.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {policy.description}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {renderStatusBadge(policy.status)}
                        <Switch 
                          checked={policy.status === 'Ativa'} 
                          onCheckedChange={() => togglePolicyStatus(policy.id)}
                          className="ml-3"
                        />
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {policy.createdAt}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {policy.createdBy}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-blue-500 hover:text-blue-400 hover:bg-blue-500/10" title="Editar">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-red-500 hover:text-red-400 hover:bg-red-500/10" title="Excluir">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-4 flex items-center justify-between border-t border-[#1e3a5f]">
            <div className="text-sm text-gray-400">
              Mostrando {filteredPolicies.length} de {creditPolicies.length} políticas
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" className="border-[#1e3a5f] text-white hover:bg-[#1e3a5f]" disabled>
                Anterior
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700">
                1
              </Button>
              <Button variant="outline" className="border-[#1e3a5f] text-white hover:bg-[#1e3a5f]" disabled>
                Próximo
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PoliciesPage;
