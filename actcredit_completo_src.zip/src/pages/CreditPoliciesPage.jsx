import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Button } from '@/components/ui/button';
import { PlusCircle, Eye, Edit, Copy, Trash2, ShieldCheck } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import PolicyForm from '@/components/creditPolicies/PolicyForm';
import PolicyListItem from '@/components/creditPolicies/PolicyListItem';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const initialPoliciesData = [
  { id: 1, name: "Política Padrão PJ", type: "PJ", scoreMinimo: 600, endividamentoMax: 40, liquidezMin: 1.2, prazoMax: 36, valorMax: 500000, garantiasExigidas: ['Aval', 'Alienação Fiduciária'], isDefault: true, isCustom: false },
  { id: 2, name: "Política Agronegócio", type: "Agro", scoreMinimo: 550, endividamentoMax: 50, liquidezMin: 1.0, prazoMax: 60, valorMax: 1000000, garantiasExigidas: ['Hipoteca Rural', 'Penhor Agrícola'], isDefault: false, isCustom: false },
  { id: 3, name: "Política Tecnologia Startup", type: "Tech", scoreMinimo: 700, endividamentoMax: 30, liquidezMin: 1.5, prazoMax: 24, valorMax: 250000, garantiasExigidas: ['Propriedade Intelectual'], isDefault: false, isCustom: true },
  { id: 4, name: "Política Varejo Express", type: "Varejo", scoreMinimo: 650, endividamentoMax: 35, liquidezMin: 1.1, prazoMax: 12, valorMax: 100000, garantiasExigidas: ['Recebíveis de Cartão'], isDefault: false, isCustom: false },
];

const CreditPoliciesPage = () => {
  const [policies, setPolicies] = useState([]);
  const [selectedPolicy, setSelectedPolicy] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [policyToDelete, setPolicyToDelete] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const storedPolicies = localStorage.getItem('actcred-policies');
    if (storedPolicies) {
      setPolicies(JSON.parse(storedPolicies));
    } else {
      setPolicies(initialPoliciesData);
      localStorage.setItem('actcred-policies', JSON.stringify(initialPoliciesData));
    }
  }, []);

  const savePoliciesToLocalStorage = (updatedPolicies) => {
    localStorage.setItem('actcred-policies', JSON.stringify(updatedPolicies));
  };

  const handleAddNew = () => {
    setSelectedPolicy(null);
    setIsEditing(false);
    setShowForm(true);
  };

  const handleEdit = (policy) => {
    setSelectedPolicy(policy);
    setIsEditing(true);
    setShowForm(true);
  };

  const handleDuplicate = (policyToDuplicate) => {
    const newPolicy = {
      ...policyToDuplicate,
      id: Date.now(),
      name: `${policyToDuplicate.name} (Cópia)`,
      isDefault: false,
    };
    const updatedPolicies = [...policies, newPolicy];
    setPolicies(updatedPolicies);
    savePoliciesToLocalStorage(updatedPolicies);
    toast({ title: "Política Duplicada", description: `Política "${newPolicy.name}" criada com sucesso.`});
  };

  const confirmDelete = (policy) => {
    if (policy.isDefault) {
      toast({ title: "Ação não permitida", description: "Não é possível excluir a política padrão.", variant: "destructive" });
      return;
    }
    setPolicyToDelete(policy);
    setShowDeleteConfirm(true);
  };
  
  const handleDelete = () => {
    if (!policyToDelete || policyToDelete.isDefault) return;
    
    const updatedPolicies = policies.filter(p => p.id !== policyToDelete.id);
    setPolicies(updatedPolicies);
    savePoliciesToLocalStorage(updatedPolicies);
    toast({ title: "Política Excluída", description: `A política "${policyToDelete.name}" foi removida.`});
    setShowDeleteConfirm(false);
    setPolicyToDelete(null);
  };

  const handleSavePolicy = (policyData) => {
    let updatedPolicies;
    if (isEditing && selectedPolicy) {
      updatedPolicies = policies.map(p => p.id === selectedPolicy.id ? policyData : p);
      toast({ title: "Política Atualizada", description: `Política "${policyData.name}" salva com sucesso.`});
    } else {
      updatedPolicies = [...policies, policyData];
      toast({ title: "Política Criada", description: `Nova política "${policyData.name}" adicionada.`});
    }
    
    if (policyData.isDefault) {
      updatedPolicies = updatedPolicies.map(p => ({ ...p, isDefault: p.id === policyData.id }));
    }

    setPolicies(updatedPolicies);
    savePoliciesToLocalStorage(updatedPolicies);
    setShowForm(false);
    setSelectedPolicy(null);
    setIsEditing(false);
  };
  
  const handleViewDetails = (policy) => {
    // Implementar modal de visualização se necessário, por enquanto alerta.
    const details = Object.entries(policy)
      .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
      .join('\n');
    alert(`Detalhes de ${policy.name}:\n${details}`);
  };

  const handleSetDefault = (policyToSetDefault) => {
    const updatedPolicies = policies.map(p => ({
      ...p,
      isDefault: p.id === policyToSetDefault.id
    }));
    setPolicies(updatedPolicies);
    savePoliciesToLocalStorage(updatedPolicies);
    toast({ title: "Política Padrão Atualizada", description: `"${policyToSetDefault.name}" é agora a política padrão.` });
  };


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <DashboardCard>
        <div className="flex flex-col md:flex-row justify-between md:items-center mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight flex items-center">
              <ShieldCheck className="mr-3 h-8 w-8 text-primary"/>
              Políticas de Crédito
            </h1>
            <p className="text-muted-foreground mt-1">
              Gerencie e configure os parâmetros das políticas de crédito utilizadas nas análises.
            </p>
          </div>
          <Button onClick={handleAddNew} className="w-full md:w-auto">
            <PlusCircle className="mr-2 h-5 w-5" /> Adicionar Nova Política
          </Button>
        </div>

        {showForm ? (
          <PolicyForm 
            policy={selectedPolicy} 
            onSave={handleSavePolicy} 
            onCancel={() => { setShowForm(false); setSelectedPolicy(null); setIsEditing(false); }}
            isEditing={isEditing}
            allPolicies={policies}
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {policies.map((policy, index) => (
              <PolicyListItem
                key={policy.id}
                policy={policy}
                index={index}
                onViewDetails={handleViewDetails}
                onEdit={handleEdit}
                onDuplicate={handleDuplicate}
                onDelete={confirmDelete}
                onSetDefault={handleSetDefault}
              />
            ))}
            {policies.length === 0 && (
              <div className="col-span-full text-center py-10 text-muted-foreground">
                <ShieldCheck size={48} className="mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium">Nenhuma política de crédito encontrada.</p>
                <p>Clique em "Adicionar Nova Política" para começar.</p>
              </div>
            )}
          </div>
        )}
      </DashboardCard>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir a política "{policyToDelete?.name}"? Esta ação não poderá ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setPolicyToDelete(null)}>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </motion.div>
  );
};

export default CreditPoliciesPage;