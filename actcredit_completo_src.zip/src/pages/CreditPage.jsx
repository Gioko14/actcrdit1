import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Upload, 
  Check, 
  AlertCircle,
  Loader2,
  Filter,
  Calendar,
  Plus,
  Users,
  BarChart3,
  ShieldAlert
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { supabaseClient } from '@/lib/supabaseClient';
import PDFImportService from '@/services/pdf-import/PDFImportService';

/**
 * Página de Crédito redesenhada conforme referência visual
 */
const CreditPage = () => {
  const [activeTab, setActiveTab] = useState('todas');
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [operacoes, setOperacoes] = useState([
    {
      id: 1,
      cliente: 'Tech Solutions Ltda',
      tipo: 'Linha de Crédito',
      valor: 500000.00,
      data: '15/05/2025',
      vencimento: '15/05/2026',
      status: 'aprovado',
      risco: 'baixo'
    },
    {
      id: 2,
      cliente: 'Mercado Central S.A.',
      tipo: 'Capital de Giro',
      valor: 300000.00,
      data: '10/05/2025',
      vencimento: '10/11/2025',
      status: 'aprovado',
      risco: 'médio'
    },
    {
      id: 3,
      cliente: 'Indústria Nacional S.A.',
      tipo: 'Financiamento',
      valor: 1200000.00,
      data: '12/05/2025',
      vencimento: '12/05/2027',
      status: 'pendente',
      risco: 'médio'
    },
    {
      id: 4,
      cliente: 'Agro Forte Ltda',
      tipo: 'Linha de Crédito',
      valor: 800000.00,
      data: '08/05/2025',
      vencimento: '08/05/2026',
      status: 'rejeitado',
      risco: 'alto'
    },
    {
      id: 5,
      cliente: 'Saúde Integral S.A.',
      tipo: 'Capital de Giro',
      valor: 250000.00,
      data: '05/05/2025',
      vencimento: '05/11/2025',
      status: 'aprovado',
      risco: 'baixo'
    },
    {
      id: 6,
      cliente: 'Serviços Gerais Ltda',
      tipo: 'Financiamento',
      valor: 200000.00,
      data: '01/05/2025',
      vencimento: '01/05/2026',
      status: 'aprovado',
      risco: 'médio'
    }
  ]);
  
  // Estatísticas calculadas com base nas operações
  const estatisticas = {
    aprovadas: {
      quantidade: operacoes.filter(op => op.status === 'aprovado').length,
      valor: operacoes.filter(op => op.status === 'aprovado').reduce((acc, op) => acc + op.valor, 0)
    },
    rejeitadas: {
      quantidade: operacoes.filter(op => op.status === 'rejeitado').length,
      valor: operacoes.filter(op => op.status === 'rejeitado').reduce((acc, op) => acc + op.valor, 0)
    },
    pendentes: {
      quantidade: operacoes.filter(op => op.status === 'pendente').length,
      valor: operacoes.filter(op => op.status === 'pendente').reduce((acc, op) => acc + op.valor, 0)
    },
    total: {
      valor: operacoes.filter(op => op.status === 'aprovado').reduce((acc, op) => acc + op.valor, 0)
    }
  };
  
  // Alertas de risco
  const alertas = [
    {
      cliente: 'Indústria Nacional S.A.',
      tipo: 'Aumento de risco detectado',
      recomendacao: 'Reavaliação recomendada',
      dias: 2
    },
    {
      cliente: 'Agro Forte Ltda',
      tipo: 'Limite de crédito ultrapassado',
      recomendacao: 'Renovação necessária',
      dias: 4
    }
  ];
  
  // Filtra operações com base na tab ativa
  const operacoesFiltradas = activeTab === 'todas' 
    ? operacoes 
    : operacoes.filter(op => 
        activeTab === 'aprovadas' ? op.status === 'aprovado' : 
        activeTab === 'rejeitadas' ? op.status === 'rejeitado' : 
        activeTab === 'pendentes' ? op.status === 'pendente' : true
      );
  
  // Importar diretamente a empresa Censi do PDF de exemplo
  const handleImportCensi = async () => {
    setIsProcessing(true);
    setError(null);
    
    try {
      const cadastroResult = await PDFImportService.cadastrarEmpresaCensi();
      
      if (cadastroResult.status === 'error') {
        throw new Error(cadastroResult.message);
      }
      
      // Adicionar a empresa Censi às operações
      const novaCensi = {
        id: operacoes.length + 1,
        cliente: 'CENSI INDÚSTRIA DE PRODUTOS HIDROSSANITÁRIOS S.A.',
        tipo: 'Linha de Crédito',
        valor: 450000.00,
        data: '27/05/2025',
        vencimento: '27/05/2026',
        status: 'pendente',
        risco: 'médio'
      };
      
      setOperacoes([novaCensi, ...operacoes]);
      
      setResult({
        cadastro: cadastroResult,
        empresa: novaCensi
      });
    } catch (err) {
      setError(err.message || 'Ocorreu um erro ao cadastrar a empresa Censi.');
    } finally {
      setIsProcessing(false);
    }
  };
  
  // Formatar valor como moeda
  const formatarMoeda = (valor) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(valor);
  };
  
  // Renderizar badge de status
  const renderizarStatus = (status) => {
    switch(status) {
      case 'aprovado':
        return <Badge className="bg-green-500 hover:bg-green-600">Aprovado</Badge>;
      case 'rejeitado':
        return <Badge className="bg-red-500 hover:bg-red-600">Rejeitado</Badge>;
      case 'pendente':
        return <Badge className="bg-yellow-500 hover:bg-yellow-600">Pendente</Badge>;
      default:
        return <Badge className="bg-gray-500 hover:bg-gray-600">{status}</Badge>;
    }
  };
  
  // Renderizar badge de risco
  const renderizarRisco = (risco) => {
    switch(risco) {
      case 'baixo':
        return <Badge className="bg-green-500 hover:bg-green-600">Baixo</Badge>;
      case 'médio':
        return <Badge className="bg-yellow-500 hover:bg-yellow-600">Médio</Badge>;
      case 'alto':
        return <Badge className="bg-red-500 hover:bg-red-600">Alto</Badge>;
      default:
        return <Badge className="bg-gray-500 hover:bg-gray-600">{risco}</Badge>;
    }
  };
  
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Crédito</h1>
          <p className="text-gray-400">Gerencie operações de crédito, limites e condições.</p>
        </div>
        <Button 
          variant="default" 
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Nova Operação
        </Button>
      </div>
      
      {/* Painel de Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-500">Aprovadas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estatisticas.aprovadas.quantidade}</div>
            <p className="text-sm text-gray-400">operações</p>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-red-500">Rejeitadas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estatisticas.rejeitadas.quantidade}</div>
            <p className="text-sm text-gray-400">operações</p>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-yellow-500">Pendentes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{estatisticas.pendentes.quantidade}</div>
            <p className="text-sm text-gray-400">operações</p>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-500">Valor Total</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatarMoeda(estatisticas.total.valor)}</div>
            <p className="text-sm text-gray-400">em crédito aprovado</p>
          </CardContent>
        </Card>
      </div>
      
      {/* Tabs e Tabela de Operações */}
      <Card className="bg-[#0f2544] border-[#1e3a5f] text-white mb-6">
        <CardContent className="p-6">
          <Tabs defaultValue="todas" onValueChange={setActiveTab} className="mb-6">
            <TabsList className="bg-[#1e3a5f] border border-[#1e3a5f]">
              <TabsTrigger value="todas" className="data-[state=active]:bg-blue-600">
                Todas
              </TabsTrigger>
              <TabsTrigger value="aprovadas" className="data-[state=active]:bg-blue-600">
                Aprovadas
              </TabsTrigger>
              <TabsTrigger value="pendentes" className="data-[state=active]:bg-blue-600">
                Em Análise
              </TabsTrigger>
              <TabsTrigger value="rejeitadas" className="data-[state=active]:bg-blue-600">
                Rejeitadas
              </TabsTrigger>
            </TabsList>
          </Tabs>
          
          <div className="flex justify-between items-center mb-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Buscar por cliente, tipo ou status..."
                className="pl-10 pr-4 py-2 bg-[#1e3a5f] border border-[#1e3a5f] rounded-md text-white w-80"
              />
              <div className="absolute left-3 top-2.5 text-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="11" cy="11" r="8"></circle>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
              </div>
            </div>
            
            <div className="flex space-x-2">
              <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                <Filter className="h-4 w-4 mr-2" />
                Filtros
              </Button>
              <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                <Calendar className="h-4 w-4 mr-2" />
                Período
              </Button>
            </div>
          </div>
          
          {/* Tabela de Operações */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1e3a5f]">
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">CLIENTE</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">TIPO</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">VALOR</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">DATA</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">VENCIMENTO</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">STATUS</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">RISCO</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">AÇÕES</th>
                </tr>
              </thead>
              <tbody>
                {operacoesFiltradas.map((op) => (
                  <tr key={op.id} className="border-b border-[#1e3a5f] hover:bg-[#1e3a5f]/30">
                    <td className="py-3 px-4">{op.cliente}</td>
                    <td className="py-3 px-4">{op.tipo}</td>
                    <td className="py-3 px-4">{formatarMoeda(op.valor)}</td>
                    <td className="py-3 px-4">{op.data}</td>
                    <td className="py-3 px-4">{op.vencimento}</td>
                    <td className="py-3 px-4">{renderizarStatus(op.status)}</td>
                    <td className="py-3 px-4">{renderizarRisco(op.risco)}</td>
                    <td className="py-3 px-4">
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <span className="sr-only">Abrir menu</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="12" r="1"></circle>
                          <circle cx="19" cy="12" r="1"></circle>
                          <circle cx="5" cy="12" r="1"></circle>
                        </svg>
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="flex justify-between items-center mt-4">
            <div className="text-sm text-gray-400">
              Mostrando 6 de 6 operações
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white" disabled>
                Anterior
              </Button>
              <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white" disabled>
                Próxima
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Cards de Ações e Monitoramento */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Plus className="h-5 w-5 mr-2 text-blue-500" />
              Nova Operação
            </CardTitle>
            <CardDescription className="text-gray-400">
              Crie uma nova operação de crédito para um cliente.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              Nova Operação
            </Button>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="h-5 w-5 mr-2 text-blue-500" />
              Clientes
            </CardTitle>
            <CardDescription className="text-gray-400">
              Visualize e gerencie seus clientes e seus limites de crédito.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">
              <Users className="h-4 w-4 mr-2" />
              Ver Clientes
            </Button>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="h-5 w-5 mr-2 text-blue-500" />
              Monitoramento
            </CardTitle>
            <CardDescription className="text-gray-400">
              Monitore o fluxo das operações e receba alertas automáticos.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">
              <BarChart3 className="h-4 w-4 mr-2" />
              Ver Monitoramento
            </Button>
          </CardContent>
        </Card>
      </div>
      
      {/* Monitoramento de Risco */}
      <Card className="bg-[#0f2544] border-[#1e3a5f] text-white mb-6">
        <CardHeader>
          <CardTitle className="flex items-center">
            <ShieldAlert className="h-5 w-5 mr-2 text-red-500" />
            Monitoramento de Risco
          </CardTitle>
          <CardDescription className="text-gray-400">
            O ActCred Premium monitora continuamente o risco das operações, fornecendo alertas automáticos sobre mudanças no perfil de risco, indicadores de alerta para clientes com risco elevado. Sugestões de reavaliação de limites e um registro completo de alterações nos limites e condições.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <h3 className="text-lg font-medium mb-4">Alertas Recentes</h3>
          
          <div className="space-y-4">
            {alertas.map((alerta, index) => (
              <div key={index} className="bg-[#1e3a5f]/50 p-4 rounded-lg">
                <div className="flex items-start">
                  <div className="bg-red-500/20 p-2 rounded-full mr-4">
                    <AlertCircle className="h-5 w-5 text-red-500" />
                  </div>
                  <div>
                    <h4 className="font-medium">{alerta.cliente}</h4>
                    <p className="text-sm text-gray-400">{alerta.tipo} - {alerta.recomendacao}</p>
                    <p className="text-xs text-gray-500 mt-1">{alerta.dias} dias atrás</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Modal de Importação PDF */}
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" style={{ display: 'none' }}>
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white w-full max-w-md mx-4">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Importação de Cadastro via PDF
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="bg-[#1e3a5f]/50 p-4 rounded-lg">
                <h3 className="text-lg font-medium mb-4">Selecione um arquivo PDF</h3>
                
                <div className="flex flex-col items-center justify-center border-2 border-dashed border-[#1e3a5f] rounded-lg p-6 cursor-pointer hover:border-blue-500 transition-colors">
                  <input
                    type="file"
                    id="pdf-upload"
                    accept="application/pdf"
                    className="hidden"
                  />
                  <label htmlFor="pdf-upload" className="cursor-pointer text-center">
                    <Upload className="h-10 w-10 mb-2 mx-auto text-gray-400" />
                    <p className="text-sm text-gray-400 mb-1">Clique para selecionar ou arraste um arquivo PDF</p>
                    <p className="text-xs text-gray-500">PDF (max. 10MB)</p>
                  </label>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  className="bg-blue-600 hover:bg-blue-700 flex-1"
                  disabled={true}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Processar PDF
                </Button>
                
                <Button
                  className="bg-green-600 hover:bg-green-700 flex-1"
                  onClick={handleImportCensi}
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Importando...
                    </>
                  ) : (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Importar Censi (Exemplo)
                    </>
                  )}
                </Button>
              </div>
              
              {result && (
                <div className="mt-4 p-4 bg-green-500/20 text-green-500 border border-green-500/50 rounded-lg">
                  <h4 className="font-medium flex items-center">
                    <Check className="h-5 w-5 mr-2" />
                    Operação concluída com sucesso
                  </h4>
                  
                  <div className="mt-2 text-sm">
                    <p>A empresa CENSI INDÚSTRIA DE PRODUTOS HIDROSSANITÁRIOS S.A. foi cadastrada com sucesso no banco de dados.</p>
                    <p className="mt-1">CNPJ: 02.308.456/0001-49</p>
                  </div>
                </div>
              )}
              
              {error && (
                <div className="mt-4 p-4 bg-red-500/20 text-red-500 border border-red-500/50 rounded-lg">
                  <h4 className="font-medium flex items-center">
                    <AlertCircle className="h-5 w-5 mr-2" />
                    Erro ao processar operação
                  </h4>
                  
                  <div className="mt-2 text-sm">
                    <p>{error}</p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CreditPage;
