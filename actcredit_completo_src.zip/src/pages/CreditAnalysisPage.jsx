import React from 'react';
import { motion } from 'framer-motion';
import DashboardCard from '@/components/dashboard/DashboardCard';
import { Button } from '@/components/ui/button';
import { UploadCloud, Edit3, Database } from 'lucide-react';

const CreditAnalysisPage = () => {
  const analysisMethods = [
    { 
      name: "Via Protheus", 
      description: "Integração direta com o sistema ERP Protheus para importação de dados.",
      icon: Database,
      action: "Iniciar Análise via Protheus" 
    },
    { 
      name: "Imputação Manual", 
      description: "Entrada manual dos dados cadastrais e financeiros para análise.",
      icon: Edit3,
      action: "Iniciar Análise Manual"
    },
    { 
      name: "Upload de Documentos", 
      description: "Extração automática de dados a partir de documentos PDF.",
      icon: UploadCloud,
      action: "Iniciar Análise por Upload"
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <DashboardCard title="Análise de Crédito">
        <p className="text-muted-foreground mb-6">
          Escolha um método para iniciar uma nova análise de crédito ou consulte análises existentes.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {analysisMethods.map((method, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="bg-card border border-border rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow flex flex-col items-center text-center"
            >
              <method.icon className="h-10 w-10 text-primary mb-3" />
              <h3 className="text-lg font-semibold text-foreground mb-2">{method.name}</h3>
              <p className="text-sm text-muted-foreground mb-4 flex-grow">{method.description}</p>
              <Button className="w-full mt-auto bg-primary hover:bg-primary/90 text-primary-foreground">
                {method.action}
              </Button>
            </motion.div>
          ))}
        </div>

        <DashboardCard title="Análises Recentes" className="mt-8">
           <p className="text-muted-foreground mb-4">
            Visualize e gerencie as análises de crédito em andamento ou concluídas.
          </p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-muted-foreground">
              <thead className="text-xs text-foreground uppercase bg-muted/50">
                <tr>
                  <th scope="col" className="px-6 py-3">Empresa</th>
                  <th scope="col" className="px-6 py-3">Data Solicitação</th>
                  <th scope="col" className="px-6 py-3">Score ActCred</th>
                  <th scope="col" className="px-6 py-3">Status</th>
                  <th scope="col" className="px-6 py-3">Ações</th>
                </tr>
              </thead>
              <tbody>
                {/* Placeholder para dados da tabela */}
                <tr className="bg-card border-b hover:bg-muted/30">
                  <td className="px-6 py-4 font-medium text-foreground whitespace-nowrap">Empresa Exemplo Alpha</td>
                  <td className="px-6 py-4">2025-05-20</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-green-500 font-semibold mr-2">850</span> 
                      <div className="w-16 h-2 bg-green-500 rounded-full"></div>
                    </div>
                  </td>
                  <td className="px-6 py-4"><span className="px-2 py-1 text-xs font-medium text-green-700 bg-green-100 rounded-full dark:bg-green-900 dark:text-green-300">Aprovado</span></td>
                  <td className="px-6 py-4"><Button variant="link" size="sm" className="text-primary">Detalhes</Button></td>
                </tr>
                <tr className="bg-card border-b hover:bg-muted/30">
                  <td className="px-6 py-4 font-medium text-foreground whitespace-nowrap">Comércio Beta Ltda.</td>
                  <td className="px-6 py-4">2025-05-18</td>
                   <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-yellow-500 font-semibold mr-2">620</span> 
                      <div className="w-12 h-2 bg-yellow-500 rounded-full"></div>
                    </div>
                  </td>
                  <td className="px-6 py-4"><span className="px-2 py-1 text-xs font-medium text-yellow-700 bg-yellow-100 rounded-full dark:bg-yellow-900 dark:text-yellow-300">Em Análise</span></td>
                  <td className="px-6 py-4"><Button variant="link" size="sm" className="text-primary">Detalhes</Button></td>
                </tr>
                 <tr className="bg-card hover:bg-muted/30">
                  <td className="px-6 py-4 font-medium text-foreground whitespace-nowrap">Indústria Delta S/A</td>
                  <td className="px-6 py-4">2025-05-15</td>
                   <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-red-500 font-semibold mr-2">450</span> 
                      <div className="w-8 h-2 bg-red-500 rounded-full"></div>
                    </div>
                  </td>
                  <td className="px-6 py-4"><span className="px-2 py-1 text-xs font-medium text-red-700 bg-red-100 rounded-full dark:bg-red-900 dark:text-red-300">Rejeitado</span></td>
                  <td className="px-6 py-4"><Button variant="link" size="sm" className="text-primary">Detalhes</Button></td>
                </tr>
              </tbody>
            </table>
          </div>
           <div className="mt-6 p-6 border border-dashed border-border rounded-lg text-center">
            <img  alt="Ícone de tabela de análises" class="mx-auto h-12 w-12 text-muted-foreground mb-3" src="https://images.unsplash.com/photo-1700052719512-12168945f61b" />
            <p className="text-md font-medium text-foreground">Mais funcionalidades em breve</p>
            <p className="text-xs text-muted-foreground">Busca avançada, filtros e ordenação serão adicionados.</p>
          </div>
        </DashboardCard>
      </DashboardCard>
    </motion.div>
  );
};

export default CreditAnalysisPage;