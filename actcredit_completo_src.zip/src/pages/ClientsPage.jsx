import React, { useState } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { 
  Users, 
  Search,
  Filter,
  UserPlus,
  Edit,
  Trash2,
  ChevronDown,
  MapPin,
  Building,
  Phone,
  Mail,
  FileText
} from 'lucide-react';

// Componentes
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const ClientsPage = () => {
  const { theme } = useTheme();
  const [searchTerm, setSearchTerm] = useState('');
  
  // Dados para os clientes
  const clients = [
    { 
      id: 1, 
      name: 'Tech Solutions Ltda', 
      segment: 'Tecnologia', 
      location: 'São Paulo, SP', 
      contact: 'João Silva', 
      phone: '(11) 98765-4321', 
      email: 'contato@techsolutions.com.br',
      status: 'Ativo'
    },
    { 
      id: 2, 
      name: 'Mercado Central S.A.', 
      segment: 'Varejo', 
      location: 'Belo Horizonte, MG', 
      contact: 'Maria Oliveira', 
      phone: '(31) 98765-4321', 
      email: 'contato@mercadocentral.com.br',
      status: 'Ativo'
    },
    { 
      id: 3, 
      name: 'Indústria Nacional S.A.', 
      segment: 'Indústria', 
      location: 'Curitiba, PR', 
      contact: 'Pedro Santos', 
      phone: '(41) 98765-4321', 
      email: 'contato@industrianacional.com.br',
      status: 'Ativo'
    },
    { 
      id: 4, 
      name: 'Agro Forte Ltda', 
      segment: 'Agronegócio', 
      location: 'Goiânia, GO', 
      contact: 'Ana Costa', 
      phone: '(62) 98765-4321', 
      email: 'contato@agroforte.com.br',
      status: 'Inativo'
    },
    { 
      id: 5, 
      name: 'Saúde Integral S.A.', 
      segment: 'Saúde', 
      location: 'Rio de Janeiro, RJ', 
      contact: 'Carlos Mendes', 
      phone: '(21) 98765-4321', 
      email: 'contato@saudeintegral.com.br',
      status: 'Ativo'
    },
    { 
      id: 6, 
      name: 'Serviços Gerais Ltda', 
      segment: 'Serviços', 
      location: 'Brasília, DF', 
      contact: 'Fernanda Lima', 
      phone: '(61) 98765-4321', 
      email: 'contato@servicosgerais.com.br',
      status: 'Ativo'
    }
  ];

  // Renderizar o badge de status com cor apropriada
  const renderStatusBadge = (status) => {
    let color = '';
    
    switch(status) {
      case 'Ativo':
        color = 'bg-green-500/20 text-green-500 border-green-500/50';
        break;
      case 'Inativo':
        color = 'bg-red-500/20 text-red-500 border-red-500/50';
        break;
      default:
        color = 'bg-gray-500/20 text-gray-500 border-gray-500/50';
    }
    
    return (
      <span className={`px-2 py-1 rounded text-xs border ${color}`}>
        {status}
      </span>
    );
  };

  return (
    <div className="p-6">
      {/* Cabeçalho */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Clientes</h1>
        <p className="text-gray-400 mt-1">
          Gerencie os clientes e visualize informações detalhadas.
        </p>
      </div>

      {/* Estatísticas de Clientes */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Total de Clientes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">87</div>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Clientes Ativos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">78</div>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Novos este mês</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
          </CardContent>
        </Card>
        
        <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Limite Total</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 4.2M</div>
          </CardContent>
        </Card>
      </div>

      {/* Barra de Ações e Pesquisa */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <Button className="bg-blue-600 hover:bg-blue-700">
          <UserPlus className="h-4 w-4 mr-2" />
          Novo Cliente
        </Button>
        
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input 
            className="pl-10 bg-[#0f2544] border-[#1e3a5f] text-white"
            placeholder="Buscar por nome, segmento ou localização..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <Button variant="outline" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
          <Filter className="h-4 w-4 mr-2" />
          Filtros
        </Button>
        
        <select className="bg-[#0f2544] border border-[#1e3a5f] rounded-md px-3 py-2 text-white">
          <option>Todos os Segmentos</option>
          <option>Tecnologia</option>
          <option>Varejo</option>
          <option>Indústria</option>
          <option>Agronegócio</option>
          <option>Saúde</option>
          <option>Serviços</option>
        </select>
      </div>

      {/* Tabela de Clientes */}
      <Card className="bg-[#0f2544] border-[#1e3a5f] text-white mb-8">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1e3a5f] text-left">
                  <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Nome ↓
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Segmento
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Localização
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Contato
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody>
                {clients.map((client) => (
                  <tr key={client.id} className="border-b border-[#1e3a5f] hover:bg-[#1e3a5f]/30">
                    <td className="px-6 py-4 whitespace-nowrap font-medium">
                      {client.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {client.segment}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1 text-gray-400" />
                        {client.location}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {client.contact}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {renderStatusBadge(client.status)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <Edit className="h-4 w-4 text-blue-500" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="px-6 py-3 text-sm text-gray-400 flex justify-between items-center">
            <span>Mostrando 6 de 87 clientes</span>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                Anterior
              </Button>
              <Button variant="outline" size="sm" className="border-[#1e3a5f] bg-[#1e3a5f] text-white">
                1
              </Button>
              <Button variant="outline" size="sm" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                2
              </Button>
              <Button variant="outline" size="sm" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                3
              </Button>
              <Button variant="outline" size="sm" className="border-[#1e3a5f] text-gray-400 hover:bg-[#1e3a5f] hover:text-white">
                Próximo
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detalhes do Cliente */}
      <Card className="bg-[#0f2544] border-[#1e3a5f] text-white">
        <CardHeader>
          <CardTitle>Detalhes do Cliente</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="col-span-1">
              <div className="bg-[#1e3a5f] rounded-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="bg-blue-600 rounded-full h-12 w-12 flex items-center justify-center mr-4">
                    <Building className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Tech Solutions Ltda</h3>
                    <p className="text-gray-400 text-sm">Tecnologia</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                    <span>São Paulo, SP</span>
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 mr-2 text-gray-400" />
                    <span>(11) 98765-4321</span>
                  </div>
                  <div className="flex items-center">
                    <Mail className="h-4 w-4 mr-2 text-gray-400" />
                    <span>contato@techsolutions.com.br</span>
                  </div>
                </div>
                
                <div className="mt-6 pt-4 border-t border-[#0a1629]">
                  <h4 className="font-medium mb-2">Contato Principal</h4>
                  <p>João Silva</p>
                  <p className="text-gray-400 text-sm">Diretor Financeiro</p>
                </div>
              </div>
            </div>
            
            <div className="col-span-2">
              <Tabs defaultValue="info">
                <TabsList className="bg-[#1e3a5f] border border-[#1e3a5f]">
                  <TabsTrigger value="info" className="data-[state=active]:bg-blue-600">Informações</TabsTrigger>
                  <TabsTrigger value="analysis" className="data-[state=active]:bg-blue-600">Análises</TabsTrigger>
                  <TabsTrigger value="docs" className="data-[state=active]:bg-blue-600">Documentos</TabsTrigger>
                </TabsList>
                
                <TabsContent value="info" className="mt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-sm font-medium text-gray-400 mb-1">CNPJ</h4>
                      <p>12.345.678/0001-90</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-400 mb-1">Data de Cadastro</h4>
                      <p>10/01/2023</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-400 mb-1">Faturamento Anual</h4>
                      <p>R$ 5.800.000,00</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-400 mb-1">Limite de Crédito</h4>
                      <p>R$ 750.000,00</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-400 mb-1">Score Atual</h4>
                      <div className="flex items-center">
                        <span className="mr-2">92</span>
                        <div className="h-2 w-24 bg-gray-700 rounded-full">
                          <div className="h-2 rounded-full bg-green-500" style={{ width: '92%' }}></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-400 mb-1">Última Análise</h4>
                      <p>15/05/2025</p>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <h4 className="text-sm font-medium text-gray-400 mb-2">Observações</h4>
                    <p className="text-sm text-gray-300">
                      Cliente com excelente histórico de pagamentos e crescimento consistente nos últimos 3 anos.
                      Possui certificações ISO 9001 e ISO 27001, o que demonstra comprometimento com qualidade e segurança.
                    </p>
                  </div>
                </TabsContent>
                
                <TabsContent value="analysis" className="mt-4">
                  <div className="space-y-4">
                    <div className="bg-[#1e3a5f] p-4 rounded-lg">
                      <div className="flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Análise Completa</h4>
                          <p className="text-gray-400 text-sm">Majoração - 15/05/2025</p>
                        </div>
                        <div className="flex items-center">
                          <span className="mr-2">92</span>
                          <div className="h-2 w-12 bg-gray-700 rounded-full">
                            <div className="h-2 rounded-full bg-green-500" style={{ width: '92%' }}></div>
                          </div>
                        </div>
                        <span className="px-2 py-1 rounded text-xs border bg-green-500/20 text-green-500 border-green-500/50">
                          Aprovado
                        </span>
                      </div>
                    </div>
                    
                    <div className="bg-[#1e3a5f] p-4 rounded-lg">
                      <div className="flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Renovação de Limite</h4>
                          <p className="text-gray-400 text-sm">Majoração - 10/02/2025</p>
                        </div>
                        <div className="flex items-center">
                          <span className="mr-2">88</span>
                          <div className="h-2 w-12 bg-gray-700 rounded-full">
                            <div className="h-2 rounded-full bg-green-500" style={{ width: '88%' }}></div>
                          </div>
                        </div>
                        <span className="px-2 py-1 rounded text-xs border bg-green-500/20 text-green-500 border-green-500/50">
                          Aprovado
                        </span>
                      </div>
                    </div>
                    
                    <div className="bg-[#1e3a5f] p-4 rounded-lg">
                      <div className="flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Análise Inicial</h4>
                          <p className="text-gray-400 text-sm">Prospecção - 10/01/2023</p>
                        </div>
                        <div className="flex items-center">
                          <span className="mr-2">85</span>
                          <div className="h-2 w-12 bg-gray-700 rounded-full">
                            <div className="h-2 rounded-full bg-green-500" style={{ width: '85%' }}></div>
                          </div>
                        </div>
                        <span className="px-2 py-1 rounded text-xs border bg-green-500/20 text-green-500 border-green-500/50">
                          Aprovado
                        </span>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="docs" className="mt-4">
                  <div className="space-y-4">
                    <div className="bg-[#1e3a5f] p-4 rounded-lg">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <FileText className="h-5 w-5 text-blue-500" />
                          <div className="ml-3">
                            <h4 className="font-medium">Contrato.pdf</h4>
                            <p className="text-gray-400 text-sm">Adicionado em 10/01/2023</p>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" className="text-blue-500 hover:text-blue-400">
                          Visualizar
                        </Button>
                      </div>
                    </div>
                    
                    <div className="bg-[#1e3a5f] p-4 rounded-lg">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <FileText className="h-5 w-5 text-blue-500" />
                          <div className="ml-3">
                            <h4 className="font-medium">Balanço_2024.pdf</h4>
                            <p className="text-gray-400 text-sm">Adicionado em 15/03/2025</p>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" className="text-blue-500 hover:text-blue-400">
                          Visualizar
                        </Button>
                      </div>
                    </div>
                    
                    <div className="bg-[#1e3a5f] p-4 rounded-lg">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <FileText className="h-5 w-5 text-blue-500" />
                          <div className="ml-3">
                            <h4 className="font-medium">Certidões_Negativas.zip</h4>
                            <p className="text-gray-400 text-sm">Adicionado em 05/05/2025</p>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" className="text-blue-500 hover:text-blue-400">
                          Baixar
                        </Button>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        <UserPlus className="h-4 w-4 mr-2" />
                        Adicionar Documento
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ClientsPage;
