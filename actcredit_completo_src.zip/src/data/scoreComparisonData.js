// Dados para gráfico de comparação de score
const scoreComparisonData = [
  { name: 'Varejo', scoreActcredit: 75, scoreMercado: 65 },
  { name: 'Serviços', scoreActcredit: 72, scoreMercado: 62 },
  { name: 'Indústria', scoreActcredit: 68, scoreMercado: 58 },
  { name: 'Agronegócio', scoreActcredit: 70, scoreMercado: 60 },
  { name: 'Tecnologia', scoreActcredit: 82, scoreMercado: 72 },
  { name: 'Saúde', scoreActcredit: 78, scoreMercado: 68 }
];
