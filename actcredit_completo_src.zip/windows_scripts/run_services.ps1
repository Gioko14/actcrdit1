# ActCredit Windows Services Runner
# This script starts all the required services for the ActCredit application

# Ensure script execution doesn't stop on first error
$ErrorActionPreference = "Continue"

# Function to display colored messages
function Write-ColoredMessage {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Message,
        
        [Parameter(Mandatory=$false)]
        [string]$Color = "White"
    )
    
    Write-Host "[$([DateTime]::Now.ToString('yyyy-MM-dd HH:mm:ss'))] $Message" -ForegroundColor $Color
}

# Function to check if a command exists
function Test-CommandExists {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Command
    )
    
    $exists = $null -ne (Get-Command $Command -ErrorAction SilentlyContinue)
    return $exists
}

# Function to start a process in a new window
function Start-ProcessInNewWindow {
    param (
        [Parameter(Mandatory=$true)]
        [string]$FilePath,
        
        [Parameter(Mandatory=$false)]
        [string]$ArgumentList = "",
        
        [Parameter(Mandatory=$false)]
        [string]$WorkingDirectory = $PWD.Path,
        
        [Parameter(Mandatory=$false)]
        [string]$WindowTitle = "ActCredit Service"
    )
    
    Start-Process powershell.exe -ArgumentList "-NoExit", "-Command", "& {Set-Location '$WorkingDirectory'; $FilePath $ArgumentList; Read-Host 'Press Enter to exit'}" -WindowStyle Normal
}

# Display welcome message
Write-ColoredMessage "Starting ActCredit Premium services..." "Cyan"

# Check Tesseract OCR
$tesseractPath = "C:\Program Files\Tesseract-OCR\tesseract.exe"
if (Test-Path $tesseractPath) {
    Write-ColoredMessage "Tesseract OCR found at $tesseractPath." "Green"
} else {
    Write-ColoredMessage "Tesseract OCR not found at the default location." "Yellow"
    Write-ColoredMessage "PDF extraction service may not work correctly." "Yellow"
    $continue = Read-Host "Do you want to continue without Tesseract OCR? (y/n)"
    if ($continue -ne "y") {
        exit 1
    }
}

# Set paths
$projectRoot = Join-Path $PSScriptRoot "..\..\actcredit"
$mlScoringDir = Join-Path $projectRoot "src\services\ml-scoring"
$pdfExtractorDir = Join-Path $projectRoot "src\services\pdf-extractor"
$rulesEngineDir = Join-Path $projectRoot "src\services\rules-engine"

# Start PDF Extractor service
Write-ColoredMessage "Starting PDF Extractor service..." "Cyan"
Set-Location $pdfExtractorDir
Start-ProcessInNewWindow -FilePath ".\venv\Scripts\python.exe" -ArgumentList "api.py" -WorkingDirectory $pdfExtractorDir -WindowTitle "ActCredit PDF Extractor"
Write-ColoredMessage "PDF Extractor service started on http://localhost:8000" "Green"

# Start ML Scoring service (assuming it has an API similar to PDF Extractor)
Write-ColoredMessage "Starting ML Scoring service..." "Cyan"
Set-Location $mlScoringDir
# Note: Replace credit_scoring.py with the actual API file if different
if (Test-Path "credit_scoring_api.py") {
    Start-ProcessInNewWindow -FilePath ".\venv\Scripts\python.exe" -ArgumentList "credit_scoring_api.py" -WorkingDirectory $mlScoringDir -WindowTitle "ActCredit ML Scoring"
    Write-ColoredMessage "ML Scoring service started" "Green"
} else {
    Write-ColoredMessage "ML Scoring API file not found. Service not started." "Yellow"
}

# Start Rules Engine service (if it has an API)
Write-ColoredMessage "Starting Rules Engine service..." "Cyan"
Set-Location $rulesEngineDir
if (Test-Path "api.py") {
    Start-ProcessInNewWindow -FilePath ".\venv\Scripts\python.exe" -ArgumentList "api.py" -WorkingDirectory $rulesEngineDir -WindowTitle "ActCredit Rules Engine"
    Write-ColoredMessage "Rules Engine service started" "Green"
} else {
    Write-ColoredMessage "Rules Engine API file not found. Service not started." "Yellow"
}

# Start Express.js backend server
Write-ColoredMessage "Starting Express.js backend server..." "Cyan"
Set-Location $projectRoot
Start-ProcessInNewWindow -FilePath "node" -ArgumentList "server.js" -WorkingDirectory $projectRoot -WindowTitle "ActCredit Express Server"
Write-ColoredMessage "Express.js server started on http://localhost:3000" "Green"

# Start React development server
Write-ColoredMessage "Starting React development server..." "Cyan"
Set-Location $projectRoot
Start-ProcessInNewWindow -FilePath "npm" -ArgumentList "run dev" -WorkingDirectory $projectRoot -WindowTitle "ActCredit React Dev Server"
Write-ColoredMessage "React development server started" "Green"

# All services started
Write-ColoredMessage "All ActCredit services have been started!" "Green"
Write-ColoredMessage "Access the application at http://localhost:5173" "Cyan"
Write-ColoredMessage "Express.js server is running at http://localhost:3000" "Cyan"
Write-ColoredMessage "PDF Extractor API is available at http://localhost:8000" "Cyan"
