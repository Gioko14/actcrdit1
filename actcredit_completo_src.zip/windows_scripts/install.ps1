# ActCredit Windows Installation Script
# This script installs all required dependencies for the ActCredit application

# Ensure script execution doesn't stop on first error
$ErrorActionPreference = "Continue"

# Function to display colored messages
function Write-ColoredMessage {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Message,
        
        [Parameter(Mandatory=$false)]
        [string]$Color = "White"
    )
    
    Write-Host "[$([DateTime]::Now.ToString('yyyy-MM-dd HH:mm:ss'))] $Message" -ForegroundColor $Color
}

# Function to check if a command exists
function Test-CommandExists {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Command
    )
    
    $exists = $null -ne (Get-Command $Command -ErrorAction SilentlyContinue)
    return $exists
}

# Display welcome message
Write-ColoredMessage "Starting installation of ActCredit Premium ML and advanced components..." "Cyan"
Write-ColoredMessage "This script will install all required dependencies for the ActCredit application." "Cyan"

# Check system requirements
Write-ColoredMessage "Checking system requirements..." "Cyan"

# Check Python
if (Test-CommandExists "python") {
    $pythonVersion = (python --version) -replace "Python "
    Write-ColoredMessage "Python $pythonVersion found." "Green"
} else {
    Write-ColoredMessage "Python not found. Please install Python 3.8 or higher." "Red"
    Write-ColoredMessage "Download from: https://www.python.org/downloads/windows/" "Yellow"
    exit 1
}

# Check pip
if (Test-CommandExists "pip") {
    $pipVersion = (pip --version) -split " ")[1]
    Write-ColoredMessage "pip $pipVersion found." "Green"
} else {
    Write-ColoredMessage "pip not found. Please install pip for Python 3." "Red"
    exit 1
}

# Check Node.js
if (Test-CommandExists "node") {
    $nodeVersion = (node --version)
    Write-ColoredMessage "Node.js $nodeVersion found." "Green"
} else {
    Write-ColoredMessage "Node.js not found. Please install Node.js 14 or higher." "Red"
    Write-ColoredMessage "Download from: https://nodejs.org/en/download/" "Yellow"
    exit 1
}

# Check npm
if (Test-CommandExists "npm") {
    $npmVersion = (npm --version)
    Write-ColoredMessage "npm $npmVersion found." "Green"
} else {
    Write-ColoredMessage "npm not found. Please install npm." "Red"
    exit 1
}

# Check Tesseract OCR
$tesseractPath = "C:\Program Files\Tesseract-OCR\tesseract.exe"
if (Test-Path $tesseractPath) {
    Write-ColoredMessage "Tesseract OCR found at $tesseractPath." "Green"
} else {
    Write-ColoredMessage "Tesseract OCR not found at the default location." "Yellow"
    Write-ColoredMessage "Please install Tesseract OCR from: https://github.com/UB-Mannheim/tesseract/wiki" "Yellow"
    Write-ColoredMessage "Make sure to install the Portuguese language pack during installation." "Yellow"
    $continue = Read-Host "Do you want to continue without Tesseract OCR? (y/n)"
    if ($continue -ne "y") {
        exit 1
    }
}

# Create Python virtual environment for ML Scoring
Write-ColoredMessage "Creating Python virtual environment for ML Scoring..." "Cyan"
$mlScoringDir = Join-Path $PSScriptRoot "..\..\actcredit\src\services\ml-scoring"
Set-Location $mlScoringDir

if (Test-Path "venv") {
    Write-ColoredMessage "Virtual environment already exists. Do you want to recreate it?" "Yellow"
    $recreate = Read-Host "This will remove all installed libraries. Continue? (y/n)"
    if ($recreate -eq "y") {
        Write-ColoredMessage "Removing existing virtual environment..." "Cyan"
        Remove-Item -Recurse -Force "venv"
        python -m venv venv
        Write-ColoredMessage "Virtual environment recreated successfully." "Green"
    } else {
        Write-ColoredMessage "Keeping existing virtual environment." "Cyan"
    }
} else {
    python -m venv venv
    Write-ColoredMessage "Virtual environment created successfully." "Green"
}

# Activate virtual environment and install dependencies
Write-ColoredMessage "Activating virtual environment and installing dependencies..." "Cyan"
& .\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt

# Install additional dependencies for MLOps
Write-ColoredMessage "Installing dependencies for MLOps..." "Cyan"
pip install mlflow dvc great-expectations

# Install dependencies for XAI
Write-ColoredMessage "Installing dependencies for Explainability (XAI)..." "Cyan"
pip install shap lime alibi interpret

# Install dependencies for Open Finance
Write-ColoredMessage "Installing dependencies for Open Finance..." "Cyan"
pip install requests-oauthlib cryptography pyjwt

# Create Python virtual environment for PDF Extractor
Write-ColoredMessage "Creating Python virtual environment for PDF Extractor..." "Cyan"
$pdfExtractorDir = Join-Path $PSScriptRoot "..\..\actcredit\src\services\pdf-extractor"
Set-Location $pdfExtractorDir

if (Test-Path "venv") {
    Write-ColoredMessage "Virtual environment already exists. Do you want to recreate it?" "Yellow"
    $recreate = Read-Host "This will remove all installed libraries. Continue? (y/n)"
    if ($recreate -eq "y") {
        Write-ColoredMessage "Removing existing virtual environment..." "Cyan"
        Remove-Item -Recurse -Force "venv"
        python -m venv venv
        Write-ColoredMessage "Virtual environment recreated successfully." "Green"
    } else {
        Write-ColoredMessage "Keeping existing virtual environment." "Cyan"
    }
} else {
    python -m venv venv
    Write-ColoredMessage "Virtual environment created successfully." "Green"
}

# Activate virtual environment and install dependencies
Write-ColoredMessage "Activating virtual environment and installing dependencies..." "Cyan"
& .\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt

# Create Python virtual environment for Rules Engine
Write-ColoredMessage "Creating Python virtual environment for Rules Engine..." "Cyan"
$rulesEngineDir = Join-Path $PSScriptRoot "..\..\actcredit\src\services\rules-engine"
Set-Location $rulesEngineDir

if (Test-Path "venv") {
    Write-ColoredMessage "Virtual environment already exists. Do you want to recreate it?" "Yellow"
    $recreate = Read-Host "This will remove all installed libraries. Continue? (y/n)"
    if ($recreate -eq "y") {
        Write-ColoredMessage "Removing existing virtual environment..." "Cyan"
        Remove-Item -Recurse -Force "venv"
        python -m venv venv
        Write-ColoredMessage "Virtual environment recreated successfully." "Green"
    } else {
        Write-ColoredMessage "Keeping existing virtual environment." "Cyan"
    }
} else {
    python -m venv venv
    Write-ColoredMessage "Virtual environment created successfully." "Green"
}

# Activate virtual environment and install dependencies
Write-ColoredMessage "Activating virtual environment and installing dependencies..." "Cyan"
& .\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt

# Install Node.js dependencies
Write-ColoredMessage "Installing Node.js dependencies..." "Cyan"
$projectRoot = Join-Path $PSScriptRoot "..\..\actcredit"
Set-Location $projectRoot
npm install

# Create data directories for ML Scoring
Write-ColoredMessage "Creating data directories..." "Cyan"
Set-Location $mlScoringDir
New-Item -ItemType Directory -Force -Path "data\raw"
New-Item -ItemType Directory -Force -Path "data\processed"
New-Item -ItemType Directory -Force -Path "data\external"
New-Item -ItemType Directory -Force -Path "data\interim"
New-Item -ItemType Directory -Force -Path "models\trained"
New-Item -ItemType Directory -Force -Path "models\deployed"
New-Item -ItemType Directory -Force -Path "models\archive"
Write-ColoredMessage "Data directories created successfully." "Green"

# Create directories for PDF Extractor
Set-Location $pdfExtractorDir
New-Item -ItemType Directory -Force -Path "uploads"
New-Item -ItemType Directory -Force -Path "temp"
Write-ColoredMessage "PDF Extractor directories created successfully." "Green"

# Verify installation
Write-ColoredMessage "Verifying installation..." "Cyan"
Set-Location $mlScoringDir
& .\venv\Scripts\Activate.ps1
$verificationResult = python -c "import numpy, pandas, sklearn; print('Import verification successful!')" 2>&1
if ($verificationResult -like "*Import verification successful!*") {
    Write-ColoredMessage "Verification successful!" "Green"
} else {
    Write-ColoredMessage "Verification failed. Check the log for details." "Red"
    Write-ColoredMessage $verificationResult "Red"
}

# Installation complete
Write-ColoredMessage "Installation completed successfully!" "Green"
Write-ColoredMessage "To start the ActCredit application, run the run_services.ps1 script." "Cyan"
