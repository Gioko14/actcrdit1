/**
 * Arquivo de configuração do backend Express com SQLite
 * Implementa endpoints para fornecer dados reais para o frontend ActCredit
 */

const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');

// Configuração do servidor
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Servir arquivos estáticos
app.use(express.static(path.join(__dirname, 'dist')));

// Inicializar banco de dados SQLite
const dbPath = path.join(__dirname, 'database.sqlite');
const db = new sqlite3.Database(dbPath);

// Criar tabelas se não existirem
db.serialize(() => {
  // Tabela de análises de crédito
  db.run(`
    CREATE TABLE IF NOT EXISTS credit_analyses (
      id TEXT PRIMARY KEY,
      client_id TEXT NOT NULL,
      client_name TEXT NOT NULL,
      amount REAL NOT NULL,
      status TEXT NOT NULL,
      score INTEGER,
      region TEXT,
      sector TEXT,
      analysis_type TEXT,
      created_at TEXT,
      updated_at TEXT
    )
  `);

  // Tabela de clientes
  db.run(`
    CREATE TABLE IF NOT EXISTS clients (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      document TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      region TEXT,
      sector TEXT,
      created_at TEXT
    )
  `);

  // Tabela de políticas de crédito
  db.run(`
    CREATE TABLE IF NOT EXISTS credit_policies (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      min_score INTEGER,
      max_amount REAL,
      active BOOLEAN,
      created_at TEXT,
      updated_at TEXT
    )
  `);

  // Tabela de usuários
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL,
      email TEXT NOT NULL,
      role TEXT NOT NULL,
      created_at TEXT
    )
  `);

  // Tabela de permissões
  db.run(`
    CREATE TABLE IF NOT EXISTS permissions (
      user_id TEXT NOT NULL,
      permission TEXT NOT NULL,
      PRIMARY KEY (user_id, permission)
    )
  `);

  // Inserir dados de exemplo se as tabelas estiverem vazias
  db.get("SELECT COUNT(*) as count FROM credit_analyses", (err, row) => {
    if (err) {
      console.error("Erro ao verificar dados:", err);
      return;
    }

    if (row.count === 0) {
      console.log("Inserindo dados de exemplo...");
      insertSampleData();
    }
  });
});

// Função para inserir dados de exemplo
function insertSampleData() {
  // Inserir clientes de exemplo
  const clients = [
    { id: 'client1', name: 'Empresa Alpha', document: '12345678901234', email: 'contato@alpha.com', phone: '11987654321', region: 'Sudeste', sector: 'Varejo', created_at: '2023-01-15T10:30:00Z' },
    { id: 'client2', name: 'Empresa Beta', document: '23456789012345', email: 'contato@beta.com', phone: '21987654321', region: 'Sul', sector: 'Serviços', created_at: '2023-02-20T14:45:00Z' },
    { id: 'client3', name: 'Empresa Gamma', document: '34567890123456', email: 'contato@gamma.com', phone: '31987654321', region: 'Nordeste', sector: 'Indústria', created_at: '2023-03-10T09:15:00Z' },
    { id: 'client4', name: 'Empresa Delta', document: '45678901234567', email: 'contato@delta.com', phone: '41987654321', region: 'Centro-Oeste', sector: 'Agronegócio', created_at: '2023-04-05T16:20:00Z' },
    { id: 'client5', name: 'Empresa Epsilon', document: '56789012345678', email: 'contato@epsilon.com', phone: '51987654321', region: 'Norte', sector: 'Tecnologia', created_at: '2023-05-12T11:10:00Z' }
  ];

  const clientStmt = db.prepare("INSERT INTO clients VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  clients.forEach(client => {
    clientStmt.run(client.id, client.name, client.document, client.email, client.phone, client.region, client.sector, client.created_at);
  });
  clientStmt.finalize();

  // Inserir análises de crédito de exemplo
  const analyses = [
    { id: 'analysis1', client_id: 'client1', client_name: 'Empresa Alpha', amount: 50000, status: 'approved', score: 85, region: 'Sudeste', sector: 'Varejo', analysis_type: 'Majoração', created_at: '2024-01-15T10:30:00Z', updated_at: '2024-01-16T14:20:00Z' },
    { id: 'analysis2', client_id: 'client2', client_name: 'Empresa Beta', amount: 30000, status: 'rejected', score: 60, region: 'Sul', sector: 'Serviços', analysis_type: 'Prospecção', created_at: '2024-02-10T09:45:00Z', updated_at: '2024-02-11T11:30:00Z' },
    { id: 'analysis3', client_id: 'client3', client_name: 'Empresa Gamma', amount: 75000, status: 'approved', score: 90, region: 'Nordeste', sector: 'Indústria', analysis_type: 'Reativação', created_at: '2024-03-05T14:20:00Z', updated_at: '2024-03-06T16:15:00Z' },
    { id: 'analysis4', client_id: 'client4', client_name: 'Empresa Delta', amount: 25000, status: 'pending', score: 70, region: 'Centro-Oeste', sector: 'Agronegócio', analysis_type: 'Revisão', created_at: '2024-04-12T11:10:00Z', updated_at: '2024-04-12T11:10:00Z' },
    { id: 'analysis5', client_id: 'client5', client_name: 'Empresa Epsilon', amount: 100000, status: 'approved', score: 95, region: 'Norte', sector: 'Tecnologia', analysis_type: 'Majoração', created_at: '2024-05-08T15:30:00Z', updated_at: '2024-05-09T10:45:00Z' },
    { id: 'analysis6', client_id: 'client1', client_name: 'Empresa Alpha', amount: 60000, status: 'approved', score: 82, region: 'Sudeste', sector: 'Varejo', analysis_type: 'Revisão', created_at: '2024-05-20T09:15:00Z', updated_at: '2024-05-21T14:30:00Z' },
    { id: 'analysis7', client_id: 'client2', client_name: 'Empresa Beta', amount: 40000, status: 'pending', score: 75, region: 'Sul', sector: 'Serviços', analysis_type: 'Majoração', created_at: '2024-05-25T16:40:00Z', updated_at: '2024-05-25T16:40:00Z' },
    { id: 'analysis8', client_id: 'client3', client_name: 'Empresa Gamma', amount: 80000, status: 'approved', score: 88, region: 'Nordeste', sector: 'Indústria', analysis_type: 'Prospecção', created_at: '2024-05-27T10:20:00Z', updated_at: '2024-05-28T09:10:00Z' }
  ];

  const analysisStmt = db.prepare("INSERT INTO credit_analyses VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
  analyses.forEach(analysis => {
    analysisStmt.run(
      analysis.id, 
      analysis.client_id, 
      analysis.client_name, 
      analysis.amount, 
      analysis.status, 
      analysis.score, 
      analysis.region, 
      analysis.sector, 
      analysis.analysis_type, 
      analysis.created_at, 
      analysis.updated_at
    );
  });
  analysisStmt.finalize();

  // Inserir políticas de crédito de exemplo
  const policies = [
    { id: 'policy1', name: 'Política Padrão', description: 'Política de crédito padrão para clientes regulares', min_score: 70, max_amount: 50000, active: true, created_at: '2023-01-01T00:00:00Z', updated_at: '2023-01-01T00:00:00Z' },
    { id: 'policy2', name: 'Política Premium', description: 'Política de crédito para clientes premium', min_score: 85, max_amount: 100000, active: true, created_at: '2023-01-01T00:00:00Z', updated_at: '2023-03-15T00:00:00Z' },
    { id: 'policy3', name: 'Política Iniciante', description: 'Política de crédito para novos clientes', min_score: 60, max_amount: 20000, active: true, created_at: '2023-01-01T00:00:00Z', updated_at: '2023-02-10T00:00:00Z' }
  ];

  const policyStmt = db.prepare("INSERT INTO credit_policies VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  policies.forEach(policy => {
    policyStmt.run(
      policy.id, 
      policy.name, 
      policy.description, 
      policy.min_score, 
      policy.max_amount, 
      policy.active ? 1 : 0, 
      policy.created_at, 
      policy.updated_at
    );
  });
  policyStmt.finalize();

  // Inserir usuários de exemplo
  const users = [
    { id: 'user1', username: 'admin', email: 'admin@actcredit.com', role: 'admin', created_at: '2023-01-01T00:00:00Z' },
    { id: 'user2', username: 'analista', email: 'analista@actcredit.com', role: 'analyst', created_at: '2023-01-02T00:00:00Z' },
    { id: 'user3', username: 'gerente', email: 'gerente@actcredit.com', role: 'manager', created_at: '2023-01-03T00:00:00Z' }
  ];

  const userStmt = db.prepare("INSERT INTO users VALUES (?, ?, ?, ?, ?)");
  users.forEach(user => {
    userStmt.run(user.id, user.username, user.email, user.role, user.created_at);
  });
  userStmt.finalize();

  // Inserir permissões de exemplo
  const permissions = [
    { user_id: 'user1', permission: 'admin:all' },
    { user_id: 'user1', permission: 'analyses:create' },
    { user_id: 'user1', permission: 'analyses:view' },
    { user_id: 'user1', permission: 'analyses:approve' },
    { user_id: 'user1', permission: 'policies:manage' },
    { user_id: 'user2', permission: 'analyses:create' },
    { user_id: 'user2', permission: 'analyses:view' },
    { user_id: 'user3', permission: 'analyses:create' },
    { user_id: 'user3', permission: 'analyses:view' },
    { user_id: 'user3', permission: 'analyses:approve' }
  ];

  const permissionStmt = db.prepare("INSERT INTO permissions VALUES (?, ?)");
  permissions.forEach(permission => {
    permissionStmt.run(permission.user_id, permission.permission);
  });
  permissionStmt.finalize();
}

// Endpoints da API

// Endpoint de status
app.get('/api/status', (req, res) => {
  res.json({
    success: true,
    status: 'online',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Endpoints para o dashboard

// KPIs do dashboard
app.get('/api/dashboard/kpi', (req, res) => {
  const { startDate, endDate } = req.query;
  
  let whereClause = '';
  const params = [];
  
  if (startDate && endDate) {
    whereClause = 'WHERE created_at >= ? AND created_at <= ?';
    params.push(startDate, endDate);
  } else if (startDate) {
    whereClause = 'WHERE created_at >= ?';
    params.push(startDate);
  } else if (endDate) {
    whereClause = 'WHERE created_at <= ?';
    params.push(endDate);
  }
  
  // Consultas para KPIs
  const queries = {
    totalClients: `SELECT COUNT(DISTINCT client_id) as count FROM credit_analyses ${whereClause}`,
    approvalRate: `SELECT 
                    ROUND((SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) * 100.0 / COUNT(*)), 1) as rate 
                   FROM credit_analyses ${whereClause}`,
    averageScore: `SELECT ROUND(AVG(score), 0) as average FROM credit_analyses ${whereClause}`,
    riskRate: `SELECT 
                ROUND((SUM(CASE WHEN score < 70 THEN 1 ELSE 0 END) * 100.0 / COUNT(*)), 1) as rate 
               FROM credit_analyses ${whereClause}`
  };
  
  // Executar consultas em paralelo
  const kpiPromises = Object.entries(queries).map(([key, query]) => {
    return new Promise((resolve, reject) => {
      db.get(query, params, (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve({ key, value: row });
        }
      });
    });
  });
  
  // Processar resultados
  Promise.all(kpiPromises)
    .then(results => {
      const kpiData = {};
      results.forEach(result => {
        kpiData[result.key] = result.value;
      });
      
      // Calcular tendências (comparação com período anterior)
      const trends = {
        clientsGrowth: Math.round((Math.random() * 20) - 5) / 10, // Simulação de tendência
        approvalRateTrend: Math.round((Math.random() * 10) - 3) / 10,
        scoreGrowth: Math.round((Math.random() * 10) - 2) / 10,
        riskRateTrend: Math.round((Math.random() * 10) - 7) / 10
      };
      
      res.json({
        success: true,
        data: {
          kpis: {
            totalClients: kpiData.totalClients.count,
            approvalRate: kpiData.approvalRate.rate,
            averageScore: kpiData.averageScore.average,
            riskRate: kpiData.riskRate.rate
          },
          trends
        }
      });
    })
    .catch(error => {
      console.error('Erro ao obter KPIs:', error);
      res.status(500).json({
        success: false,
        error: 'Erro ao processar KPIs'
      });
    });
});

// Tendências de aprovação
app.get('/api/dashboard/trends/approval', (req, res) => {
  const { startDate, endDate } = req.query;
  
  // Consulta para obter dados mensais
  const query = `
    SELECT 
      strftime('%Y-%m', created_at) as month,
      COUNT(*) as total,
      SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
      SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
    FROM credit_analyses
    GROUP BY month
    ORDER BY month
  `;
  
  db.all(query, [], (err, rows) => {
    if (err) {
      console.error('Erro ao obter tendências de aprovação:', err);
      res.status(500).json({
        success: false,
        error: 'Erro ao processar tendências de aprovação'
      });
      return;
    }
    
    // Formatar dados para o frontend
    const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    const formattedData = rows.map(row => {
      const [year, month] = row.month.split('-');
      return {
        month: months[parseInt(month) - 1],
        approvals: row.approved,
        rejections: row.rejected
      };
    });
    
    res.json({
      success: true,
      data: formattedData
    });
  });
});

// Distribuição por setor
app.get('/api/dashboard/distribution/sector', (req, res) => {
  const { startDate, endDate } = req.query;
  
  let whereClause = '';
  const params = [];
  
  if (startDate && endDate) {
    whereClause = 'WHERE created_at >= ? AND created_at <= ?';
    params.push(startDate, endDate);
  } else if (startDate) {
    whereClause = 'WHERE created_at >= ?';
    params.push(startDate);
  } else if (endDate) {
    whereClause = 'WHERE created_at <= ?';
    params.push(endDate);
  }
  
  const query = `
    SELECT 
      sector,
      COUNT(*) as count,
      SUM(amount) as total_amount
    FROM credit_analyses
    ${whereClause}
    GROUP BY sector
    ORDER BY count DESC
  `;
  
  db.all(query, params, (err, rows) => {
    if (err) {
      console.error('Erro ao obter distribuição por setor:', err);
      res.status(500).json({
        success: false,
        error: 'Erro ao processar distribuição por setor'
      });
      return;
    }
    
    res.json({
      success: true,
      data: rows
    });
  });
});

// Distribuição regional
app.get('/api/dashboard/distribution/regional', (req, res) => {
  const { startDate, endDate } = req.query;
  
  let whereClause = '';
  const params = [];
  
  if (startDate && endDate) {
    whereClause = 'WHERE created_at >= ? AND created_at <= ?';
    params.push(startDate, endDate);
  } else if (startDate) {
    whereClause = 'WHERE created_at >= ?';
    params.push(startDate);
  } else if (endDate) {
    whereClause = 'WHERE created_at <= ?';
    params.push(endDate);
  }
  
  const query = `
    SELECT 
      region,
      COUNT(*) as clients,
      ROUND((SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) * 100.0 / COUNT(*)), 1) as approval_rate,
      ROUND(AVG(score), 0) as average_score,
      SUM(amount) as total_amount
    FROM credit_analyses
    ${whereClause}
    GROUP BY region
    ORDER BY clients DESC
  `;
  
  db.all(query, params, (err, rows) => {
    if (err) {
      console.error('Erro ao obter distribuição regional:', err);
      res.status(500).json({
        success: false,
        error: 'Erro ao processar distribuição regional'
      });
      return;
    }
    
    res.json({
      success: true,
      data: rows
    });
  });
});

// Distribuição por tipo de análise
app.get('/api/dashboard/distribution/analysis-type', (req, res) => {
  const { startDate, endDate } = req.query;
  
  let whereClause = '';
  const params = [];
  
  if (startDate && endDate) {
    whereClause = 'WHERE created_at >= ? AND created_at <= ?';
    params.push(startDate, endDate);
  } else if (startDate) {
    whereClause = 'WHERE created_at >= ?';
    params.push(startDate);
  } else if (endDate) {
    whereClause = 'WHERE created_at <= ?';
    params.push(endDate);
  }
  
  const query = `
    SELECT 
      analysis_type,
      COUNT(*) as count,
      SUM(amount) as total_amount
    FROM credit_analyses
    ${whereClause}
    GROUP BY analysis_type
    ORDER BY count DESC
  `;
  
  db.all(query, params, (err, rows) => {
    if (err) {
      console.error('Erro ao obter distribuição por tipo de análise:', err);
      res.status(500).json({
        success: false,
        error: 'Erro ao processar distribuição por tipo de análise'
      });
      return;
    }
    
    res.json({
      success: true,
      data: rows
    });
  });
});

// Endpoints para regras de negócio

// Analisar dados de crédito
app.post('/api/rules/analyze', (req, res) => {
  const creditData = req.body;
  
  // Validar dados de entrada
  if (!creditData || !creditData.clientId || !creditData.amount) {
    res.status(400).json({
      success: false,
      error: 'Dados de crédito inválidos ou incompletos'
    });
    return;
  }
  
  // Buscar política de crédito aplicável
  const policyQuery = `
    SELECT * FROM credit_policies 
    WHERE active = 1 
    ORDER BY min_score ASC
    LIMIT 1
  `;
  
  db.get(policyQuery, [], (err, policy) => {
    if (err) {
      console.error('Erro ao buscar política de crédito:', err);
      res.status(500).json({
        success: false,
        error: 'Erro ao processar análise de crédito'
      });
      return;
    }
    
    // Buscar cliente
    const clientQuery = `
      SELECT * FROM clients 
      WHERE id = ?
    `;
    
    db.get(clientQuery, [creditData.clientId], (err, client) => {
      if (err || !client) {
        console.error('Erro ao buscar cliente:', err);
        res.status(404).json({
          success: false,
          error: 'Cliente não encontrado'
        });
        return;
      }
      
      // Calcular score (simulação)
      const score = Math.floor(Math.random() * 40) + 60; // Score entre 60 e 99
      
      // Determinar status com base no score e política
      let status = 'rejected';
      if (score >= (policy?.min_score || 70)) {
        status = creditData.amount <= (policy?.max_amount || 50000) ? 'approved' : 'pending';
      }
      
      // Criar análise de crédito
      const analysisId = `analysis_${Date.now()}`;
      const now = new Date().toISOString();
      
      const insertQuery = `
        INSERT INTO credit_analyses 
        (id, client_id, client_name, amount, status, score, region, sector, analysis_type, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      
      db.run(insertQuery, [
        analysisId,
        client.id,
        client.name,
        creditData.amount,
        status,
        score,
        client.region,
        client.sector,
        creditData.analysisType || 'Padrão',
        now,
        now
      ], function(err) {
        if (err) {
          console.error('Erro ao inserir análise de crédito:', err);
          res.status(500).json({
            success: false,
            error: 'Erro ao salvar análise de crédito'
          });
          return;
        }
        
        // Retornar resultado da análise
        res.json({
          success: true,
          analysisId,
          clientId: client.id,
          clientName: client.name,
          amount: creditData.amount,
          status,
          score,
          policyApplied: policy?.name || 'Política Padrão',
          createdAt: now
        });
      });
    });
  });
});

// Obter políticas de crédito
app.get('/api/rules/policies', (req, res) => {
  const query = `
    SELECT * FROM credit_policies
    ORDER BY min_score ASC
  `;
  
  db.all(query, [], (err, policies) => {
    if (err) {
      console.error('Erro ao buscar políticas de crédito:', err);
      res.status(500).json({
        success: false,
        error: 'Erro ao processar políticas de crédito'
      });
      return;
    }
    
    res.json({
      success: true,
      policies: policies.map(policy => ({
        ...policy,
        active: policy.active === 1
      }))
    });
  });
});

// Obter histórico de decisões
app.get('/api/rules/history', (req, res) => {
  const { startDate, endDate, status, clientId } = req.query;
  
  let whereClause = '';
  const params = [];
  
  const conditions = [];
  
  if (startDate) {
    conditions.push('created_at >= ?');
    params.push(startDate);
  }
  
  if (endDate) {
    conditions.push('created_at <= ?');
    params.push(endDate);
  }
  
  if (status) {
    conditions.push('status = ?');
    params.push(status);
  }
  
  if (clientId) {
    conditions.push('client_id = ?');
    params.push(clientId);
  }
  
  if (conditions.length > 0) {
    whereClause = 'WHERE ' + conditions.join(' AND ');
  }
  
  const query = `
    SELECT * FROM credit_analyses
    ${whereClause}
    ORDER BY created_at DESC
    LIMIT 100
  `;
  
  db.all(query, params, (err, analyses) => {
    if (err) {
      console.error('Erro ao buscar histórico de decisões:', err);
      res.status(500).json({
        success: false,
        error: 'Erro ao processar histórico de decisões'
      });
      return;
    }
    
    res.json({
      success: true,
      history: analyses
    });
  });
});

// Endpoints para ML-Scoring

// Calcular score de crédito
app.post('/api/ml-scoring/calculate', (req, res) => {
  const clientData = req.body;
  
  // Validar dados de entrada
  if (!clientData || !clientData.clientId) {
    res.status(400).json({
      success: false,
      error: 'Dados do cliente inválidos ou incompletos'
    });
    return;
  }
  
  // Buscar cliente
  const clientQuery = `
    SELECT * FROM clients 
    WHERE id = ?
  `;
  
  db.get(clientQuery, [clientData.clientId], (err, client) => {
    if (err || !client) {
      console.error('Erro ao buscar cliente:', err);
      res.status(404).json({
        success: false,
        error: 'Cliente não encontrado'
      });
      return;
    }
    
    // Calcular score (simulação)
    const score = Math.floor(Math.random() * 40) + 60; // Score entre 60 e 99
    
    // Determinar faixa de risco
    let riskBand = 'Alto';
    if (score >= 80) {
      riskBand = 'Baixo';
    } else if (score >= 70) {
      riskBand = 'Médio';
    }
    
    // Retornar resultado do scoring
    res.json({
      success: true,
      scoreId: `score_${Date.now()}`,
      clientId: client.id,
      clientName: client.name,
      score,
      riskBand,
      factors: [
        { name: 'Histórico de Pagamentos', impact: 'positive', weight: 0.35 },
        { name: 'Utilização de Crédito', impact: 'neutral', weight: 0.25 },
        { name: 'Tempo de Relacionamento', impact: 'positive', weight: 0.20 },
        { name: 'Consultas Recentes', impact: 'negative', weight: 0.10 },
        { name: 'Mix de Crédito', impact: 'neutral', weight: 0.10 }
      ],
      timestamp: new Date().toISOString()
    });
  });
});

// Rota para todas as outras requisições (SPA)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// Iniciar servidor
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor rodando na porta ${PORT}`);
  console.log(`Banco de dados SQLite em ${dbPath}`);
});
