# Documentação Técnica - ActCredit

## Visão Geral

A plataforma ActCredit é uma solução completa para gestão de crédito que integra múltiplos serviços e tecnologias, incluindo extratores de dados baseados em OCR (Reconhecimento Óptico de Caracteres). Este documento fornece informações técnicas detalhadas sobre a arquitetura, componentes, instalação e uso da plataforma.

## Arquitetura

A plataforma ActCredit é construída com uma arquitetura moderna baseada em:

- **Frontend**: React com Vite
- **Backend**: Express.js (Node.js)
- **Extratores de Dados**: Tesseract OCR e PaddleOCR (deep learning)
- **Integração**: Serviços RESTful para comunicação entre componentes

### Diagrama de Componentes

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  Cliente Web    │────▶│  Servidor       │────▶│  Serviços de    │
│  (React + Vite) │     │  (Express.js)   │     │  Extração       │
│                 │◀────│                 │◀────│                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                                                        │
                                                        ▼
                                               ┌─────────────────┐
                                               │                 │
                                               │  Tesseract OCR  │
                                               │  PaddleOCR      │
                                               │                 │
                                               └─────────────────┘
```

## Requisitos do Sistema

### Requisitos Mínimos

- **Sistema Operacional**: Windows 10/11 ou Linux (Ubuntu 20.04+)
- **Processador**: Quad-core 2.0 GHz
- **Memória**: 8GB RAM
- **Espaço em Disco**: 2GB disponíveis
- **Node.js**: v14.x ou superior
- **Python**: v3.7 ou superior

### Dependências Principais

- **Node.js**: Ambiente de execução JavaScript
- **Python**: Necessário para os extratores OCR
- **Tesseract OCR**: Engine OCR básica
- **PaddleOCR**: Engine OCR avançada baseada em deep learning
- **ImageMagick**: Processamento de imagens

## Instalação

### Windows

1. **Instalar Node.js**:
   - Baixe e instale a versão LTS do [site oficial](https://nodejs.org/)
   - Verifique a instalação: `node --version` e `npm --version`

2. **Instalar Python**:
   - Baixe e instale Python 3.x do [site oficial](https://www.python.org/)
   - Marque a opção "Add Python to PATH" durante a instalação
   - Verifique a instalação: `python --version`

3. **Instalar Tesseract OCR**:
   - Baixe o instalador do [UB Mannheim](https://github.com/UB-Mannheim/tesseract/wiki)
   - Instale com suporte ao idioma português
   - Adicione ao PATH do sistema: `C:\Program Files\Tesseract-OCR`
   - Verifique a instalação: `tesseract --version`

4. **Instalar PaddleOCR**:
   - Abra o prompt de comando como administrador
   - Execute: `pip install paddlepaddle paddleocr pymupdf`
   - Verifique a instalação: `python -c "from paddleocr import PaddleOCR; print('PaddleOCR instalado')"` 

5. **Instalar ImageMagick**:
   - Baixe e instale do [site oficial](https://imagemagick.org/script/download.php)
   - Verifique a instalação: `magick --version`

6. **Configurar a Plataforma ActCredit**:
   - Clone ou extraia o código-fonte para um diretório local
   - Navegue até o diretório da aplicação: `cd caminho/para/actcredit`
   - Instale as dependências: `npm install`
   - Inicie a aplicação: `npm run start:win`

### Linux (Ubuntu/Debian)

1. **Instalar Node.js**:
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

2. **Instalar Python e PIP**:
   ```bash
   sudo apt-get update
   sudo apt-get install -y python3 python3-pip
   ```

3. **Instalar Tesseract OCR**:
   ```bash
   sudo apt-get install -y tesseract-ocr tesseract-ocr-por
   ```

4. **Instalar PaddleOCR**:
   ```bash
   pip3 install paddlepaddle paddleocr pymupdf
   ```

5. **Instalar ImageMagick**:
   ```bash
   sudo apt-get install -y imagemagick
   ```

6. **Configurar a Plataforma ActCredit**:
   ```bash
   # Clone ou extraia o código-fonte
   cd caminho/para/actcredit
   npm install
   npm start
   ```

## Configuração

### Arquivo de Configuração Principal

O arquivo `config.js` na raiz do projeto contém as principais configurações da plataforma:

```javascript
module.exports = {
  // Configurações do servidor
  server: {
    port: 3000,
    host: '0.0.0.0'
  },
  
  // Configurações dos extratores
  extractors: {
    // Configurações do Tesseract OCR
    tesseract: {
      enabled: true,
      path: 'tesseract', // Comando ou caminho para o executável
      language: 'por'    // Idioma padrão
    },
    
    // Configurações do PaddleOCR
    paddleOCR: {
      enabled: true,
      pythonPath: 'python3', // Comando ou caminho para o Python
      language: 'por'        // Idioma padrão
    }
  },
  
  // Configurações de logging
  logging: {
    level: 'info',      // debug, info, warn, error, fatal
    logToFile: true,
    logDir: './logs'
  }
};
```

### Configuração para Windows

Para Windows, é recomendável ajustar as seguintes configurações:

```javascript
module.exports = {
  // ... outras configurações
  
  extractors: {
    tesseract: {
      path: 'C:\\Program Files\\Tesseract-OCR\\tesseract.exe',
      // ... outras configurações
    },
    paddleOCR: {
      pythonPath: 'python', // Ou caminho completo se não estiver no PATH
      // ... outras configurações
    }
  }
};
```

## Uso dos Extratores

### Tesseract OCR

O Tesseract OCR é uma solução de OCR rápida e eficiente para documentos simples:

```javascript
const tesseractService = require('./src/services/ocr/TesseractService');

// Extrair texto de uma imagem
async function extractTextFromImage() {
  try {
    const imagePath = '/caminho/para/imagem.png';
    const text = await tesseractService.extractTextFromImage(imagePath);
    console.log('Texto extraído:', text);
    
    // Extrair dados estruturados
    const patterns = {
      cpf: '\\b(\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2})\\b',
      data: '\\b(\\d{2}/\\d{2}/\\d{4})\\b'
    };
    
    const data = tesseractService.extractStructuredData(text, patterns);
    console.log('Dados estruturados:', data);
  } catch (error) {
    console.error('Erro ao extrair texto:', error);
  }
}
```

### PaddleOCR (Deep Learning)

O PaddleOCR oferece reconhecimento mais preciso para documentos complexos:

```javascript
const paddleOCRService = require('./src/services/ocr/PaddleOCRService');

// Extrair texto de uma imagem
async function extractTextWithDeepLearning() {
  try {
    const imagePath = '/caminho/para/imagem.png';
    const text = await paddleOCRService.extractTextFromImage(imagePath);
    console.log('Texto extraído com deep learning:', text);
    
    // Extrair dados estruturados
    const patterns = {
      cpf: '\\b(\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2})\\b',
      data: '\\b(\\d{2}/\\d{2}/\\d{4})\\b'
    };
    
    const data = paddleOCRService.extractStructuredData(text, patterns);
    console.log('Dados estruturados:', data);
  } catch (error) {
    console.error('Erro ao extrair texto com deep learning:', error);
  }
}
```

### Processamento de PDFs

Ambos os serviços suportam extração de texto de PDFs:

```javascript
// Com Tesseract
const textFromPDF = await tesseractService.extractTextFromPDF('/caminho/para/documento.pdf');

// Com PaddleOCR (mais preciso para documentos complexos)
const textFromPDF = await paddleOCRService.extractTextFromPDF('/caminho/para/documento.pdf');
```

## Tratamento de Erros

A plataforma utiliza um sistema centralizado de tratamento de erros:

```javascript
const ErrorHandler = require('./src/utils/ErrorHandler');
const Logger = require('./src/utils/Logger');

try {
  // Código que pode gerar erro
} catch (error) {
  // Registrar erro
  ErrorHandler.logError(error, 'NomeDoComponente', { contexto: 'adicional' });
  
  // Obter resposta de erro padronizada para APIs
  const errorResponse = ErrorHandler.getErrorResponse(error, 'NomeDoComponente');
  
  // Registrar no sistema de logging
  Logger.error('Descrição do erro', error, { componente: 'NomeDoComponente' });
}
```

## Logging e Monitoramento

O sistema de logging permite rastrear operações e erros:

```javascript
const Logger = require('./src/utils/Logger');

// Registrar informações
Logger.info('Operação iniciada', { usuario: 'id123', acao: 'extrair_dados' });

// Registrar avisos
Logger.warn('Recurso próximo do limite', { recurso: 'memoria', uso: '85%' });

// Registrar erros
Logger.error('Falha na operação', new Error('Mensagem de erro'), { contexto: 'adicional' });

// Monitorar operações
const opContext = Logger.startOperation('processamento_documento', { documentoId: '123' });
try {
  // Realizar operação
  const resultado = await processarDocumento();
  Logger.endOperation(opContext, resultado);
} catch (error) {
  Logger.endOperation(opContext, null, error);
}
```

## Compatibilidade com Windows

Para garantir compatibilidade com Windows, a plataforma utiliza:

```javascript
const PathUtils = require('./src/utils/PathUtils');

// Normalizar caminhos para o sistema operacional atual
const normalizedPath = PathUtils.normalize('/caminho/do/arquivo');

// Juntar segmentos de caminho de forma compatível
const filePath = PathUtils.join(diretorio, nomeArquivo);

// Verificar se estamos no Windows
if (PathUtils.isWindows()) {
  // Lógica específica para Windows
}
```

## Solução de Problemas

### Problemas Comuns

1. **Tesseract não encontrado**:
   - Verifique se o Tesseract está instalado: `tesseract --version`
   - Verifique se o caminho está correto no arquivo de configuração
   - No Windows, certifique-se de que o Tesseract está no PATH do sistema

2. **PaddleOCR não funciona**:
   - Verifique se o Python está instalado: `python --version`
   - Verifique se o PaddleOCR está instalado: `pip list | grep paddle`
   - Instale novamente se necessário: `pip install paddlepaddle paddleocr pymupdf`

3. **Erros de permissão**:
   - No Windows, execute como administrador
   - No Linux, verifique as permissões dos diretórios: `chmod -R 755 /caminho/para/actcredit`

4. **Servidor não inicia**:
   - Verifique se a porta está disponível: `netstat -ano | findstr :3000` (Windows) ou `netstat -ano | grep :3000` (Linux)
   - Verifique os logs em `./logs/actcredit.log`

### Logs de Diagnóstico

Os logs da aplicação são armazenados em:
- Windows: `C:\caminho\para\actcredit\logs\`
- Linux: `/caminho/para/actcredit/logs/`

## Desempenho e Otimização

### Comparação de Extratores

| Extrator    | Velocidade | Precisão | Uso de Memória | Melhor para                  |
|-------------|------------|----------|----------------|------------------------------|
| Tesseract   | Rápido     | Boa      | Baixo          | Documentos simples, texto limpo |
| PaddleOCR   | Lento      | Excelente| Alto           | Documentos complexos, baixa qualidade |

### Recomendações de Uso

- Use Tesseract para processamento em lote de documentos simples
- Use PaddleOCR para documentos complexos ou de baixa qualidade
- Para melhor desempenho, pré-processe as imagens:
  - Redimensione para resolução adequada (300 DPI recomendado)
  - Converta para escala de cinza
  - Aumente o contraste

## Segurança

- Todos os arquivos temporários são automaticamente removidos após o processamento
- Não são armazenados dados sensíveis em disco, exceto durante o processamento
- Recomenda-se implementar autenticação e autorização para acesso à API

## Referências

- [Documentação do Tesseract OCR](https://tesseract-ocr.github.io/)
- [Documentação do PaddleOCR](https://github.com/PaddlePaddle/PaddleOCR)
- [Documentação do Node.js](https://nodejs.org/en/docs/)
- [Documentação do Express.js](https://expressjs.com/)
- [Documentação do React](https://reactjs.org/docs/getting-started.html)
- [Documentação do Vite](https://vitejs.dev/guide/)

## Suporte

Para suporte técnico, entre em contato com a equipe de desenvolvimento:
- Email: suporte@actcredit.com
- Sistema de tickets: https://suporte.actcredit.com
