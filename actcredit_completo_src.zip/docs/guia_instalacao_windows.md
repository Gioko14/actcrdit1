# Guia de Instalação e Uso do ActCredit para Windows

## Requisitos do Sistema
- Windows 10 ou superior (64 bits)
- Mínimo de 4GB de RAM (8GB recomendado)
- 2GB de espaço livre em disco
- Conexão com a Internet (para instalação inicial)

## Instalação

### Método 1: Instalação Automática (Recomendado)
1. Extraia o arquivo `actcredit_completo_melhorado.zip` para uma pasta de sua escolha
2. Navegue até a pasta extraída e entre na pasta `actcredit`
3. Clique com o botão direito no arquivo `windows_scripts/install.bat` e selecione "Executar como administrador"
4. Siga as instruções na tela para completar a instalação
5. Após a instalação, execute o arquivo `windows_scripts/run_actcredit.bat` para iniciar o ActCredit

### Método 2: Instalação Manual
Se a instalação automática falhar, siga estes passos:

1. Instale o Node.js (versão LTS) de https://nodejs.org/
2. Instale o Python 3.9 ou superior de https://www.python.org/downloads/windows/
   - **IMPORTANTE**: Marque a opção "Add Python to PATH" durante a instalação
3. Instale o Tesseract OCR 5.0 de https://github.com/UB-Mannheim/tesseract/wiki
   - **IMPORTANTE**: Marque a opção para adicionar Tesseract ao PATH
   - Selecione o pacote de idioma Português (por) durante a instalação
4. Abra o Prompt de Comando como administrador
5. Navegue até a pasta do ActCredit extraída
6. Execute os seguintes comandos:
   ```
   npm install
   python -m pip install --upgrade pip
   python -m pip install pytesseract pillow numpy pandas opencv-python pdf2image
   ```
7. Execute `node server.js` para iniciar o ActCredit

## Uso do ActCredit

1. Após iniciar o ActCredit, o navegador abrirá automaticamente com o endereço http://localhost:3000
2. Na página inicial, você verá o dashboard com as estatísticas e opções disponíveis
3. Para processar um documento:
   - Clique em "Novo Processamento" no menu lateral
   - Arraste e solte o arquivo PDF ou clique para selecionar
   - Aguarde o processamento (o tempo varia conforme o tamanho e complexidade do documento)
   - Revise os dados extraídos e faça correções se necessário
   - Clique em "Salvar" para armazenar os resultados

## Recursos Avançados

### Processamento em Lote
Para processar múltiplos documentos de uma vez:
1. Clique em "Processamento em Lote" no menu lateral
2. Selecione múltiplos arquivos ou arraste e solte uma pasta
3. Configure as opções de processamento
4. Clique em "Iniciar Processamento"

### Dashboard Interativo
O dashboard interativo permite:
- Visualizar estatísticas de processamento
- Filtrar dados por período
- Exportar relatórios em diversos formatos
- Visualizar gráficos de desempenho

### Sistema de Aprendizado Contínuo
O ActCredit aprende com cada correção:
1. Ao corrigir dados extraídos incorretamente, o sistema registra a correção
2. Em processamentos futuros, o sistema aplica automaticamente o conhecimento adquirido
3. A precisão aumenta progressivamente com o uso

Para visualizar estatísticas de aprendizado:
1. Clique em "Configurações" no menu lateral
2. Selecione "Sistema de Aprendizado"
3. Visualize o histórico de melhorias e estatísticas

### Exportação e Importação de Conhecimento
Para compartilhar o conhecimento adquirido entre diferentes instalações:
1. Clique em "Configurações" > "Sistema de Aprendizado"
2. Clique em "Exportar Base de Conhecimento"
3. Na outra instalação, clique em "Importar Base de Conhecimento"

## Solução de Problemas

### O servidor não inicia
- Verifique se o Node.js está instalado corretamente
- Verifique se a porta 3000 não está sendo usada por outro programa
- Execute o servidor manualmente via prompt de comando para ver mensagens de erro

### Erros de extração de texto
- Verifique se o Tesseract OCR está instalado corretamente
- Verifique se o pacote de idioma português está instalado
- Tente reinstalar o Tesseract OCR

### Desempenho lento
- Verifique se seu computador atende aos requisitos mínimos
- Feche outros programas que consomem muitos recursos
- Para documentos muito grandes, considere o processamento em lote durante períodos de baixo uso

## Suporte

Para obter suporte adicional:
- Consulte a documentação completa na pasta `docs`
- Verifique os logs de erro na pasta `logs`
- Entre em contato com o suporte técnico pelo email suporte@actcredit.com
