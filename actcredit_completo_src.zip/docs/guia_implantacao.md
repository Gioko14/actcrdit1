# Guia de Implantação - ActCredit Extrator

## Preparação do Ambiente

### Requisitos de Sistema
- **Sistema Operacional**: Windows 10/11 ou Ubuntu 20.04+
- **Memória**: Mínimo 8GB RAM, recomendado 16GB
- **Espaço em Disco**: 5GB para instalação básica, 10GB+ para operação
- **Python**: Versão 3.8 ou superior

### Dependências Principais
- Node.js 14+
- Python 3.8+
- Tesseract OCR 5.0+
- PaddleOCR
- LayoutParser
- Bibliotecas de processamento de PDF

## Instalação em Windows

### 1. Instalação do Node.js
1. Baixe o instalador do [site oficial do Node.js](https://nodejs.org/)
2. Execute o instalador e siga as instruções
3. Verifique a instalação com `node --version` e `npm --version`

### 2. Instalação do Python e Dependências
1. Baixe o instalador do [Python](https://www.python.org/downloads/)
2. Durante a instalação, marque "Add Python to PATH"
3. Abra o PowerShell como administrador e execute:
   ```powershell
   pip install paddlepaddle paddleocr layoutparser spacy pytesseract pillow
   python -m spacy download pt_core_news_sm
   ```

### 3. Instalação do Tesseract OCR
1. Baixe o instalador do [Tesseract OCR](https://github.com/UB-Mannheim/tesseract/wiki)
2. Execute o instalador e selecione o idioma português
3. Adicione o diretório de instalação ao PATH do sistema

### 4. Configuração do ActCredit
1. Extraia o arquivo `actcredit_completo.tar.gz`
2. Navegue até o diretório extraído
3. Execute `npm install` para instalar as dependências
4. Execute `npm run build` para compilar o frontend

## Instalação em Linux

### 1. Instalação do Node.js
```bash
curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### 2. Instalação do Python e Dependências
```bash
sudo apt-get update
sudo apt-get install -y python3-pip python3-dev
pip3 install paddlepaddle paddleocr layoutparser spacy pytesseract pillow
python3 -m spacy download pt_core_news_sm
```

### 3. Instalação do Tesseract OCR
```bash
sudo apt-get install -y tesseract-ocr tesseract-ocr-por
```

### 4. Configuração do ActCredit
```bash
tar -xzf actcredit_completo.tar.gz
cd actcredit
npm install
npm run build
```

## Execução da Plataforma

### Iniciar o Servidor
```bash
node server.js
```

A plataforma estará disponível em `http://localhost:3000`

### Uso do Extrator
1. Acesse a interface web
2. Faça upload de documentos PDF
3. Selecione o tipo de extração desejada
4. Visualize e exporte os resultados

## Solução de Problemas

### Erros Comuns
1. **Erro de inicialização do PaddleOCR**:
   - Verifique se todas as dependências estão instaladas
   - Tente reinstalar o paddlepaddle e paddleocr

2. **Erro de acesso ao Tesseract**:
   - Verifique se o Tesseract está no PATH do sistema
   - Reinstale o Tesseract com suporte ao idioma português

3. **Falha na extração de tabelas**:
   - Verifique se o documento tem tabelas bem estruturadas
   - Tente ajustar as configurações de extração

4. **Segmentation Fault**:
   - Verifique a memória disponível
   - Reinicie o servidor
   - Considere processar documentos menores

## Suporte e Recursos Adicionais

- Documentação completa: `/docs/technical_documentation.md`
- Limitações e alternativas: `/docs/limitacoes_e_alternativas.md`
- Scripts de Windows: `/windows_scripts/`

Para suporte adicional, consulte a equipe de desenvolvimento.
